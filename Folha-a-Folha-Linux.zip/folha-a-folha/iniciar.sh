#!/bin/sh
# Liga o Folha a Folha (Linux). Use: ./iniciar.sh   ou   ./iniciar.sh --porta 9000
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "O Python 3 não está instalado. No Ubuntu/Mint: sudo apt install python3"
  exit 1
fi
# O Pillow é opcional: só serve para girar e recortar páginas escaneadas antes de gerar o PDF.
# No Ubuntu/Mint, o pip do sistema recusa instalar pacotes (PEP 668); o jeito certo é pelo apt.
if ! python3 -c 'import PIL' >/dev/null 2>&1; then
  echo "Aviso: para girar e recortar páginas escaneadas, instale o Pillow:  sudo apt install python3-pil"
fi
exec python3 servidor.py "$@"
