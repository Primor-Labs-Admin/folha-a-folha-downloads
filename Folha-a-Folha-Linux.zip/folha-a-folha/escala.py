"""Folha a Folha: muda o tamanho do que sai na folha (escala), sem perder a nitidez.

Cada página continua do mesmo tamanho. O conteúdo é desenhado maior ou menor a partir do centro
da página, e texto e desenhos continuam vetoriais (nada vira imagem).

O PDF original fica intacto: a cópia recebe, no fim, uma "atualização incremental" com as páginas
novas, que é o mesmo jeito que os leitores de PDF usam para salvar anotações. Só biblioteca padrão.

Não funciona com PDF protegido por senha ou danificado: nesses casos escalar() lança NaoDa e quem
chamou pode tentar outro caminho (desenhar as páginas como imagem).
"""
import re
import zlib

__all__ = ["escalar", "NaoDa"]


class NaoDa(Exception):
    """Este PDF não dá para mudar assim (protegido por senha ou danificado)."""


# ---------------------------------------------------------------- leitura dos objetos do PDF

_BRANCO = b" \t\r\n\x0c\x00"
_FIM_TOKEN = rb"(?![^ \t\r\n\x0c\x00()<>\[\]{}/%])"
_RE_BRANCO = re.compile(rb"(?:[ \t\r\n\x0c\x00]+|%[^\r\n]*)*")
_RE_NUM = re.compile(rb"[+-]?(?:\d+\.?\d*|\.\d+)" + _FIM_TOKEN)
_RE_INT = re.compile(rb"\d+" + _FIM_TOKEN)
_RE_REF = re.compile(rb"[ \t\r\n\x0c\x00]+(\d+)[ \t\r\n\x0c\x00]+R" + _FIM_TOKEN)
_RE_NOME = re.compile(rb"/[^ \t\r\n\x0c\x00()<>\[\]{}/%]*")
_RE_PALAVRA = re.compile(rb"[^ \t\r\n\x0c\x00()<>\[\]{}/%]+")
_RE_CAB = re.compile(rb"[ \t\r\n\x0c\x00]*(\d+)[ \t\r\n\x0c\x00]+(\d+)[ \t\r\n\x0c\x00]+obj" + _FIM_TOKEN)
_RE_HEX = re.compile(rb"#([0-9A-Fa-f]{2})")
_RE_SUBSECAO = re.compile(rb"(\d+)[ \t]+(\d+)")
_RE_ENTRADA = re.compile(rb"[ \t\r\n]*(\d{1,10})[ \t]+(\d{1,5})[ \t]+([nf])")


class Nome(str):
    """/Type vira Nome("Type")."""


class Cru(bytes):
    """Pedaço copiado como está: texto, número com casas, true, false, null."""


class Ref:
    __slots__ = ("num", "ger")

    def __init__(self, num, ger):
        self.num, self.ger = num, ger

    def __eq__(self, outro):
        return isinstance(outro, Ref) and outro.num == self.num and outro.ger == self.ger

    def __hash__(self):
        return hash((self.num, self.ger))


class Fluxo:
    """Objeto com stream: o dicionário e os bytes ainda comprimidos."""
    __slots__ = ("dic", "bruto")

    def __init__(self, dic, bruto):
        self.dic, self.bruto = dic, bruto


def _pular(d, i):
    return _RE_BRANCO.match(d, i).end()


def _texto(d, i):
    """(...) com parênteses equilibrados e barras invertidas; devolve o fim."""
    prof, j, n = 0, i, len(d)
    while j < n:
        c = d[j]
        if c == 0x5C:  # \
            j += 2
            continue
        if c == 0x28:
            prof += 1
        elif c == 0x29:
            prof -= 1
            if prof == 0:
                return j + 1
        j += 1
    raise NaoDa("texto sem fim")


def _ler(d, i, prof=0):
    """Lê um objeto direto a partir de i. Devolve (objeto, posição depois dele)."""
    if prof > 200:
        raise NaoDa("aninhado demais")
    i = _pular(d, i)
    if i >= len(d):
        raise NaoDa("fim inesperado")
    c = d[i:i + 1]
    if c == b"/":
        m = _RE_NOME.match(d, i)
        cru = _RE_HEX.sub(lambda x: bytes([int(x.group(1), 16)]), m.group()[1:])
        return Nome(cru.decode("latin-1")), m.end()
    if c == b"<":
        if d[i + 1:i + 2] == b"<":
            dic, j = {}, i + 2
            while True:
                j = _pular(d, j)
                if d[j:j + 2] == b">>":
                    return dic, j + 2
                if d[j:j + 1] != b"/":
                    raise NaoDa("dicionário estranho")
                chave, j = _ler(d, j, prof + 1)
                valor, j = _ler(d, j, prof + 1)
                dic[chave] = valor
        f = d.find(b">", i)
        if f < 0:
            raise NaoDa("texto hexadecimal sem fim")
        return Cru(d[i:f + 1]), f + 1
    if c == b"[":
        lst, j = [], i + 1
        while True:
            j = _pular(d, j)
            if d[j:j + 1] == b"]":
                return lst, j + 1
            if j >= len(d):
                raise NaoDa("lista sem fim")
            v, j = _ler(d, j, prof + 1)
            lst.append(v)
    if c == b"(":
        f = _texto(d, i)
        return Cru(d[i:f]), f
    m = _RE_INT.match(d, i)
    if m:
        r = _RE_REF.match(d, m.end())
        if r:
            return Ref(int(m.group()), int(r.group(1))), r.end()
        return int(m.group()), m.end()
    m = _RE_NUM.match(d, i)
    if m:
        return Cru(m.group()), m.end()
    m = _RE_PALAVRA.match(d, i)
    if m and m.group() in (b"true", b"false", b"null"):
        return Cru(m.group()), m.end()
    raise NaoDa("objeto desconhecido")


def _numero(v):
    if isinstance(v, bool):
        raise NaoDa("número estranho")
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, Cru):
        try:
            return float(bytes(v))
        except ValueError:
            pass
    raise NaoDa("número estranho")


def _fmt(x):
    t = f"{x:.4f}".rstrip("0").rstrip(".")
    return "0" if t in ("-0", "") else t


def _escrever_nome(nome):
    saida = bytearray(b"/")
    for b in nome.encode("latin-1", "replace"):
        if b < 0x21 or b > 0x7E or b in b"#()<>[]{}/%":
            saida += b"#%02X" % b
        else:
            saida.append(b)
    return bytes(saida)


def _escrever(o):
    if isinstance(o, Nome):
        return _escrever_nome(o)
    if isinstance(o, Ref):
        return b"%d %d R" % (o.num, o.ger)
    if isinstance(o, dict):
        return b"<<" + b"".join(_escrever_nome(k) + b" " + _escrever(v) + b" " for k, v in o.items()) + b">>"
    if isinstance(o, list):
        return b"[" + b" ".join(_escrever(v) for v in o) + b"]"
    if isinstance(o, Cru):
        return bytes(o)
    if isinstance(o, bool):
        return b"true" if o else b"false"
    if isinstance(o, int):
        return b"%d" % o
    if isinstance(o, float):
        return _fmt(o).encode()
    if o is None:
        return b"null"
    raise NaoDa("não sei escrever este objeto")


def _sem_previsao(dados, parms):
    """Desfaz o "Predictor" PNG (10 a 15) dos fluxos de referência cruzada."""
    if not isinstance(parms, dict):
        return dados
    pred = int(_numero(parms.get("Predictor", 1)))
    if pred < 10:
        if pred > 1:
            raise NaoDa("previsor TIFF")
        return dados
    cores = int(_numero(parms.get("Colors", 1)))
    bpc = int(_numero(parms.get("BitsPerComponent", 8)))
    colunas = int(_numero(parms.get("Columns", 1)))
    bpp = max(1, cores * bpc // 8)
    larg = (colunas * cores * bpc + 7) // 8
    saida, ant = bytearray(), bytearray(larg)
    for k in range(0, len(dados) - larg, larg + 1):
        tipo, linha = dados[k], bytearray(dados[k + 1:k + 1 + larg])
        for x in range(larg):
            a = linha[x - bpp] if x >= bpp else 0
            b = ant[x]
            c = ant[x - bpp] if x >= bpp else 0
            if tipo == 1:
                linha[x] = (linha[x] + a) & 255
            elif tipo == 2:
                linha[x] = (linha[x] + b) & 255
            elif tipo == 3:
                linha[x] = (linha[x] + (a + b) // 2) & 255
            elif tipo == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                linha[x] = (linha[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        saida += linha
        ant = linha
    return bytes(saida)


class _Leitor:
    def __init__(self, d):
        self.d = d
        self.entradas = {}   # número -> (1, posição, geração) | (2, fluxo, índice) | (0,)
        self.cache = {}
        self.fluxos = {}
        self.trailer = None
        self.ultimo_tipo = None
        self.startxref = None
        self._ler_xref()

    # --- tabela de referências cruzadas
    def _ler_xref(self):
        d = self.d
        p = d.rfind(b"startxref")
        m = re.match(rb"startxref[ \t\r\n\x0c\x00]+(\d+)", d[p:p + 40]) if p >= 0 else None
        if not m:
            raise NaoDa("sem startxref")
        pos = self.startxref = int(m.group(1))
        vistos = set()
        while pos is not None:
            if pos in vistos or pos >= len(d) or len(vistos) > 500:
                raise NaoDa("referências cruzadas em laço")
            vistos.add(pos)
            j = _pular(d, pos)
            if d.startswith(b"xref", j):
                trailer, tipo = self._tabela(j + 4), "tabela"
                if isinstance(trailer.get("XRefStm"), int):
                    self._fluxo_xref(trailer["XRefStm"])
            else:
                trailer, tipo = self._fluxo_xref(j), "fluxo"
            if self.trailer is None:
                self.trailer, self.ultimo_tipo = trailer, tipo
            prev = trailer.get("Prev")
            pos = int(_numero(prev)) if prev is not None else None
        if not isinstance(self.trailer.get("Root"), Ref):
            raise NaoDa("sem raiz")

    def _tabela(self, i):
        d = self.d
        while True:
            i = _pular(d, i)
            if d.startswith(b"trailer", i):
                trailer, _ = _ler(d, i + 7)
                if not isinstance(trailer, dict):
                    raise NaoDa("trailer estranho")
                return trailer
            m = _RE_SUBSECAO.match(d, i)
            if not m:
                raise NaoDa("tabela estranha")
            ini, qtd = int(m.group(1)), int(m.group(2))
            i = m.end()
            for k in range(qtd):
                e = _RE_ENTRADA.match(d, i)
                if not e:
                    raise NaoDa("linha da tabela estranha")
                i = e.end()
                num = ini + k
                if num not in self.entradas:
                    self.entradas[num] = (1, int(e.group(1)), int(e.group(2))) if e.group(3) == b"n" else (0,)

    def _fluxo_xref(self, pos):
        f = self._objeto_em(pos)
        if not isinstance(f, Fluxo):
            raise NaoDa("fluxo de referências estranho")
        dic = f.dic
        w = [int(_numero(x)) for x in dic.get("W", [])]
        if len(w) != 3:
            raise NaoDa("fluxo de referências sem W")
        tam = int(_numero(dic.get("Size", 0)))
        indice = [int(_numero(x)) for x in dic.get("Index", [0, tam])]
        dados = self._decodificar(f)
        passo, k = sum(w), 0
        for a in range(0, len(indice) - 1, 2):
            for num in range(indice[a], indice[a] + indice[a + 1]):
                if k + passo > len(dados):
                    break
                campos, q = [], k
                for largura in w:
                    campos.append(int.from_bytes(dados[q:q + largura], "big") if largura else None)
                    q += largura
                k += passo
                tipo = 1 if campos[0] is None else campos[0]
                if num in self.entradas:
                    continue
                if tipo == 0:
                    self.entradas[num] = (0,)
                elif tipo == 1:
                    self.entradas[num] = (1, campos[1], campos[2] or 0)
                elif tipo == 2:
                    self.entradas[num] = (2, campos[1], campos[2] or 0)
        return dic

    # --- objetos
    def _objeto_em(self, pos, num=None):
        d = self.d
        m = _RE_CAB.match(d, pos)
        if not m or (num is not None and int(m.group(1)) != num):
            raise NaoDa("objeto fora do lugar")
        obj, i = _ler(d, m.end())
        i = _pular(d, i)
        if isinstance(obj, dict) and d.startswith(b"stream", i):
            i += 6
            if d[i:i + 2] == b"\r\n":
                i += 2
            elif d[i:i + 1] in (b"\n", b"\r"):
                i += 1
            comp = obj.get("Length")
            n = None
            try:
                n = int(_numero(self.valor(comp))) if comp is not None else None
            except NaoDa:
                n = None
            if n is None or n < 0 or not re.match(rb"[ \t\r\n\x0c\x00]*endstream", d[i + n:i + n + 40]):
                fim = d.find(b"endstream", i)
                if fim < 0:
                    raise NaoDa("stream sem fim")
                n = fim - i
                while n > 0 and d[i + n - 1:i + n] in (b"\n", b"\r"):
                    n -= 1
            return Fluxo(obj, d[i:i + n])
        return obj

    def _decodificar(self, f):
        filtro = self.valor(f.dic.get("Filter"))
        parms = self.valor(f.dic.get("DecodeParms"))
        filtros = filtro if isinstance(filtro, list) else [filtro] if filtro is not None else []
        lparms = parms if isinstance(parms, list) else [parms] * max(1, len(filtros))
        dados = f.bruto
        for k, fl in enumerate(filtros):
            if fl not in ("FlateDecode", "Fl"):
                raise NaoDa(f"filtro {fl}")
            try:
                dados = zlib.decompressobj().decompress(dados)
            except zlib.error:
                raise NaoDa("fluxo danificado")
            dados = _sem_previsao(dados, self.valor(lparms[k]) if k < len(lparms) else None)
        return dados

    def _do_fluxo(self, num_fluxo, indice):
        if num_fluxo not in self.fluxos:
            f = self.objeto(num_fluxo)
            if not isinstance(f, Fluxo):
                raise NaoDa("fluxo de objetos estranho")
            dados = self._decodificar(f)
            n = int(_numero(f.dic.get("N", 0)))
            primeiro = int(_numero(f.dic.get("First", 0)))
            nums = re.findall(rb"\d+", dados[:primeiro])
            pares = [(int(nums[2 * k]), int(nums[2 * k + 1])) for k in range(min(n, len(nums) // 2))]
            self.fluxos[num_fluxo] = (dados, primeiro, pares)
        dados, primeiro, pares = self.fluxos[num_fluxo]
        if indice >= len(pares):
            raise NaoDa("objeto fora do fluxo")
        return _ler(dados, primeiro + pares[indice][1])[0]

    def objeto(self, num):
        if num in self.cache:
            return self.cache[num]
        e = self.entradas.get(num)
        if not e or e[0] == 0:
            obj = None
        elif e[0] == 1:
            obj = self._objeto_em(e[1], num)
        else:
            obj = self._do_fluxo(e[1], e[2])
        self.cache[num] = obj
        return obj

    def valor(self, v, voltas=0):
        while isinstance(v, Ref) and voltas < 20:
            v, voltas = self.objeto(v.num), voltas + 1
        return v

    def geracao(self, num):
        e = self.entradas.get(num)
        return e[2] if e and e[0] == 1 else 0

    # --- páginas
    def paginas(self):
        """[(ref da página, dicionário, caixa visível [x0, y0, x1, y1], giro 0/90/180/270)] na ordem do documento."""
        raiz = self.valor(self.trailer["Root"])
        if not isinstance(raiz, dict):
            raise NaoDa("raiz estranha")
        saida, vistos = [], set()

        def caixa(v):
            v = self.valor(v)
            if not isinstance(v, list) or len(v) != 4:
                return None
            x0, y0, x1, y1 = (_numero(self.valor(x)) for x in v)
            return [min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)]

        def andar(ref, herdado, prof):
            if prof > 60 or ref in vistos:
                raise NaoDa("árvore de páginas estranha")
            vistos.add(ref)
            no = self.objeto(ref.num)
            if not isinstance(no, dict):
                raise NaoDa("página estranha")
            h = dict(herdado)
            for k in ("MediaBox", "CropBox", "Rotate"):
                if k in no:
                    h[k] = no[k]
            kids = self.valor(no.get("Kids"))
            if no.get("Type") == "Pages" or (no.get("Type") != "Page" and isinstance(kids, list)):
                for k in kids or []:
                    if not isinstance(k, Ref):
                        raise NaoDa("página sem referência")
                    andar(k, h, prof + 1)
                return
            midia = caixa(h.get("MediaBox")) or [0.0, 0.0, 612.0, 792.0]
            corte = caixa(h.get("CropBox"))
            if corte:
                corte = [max(corte[0], midia[0]), max(corte[1], midia[1]), min(corte[2], midia[2]), min(corte[3], midia[3])]
                if corte[2] - corte[0] < 1 or corte[3] - corte[1] < 1:
                    corte = None
            try:
                giro = int(_numero(self.valor(h.get("Rotate", 0)))) % 360
            except NaoDa:
                giro = 0
            saida.append((ref, no, corte or midia, giro if giro in (0, 90, 180, 270) else 0))

        topo = raiz.get("Pages")
        if not isinstance(topo, Ref):
            raise NaoDa("sem páginas")
        andar(topo, {}, 0)
        if not saida:
            raise NaoDa("sem páginas")
        return saida


# ---------------------------------------------------------------- escala

def escalar(dados, fator, deslocamento_y=0):
    """Redimensiona o conteúdo a partir do centro e desloca-o verticalmente (em pontos PDF).

    `fator` 1.0 mantém o tamanho original. `deslocamento_y` positivo sobe o conteúdo na página
    como ela aparece (e sai na impressora); negativo desce. Em página girada (/Rotate 90, 180, 270),
    o deslocamento é convertido para as coordenadas internas, para "para baixo" continuar sendo
    para baixo na folha, como na prévia. Lança NaoDa se este PDF não der para mudar assim.
    """
    if not (0.05 <= fator <= 10):
        raise ValueError("fator fora do limite")
    if not isinstance(deslocamento_y, (int, float)) or not (-720 <= deslocamento_y <= 720):
        raise ValueError("deslocamento fora do limite")
    if b"%PDF" not in dados[:1024]:
        raise NaoDa("não é PDF")
    try:
        return _escalar(dados, fator, float(deslocamento_y))
    except NaoDa:
        raise
    except (ValueError, IndexError, KeyError, TypeError, AttributeError, RecursionError, OverflowError) as e:
        raise NaoDa(f"PDF estranho ({type(e).__name__})")


def _escalar(dados, fator, deslocamento_y=0.0):
    leitor = _Leitor(dados)
    if leitor.trailer.get("Encrypt") is not None:
        raise NaoDa("protegido por senha")
    paginas = leitor.paginas()

    saida = bytearray(dados)
    if not saida.endswith((b"\n", b"\r")):
        saida += b"\n"
    maior = max([n for n in leitor.entradas] + [0])
    proximo = [max(int(_numero(leitor.trailer.get("Size", 0))), maior + 1)]
    gravados = {}  # número -> (posição, geração)

    def novo_num():
        n = proximo[0]
        proximo[0] += 1
        return n

    def gravar(num, ger, corpo):
        gravados[num] = (len(saida), ger)
        saida.extend(b"%d %d obj\n" % (num, ger) + corpo + b"\nendobj\n")

    def gravar_fluxo(texto):
        num = novo_num()
        gravar(num, 0, b"<</Length %d>>\nstream\n" % len(texto) + texto + b"\nendstream")
        return Ref(num, 0)

    fim = gravar_fluxo(b"\nQ\n")
    inicios = {}
    s = fator
    for ref, pagina, (x0, y0, x1, y1), giro in paginas:
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        # "subir u" na página vista vira, nas coordenadas internas: 0° (0, u); 90° (-u, 0); 180° (0, -u); 270° (u, 0)
        u = deslocamento_y
        dx, dy = {0: (0.0, u), 90: (-u, 0.0), 180: (0.0, -u), 270: (u, 0.0)}[giro]
        tx, ty = cx * (1 - s) + dx, cy * (1 - s) + dy
        # recorta na área visível de antes: ao diminuir, o que ficava escondido fora da página continua escondido
        cm = (f"q {_fmt(s)} 0 0 {_fmt(s)} {_fmt(tx)} {_fmt(ty)} cm "
              f"{_fmt(x0)} {_fmt(y0)} {_fmt(x1 - x0)} {_fmt(y1 - y0)} re W n\n").encode()
        if cm not in inicios:
            inicios[cm] = gravar_fluxo(cm)

        conteudo = pagina.get("Contents")
        partes = []
        alvo = leitor.valor(conteudo) if isinstance(conteudo, Ref) else conteudo
        if isinstance(alvo, list):
            partes = [x for x in alvo if isinstance(x, Ref)]
        elif isinstance(conteudo, Ref) and isinstance(alvo, Fluxo):
            partes = [conteudo]
        nova = dict(pagina)
        nova["Contents"] = [inicios[cm]] + partes + [fim]

        # anotações impressas (campos de formulário preenchidos, carimbos): o retângulo acompanha a escala
        anots = leitor.valor(pagina.get("Annots"))
        if isinstance(anots, list):
            lista = []
            for a in anots:
                dic = leitor.valor(a)
                if isinstance(dic, dict) and isinstance(leitor.valor(dic.get("Rect")), list):
                    r = [_numero(leitor.valor(v)) for v in leitor.valor(dic["Rect"])][:4]
                    if len(r) == 4:
                        dic = dict(dic)
                        dic["Rect"] = [cx + (r[0] - cx) * s + dx,
                                       cy + (r[1] - cy) * s + dy,
                                       cx + (r[2] - cx) * s + dx,
                                       cy + (r[3] - cy) * s + dy]
                        if isinstance(a, Ref):
                            gravar(a.num, leitor.geracao(a.num), _escrever(dic))
                            lista.append(a)
                            continue
                lista.append(dic if not isinstance(a, Ref) else a)
            nova["Annots"] = lista
        gravar(ref.num, leitor.geracao(ref.num), _escrever(nova))

    _fechar(saida, leitor, gravados, novo_num)
    _conferir(bytes(saida), len(paginas))
    return bytes(saida)


def _fechar(saida, leitor, gravados, novo_num):
    """Escreve a tabela (ou o fluxo) de referências cruzadas da atualização e o fim do arquivo."""
    extra = {k: leitor.trailer[k] for k in ("Root", "Info", "ID") if k in leitor.trailer}
    if leitor.ultimo_tipo == "fluxo":
        num = novo_num()
        gravados[num] = (len(saida), 0)
        nums = sorted(gravados)
        corpo = b"".join(b"\x01" + gravados[k][0].to_bytes(4, "big") + min(gravados[k][1], 65535).to_bytes(2, "big")
                         for k in nums)
        dic = {Nome("Type"): Nome("XRef"), Nome("Size"): num + 1, Nome("W"): [1, 4, 2],
               Nome("Index"): [x for a, b in _faixas(nums) for x in (a, b)], Nome("Prev"): leitor.startxref,
               Nome("Length"): len(corpo)}
        dic.update({Nome(k): v for k, v in extra.items()})
        pos = len(saida)
        saida.extend(b"%d 0 obj\n" % num + _escrever(dic) + b"\nstream\n" + corpo + b"\nendstream\nendobj\n")
        saida.extend(b"startxref\n%d\n%%%%EOF\n" % pos)
        return
    nums = sorted(gravados)
    pos = len(saida)
    saida.extend(b"xref\n")
    for ini, qtd in _faixas(nums):
        saida.extend(b"%d %d\n" % (ini, qtd))
        for k in range(ini, ini + qtd):
            saida.extend(b"%010d %05d n\r\n" % (gravados[k][0], min(gravados[k][1], 65535)))
    dic = {Nome("Size"): max(nums) + 1, Nome("Prev"): leitor.startxref}
    dic.update({Nome(k): v for k, v in extra.items()})
    saida.extend(b"trailer\n" + _escrever(dic) + b"\nstartxref\n%d\n%%%%EOF\n" % pos)


def _faixas(nums):
    faixas = []
    for n in nums:
        if faixas and faixas[-1][0] + faixas[-1][1] == n:
            faixas[-1][1] += 1
        else:
            faixas.append([n, 1])
    return [tuple(f) for f in faixas]


def _conferir(dados, qtd):
    """Lê de novo o resultado: precisa abrir e ter as mesmas páginas, cada uma começando pela escala."""
    leitor = _Leitor(dados)
    paginas = leitor.paginas()
    if len(paginas) != qtd:
        raise NaoDa("a conferência não bateu")
    for _, pagina, _, _ in paginas:
        c = pagina.get("Contents")
        primeiro = leitor.valor(c[0]) if isinstance(c, list) and c else None
        if not isinstance(primeiro, Fluxo) or b" cm " not in primeiro.bruto:
            raise NaoDa("a conferência não bateu")


# ---------------------------------------------------------------- imposição na folha da impressora

def _mult(a, b):
    """Matriz PDF a seguida de b."""
    return (a[0] * b[0] + a[1] * b[2], a[0] * b[1] + a[1] * b[3],
            a[2] * b[0] + a[3] * b[2], a[2] * b[1] + a[3] * b[3],
            a[4] * b[0] + a[5] * b[2] + b[4], a[4] * b[1] + a[5] * b[3] + b[5])


def _aplicar(m, x, y):
    return m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]


def _para_vista(caixa, giro):
    """Matriz das coordenadas internas da página para a página como é vista (origem embaixo à esquerda)."""
    x0, y0, x1, y1 = caixa
    return {0: (1, 0, 0, 1, -x0, -y0), 90: (0, -1, 1, 0, -y0, x1),
            180: (-1, 0, 0, -1, x1, y1), 270: (0, 1, -1, 0, y1, -x0)}[giro]


def _tamanho_visto(caixa, giro):
    w, h = caixa[2] - caixa[0], caixa[3] - caixa[1]
    return (h, w) if giro in (90, 270) else (w, h)


def matriz_na_folha(tamanho_visto, colocacao):
    """Da página vista (origem embaixo à esquerda) para a folha: giro de 90° anti-horário (se houver),
    escala e posição do plano (imposicao.planejar)."""
    w, h = tamanho_visto
    m = (1, 0, 0, 1, 0, 0)
    if colocacao["giro"]:
        m = _mult(m, (0, 1, -1, 0, h, 0))
    s = colocacao["escala"]
    return _mult(m, (s, 0, 0, s, colocacao["x"], colocacao["y"]))


def medidas(dados):
    """Tamanho de cada página como é vista (largura, altura em pontos), já com o giro do próprio PDF."""
    try:
        return [_tamanho_visto(caixa, giro) for _, _, caixa, giro in _Leitor(dados).paginas()]
    except NaoDa:
        raise
    except (ValueError, IndexError, KeyError, TypeError, AttributeError, RecursionError, OverflowError) as e:
        raise NaoDa(f"PDF estranho ({type(e).__name__})")


def impor(dados, papel_pt, plano):
    """PDF com cada página do tamanho do papel da impressora e o conteúdo girado, redimensionado e posto
    onde o plano manda. Texto e desenhos continuam vetoriais. O sistema de impressão não precisa
    (e não deve) mexer em mais nada: imprima sem ajuste (print-scaling=none)."""
    if b"%PDF" not in dados[:1024]:
        raise NaoDa("não é PDF")
    try:
        return _impor(dados, papel_pt, plano)
    except NaoDa:
        raise
    except (ValueError, IndexError, KeyError, TypeError, AttributeError, RecursionError, OverflowError) as e:
        raise NaoDa(f"PDF estranho ({type(e).__name__})")


def _impor(dados, papel_pt, plano):
    leitor = _Leitor(dados)
    if leitor.trailer.get("Encrypt") is not None:
        raise NaoDa("protegido por senha")
    paginas = leitor.paginas()
    if len(plano) != len(paginas):
        raise NaoDa("o plano não bate com as páginas")
    W, H = papel_pt
    saida = bytearray(dados)
    if not saida.endswith((b"\n", b"\r")):
        saida += b"\n"
    maior = max([n for n in leitor.entradas] + [0])
    proximo = [max(int(_numero(leitor.trailer.get("Size", 0))), maior + 1)]
    gravados = {}

    def novo_num():
        n = proximo[0]
        proximo[0] += 1
        return n

    def gravar(num, ger, corpo):
        gravados[num] = (len(saida), ger)
        saida.extend(b"%d %d obj\n" % (num, ger) + corpo + b"\nendobj\n")

    def gravar_fluxo(texto):
        num = novo_num()
        gravar(num, 0, b"<</Length %d>>\nstream\n" % len(texto) + texto + b"\nendstream")
        return Ref(num, 0)

    fim = gravar_fluxo(b"\nQ\n")
    folha = [0, 0, W, H]
    for (ref, pagina, caixa, giro), colocacao in zip(paginas, plano):
        x0, y0, x1, y1 = caixa
        m = _mult(_para_vista(caixa, giro), matriz_na_folha(_tamanho_visto(caixa, giro), colocacao))
        # recorta na área visível de antes: o que ficava escondido fora da página continua escondido
        cm = (f"q {_fmt(m[0])} {_fmt(m[1])} {_fmt(m[2])} {_fmt(m[3])} {_fmt(m[4])} {_fmt(m[5])} cm "
              f"{_fmt(x0)} {_fmt(y0)} {_fmt(x1 - x0)} {_fmt(y1 - y0)} re W n\n").encode()
        inicio = gravar_fluxo(cm)
        conteudo = pagina.get("Contents")
        alvo = leitor.valor(conteudo) if isinstance(conteudo, Ref) else conteudo
        partes = []
        if isinstance(alvo, list):
            partes = [x for x in alvo if isinstance(x, Ref)]
        elif isinstance(conteudo, Ref) and isinstance(alvo, Fluxo):
            partes = [conteudo]
        nova = {k: v for k, v in pagina.items() if k not in ("TrimBox", "BleedBox", "ArtBox", "Rotate", "CropBox")}
        nova[Nome("MediaBox")] = folha
        nova[Nome("CropBox")] = folha
        nova[Nome("Rotate")] = 0
        nova[Nome("Contents")] = [inicio] + partes + [fim]
        # anotações impressas (campos preenchidos, carimbos): o retângulo vai junto
        anots = leitor.valor(pagina.get("Annots"))
        if isinstance(anots, list):
            lista = []
            for a in anots:
                dic = leitor.valor(a)
                ret = leitor.valor(dic.get("Rect")) if isinstance(dic, dict) else None
                if isinstance(ret, list) and len(ret) >= 4:
                    r = [_numero(leitor.valor(v)) for v in ret[:4]]
                    cantos = [_aplicar(m, r[0], r[1]), _aplicar(m, r[2], r[3]), _aplicar(m, r[0], r[3]), _aplicar(m, r[2], r[1])]
                    dic = dict(dic)
                    dic[Nome("Rect")] = [min(c[0] for c in cantos), min(c[1] for c in cantos),
                                         max(c[0] for c in cantos), max(c[1] for c in cantos)]
                    if isinstance(a, Ref):
                        gravar(a.num, leitor.geracao(a.num), _escrever(dic))
                        lista.append(a)
                        continue
                    lista.append(dic)
                    continue
                lista.append(a)
            nova[Nome("Annots")] = lista
        gravar(ref.num, leitor.geracao(ref.num), _escrever(nova))
    _fechar(saida, leitor, gravados, novo_num)
    _conferir(bytes(saida), len(paginas))
    return bytes(saida)
