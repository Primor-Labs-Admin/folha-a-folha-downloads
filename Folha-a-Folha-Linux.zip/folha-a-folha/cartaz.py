"""Folha a Folha: cartaz para a equipe entrar pelo celular (2.6.0).

Uma folha com o nome do lugar, o QR code do endereço, o endereço escrito e os passos para entrar.
O gestor imprime (sem contar na cota de ninguém) ou baixa em PDF, em Gestão > Resumo do mês.

pdf(endereco, nome_lugar, do_lugar, cadastro_aberto, papel_mm) devolve os bytes do PDF, do tamanho do papel.
O QR é o mesmo da tela (qr.py é o web/qr.js passado para Python). Texto e QR são vetoriais.
Só biblioteca padrão.
"""
import unicodedata

import qr

MM = 72 / 25.4

# larguras das letras (milésimos do tamanho), do espaço (32) ao til (126): Helvetica e Helvetica-Bold
_HELV = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
         556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015,
         667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944,
         667, 667, 611, 278, 278, 278, 469, 556, 333,
         556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722,
         500, 500, 500, 334, 260, 334, 584]
_BOLD = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278,
         556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611, 975,
         722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944,
         667, 667, 611, 333, 278, 333, 584, 556, 333,
         556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778,
         556, 556, 500, 389, 280, 389, 584]
_OUTRAS = {"“": (333, 500), "”": (333, 500), "‘": (222, 278), "’": (222, 278), "–": (556, 556),
           "—": (1000, 1000), "º": (365, 365), "ª": (370, 370), "·": (278, 278)}


def largura(texto, tam, negrito=False):
    """Largura do texto em pontos, na Helvetica (letra com acento conta como a letra sem acento)."""
    tabela = _BOLD if negrito else _HELV
    total = 0
    for c in str(texto):
        if c in _OUTRAS:
            total += _OUTRAS[c][1 if negrito else 0]
            continue
        k = ord(c)
        if not 32 <= k <= 126:
            base = unicodedata.normalize("NFD", c)[:1]
            k = ord(base) if base and 32 <= ord(base) <= 126 else ord("n")
        total += tabela[k - 32]
    return total * tam / 1000


def quebrar(texto, tam, max_larg, negrito=False):
    """Divide o texto em linhas que cabem em max_larg (palavra maior que a linha fica sozinha)."""
    linhas, atual = [], ""
    for palavra in str(texto).split():
        tentativa = f"{atual} {palavra}".strip()
        if atual and largura(tentativa, tam, negrito) > max_larg:
            linhas.append(atual)
            atual = palavra
        else:
            atual = tentativa
    if atual:
        linhas.append(atual)
    return linhas or [""]


def _texto_pdf(t):
    return "(" + str(t).encode("cp1252", "replace").decode("latin-1").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") + ")"


def _caber(texto, tam, minimo, max_larg, negrito):
    """O maior tamanho de letra, entre minimo e tam, em que o texto cabe numa linha."""
    while tam > minimo and largura(texto, tam, negrito) > max_larg:
        tam -= 0.5
    return tam


def pdf(endereco, nome_lugar, do_lugar="", cadastro_aberto=False, papel_mm=(210.0, 297.0)):
    """PDF de uma página, do tamanho do papel. Lança ValueError se o endereço não couber num QR code.
    O desenho é feito para A4 e encolhe ou cresce junto com o papel (A5, Carta, Ofício, A3)."""
    grade = qr.matriz(endereco)
    if not grade:
        raise ValueError("endereço grande demais para o QR code")
    W, H = (float(v) * MM for v in papel_mm)
    k = max(0.5, min(1.5, W / (210 * MM), H / (297 * MM)))  # proporção em relação ao A4
    margem = 18 * MM * k
    util = W - 2 * margem
    c = ["0 g 0 G"]

    def txt(x, y, t, tam, negrito=False):
        c.append(f"BT /{'F2' if negrito else 'F1'} {tam:.1f} Tf {x:.2f} {y:.2f} Td {_texto_pdf(t)} Tj ET")

    def centro(y, t, tam, negrito=False):
        txt((W - largura(t, tam, negrito)) / 2, y, t, tam, negrito)

    # ---- nome do lugar (até duas linhas) e chamada
    y = H - margem - 26 * k
    nome = " ".join(str(nome_lugar or "").split()) or "Folha a Folha"
    tam_nome = _caber(nome, 30 * k, 20 * k, util, True)
    for linha in quebrar(nome, tam_nome, util, True)[:2]:
        centro(y, linha, tam_nome, True)
        y -= tam_nome * 1.25
    y -= 4 * k
    centro(y, "Para imprimir, entre no Folha a Folha pelo celular", _caber("Para imprimir, entre no Folha a Folha pelo celular", 17 * k, 8, util, False))
    y -= 30 * k

    # ---- os passos e o rodapé são medidos antes, para o QR ocupar o que sobra
    tam_p, entre = 16 * k, 23 * k
    x_passo = margem + 6 * MM * k
    larg_passo = util - 12 * MM * k
    onde = f"no Wi-Fi {do_lugar}" if do_lugar else "no Wi-Fi do lugar"
    passos = [f"1. Ligue o celular {onde}.",
              "2. Aponte a câmera para o quadrado acima ou digite o endereço no navegador.",
              "3. Entre com o seu usuário e a sua senha."]
    if cadastro_aberto:
        passos.append("Ainda não tem cadastro? Toque em \u201cCriar meu cadastro\u201d e espere o gestor aprovar.")
    linhas_passos = [quebrar(p, tam_p, larg_passo - (largura("1. ", tam_p) if p[:2] in ("1.", "2.", "3.") else 0)) for p in passos]
    alt_passos = sum(len(l) for l in linhas_passos) * entre + (len(passos) - 1) * 7 * k
    tam_r, entre_r = 9.5 * k, 13 * k
    rodape = quebrar("No app Folha a Folha do Android, toque em \u201cLer QR code\u201d. O celular precisa estar na mesma rede "
                     "do computador do sistema.", tam_r, util)
    alt_rodape = len(rodape) * entre_r
    tam_end = _caber(endereco, 24 * k, 9 * k, util, True)
    alt_end = tam_end * 1.3 + 30 * k

    # ---- QR code: o maior quadrado que cabe, até 125 mm (no A4), com a borda branca de 4 módulos
    sobra = y - (margem + alt_rodape + 18 * k + alt_passos + 14 * k + alt_end)
    lado = max(40 * MM * k, min(125 * MM * k, util, sobra))
    n = len(grade)
    mod = lado / (n + 8)
    x0, topo = (W - lado) / 2 + 4 * mod, y - 4 * mod
    for yi, linha in enumerate(grade):
        xi = 0
        while xi < n:
            if not linha[xi]:
                xi += 1
                continue
            fim = xi
            while fim < n and linha[fim]:
                fim += 1
            c.append(f"{x0 + xi * mod:.3f} {topo - (yi + 1) * mod:.3f} {(fim - xi) * mod:.3f} {mod:.3f} re")
            xi = fim
    c.append("f")
    y -= lado

    # ---- endereço escrito
    y -= tam_end + 6 * k
    centro(y, endereco, tam_end, True)
    y -= 38 * k

    # ---- passos (as linhas seguintes de um passo numerado começam debaixo do texto, não do número)
    for passo, linhas in zip(passos, linhas_passos):
        recuo = largura("1. ", tam_p) if passo[:2] in ("1.", "2.", "3.") else 0
        for n_linha, linha in enumerate(linhas):
            txt(x_passo + (recuo if n_linha else 0), y, linha, tam_p)
            y -= entre
        y -= 7 * k

    # ---- rodapé
    yr = margem + (len(rodape) - 1) * entre_r
    c.append("0.35 g")
    for linha in rodape:
        centro(yr, linha, tam_r)
        yr -= entre_r
    c.append("0 g")

    corpo = "\n".join(c).encode("latin-1")
    fonte = "<< /Type /Font /Subtype /Type1 /BaseFont /%s /Encoding /WinAnsiEncoding >>"
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {W:.2f} {H:.2f}] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> "
         f"/Contents 4 0 R >>").encode(),
        b"<< /Length %d >>\nstream\n" % len(corpo) + corpo + b"\nendstream",
        (fonte % "Helvetica").encode(),
        (fonte % "Helvetica-Bold").encode(),
    ]
    saida = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    pos = []
    for k, o in enumerate(objs, 1):
        pos.append(len(saida))
        saida += b"%d 0 obj\n" % k + o + b"\nendobj\n"
    xref = len(saida)
    saida += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    for p in pos:
        saida += b"%010d 00000 n \n" % p
    saida += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, xref)
    return bytes(saida)
