#!/usr/bin/env python3
"""Folha a Folha — servidor.

Rode no computador que está ligado às impressoras (de uma escola, empresa ou outra organização):
    python servidor.py            (porta 8080)
    python servidor.py --porta 9000

A equipe acessa pelo navegador do celular ou do computador, na mesma rede.
Usa somente a biblioteca padrão do Python (3.9 ou mais novo).
"""
import argparse
import csv
import datetime as dt
import gzip
import hashlib
import hmac
import io
import json
import mimetypes
import os
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import sqlite3
import unicodedata
import sys
import threading
import time
import uuid
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import acompanhar
import cartaz
import relatorio_pdf
import contador
import impressao
import imposicao
import ipp
import licenca
import mdns
import raster
import scanner
from contador import ErroContador
from impressao import ErroImpressao

VERSAO = "2.7.0"
BASE = Path(__file__).resolve().parent
DADOS = Path(os.environ.get("CI_DADOS", BASE / "dados"))
ARQUIVOS = DADOS / "arquivos"
FILA = DADOS / "fila"
DIGITALIZACOES = DADOS / "digitalizacoes"
WEB = BASE / "web"
BANCO = DADOS / "controle.db"
LIMITE_UPLOAD = 60 * 1024 * 1024
LIMITE_IPP = 400 * 1024 * 1024
DIAS_SESSAO = 60

LOCK = threading.RLock()
LOCK_DIGITALIZACAO = threading.Lock()
DB = None
TENTATIVAS = {}  # ("u", usuário) / ("ip", endereço) / ("d", id) -> [falhas, bloqueado_até]


# ================================================================ utilidades

def agora():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def mes_atual():
    return dt.date.today().strftime("%Y-%m")


ITERACOES_SENHA = int(os.environ.get("CI_ITERACOES", 300_000))


def hash_senha(senha):
    """Resumo da senha (PBKDF2-SHA256 com sal). A senha em si nunca é guardada."""
    sal = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", senha.encode(), sal.encode(), ITERACOES_SENHA).hex()
    return f"p2${ITERACOES_SENHA}${sal}${h}"


def confere_senha(senha, guardado):
    """Confere a senha com o resumo guardado (também os PINs da versão 2.0 e anteriores)."""
    try:
        if guardado.startswith("p2$"):
            _, it, sal, h = guardado.split("$", 3)
            it = int(it)
        else:
            sal, h = guardado.split("$", 1)
            it = 120_000
    except (ValueError, AttributeError):
        hashlib.pbkdf2_hmac("sha256", b"x", b"y", ITERACOES_SENHA)  # mesmo tempo de quem existe
        return False
    calc = hashlib.pbkdf2_hmac("sha256", str(senha).encode(), sal.encode(), it).hex()
    return hmac.compare_digest(calc, h)


def senha_antiga(guardado):
    """O resumo ainda é de um PIN da versão 2.0 (antes de usuário e senha)."""
    return bool(guardado) and not guardado.startswith("p2$")



class Erro(Exception):
    def __init__(self, msg, status=400, codigo=None, dados=None):
        super().__init__(msg)
        self.msg, self.status, self.codigo, self.dados = msg, status, codigo, dados


INTEIRO_MAX = 2 ** 53  # acima disso o banco não guarda e nenhuma conta do sistema chega perto


def inteiro(v, nome="valor", minimo=None, maximo=None):
    try:
        if isinstance(v, (bool, list, dict, tuple, set)):
            raise ValueError
        if isinstance(v, float) and not v.is_integer():  # 1.5, infinito e "não é número"
            raise ValueError
        n = int(v)
        if abs(n) > INTEIRO_MAX:
            raise ValueError
    except (TypeError, ValueError, OverflowError):
        raise Erro(f"Informe um número válido para {nome}.")
    if minimo is not None and n < minimo:
        raise Erro(f"O {nome} precisa ser pelo menos {minimo}.")
    if maximo is not None and n > maximo:
        raise Erro(f"O {nome} pode ser no máximo {maximo}.")
    return n


def valor_reais(v, nome, minimo=0.0, maximo=None):
    """Aceita '0,37', '0.37', 'R$ 1.234,56'. Vazio = 0."""
    txt = str(v if v is not None else "").strip().replace("R$", "").replace(" ", "")
    if not txt:
        return 0.0
    if "," in txt:
        txt = txt.replace(".", "").replace(",", ".")
    try:
        n = float(txt)
    except ValueError:
        raise Erro(f"Informe um valor válido para {nome}, como 0,37.")
    if n < minimo or (maximo is not None and n > maximo):
        raise Erro(f"O {nome} precisa ficar entre {minimo:g} e {maximo:g}.".replace(".", ","))
    return round(n, 4)


SENHA_MINIMO = 8


def valida_senha(senha, login="", nome=""):
    senha = str(senha or "")
    if len(senha) < SENHA_MINIMO:
        raise Erro(f"A senha precisa ter pelo menos {SENHA_MINIMO} caracteres.", 400, "senha")
    if len(senha) > 128:
        raise Erro("A senha pode ter no máximo 128 caracteres.", 400, "senha")
    baixa = senha.lower()
    if len(set(senha)) < 3 or baixa in ("12345678", "123456789", "1234567890", "senha123", "password", "folhaafolha"):
        raise Erro("Essa senha é fácil demais de adivinhar. Misture palavras, números ou símbolos.", 400, "senha")
    if login and baixa == login.lower() or nome and baixa.replace(" ", "") == nome.lower().replace(" ", ""):
        raise Erro("A senha não pode ser o seu usuário nem o seu nome.", 400, "senha")
    return senha


def sem_acento(t):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", str(t or "")) if unicodedata.category(c) != "Mn")


def valida_login(login):
    login = sem_acento(str(login or "").strip().lower())
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{2,39}", login):
        raise Erro("O usuário deve ter de 3 a 40 letras, números, ponto, hífen ou sublinhado, sem espaços.", 400, "login")
    return login


def login_em_uso(login, menos_id=None):
    return DB.execute("SELECT 1 FROM usuarios WHERE login=? AND id<>?", (login, menos_id or 0)).fetchone() is not None


def gerar_login(nome, menos_id=None):
    """Sugere um usuário a partir do nome: "Ana Maria Silva" vira "ana.silva" (ou "ana.silva2", se já existe)."""
    partes = [p for p in re.sub(r"[^a-z0-9 ]", " ", sem_acento(nome).lower()).split()
              if p not in ("da", "de", "do", "das", "dos", "e")]
    base = ".".join(partes[:1] + partes[-1:] if len(partes) > 1 else partes) or "pessoa"
    base = (base if len(base) >= 3 else base + ".usuario")[:36]
    login, n = base, 1
    while login_em_uso(login, menos_id):
        n += 1
        login = f"{base}{n}"
    return login


def linhas(cur):
    return [dict(r) for r in cur.fetchall()]


def uma(cur):
    r = cur.fetchone()
    return dict(r) if r else None


# ================================================================ banco

ESQUEMA = """
CREATE TABLE IF NOT EXISTS usuarios(
  id INTEGER PRIMARY KEY, nome TEXT NOT NULL, pin_hash TEXT NOT NULL,
  papel TEXT NOT NULL DEFAULT 'prof', ativo INTEGER NOT NULL DEFAULT 1, criado_em TEXT);
CREATE TABLE IF NOT EXISTS impressoras(
  id INTEGER PRIMARY KEY, nome TEXT NOT NULL, sistema TEXT DEFAULT '',
  cota_total INTEGER DEFAULT 0, cor TEXT DEFAULT '#0E7C7B', ativa INTEGER DEFAULT 1, ordem INTEGER DEFAULT 0,
  custo_pagina REAL DEFAULT 0, base_mensal INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS cotas(
  usuario_id INTEGER, impressora_id INTEGER, mensal INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(usuario_id, impressora_id));
CREATE TABLE IF NOT EXISTS movimentos(
  id INTEGER PRIMARY KEY, mes TEXT, impressora_id INTEGER, de_id INTEGER, para_id INTEGER,
  paginas INTEGER, tipo TEXT, obs TEXT, criado_por INTEGER, criado_em TEXT);
CREATE TABLE IF NOT EXISTS trabalhos(
  id INTEGER PRIMARY KEY, usuario_id INTEGER, impressora_id INTEGER, mes TEXT, arquivo TEXT,
  paginas_doc INTEGER, paginas_sel INTEGER, copias INTEGER, total INTEGER, intervalo TEXT,
  frente_verso INTEGER, status TEXT, erro TEXT, criado_em TEXT, custo_unit REAL);
CREATE TABLE IF NOT EXISTS pedidos(
  id INTEGER PRIMARY KEY, mes TEXT, impressora_id INTEGER, solicitante_id INTEGER,
  destinatario_id INTEGER, paginas INTEGER, status TEXT, respondido_por INTEGER,
  criado_em TEXT, respondido_em TEXT);
CREATE TABLE IF NOT EXISTS mensagens(
  id INTEGER PRIMARY KEY, de_id INTEGER, para_id INTEGER, texto TEXT,
  tipo TEXT DEFAULT 'texto', ref_id INTEGER, criado_em TEXT);
CREATE TABLE IF NOT EXISTS bloqueios(
  usuario_id INTEGER NOT NULL, bloqueado_id INTEGER NOT NULL, criado_em TEXT,
  PRIMARY KEY(usuario_id, bloqueado_id));
CREATE TABLE IF NOT EXISTS denuncias(
  id INTEGER PRIMARY KEY, denunciante_id INTEGER, alvo_id INTEGER, mensagem_id INTEGER, conversa TEXT,
  motivo TEXT, trecho TEXT, criado_em TEXT, status TEXT DEFAULT 'aberta', resolvido_por INTEGER,
  resolvido_em TEXT, acao TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS pedidos_ocultos(
  usuario_id INTEGER NOT NULL, pedido_id INTEGER NOT NULL, criado_em TEXT,
  PRIMARY KEY(usuario_id, pedido_id));
CREATE TABLE IF NOT EXISTS leituras(
  usuario_id INTEGER, conversa TEXT, ultimo_id INTEGER, PRIMARY KEY(usuario_id, conversa));
CREATE TABLE IF NOT EXISTS sessoes(token TEXT PRIMARY KEY, usuario_id INTEGER, criado_em TEXT);
CREATE TABLE IF NOT EXISTS uploads(
  id TEXT PRIMARY KEY, usuario_id INTEGER, caminho TEXT, nome TEXT, tipo TEXT,
  paginas INTEGER, criado_em TEXT);
CREATE TABLE IF NOT EXISTS config(chave TEXT PRIMARY KEY, valor TEXT);
CREATE TABLE IF NOT EXISTS leituras_contador(
  id INTEGER PRIMARY KEY, impressora_id INTEGER, valor INTEGER, origem TEXT, modelo TEXT,
  criado_em TEXT, criado_por INTEGER);
CREATE INDEX IF NOT EXISTS ix_leit ON leituras_contador(impressora_id, criado_em);
CREATE TABLE IF NOT EXISTS retidas(
  id INTEGER PRIMARY KEY, criado_em TEXT, ip TEXT, usuario_so TEXT, nome TEXT, formato TEXT,
  caminho TEXT, tipo TEXT, paginas INTEGER, copias INTEGER, intervalo TEXT, frente_verso INTEGER,
  impressora_id INTEGER, status TEXT, mensagem TEXT, liberado_por INTEGER, trabalho_id INTEGER,
  atualizado_em TEXT);
CREATE INDEX IF NOT EXISTS ix_ret ON retidas(status, ip);
CREATE TABLE IF NOT EXISTS conferencias(
  id INTEGER PRIMARY KEY, usuario_id INTEGER, caminho TEXT, tipo TEXT, nome TEXT, paginas_doc INTEGER,
  impressora_id INTEGER, frente_verso INTEGER, finalidade TEXT, descricao TEXT, prova TEXT,
  prova_total INTEGER, resto TEXT, resto_total INTEGER, retida_id INTEGER, trabalho_prova INTEGER,
  status TEXT, criado_em TEXT, atualizado_em TEXT);
CREATE INDEX IF NOT EXISTS ix_conf ON conferencias(usuario_id, status);
CREATE TABLE IF NOT EXISTS setores(
  id INTEGER PRIMARY KEY, nome TEXT NOT NULL, pai_id INTEGER, cota INTEGER, remoto INTEGER DEFAULT 0,
  ativo INTEGER DEFAULT 1, politica TEXT DEFAULT '{}', ordem INTEGER DEFAULT 0, criado_em TEXT,
  adesao_hash TEXT DEFAULT '', adesao_ate TEXT DEFAULT '', token_hash TEXT DEFAULT '', ultimo_contato TEXT,
  aparelho TEXT DEFAULT '', resumo TEXT DEFAULT '{}', pacote_versao INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS excecoes(
  id INTEGER PRIMARY KEY, mes TEXT, tipo TEXT, setor_id INTEGER, usuario_id INTEGER, impressora_id INTEGER,
  paginas INTEGER, justificativa TEXT, decisao TEXT, por_id INTEGER, ref_id INTEGER, criado_em TEXT);
CREATE INDEX IF NOT EXISTS ix_exc ON excecoes(mes, setor_id);
CREATE TABLE IF NOT EXISTS aumentos(
  id INTEGER PRIMARY KEY, mes TEXT, usuario_id INTEGER, impressora_id INTEGER, paginas INTEGER,
  justificativa TEXT, status TEXT, aprovadas INTEGER DEFAULT 0, decisao TEXT DEFAULT '', respondido_por INTEGER,
  criado_em TEXT, respondido_em TEXT);
CREATE TABLE IF NOT EXISTS unidade_impressoras(
  setor_id INTEGER, ref TEXT, nome TEXT, ativa INTEGER DEFAULT 1, PRIMARY KEY(setor_id, ref));
CREATE TABLE IF NOT EXISTS cotas_remotas(
  usuario_id INTEGER, ref TEXT, mensal INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(usuario_id, ref));
CREATE INDEX IF NOT EXISTS ix_trab ON trabalhos(usuario_id, impressora_id, mes);
CREATE INDEX IF NOT EXISTS ix_mov ON movimentos(mes, impressora_id);
CREATE INDEX IF NOT EXISTS ix_msg ON mensagens(para_id, de_id);
"""

# Como perguntar para que é cada impressão: "livre" (a pessoa escreve o que é) ou "lista" (escolhe uma finalidade).
# Instalação nova começa em "livre"; quem já usava continua em "lista" (veja abrir_banco). CI_FINALIDADE_FORMA é dos testes.
FORMAS_FINALIDADE = ("livre", "lista")
FORMA_PADRAO = os.environ.get("CI_FINALIDADE_FORMA") if os.environ.get("CI_FINALIDADE_FORMA") in FORMAS_FINALIDADE else "livre"
# "escola" guarda o nome do lugar (escola, empresa ou organização); o nome da chave ficou da primeira versão
CONFIG_PADRAO = {"finalidade_forma": FORMA_PADRAO, "escola": "", "tipo_local": "", "aviso_pct": "80", "sumatra": "", "soffice": "",
                 "max_copias": "60", "empresa_nome": "", "empresa_cnpj": "",
                 "contato_privacidade": "",
                 "contato_escola": "", "reter_mensagens_meses": "12", "filtro_ligado": "1", "filtro_extras": "", "filtro_liberadas": "", "termos_url": "", "filas_por_impressora": "0",
                 "horas_fila": "4", "anunciar_rede": "1", "ipp_so_conectado": "1", "cadastro_aberto": "1", "ipp_uuid": "", "modo": "", "licenca": "",
                 "instalado_em": "", "site_empresa": "", "modo_trocas": "limite", "limite_doar_pct": "50",
                 "limite_receber_pct": "100", "reserva_auto": "20",
                 "finalidade": "todas", "descricao": "outro", "limite_pessoal": "10", "previa": "obrigatoria", "confirmar_impressora": "1",
                 "prova": "opcional", "prova_minimo": "20", "alerta_grande": "50", "bloqueio_minutos": "5",
                 "finalidades": "",
                 # 2.0: tipo de instalação, aumento de cota e cota negativa, central e unidades
                 "instalacao": "local", "aumento": "1", "negativo": "0", "negativo_desconta": "1",
                 "central_segredo": "", "central_publica": "", "central_url": "", "central_unidade": "",
                 "central_token": "", "central_chave": "", "central_pacote": "", "central_ultimo": "",
                 "central_erro": "", "central_nome": "", "central_intervalo": "5"}
MODOS_TROCA = ("livre", "limite", "reserva")
# Tipo de lugar: muda as palavras das telas e as finalidades sugeridas. As regras são as mesmas.
LOCAIS = {
    "escola": {"tipo": "escola", "nome": "Escola", "o": "a escola", "do": "da escola", "ao": "à escola",
               "no": "na escola", "rotulo": "Nome da escola", "exemplo": "Ex.: CEI Pequenos Passos",
               "padrao": "Nossa escola", "exemplo_desc": "Ex.: atividade de pintura do Maternal II",
               "rotulo_funcao": "Sua função ou turma (opcional)", "exemplo_funcao": "Ex.: Professora do Maternal II, manhã",
               "exemplo_aumento": "Ex.: provas do fim do semestre para 3 turmas",
               "exemplo_alem": "Ex.: bilhetes da reunião de amanhã"},
    "empresa": {"tipo": "empresa", "nome": "Empresa", "o": "a empresa", "do": "da empresa", "ao": "à empresa",
                "no": "na empresa", "rotulo": "Nome da empresa", "exemplo": "Ex.: Contabilidade Silva",
                "padrao": "Nossa empresa", "exemplo_desc": "Ex.: proposta para o cliente Souza",
                "rotulo_funcao": "Sua função ou setor (opcional)", "exemplo_funcao": "Ex.: Financeiro, período da tarde",
                "exemplo_aumento": "Ex.: relatórios do fechamento do mês",
                "exemplo_alem": "Ex.: contrato urgente pedido pelo cliente"},
    "outro": {"tipo": "outro", "nome": "Organização", "o": "a organização", "do": "da organização",
              "ao": "à organização", "no": "na organização", "rotulo": "Nome da organização",
              "exemplo": "Ex.: Associação Bem Viver", "padrao": "Nossa organização",
              "exemplo_desc": "Ex.: lista de presença da assembleia",
              "rotulo_funcao": "Sua função ou setor (opcional)", "exemplo_funcao": "Ex.: Secretaria, período da manhã",
              "exemplo_aumento": "Ex.: material da assembleia de sábado",
              "exemplo_alem": "Ex.: documento urgente para a reunião de hoje"},
}
# Para que é cada impressão: sugestões por tipo de lugar (a gestão pode trocar em Ajustes).
# Os ids ficam gravados em cada impressão; os das escolas são os mesmos das versões anteriores.
FINALIDADES_SUGERIDAS = {
    "escola": [("pedagogica", "Atividade pedagógica", "Para as turmas: atividades, registros, portfólio"),
               ("planejamento", "Planejamento e formação", "Planos, estudos, formação"),
               ("escola", "Documento da escola", "Bilhetes, comunicados, secretaria, reuniões")],
    "empresa": [("trabalho", "Trabalho e clientes", "Propostas, contratos, relatórios, materiais"),
                ("interno", "Documento interno", "Administrativo, financeiro, RH, reuniões"),
                ("formacao", "Treinamento e estudo", "Cursos, manuais, apresentações")],
    "outro": [("atividade", "Atividades do dia a dia", "O trabalho principal da organização"),
              ("interno", "Documento interno", "Administrativo, comunicados, reuniões"),
              ("formacao", "Formação e estudo", "Cursos, manuais, apresentações")],
}
# Sempre existem: "pessoal" tem limite próprio e "outro" pede descrição
FINALIDADES_FIXAS = [("pessoal", "Documento pessoal", "Uso particular"), ("outro", "Outro", "Escreva do que se trata")]
MAX_FINALIDADES = 10
MAX_TEXTOS_RELATORIO = 12  # no campo livre, quantos textos diferentes o relatório mostra antes de juntar o resto
MAX_LOTE = 20
MODOS_FINALIDADE = ("todas", "escolhidas", "desligada")
MODOS_DESCRICAO = ("outro", "sempre")
MODOS_PREVIA = ("obrigatoria", "opcional", "desligada")
MODOS_PROVA = ("desligada", "opcional", "acima")
# sobe quando o aviso de privacidade muda; quem confirmou uma versão antiga vê o aviso de novo
AVISO_VERSAO = 3
# guardados pelo próprio sistema, não pelo formulário de ajustes
CONFIG_INTERNA = ("ipp_uuid", "licenca", "instalado_em", "instalacao", "central_segredo", "central_publica",
                  "central_url", "central_unidade", "central_token", "central_chave", "central_pacote",
                  "central_ultimo", "central_erro", "central_nome")
# nunca saem para as telas
CONFIG_SECRETA = ("central_segredo", "central_token", "central_pacote")
MODOS = ("navegador", "impressora")

# Status de trabalho que contam na cota
CONTA = ("enviando", "na_fila", "impresso", "teste")  # na_fila: reservado até a impressora terminar


def abrir_banco():
    global DB
    DADOS.mkdir(parents=True, exist_ok=True)
    ARQUIVOS.mkdir(parents=True, exist_ok=True)
    FILA.mkdir(parents=True, exist_ok=True)
    DIGITALIZACOES.mkdir(parents=True, exist_ok=True)
    DB = sqlite3.connect(str(BANCO), check_same_thread=False)
    DB.row_factory = sqlite3.Row
    DB.execute("PRAGMA journal_mode=WAL")
    DB.executescript(ESQUEMA)
    migrar_colunas()
    migrar_logins()
    if not DB.execute("SELECT 1 FROM impressoras").fetchone():
        DB.execute("INSERT INTO impressoras(nome, cor, ordem) VALUES(?,?,1)",
                   ("Impressora principal", "#0E7C7B"))
        DB.execute("INSERT INTO impressoras(nome, cor, ordem) VALUES(?,?,2)",
                   ("Segunda impressora", "#6B4FBB"))
    existentes = {r[0] for r in DB.execute("SELECT chave FROM config")}
    for k, v in CONFIG_PADRAO.items():
        DB.execute("INSERT OR IGNORE INTO config(chave, valor) VALUES(?,?)", (k, v))
    # 2.6.0: quem já usava continua como estava (palavras de escola e lista de finalidades); só a instalação
    # nova começa com as palavras neutras e com o campo livre em "Para que é?"
    if DB.execute("SELECT 1 FROM usuarios").fetchone():
        DB.execute("UPDATE config SET valor='escola' WHERE chave='tipo_local' AND valor=''")
        if "finalidade_forma" not in existentes:
            DB.execute("UPDATE config SET valor='lista' WHERE chave='finalidade_forma'")
    # 2.4.9: o nome antigo da empresa (marca que saiu do app) não aparece mais; o que o gestor digitou fica
    DB.execute("UPDATE config SET valor='' WHERE chave='empresa_nome' AND valor LIKE '% - Sistemas para gestão escolar'")
    if "modo" not in existentes:
        # quem veio da 1.1 já usava a impressora; quem veio da 1.0 usava só o navegador; novo escolhe na configuração
        if "ipp_uuid" in existentes:
            modo = "impressora"
        elif DB.execute("SELECT 1 FROM usuarios").fetchone():
            modo = "navegador"
        else:
            modo = ""
        DB.execute("UPDATE config SET valor=? WHERE chave='modo'", (modo,))
    if not DB.execute("SELECT valor FROM config WHERE chave='instalado_em'").fetchone()[0]:
        DB.execute("UPDATE config SET valor=? WHERE chave='instalado_em'", (hoje().isoformat(),))
    if not DB.execute("SELECT valor FROM config WHERE chave='ipp_uuid'").fetchone()[0]:
        DB.execute("UPDATE config SET valor=? WHERE chave='ipp_uuid'", (str(uuid.uuid4()),))
    if not DB.execute("SELECT 1 FROM setores WHERE id=1").fetchone():
        DB.execute("INSERT INTO setores(id, nome, pai_id, criado_em) VALUES(1, 'Geral', NULL, ?)", (agora(),))
    DB.execute("UPDATE retidas SET status='aguardando' WHERE status='liberando'")
    DB.execute("UPDATE conferencias SET status='aguardando' WHERE status='imprimindo'")
    DB.execute("DELETE FROM conferencias WHERE status='preparando'")
    # trabalhos que ficaram "enviando" por queda do servidor viram erro
    DB.execute("UPDATE trabalhos SET status='erro', erro='Servidor reiniciado durante o envio' "
               "WHERE status='enviando'")
    DB.commit()


# Colunas acrescentadas depois da primeira versão (bancos antigos ganham as colunas sozinhos)
NOVAS_COLUNAS = {
    "impressoras": {"custo_pagina": "REAL DEFAULT 0", "base_mensal": "INTEGER DEFAULT 0",
                    "endereco_ip": "TEXT DEFAULT ''", "snmp_comunidade": "TEXT DEFAULT 'public'",
                    "pede_finalidade": "INTEGER DEFAULT 0", "conferir_contador": "INTEGER DEFAULT 1",
                    "contador_confiavel": "INTEGER DEFAULT 0",
                    # papel e área de impressão anotados pela gestão (vazio/NULL: os que a impressora informa)
                    "papel": "TEXT DEFAULT ''", "margem_topo": "REAL", "margem_baixo": "REAL",
                    "margem_esq": "REAL", "margem_dir": "REAL"},
    "trabalhos": {"escala": "TEXT DEFAULT ''", "custo_unit": "REAL", "finalidade": "TEXT DEFAULT ''", "descricao": "TEXT DEFAULT ''",
                  "etapa": "TEXT DEFAULT ''", "conferencia_id": "INTEGER", "excedente": "INTEGER DEFAULT 0",
                  "justificativa": "TEXT DEFAULT ''", "job_sistema": "TEXT DEFAULT ''", "pedido": "INTEGER",
                  "fila_etapa": "INTEGER DEFAULT 0", "fila_motivo": "TEXT DEFAULT ''", "contador_ini": "INTEGER",
                  "aviso_fila": "INTEGER DEFAULT 0", "fila_fim": "TEXT"},
    "movimentos": {"trabalho_id": "INTEGER"},
    "pedidos": {"reserva": "INTEGER DEFAULT 0", "motivo": "TEXT DEFAULT ''"},
    "sessoes": {"atividade_em": "TEXT", "bloqueada": "INTEGER DEFAULT 0", "ip": "TEXT DEFAULT ''", "visto_em": "TEXT"},
    "retidas": {"usuario_id": "INTEGER"},
    "uploads": {"imagem": "TEXT DEFAULT ''", "origens": "TEXT DEFAULT ''"},
    "usuarios": {"ciencia_privacidade": "TEXT", "anonimizado": "INTEGER DEFAULT 0",
                 "nomes_computador": "TEXT DEFAULT ''", "prefs": "TEXT DEFAULT '{}'",
                 "ciencia_versao": "INTEGER DEFAULT 0", "setor_id": "INTEGER DEFAULT 1",
                 "ref_central": "TEXT DEFAULT ''", "login": "TEXT DEFAULT ''", "trocar_senha": "INTEGER DEFAULT 0",
                 "aprovacao": "TEXT DEFAULT ''", "cadastro_obs": "TEXT DEFAULT ''",
                 "exclusao_pedida": "TEXT DEFAULT ''"},
    "conferencias": {"alem": "TEXT DEFAULT ''", "escala": "TEXT DEFAULT ''"},
}

# Custo de cada impressão: o preço gravado na hora; se não houver, o preço atual da impressora
CUSTO_SQL = "COALESCE(t.custo_unit, i.custo_pagina, 0)"


def migrar_colunas():
    for tabela, novas in NOVAS_COLUNAS.items():
        existentes = {r[1] for r in DB.execute(f"PRAGMA table_info({tabela})")}
        for coluna, tipo in novas.items():
            if coluna not in existentes:
                DB.execute(f"ALTER TABLE {tabela} ADD COLUMN {coluna} {tipo}")


def migrar_logins():
    """Versão 2.1: cada pessoa passa a entrar com usuário e senha. Quem veio de antes ganha um usuário
    tirado do nome e, no primeiro acesso (nome + PIN antigo), cria a senha."""
    for u in linhas(DB.execute("SELECT id, nome, pin_hash, ref_central, anonimizado FROM usuarios "
                               "WHERE login IS NULL OR login='' ORDER BY id")):
        login = gerar_login(u["nome"], u["id"]) if not u["anonimizado"] else f"removido{u['id']}"
        troca = 1 if senha_antiga(u["pin_hash"]) and not u["ref_central"] else 0
        DB.execute("UPDATE usuarios SET login=?, trocar_senha=MAX(COALESCE(trocar_senha,0), ?) WHERE id=?",
                   (login, troca, u["id"]))
    DB.execute("CREATE UNIQUE INDEX IF NOT EXISTS usuarios_login ON usuarios(login) WHERE login<>''")


def cfg(chave):
    r = DB.execute("SELECT valor FROM config WHERE chave=?", (chave,)).fetchone()
    return r[0] if r else CONFIG_PADRAO.get(chave, "")


# ---------------------------------------------------------------- tipo de lugar e finalidades

def tipo_local():
    t = cfg("tipo_local")
    return t if t in LOCAIS else "outro"  # sem tipo escolhido, as palavras são as neutras ("a organização")


def L(chave):
    """Palavra do tipo de lugar: L("do") = "da escola", "da empresa" ou "da organização"."""
    return LOCAIS[tipo_local()][chave]


def cap(txt):
    return txt[:1].upper() + txt[1:]


def nome_local():
    return cfg("escola") or L("padrao")


def info_local():
    return {**LOCAIS[tipo_local()], "nome_lugar": nome_local(), "definido": bool(cfg("tipo_local"))}


def aviso_troca():
    return f"As páginas são {L('do')}. Passar é ajuda entre colegas; não é permitido vender nem trocar por pagamento."


def finalidades_proprias():
    """As finalidades do lugar (sem "pessoal" e "outro"), inclusive as tiradas, que continuam nos relatórios."""
    txt = cfg("finalidades")
    if txt:
        try:
            lista = json.loads(txt)
            if isinstance(lista, list):
                return [{"id": str(f["id"]), "nome": str(f.get("nome") or f["id"]), "dica": str(f.get("dica") or ""),
                         "ativa": f.get("ativa", True) is not False}
                        for f in lista if isinstance(f, dict) and f.get("id")]
        except (ValueError, TypeError):
            pass
    return [{"id": i, "nome": n, "dica": d, "ativa": True} for i, n, d in FINALIDADES_SUGERIDAS[tipo_local()]]


def forma_finalidade():
    v = cfg("finalidade_forma")
    return v if v in FORMAS_FINALIDADE else "livre"


def arrumar_texto(t, maximo=120):
    """Primeira letra maiúscula e o resto minúsculo, sem espaços sobrando: o que é igual fica igual nos relatórios."""
    t = " ".join(str(t or "").split())[:maximo].strip()
    return t[:1].upper() + t[1:].lower() if t else ""


def rotulo_finalidade(t):
    """Como aparece a finalidade de uma impressão: o que a pessoa escreveu (campo livre) ou o nome da lista."""
    if t["finalidade"] == "livre":
        return t["descricao"] or "Não informada"
    return nome_finalidade(t["finalidade"])


def textos_recentes(uid, n=6):
    """Os últimos textos que a própria pessoa escreveu no campo livre, para tocar em vez de digitar de novo."""
    return [r[0] for r in DB.execute(
        "SELECT descricao FROM trabalhos WHERE usuario_id=? AND finalidade='livre' AND COALESCE(descricao,'')<>'' "
        "GROUP BY descricao ORDER BY MAX(id) DESC LIMIT ?", (uid, n))]


def finalidades_ativas():
    """[(id, nome, dica)] na ordem em que aparecem para quem imprime."""
    return [(f["id"], f["nome"], f["dica"]) for f in finalidades_proprias() if f["ativa"]] + FINALIDADES_FIXAS


def finalidades_conhecidas():
    """id -> nome de toda finalidade que pode estar gravada numa impressão (atuais, tiradas e sugestões)."""
    nomes = {}
    for lista in FINALIDADES_SUGERIDAS.values():
        for i, n, _ in lista:
            nomes.setdefault(i, n)
    for f in finalidades_proprias():
        nomes[f["id"]] = f["nome"]
    for i, n, _ in FINALIDADES_FIXAS:
        nomes[i] = n
    nomes["livre"] = "Texto livre"  # campo livre: o que vale é o texto, guardado na descrição
    return nomes


def nome_finalidade(f):
    return finalidades_conhecidas().get(f) or "Não informada"


def _id_finalidade(nome, usados):
    base = unicodedata.normalize("NFKD", nome).encode("ascii", "ignore").decode().lower()
    base = re.sub(r"[^a-z0-9]+", "_", base).strip("_")[:24] or "finalidade"
    novo, k = base, 2
    while novo in usados:
        novo, k = f"{base}_{k}", k + 1
    return novo


def preparar_finalidades(valor):
    """Confere a lista enviada pela gestão. Devolve o texto para guardar ("" = usar as sugestões).
    As que saírem da lista ficam guardadas como tiradas, para os relatórios antigos continuarem com o nome."""
    if valor in (None, "", "sugestoes"):
        return ""
    if not isinstance(valor, list):
        raise Erro("Lista de finalidades inválida.")
    atuais = finalidades_proprias()
    por_id = {f["id"]: f for f in atuais}
    por_nome = {f["nome"].strip().lower(): f for f in atuais}
    fixas = {i for i, _, _ in FINALIDADES_FIXAS} | {"nenhuma"}
    usados = set(fixas)
    for lista in FINALIDADES_SUGERIDAS.values():
        usados |= {i for i, _, _ in lista}
    usados |= set(por_id)
    nova, ids, nomes = [], set(), set()
    for item in valor:
        if not isinstance(item, dict):
            raise Erro("Lista de finalidades inválida.")
        nome = " ".join(str(item.get("nome") or "").split())[:40]
        dica = " ".join(str(item.get("dica") or "").split())[:80]
        if not nome:
            raise Erro("Dê um nome a cada finalidade.")
        if nome.lower() in nomes or nome.lower() in {n.lower() for _, n, _ in FINALIDADES_FIXAS}:
            raise Erro(f'A finalidade "{nome}" aparece duas vezes.')
        fid = str(item.get("id") or "")
        if fid not in por_id or fid in ids:
            antiga = por_nome.get(nome.lower())
            fid = antiga["id"] if antiga and antiga["id"] not in ids else ""
        if not fid:
            sugerida = next((i for lista in FINALIDADES_SUGERIDAS.values() for i, n, _ in lista
                             if n.lower() == nome.lower() and i not in ids), None)
            fid = sugerida or _id_finalidade(nome, usados | ids)
        ids.add(fid)
        nomes.add(nome.lower())
        nova.append({"id": fid, "nome": nome, "dica": dica, "ativa": True})
    if not nova:
        raise Erro("Deixe pelo menos uma finalidade, além de documento pessoal e outro.")
    if len(nova) > MAX_FINALIDADES:
        raise Erro(f"Use até {MAX_FINALIDADES} finalidades.")
    for f in atuais:
        if f["id"] not in ids:
            nova.append({**f, "ativa": False})
    return json.dumps(nova, ensure_ascii=False)


def impressoras(so_ativas=True):
    q = "SELECT * FROM impressoras" + (" WHERE ativa=1" if so_ativas else "") + " ORDER BY ordem, id"
    return linhas(DB.execute(q))


def saldo(uid, iid, mes):
    base = DB.execute("SELECT mensal FROM cotas WHERE usuario_id=? AND impressora_id=?",
                      (uid, iid)).fetchone()
    base = base[0] if base else 0
    recebido = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND "
                          "impressora_id=? AND para_id=?", (mes, iid, uid)).fetchone()[0]
    cedido = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND "
                        "impressora_id=? AND de_id=?", (mes, iid, uid)).fetchone()[0]
    usado = DB.execute(
        f"SELECT COALESCE(SUM(total),0) FROM trabalhos WHERE usuario_id=? AND impressora_id=? "
        f"AND mes=? AND status IN ({','.join('?' * len(CONTA))})", (uid, iid, mes, *CONTA)).fetchone()[0]
    gasto = DB.execute(
        f"SELECT COALESCE(SUM(t.total * {CUSTO_SQL}),0) FROM trabalhos t JOIN impressoras i ON i.id=t.impressora_id "
        f"WHERE t.usuario_id=? AND t.impressora_id=? AND t.mes=? AND t.status IN ({','.join('?' * len(CONTA))})",
        (uid, iid, mes, *CONTA)).fetchone()[0]
    cota = base + recebido - cedido
    return {"base": base, "recebido": recebido, "cedido": cedido, "cota": cota,
            "usado": usado, "restante": cota - usado, "gasto": round(gasto, 2)}


def saldos_usuario(uid, mes):
    aviso = int(cfg("aviso_pct") or 80)
    saida = []
    for imp in impressoras():
        s = saldo(uid, imp["id"], mes)
        pct = round(100 * s["usado"] / s["cota"]) if s["cota"] > 0 else (100 if s["usado"] else 0)
        estado = "ok"
        if s["cota"] <= 0 and s["usado"] == 0:
            estado = "sem_cota"
        elif s["restante"] <= 0:
            estado = "esgotado"
        elif pct >= aviso:
            estado = "alerta"
        saida.append({"impressora_id": imp["id"], "nome": imp["nome"], "cor": imp["cor"],
                      "teste": not imp["sistema"], "pct": pct, "estado": estado,
                      "custo_pagina": imp["custo_pagina"] or 0, "pede_finalidade": pede_finalidade(imp), **s})
    return saida


# ---------------------------------------------------------------- controle de impressão

def pede_finalidade(imp):
    modo = cfg("finalidade")
    if modo == "desligada":
        return False
    if modo == "escolhidas":
        return bool(imp["pede_finalidade"])
    return True


def limite_pessoal():
    """None = sem limite próprio; 0 = não permitido; n = páginas por pessoa por mês."""
    v = (cfg("limite_pessoal") or "").strip()
    return int(v) if v.isdigit() else None


def pessoal_usado(uid, mes):
    return DB.execute(f"SELECT COALESCE(SUM(total),0) FROM trabalhos WHERE usuario_id=? AND mes=? AND "
                      f"finalidade='pessoal' AND status IN ({','.join('?' * len(CONTA))})",
                      (uid, mes, *CONTA)).fetchone()[0]


def conferir_finalidade(uid, imp, finalidade, descricao, total, mes):
    """Confere a finalidade informada. Devolve (finalidade, descrição) para gravar."""
    finalidade = str(finalidade or "").strip()
    descricao = " ".join(str(descricao or "").split())[:200]
    livre = forma_finalidade() == "livre"
    if livre and finalidade != "pessoal":
        # campo livre: vale o que a pessoa escreveu. Quem manda uma finalidade da lista (tela antiga aberta
        # num aparelho) fica com o nome dela como texto
        da_lista = finalidade in finalidades_conhecidas() and finalidade not in ("outro", "livre")
        texto = arrumar_texto(descricao or (nome_finalidade(finalidade) if da_lista else ""))
        if not pede_finalidade(imp):
            return ("livre" if texto else ""), texto
        if len(texto) < 3:
            raise Erro("Escreva o que é esta impressão, em poucas palavras.", 400, "descricao")
        return "livre", texto
    if finalidade == "livre":  # ficou de quando o lugar usava o campo livre (uma prova esperando, por exemplo)
        finalidade = "outro" if descricao else ""
    if not pede_finalidade(imp):
        return (finalidade if finalidade in finalidades_conhecidas() else ""), descricao
    ativas = finalidades_ativas()
    if finalidade not in {i for i, _, _ in ativas}:
        nomes = [n[:1].lower() + n[1:] for _, n, _ in ativas]
        raise Erro(f"Diga para que é esta impressão: {', '.join(nomes[:-1])} ou {nomes[-1]}.", 400, "finalidade")
    if not descricao and (finalidade == "outro" or (cfg("descricao") == "sempre" and not livre)):
        raise Erro("Escreva em poucas palavras do que se trata.", 400, "descricao")
    if livre:
        descricao = arrumar_texto(descricao)
    if finalidade == "pessoal":
        lim = limite_pessoal()
        if lim == 0:
            raise Erro(f"{cap(L('o'))} não libera a impressão de documentos pessoais.", 409, "pessoal")
        if lim is not None:
            usado = pessoal_usado(uid, mes)
            if usado + total > lim:
                resta = max(lim - usado, 0)
                raise Erro(f"Documentos pessoais: até {lim} páginas por mês. Você já usou {usado} e esta impressão "
                           f"tem {total}." + (f" Ainda dá para {resta}." if resta else ""), 409, "pessoal")
    return finalidade, descricao


def prefs_usuario(u):
    try:
        p = json.loads(u["prefs"] or "{}")
    except (ValueError, TypeError, KeyError, IndexError):
        p = {}
    return {"prova_sempre": bool(p.get("prova_sempre")), "frente_verso": bool(p.get("frente_verso")),
            "previa": p.get("previa", True) is not False, "tamanho_original": bool(p.get("tamanho_original"))}


def info_controle(uid, mes):
    lim = limite_pessoal()
    return {"forma": forma_finalidade(), "recentes": textos_recentes(uid),
            "finalidade": cfg("finalidade"), "descricao": cfg("descricao"), "previa": cfg("previa"),
            "confirmar_impressora": cfg("confirmar_impressora") != "0",
            "prova": cfg("prova"), "prova_minimo": int(cfg("prova_minimo") or 0),
            "limite_pessoal": lim, "pessoal_usado": pessoal_usado(uid, mes),
            "finalidades": [{"id": i, "nome": n, "dica": d} for i, n, d in finalidades_ativas()]}


def prova_obrigatoria(total):
    return cfg("prova") == "acima" and total >= int(cfg("prova_minimo") or 0) and total > 1


def nome_usuario(uid):
    if uid is None:
        return None
    r = DB.execute("SELECT nome FROM usuarios WHERE id=?", (uid,)).fetchone()
    return r[0] if r else "?"


def area_impressora(imp):
    """Papel e área de impressão desta impressora (imposicao.area_da_impressora)."""
    margens = {k: imp.get("margem_" + k) for k in imposicao.LADOS}
    if any(v is None for v in margens.values()):
        margens = None
    return imposicao.area_da_impressora(imp.get("sistema") or "", imp.get("papel") or "", margens)


def imp_por_id(iid):
    try:
        iid = inteiro(iid, "impressora")
    except Erro:
        raise Erro("Impressora não encontrada.")
    imp = uma(DB.execute("SELECT * FROM impressoras WHERE id=?", (iid,)))
    if not imp or not imp["ativa"]:
        raise Erro("Impressora não encontrada.")
    return imp


def usuario_ativo(uid):
    u = uma(DB.execute("SELECT * FROM usuarios WHERE id=? AND ativo=1", (uid,)))
    if not u:
        raise Erro("Pessoa não encontrada.")
    return u


# ================================================================ rotas

ROTAS = {}


def rota(metodo, caminho, auth="user", trava=True):
    def deco(f):
        ROTAS[(metodo, caminho)] = (f, auth, trava)
        return f
    return deco


class Req:
    def __init__(self, handler, usuario, query, corpo):
        self.h, self.usuario, self.query, self.corpo = handler, usuario, query, corpo
        self.novos_cookies = []

    def q(self, k, padrao=None):
        v = self.query.get(k)
        return v[0] if v else padrao

    def b(self, k, padrao=None):
        if isinstance(self.corpo, dict):
            return self.corpo.get(k, padrao)
        return padrao

    @property
    def uid(self):
        return self.usuario["id"]

    @property
    def ip(self):
        return self.h.client_address[0]


# ---------------------------------------------------------------- acesso

@rota("GET", "/api/inicio", auth=None)
def r_inicio(req):
    configurado = bool(DB.execute("SELECT 1 FROM usuarios").fetchone())
    bloqueado = req.usuario is not None and conferir_bloqueio(req.usuario, False)
    # a lista de pessoas não sai daqui: cada uma entra digitando o próprio usuário
    return {"configurado": configurado, "escola": nome_local(), "local": info_local(), "instalacao": instalacao(),
            "locais": None if configurado else LOCAIS,
            "logado": req.usuario is not None, "versao": VERSAO, "privacidade": info_privacidade(),
            "modo": cfg("modo"), "bloqueado": bloqueado,
            "bloqueado_nome": req.usuario["nome"] if bloqueado else None,
            "trocar_senha": bool(req.usuario and req.usuario["trocar_senha"]),
            "login": req.usuario["login"] if req.usuario and req.usuario["trocar_senha"] else None,
            "senha_minimo": SENHA_MINIMO, "cadastro_aberto": configurado and cadastro_permitido(),
            # alguém ainda entra com o PIN da versão 2.0 (pelo nome): a tela de entrada explica como
            "pin_antigo": configurado and any(senha_antiga(r[0]) for r in DB.execute(
                "SELECT pin_hash FROM usuarios WHERE ativo=1 AND anonimizado=0 AND ref_central=''"))}


# ---------------------------------------------------------------- bloqueio por falta de uso

# Estas rotas funcionam com a tela bloqueada (para desbloquear, sair ou saber que está bloqueada)
LIVRES_NO_BLOQUEIO = ("/api/inicio", "/api/desbloquear", "/api/bloquear", "/api/sair", "/api/presenca")
# Com a senha provisória (dada pelo gestor ou o PIN antigo), só dá para criar a senha nova ou sair
LIVRES_NA_TROCA = ("/api/inicio", "/api/senha", "/api/sair", "/api/bloquear", "/api/desbloquear", "/api/presenca")


def ler_mes(req):
    """O mês pedido (AAAA-MM) ou o mês atual. Mês mal escrito é recusado aqui, antes de chegar às contas."""
    mes = req.q("mes") or mes_atual()
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", mes):
        raise Erro("Mês inválido.", 400)
    return mes


MESES_PT = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
            "novembro", "dezembro"]
MAX_DIAS_PERIODO = 731


def data_br(iso):
    return f"{iso[8:10]}/{iso[5:7]}/{iso[:4]}"


def ler_periodo(req):
    """Período livre do relatório (2.7.0): de e ate, no formato AAAA-MM-DD. Sem nenhum dos dois, vale o mês.
    Devolve None (vale o mês) ou {"de", "ate", "rotulo"}. Data mal escrita, fim antes do início e período
    de mais de 2 anos são recusados aqui."""
    de, ate = (req.q("de") or "").strip(), (req.q("ate") or "").strip()
    if not de and not ate:
        return None
    if not (re.fullmatch(r"\d{4}-\d{2}-\d{2}", de) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", ate)):
        raise Erro("Período inválido. Escolha a data de início e a data de fim.", 400)
    try:
        d1, d2 = dt.date.fromisoformat(de), dt.date.fromisoformat(ate)
    except ValueError:
        raise Erro("Período inválido. Escolha a data de início e a data de fim.", 400)
    if d1 > d2:
        raise Erro("A data de início vem depois da data de fim.", 400)
    if (d2 - d1).days > MAX_DIAS_PERIODO:
        raise Erro("O período pode ter no máximo 2 anos.", 400)
    return {"de": de, "ate": ate, "rotulo": f"{data_br(de)} a {data_br(ate)}"}


def tempo_sql(periodo, mes, col_mes, col_data):
    """Condição de SQL e valores do tempo do relatório: o mês, ou as datas do período."""
    if periodo:
        return f"substr({col_data},1,10) BETWEEN ? AND ?", [periodo["de"], periodo["ate"]]
    return f"{col_mes}=?", [mes]


def tentativa_bloqueada(*chaves):
    agora_s = time.time()
    ate = max(TENTATIVAS.get(k, [0, 0])[1] for k in chaves)
    if ate > agora_s:
        raise Erro(f"Muitas tentativas erradas. Espere {int(ate - agora_s) + 1} segundos.", 429, "tentativas")


def tentativa_errada(*chaves):
    """5 erros seguidos no mesmo usuário (ou 20 no mesmo aparelho): espera 30 s, depois 1 min, 2 min... até 15 min."""
    for k in chaves:
        falhas = TENTATIVAS.get(k, [0, 0])[0] + 1
        limite = 20 if k[0] == "ip" else 5
        espera = min(900, 30 * 2 ** (falhas - limite)) if falhas >= limite else 0
        TENTATIVAS[k] = [falhas, time.time() + espera if espera else 0]


def tentativa_certa(*chaves):
    for k in chaves:
        TENTATIVAS.pop(k, None)


def conferir_bloqueio(u, atividade):
    """Diz se a sessão está bloqueada por falta de uso (e bloqueia, se passou do tempo).
    Só conta como uso o pedido que o app marca como vindo de um toque ou tecla da pessoa:
    a atualização automática da tela não segura a sessão aberta."""
    minutos = int(cfg("bloqueio_minutos") or 0)
    token = u.get("sessao_token")
    if not token:
        return False
    if minutos:
        if u.get("sessao_bloqueada"):
            return True
        if token in SESSOES_DIGITALIZANDO:  # o scanner está trabalhando para esta pessoa: conta como uso
            return False
        ultima = u.get("sessao_atividade") or u.get("sessao_em")
        try:
            parado = dt.datetime.now() - dt.datetime.strptime(ultima, "%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError):
            parado = dt.timedelta(0)
        if parado > dt.timedelta(minutes=minutos):
            DB.execute("UPDATE sessoes SET bloqueada=1 WHERE token=?", (token,))
            DB.commit()
            return True
    if atividade:
        DB.execute("UPDATE sessoes SET atividade_em=?, bloqueada=0 WHERE token=?", (agora(), token))
        DB.commit()
    return False


@rota("POST", "/api/bloquear")
def r_bloquear(req):
    """O app avisa que ficou parado: a sessão fica bloqueada até a senha ser digitada de novo."""
    if int(cfg("bloqueio_minutos") or 0):
        DB.execute("UPDATE sessoes SET bloqueada=1 WHERE token=?", (req.usuario["sessao_token"],))
    return {"ok": True}


@rota("POST", "/api/desbloquear")
def r_desbloquear(req):
    chave = ("d", req.uid)
    tentativa_bloqueada(chave)
    if not confere_senha(str(req.b("senha") or ""), req.usuario["pin_hash"]):
        tentativa_errada(chave)
        raise Erro("Senha incorreta.", 401, "senha")
    tentativa_certa(chave)
    DB.execute("UPDATE sessoes SET bloqueada=0, atividade_em=? WHERE token=?", (agora(), req.usuario["sessao_token"]))
    return {"ok": True}


def hoje():
    t = os.environ.get("CI_HOJE")
    return dt.date.fromisoformat(t) if t else dt.date.today()


def modo_impressora():
    return cfg("modo") == "impressora"


def estado_licenca():
    return licenca.situacao(cfg("licenca"), cfg("instalado_em"), hoje())


def info_licenca(completa=False):
    s = estado_licenca()
    if not completa:
        return {k: s[k] for k in ("estado", "mensagem", "pode_imprimir", "dias", "fim")}
    return {**s, "site": cfg("site_empresa"), "empresa": cfg("empresa_nome"),
            "avaliacao_dias": licenca.AVALIACAO_DIAS, "carencia_dias": licenca.CARENCIA_DIAS}


@rota("GET", "/api/admin/licenca", auth="admin")
def r_licenca(req):
    return info_licenca(completa=True)


@rota("POST", "/api/admin/licenca", auth="admin")
def r_ativar(req):
    try:
        dados = licenca.ler_chave(req.b("chave"))
    except licenca.ErroLicenca as e:
        raise Erro(str(e), 400, "chave_invalida")
    DB.execute("UPDATE config SET valor=? WHERE chave='licenca'", (dados["texto"],))
    return {"ok": True, **info_licenca(completa=True)}


def info_privacidade():
    return {"escola": nome_local(), "local": info_local(), "empresa": cfg("empresa_nome"), "cnpj": cfg("empresa_cnpj"),
            "contato_privacidade": cfg("contato_privacidade"), "contato_escola": cfg("contato_escola"),
            "termos_url": cfg("termos_url"), "reter_meses": int(cfg("reter_mensagens_meses") or 12),
            "horas_arquivos": max(12, int(cfg("horas_fila") or 4))}


@rota("POST", "/api/ciencia")
def r_ciencia(req):
    DB.execute("UPDATE usuarios SET ciencia_privacidade=?, ciencia_versao=? WHERE id=?",
               (agora(), AVISO_VERSAO, req.uid))
    return {"ok": True}


# ---------------------------------------------------------------- bloquear, denunciar e excluir a conta (2.5.0)

MOTIVOS_DENUNCIA = ("ofensa", "assedio", "conteudo_improprio", "spam", "outro")


@rota("GET", "/api/bloqueios")
def r_bloqueios(req):
    return {"bloqueados": linhas(DB.execute(
        "SELECT u.id, u.nome FROM bloqueios b JOIN usuarios u ON u.id=b.bloqueado_id "
        "WHERE b.usuario_id=? ORDER BY u.nome COLLATE NOCASE", (req.uid,)))}


@rota("POST", "/api/colega/bloquear")
def r_bloquear_colega(req):
    outro = inteiro(req.b("usuario_id"), "pessoa")
    if outro == req.uid:
        raise Erro("Você não pode bloquear a si mesmo.")
    if not uma(DB.execute("SELECT 1 AS x FROM usuarios WHERE id=?", (outro,))):
        raise Erro("Pessoa não encontrada.", 404)
    if req.b("bloquear", True):
        DB.execute("INSERT OR IGNORE INTO bloqueios(usuario_id, bloqueado_id, criado_em) VALUES(?,?,?)",
                   (req.uid, outro, agora()))
    else:
        DB.execute("DELETE FROM bloqueios WHERE usuario_id=? AND bloqueado_id=?", (req.uid, outro))
    return {"ok": True}


@rota("POST", "/api/denunciar")
def r_denunciar(req):
    """Denuncia uma mensagem (ou só uma pessoa) à gestão. A gestão vê o trecho como estava na hora."""
    mid = req.b("mensagem_id")
    alvo, trecho, conversa = None, "", ""
    if mid:
        m = uma(DB.execute("SELECT * FROM mensagens WHERE id=?", (inteiro(mid, "mensagem"),)))
        if not m or not (m["para_id"] is None or req.uid in (m["de_id"], m["para_id"])):
            raise Erro("Mensagem não encontrada.", 404)
        if m["de_id"] == req.uid:
            raise Erro("Você não pode denunciar a sua própria mensagem.")
        alvo, trecho = m["de_id"], (m["texto"] or "")[:1000]
        conversa = "mural" if m["para_id"] is None else chave_direta(m["de_id"])
    else:
        alvo = inteiro(req.b("usuario_id"), "pessoa")
        if alvo == req.uid or not uma(DB.execute("SELECT 1 AS x FROM usuarios WHERE id=?", (alvo,))):
            raise Erro("Pessoa não encontrada.", 404)
    motivo = str(req.b("motivo") or "outro")
    if motivo not in MOTIVOS_DENUNCIA:
        motivo = "outro"
    detalhe = " ".join(str(req.b("texto") or "").split())[:300]
    if DB.execute("SELECT 1 FROM denuncias WHERE denunciante_id=? AND status='aberta' AND alvo_id=? "
                  "AND COALESCE(mensagem_id,0)=?", (req.uid, alvo, int(mid or 0))).fetchone():
        return {"ok": True, "repetida": True}
    DB.execute("INSERT INTO denuncias(denunciante_id, alvo_id, mensagem_id, conversa, motivo, trecho, criado_em) "
               "VALUES(?,?,?,?,?,?,?)", (req.uid, alvo, mid, conversa, motivo + (": " + detalhe if detalhe else ""),
                                          trecho, agora()))
    return {"ok": True}


def denuncias_abertas():
    return linhas(DB.execute(
        "SELECT d.id, d.mensagem_id, d.conversa, d.motivo, d.trecho, d.criado_em, d.alvo_id, d.denunciante_id, "
        "ua.nome AS alvo_nome, ud.nome AS denunciante_nome, ua.ativo AS alvo_ativo "
        "FROM denuncias d LEFT JOIN usuarios ua ON ua.id=d.alvo_id LEFT JOIN usuarios ud ON ud.id=d.denunciante_id "
        "WHERE d.status='aberta' ORDER BY d.id"))


@rota("GET", "/api/admin/denuncias", auth="gestor")
def r_denuncias(req):
    return {"denuncias": denuncias_abertas(), "exclusoes": exclusoes_pedidas()}


@rota("POST", "/api/admin/denuncias/resolver", auth="gestor")
def r_resolver_denuncia(req):
    d = uma(DB.execute("SELECT * FROM denuncias WHERE id=? AND status='aberta'", (inteiro(req.b("id"), "denúncia"),)))
    if not d:
        raise Erro("Esta denúncia já foi resolvida.", 404)
    acao = str(req.b("acao") or "ignorar")
    if acao not in ("ignorar", "apagar_mensagem", "desativar"):
        raise Erro("Ação inválida.")
    if acao == "apagar_mensagem" and d["mensagem_id"]:
        DB.execute("UPDATE mensagens SET texto='[mensagem removida pela gestão]' WHERE id=? AND tipo='texto'",
                   (d["mensagem_id"],))
    if acao == "desativar" and d["alvo_id"]:
        alvo = uma(DB.execute("SELECT papel FROM usuarios WHERE id=?", (d["alvo_id"],)))
        if alvo and alvo["papel"] == "admin":
            raise Erro("Um gestor principal não pode ser desativado por aqui.")
        DB.execute("UPDATE usuarios SET ativo=0 WHERE id=?", (d["alvo_id"],))
        DB.execute("DELETE FROM sessoes WHERE usuario_id=?", (d["alvo_id"],))
    DB.execute("UPDATE denuncias SET status='resolvida', acao=?, resolvido_por=?, resolvido_em=?, trecho=? WHERE id=?",
               (acao, req.uid, agora(), "" if acao != "ignorar" else d["trecho"], d["id"]))
    return {"ok": True}


# Excluir a conta: a pessoa pede dentro do app; o gestor (que é quem responde pelos dados) atende em Gestão.
def exclusoes_pedidas():
    return linhas(DB.execute("SELECT id, nome, login, exclusao_pedida AS pedido_em FROM usuarios "
                             "WHERE exclusao_pedida<>'' AND COALESCE(anonimizado,0)=0 ORDER BY exclusao_pedida"))


@rota("POST", "/api/excluir-conta/pedir")
def r_pedir_exclusao(req):
    u = req.usuario
    if not confere_senha(str(req.b("senha") or ""), u["pin_hash"]):
        raise Erro("Senha incorreta.", 403, "senha")
    if u["papel"] == "admin" and DB.execute("SELECT COUNT(*) FROM usuarios WHERE papel='admin' AND ativo=1 "
                                           "AND id<>?", (u["id"],)).fetchone()[0] == 0:
        raise Erro("Você é o único gestor principal. Cadastre outro gestor principal antes de pedir a exclusão.")
    DB.execute("UPDATE usuarios SET exclusao_pedida=? WHERE id=?", (agora(), u["id"]))
    return {"ok": True}


@rota("POST", "/api/excluir-conta/cancelar")
def r_cancelar_exclusao(req):
    DB.execute("UPDATE usuarios SET exclusao_pedida='' WHERE id=?", (req.uid,))
    return {"ok": True}


@rota("POST", "/api/admin/exclusoes/atender", auth="admin")
def r_atender_exclusao(req):
    uid = inteiro(req.b("id"), "pessoa")
    u = uma(DB.execute("SELECT * FROM usuarios WHERE id=? AND exclusao_pedida<>''", (uid,)))
    if not u:
        raise Erro("Este pedido não existe mais.", 404)
    if uid == req.uid:
        raise Erro("Outro gestor principal precisa atender o seu pedido.")
    apagar_dados_pessoais(uid)
    return {"ok": True}


@rota("POST", "/api/admin/exclusoes/recusar", auth="admin")
def r_recusar_exclusao(req):
    DB.execute("UPDATE usuarios SET exclusao_pedida='' WHERE id=?", (inteiro(req.b("id"), "pessoa"),))
    return {"ok": True}


@rota("POST", "/api/preferencias")
def r_preferencias(req):
    atual = prefs_usuario(req.usuario)
    for k in atual:
        if k in req.corpo:
            atual[k] = bool(req.corpo[k])
    DB.execute("UPDATE usuarios SET prefs=? WHERE id=?", (json.dumps(atual), req.uid))
    return {"ok": True, "prefs": atual}


@rota("POST", "/api/configurar", auth=None)
def r_configurar(req):
    if DB.execute("SELECT 1 FROM usuarios").fetchone():
        raise Erro("O sistema já foi configurado.", 403)
    nome = str(req.b("nome") or "").strip()
    escola = str(req.b("escola") or "").strip()[:120]
    tipo = str(req.b("tipo_local") or "outro")
    if tipo not in LOCAIS:
        raise Erro("Escolha onde o Folha a Folha vai ser usado: empresa, escola ou outra organização.")
    if not nome:
        raise Erro("Informe seu nome.")
    login = valida_login(req.b("usuario") or gerar_login(nome))
    senha = valida_senha(req.b("senha"), login, nome)
    modo = str(req.b("modo") or "impressora")
    if modo not in MODOS:
        raise Erro("Escolha como a equipe vai imprimir.")
    instal = str(req.b("instalacao") or "local")
    if instal not in INSTALACOES:
        raise Erro("Escolha o tipo de instalação.")
    if instal == "unidade":
        if req.b("arquivo"):
            adesao = ler_arquivo_adesao(req.b("arquivo"))
            url = normalizar_url(req.b("central_url") or adesao.get("endereco") or "")
        else:
            url = normalizar_url(req.b("central_url"))
            if not url:
                raise Erro("Informe o endereço da central (a TI informa) ou carregue o arquivo de adesão.")
            if not str(req.b("codigo") or "").strip():
                raise Erro("Informe o código de adesão que a TI gerou para esta unidade.")
            adesao = chamar_central(url, "/api/central/adesao", {"codigo": req.b("codigo"), "versao": VERSAO,
                                                                 "aparelho": socket.gethostname()[:60]})
        ligar_unidade(adesao, url)
        escola = cfg("escola")
        tipo = cfg("tipo_local") if cfg("tipo_local") in LOCAIS else tipo
    DB.execute("UPDATE config SET valor=? WHERE chave='instalacao'", (instal,))
    if instal == "central":
        segredo_central()
    cur = DB.execute("INSERT INTO usuarios(nome, pin_hash, papel, criado_em, login) VALUES(?,?, 'admin', ?, ?)",
                     (nome, hash_senha(senha), agora(), login))
    if escola:
        DB.execute("UPDATE config SET valor=? WHERE chave='escola'", (escola,))
    DB.execute("UPDATE config SET valor=? WHERE chave='tipo_local'", (tipo,))
    DB.execute("UPDATE config SET valor=? WHERE chave='modo'", (modo,))
    criar_sessao(req, cur.lastrowid)
    DB.commit()
    threading.Thread(target=aplicar_modo, daemon=True).start()
    return {"ok": True}


def criar_sessao(req, uid):
    token = secrets.token_urlsafe(32)
    DB.execute("INSERT INTO sessoes(token, usuario_id, criado_em, atividade_em, ip, visto_em) VALUES(?,?,?,?,?,?)",
               (token, uid, agora(), agora(), req.ip, agora()))
    req.novos_cookies.append(
        f"sessao={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={DIAS_SESSAO * 86400}")


def achar_para_login(ident):
    login = sem_acento(ident.strip().lower())
    u = uma(DB.execute("SELECT * FROM usuarios WHERE login=? AND (ativo=1 OR aprovacao='pendente') AND anonimizado=0",
                       (login,)))
    if u:
        return u
    # quem veio da versão 2.0 ainda não sabe o próprio usuário: entra pelo nome e pelo PIN antigo, uma vez
    alvo = " ".join(sem_acento(ident).lower().split())
    achados = [x for x in linhas(DB.execute("SELECT * FROM usuarios WHERE ativo=1 AND anonimizado=0"))
               if senha_antiga(x["pin_hash"]) and " ".join(sem_acento(x["nome"]).lower().split()) == alvo]
    return achados[0] if len(achados) == 1 else None


CADASTROS_IP = {}  # endereço -> horários dos últimos pedidos de cadastro
MAX_PENDENTES = 200


def cadastro_permitido():
    """A pessoa pode pedir o próprio cadastro na tela de entrada (sem cota; o gestor aprova)."""
    if cfg("cadastro_aberto") != "1":
        return False
    return not (instalacao() == "unidade" and politica_setor(1)["cadastro"] == "ti")


@rota("POST", "/api/cadastro", auth=None)
def r_cadastro(req):
    if not DB.execute("SELECT 1 FROM usuarios").fetchone() or not cadastro_permitido():
        raise Erro("O cadastro pela tela de entrada não está aberto. Peça o seu ao gestor.", 403)
    agora_s = time.time()
    feitos = [t for t in CADASTROS_IP.get(req.ip, []) if agora_s - t < 3600]
    if len(feitos) >= 5:
        raise Erro("Muitos cadastros feitos deste aparelho na última hora. Tente mais tarde.", 429)
    if DB.execute("SELECT COUNT(*) FROM usuarios WHERE aprovacao='pendente'").fetchone()[0] >= MAX_PENDENTES:
        raise Erro("Há muitos cadastros esperando aprovação. Fale com o gestor.", 429)
    nome = " ".join(str(req.b("nome") or "").split())[:80]
    if len(nome) < 3 or " " not in nome:
        raise Erro("Escreva seu nome e sobrenome.", 400, "nome")
    login = valida_login(req.b("usuario") or gerar_login(nome))
    if login_em_uso(login):
        raise Erro(f"O usuário {login} já existe. Escolha outro (por exemplo, com o sobrenome do meio ou um número).",
                   400, "login")
    senha = valida_senha(req.b("senha"), login, nome)
    obs = " ".join(str(req.b("obs") or "").split())[:120]
    DB.execute("INSERT INTO usuarios(nome, pin_hash, papel, ativo, criado_em, setor_id, login, trocar_senha, aprovacao, "
               "cadastro_obs) VALUES(?,?, 'prof', 0, ?, 1, ?, 0, 'pendente', ?)",
               (nome, hash_senha(senha), agora(), login, obs))
    CADASTROS_IP[req.ip] = feitos + [agora_s]
    return {"ok": True, "login": login}


@rota("POST", "/api/admin/cadastro/recusar", auth="admin")
def r_recusar_cadastro(req):
    uid = inteiro(req.b("id"), "pessoa")
    if not DB.execute("SELECT 1 FROM usuarios WHERE id=? AND aprovacao='pendente'", (uid,)).fetchone():
        raise Erro("Este cadastro não está mais esperando aprovação.", 404)
    for tabela in ("sessoes", "cotas", "cotas_remotas"):
        DB.execute(f"DELETE FROM {tabela} WHERE usuario_id=?", (uid,))
    DB.execute("DELETE FROM usuarios WHERE id=? AND aprovacao='pendente'", (uid,))
    return {"ok": True}


def cadastros_pendentes():
    return linhas(DB.execute("SELECT id, nome, login, cadastro_obs AS obs, criado_em FROM usuarios "
                             "WHERE aprovacao='pendente' ORDER BY id"))


@rota("POST", "/api/login", auth=None)
def r_login(req):
    ident = str(req.b("usuario") or "").strip()[:120]
    senha = str(req.b("senha") or "")
    if not ident or not senha:
        raise Erro("Digite seu usuário e sua senha.")
    chaves = (("u", sem_acento(ident).lower()), ("ip", req.ip))
    tentativa_bloqueada(*chaves)
    u = achar_para_login(ident)
    if not u or not confere_senha(senha, u["pin_hash"]):
        if not u:
            confere_senha(senha, "")  # leva o mesmo tempo: não dá para descobrir quem existe pela demora
        tentativa_errada(*chaves)
        raise Erro("Usuário ou senha incorretos.", 401, "senha")
    tentativa_certa(*chaves)
    if u["aprovacao"] == "pendente":
        raise Erro("Seu cadastro ainda está esperando a aprovação do gestor. Depois de aprovado, é só entrar com "
                   "este usuário e esta senha.", 403, "pendente")
    if instalacao() == "central" and (u["setor_id"] or 1) != 1 and setor(u["setor_id"])["remoto"]:
        raise Erro(f"Você imprime pela unidade {setor(u['setor_id'])['nome']}. Entre pelo aparelho de lá.", 403)
    criar_sessao(req, u["id"])
    return {"ok": True, "trocar_senha": bool(u["trocar_senha"]), "login": u["login"]}


@rota("POST", "/api/sair")
def r_sair(req):
    token = req.h.token_sessao()
    DB.execute("DELETE FROM sessoes WHERE token=?", (token,))
    req.novos_cookies.append("sessao=; Path=/; Max-Age=0")
    return {"ok": True}


@rota("POST", "/api/senha")
def r_trocar_senha(req):
    u = req.usuario
    if u["ref_central"]:
        raise Erro("Sua senha é cuidada pela TI, na central. Peça a troca para ela.", 403)
    chave = ("d", u["id"])
    tentativa_bloqueada(chave)
    if not u["trocar_senha"] and not confere_senha(str(req.b("atual") or ""), u["pin_hash"]):
        tentativa_errada(chave)
        raise Erro("A senha atual não confere.", 400, "senha")
    nova = valida_senha(req.b("nova"), u["login"], u["nome"])
    if confere_senha(nova, u["pin_hash"]):
        raise Erro("A senha nova precisa ser diferente da atual.", 400, "senha")
    tentativa_certa(chave)
    DB.execute("UPDATE usuarios SET pin_hash=?, trocar_senha=0 WHERE id=?", (hash_senha(nova), u["id"]))
    # as outras sessões (outros aparelhos) saem: quem tinha a senha antiga não continua dentro
    DB.execute("DELETE FROM sessoes WHERE usuario_id=? AND token<>?", (u["id"], u["sessao_token"]))
    return {"ok": True, "login": u["login"]}


@rota("GET", "/api/presenca")
def r_presenca(req):
    """O app aberto em segundo plano avisa que continua aberto (a impressora Folha a Folha usa isso)."""
    return {"ok": True}


# ---------------------------------------------------------------- painel de cada pessoa

def pedidos_abertos_para(uid, mes):
    """Pedidos que esta pessoa pode atender agora."""
    return linhas(DB.execute(
        "SELECT p.*, u.nome AS solicitante_nome, i.nome AS impressora_nome, i.cor "
        "FROM pedidos p JOIN usuarios u ON u.id=p.solicitante_id JOIN impressoras i ON i.id=p.impressora_id "
        "WHERE p.status='pendente' AND p.mes=? AND p.solicitante_id<>? AND COALESCE(p.reserva,0)=0 "
        "AND (p.destinatario_id=? OR p.destinatario_id IS NULL) "
        "AND NOT EXISTS (SELECT 1 FROM pedidos_ocultos po WHERE po.pedido_id=p.id AND po.usuario_id=?) "
        "AND p.solicitante_id NOT IN (SELECT bloqueado_id FROM bloqueios WHERE usuario_id=?) "
        "ORDER BY p.id DESC", (mes, uid, uid, uid, uid)))


def nao_lidas(uid):
    total = 0
    for conv in conversas_de(uid):
        total += conv["nao_lidas"]
    return total


@rota("GET", "/api/eu")
def r_eu(req):
    mes = mes_atual()
    u = req.usuario
    return {
        "usuario": {"id": u["id"], "nome": u["nome"], "admin": u["papel"] == "admin", "papel": u["papel"],
                    "gestor": u["papel"] in ("admin", "gestor"), "setor_id": u["setor_id"] or 1,
                    "setor": nome_setor(u["setor_id"] or 1), "login": u["login"], "senha_pela_ti": bool(u["ref_central"])},
        "instalacao": instalacao(), "negativo": info_negativo(u["id"], mes),
        "aumentos": aumentos_de(u["id"]),
        "escola": nome_local(), "local": info_local(), "mes": mes, "aviso_pct": int(cfg("aviso_pct") or 80),
        "saldos": saldos_usuario(u["id"], mes),
        "nao_lidas": nao_lidas(u["id"]),
        "pedidos": [formatar_pedido(p, u["id"]) for p in pedidos_abertos_para(u["id"], mes)],
        "max_copias": int(cfg("max_copias") or 60),
        "ciencia": bool(u["ciencia_privacidade"]) and (u["ciencia_versao"] or 0) >= AVISO_VERSAO,
        "ciencia_mudou": bool(u["ciencia_privacidade"]) and (u["ciencia_versao"] or 0) < AVISO_VERSAO,
        "privacidade": info_privacidade(),
        "termos_url": cfg("termos_url"), "exclusao_pedida": u["exclusao_pedida"] or "",
        "denuncias_abertas": (DB.execute("SELECT COUNT(*) FROM denuncias WHERE status='aberta'").fetchone()[0]
                              + len(exclusoes_pedidas())) if u["papel"] in ("admin", "gestor") else 0,
        "controle": info_controle(u["id"], mes), "prefs": prefs_usuario(u),
        "conferencias": [formatar_conferencia(c) for c in conferencias_de(u["id"])],
        "fila": fila_do_usuario(u["id"]),
        "retidas": len(retidas_visiveis(u, req.ip)) if modo_impressora() else 0,
        "cadastros_pendentes": DB.execute("SELECT COUNT(*) FROM usuarios WHERE aprovacao='pendente'").fetchone()[0]
        if u["papel"] == "admin" else 0,
        "so_conectado": cfg("ipp_so_conectado") == "1",
        "impressora_virtual": (ENDERECOS[0] + "/ipp/print") if ENDERECOS else "",
        "modo": cfg("modo") or "navegador", "licenca": info_licenca(),
        "trocas": info_trocas_usuario(u["id"], mes),
        "bloqueio_minutos": int(cfg("bloqueio_minutos") or 0),
        "max_lote": MAX_LOTE,
        "extensoes": sorted(impressao.EXT_PDF | impressao.EXT_IMAGEM | impressao.EXT_OFFICE),
    }


def info_trocas_usuario(uid, mes):
    modo = modo_trocas()
    limites = {}
    if modo == "limite":
        for imp in impressoras():
            limites[str(imp["id"])] = limites_troca(uid, imp["id"], mes)
    return {"modo": modo, "limites": limites, "reserva_auto": int(cfg("reserva_auto") or 0), "aviso": aviso_troca(),
            "limite_doar_pct": int(cfg("limite_doar_pct") or 0), "limite_receber_pct": int(cfg("limite_receber_pct") or 0)}


@rota("GET", "/api/colegas")
def r_colegas(req):
    mes = mes_atual()
    saida = []
    for u in linhas(DB.execute("SELECT id, nome FROM usuarios WHERE ativo=1 AND id<>? "
                               "ORDER BY nome COLLATE NOCASE", (req.uid,))):
        saida.append({"id": u["id"], "nome": u["nome"],
                      "saldos": [{"impressora_id": s["impressora_id"], "restante": s["restante"],
                                  "cota": s["cota"]} for s in saldos_usuario(u["id"], mes)]})
    return {"colegas": saida}


@rota("GET", "/api/trabalhos")
def r_trabalhos(req):
    mes = ler_mes(req)
    return {"mes": mes, "trabalhos": linhas(DB.execute(
        f"SELECT t.*, i.nome AS impressora_nome, i.cor, ROUND(t.total * {CUSTO_SQL}, 2) AS custo "
        "FROM trabalhos t "
        "JOIN impressoras i ON i.id=t.impressora_id WHERE t.usuario_id=? AND t.mes=? "
        "ORDER BY t.id DESC LIMIT 300", (req.uid, mes))),
        "movimentos": movimentos_de(req.uid, mes)}


def movimentos_de(uid, mes):
    rows = linhas(DB.execute(
        "SELECT m.*, i.nome AS impressora_nome, i.cor FROM movimentos m "
        "JOIN impressoras i ON i.id=m.impressora_id WHERE m.mes=? AND (m.de_id=? OR m.para_id=?) "
        "ORDER BY m.id DESC", (mes, uid, uid)))
    for m in rows:
        m["de_nome"] = nome_usuario(m["de_id"])
        m["para_nome"] = nome_usuario(m["para_id"])
        m["entrada"] = m["para_id"] == uid
    return rows


# ---------------------------------------------------------------- imprimir

@rota("POST", "/api/upload", trava=False)
def r_upload(req):
    nome = unquote(req.h.headers.get("X-Nome-Arquivo", "arquivo"))[:200]
    nome = nome.replace("/", "_").replace("\\", "_")
    tipo = impressao.tipo_arquivo(nome)
    if not tipo:
        raise Erro(f'"{nome}" não dá para enviar por aqui. Envie PDF, foto (JPG ou PNG) ou arquivo do Word, '
                   "Excel, PowerPoint ou LibreOffice. " + ("Outros tipos: imprima do próprio programa pela impressora "
                   "Folha a Folha ou salve como PDF." if modo_impressora() else "Outros tipos: salve como PDF antes."))
    dados = req.corpo
    if not dados:
        raise Erro("O arquivo chegou vazio.")
    imagem = ""
    uid_arq = uuid.uuid4().hex
    caminho = ARQUIVOS / f"{uid_arq}{Path(nome).suffix.lower()}"
    caminho.write_bytes(dados)
    try:
        if tipo == "office":
            with LOCK:
                soffice = cfg("soffice")
            caminho = Path(impressao.converter_para_pdf(str(caminho), impressao.achar_soffice(soffice)))
            tipo = "pdf"
        elif tipo == "imagem":
            # a foto vira PDF de uma página: a impressora recebe sempre PDF e a prévia mostra a folha como vai sair
            # a foto original fica guardada junto, para montar várias por folha ou um banner
            foto = caminho
            orientacao = str(req.h.headers.get("X-Orientacao-Papel", "auto")).lower()
            if orientacao not in ("auto", "retrato", "paisagem"):
                orientacao = "auto"
            caminho = Path(impressao.imagem_para_pdf(str(foto), str(foto.with_suffix(".pdf")), orientacao))
            tipo = "pdf"
            imagem = str(foto)
        paginas = impressao.contar_paginas_pdf(str(caminho)) if tipo == "pdf" else 1
    except ErroImpressao as e:
        for p in (caminho, caminho.with_suffix(Path(nome).suffix.lower())):
            try:
                p.unlink()
            except OSError:
                pass
        raise Erro(str(e))
    with LOCK:
        DB.execute("INSERT INTO uploads(id, usuario_id, caminho, nome, tipo, paginas, criado_em, imagem) "
                   "VALUES(?,?,?,?,?,?,?,?)", (uid_arq, req.uid, str(caminho), nome, tipo, paginas, agora(), imagem))
        DB.commit()
    return {"id": uid_arq, "nome": nome, "paginas": paginas, "tipo": tipo, "foto": bool(imagem),
            "renderizador": bool(impressao.achar_renderizador())}


def apagar_envio(up, com_origens=True):
    """Apaga um arquivo enviado (e a foto original e, se for montagem, os arquivos de que ela foi feita)."""
    apagar_arquivo(up.get("imagem"))
    apagar_previas(up["id"])
    if com_origens and up.get("origens"):
        try:
            ids = json.loads(up["origens"])
        except ValueError:
            ids = []
        for i in ids:
            o = uma(DB.execute("SELECT * FROM uploads WHERE id=? AND usuario_id=?", (i, up["usuario_id"])))
            if o:
                DB.execute("DELETE FROM uploads WHERE id=?", (o["id"],))
                apagar_arquivo(o["caminho"])
                apagar_envio(o, False)


MODOS_MONTAGEM = ("fotos", "banner", "paginas")


@rota("POST", "/api/montar", trava=False)
def r_montar(req):
    """Monta um PDF novo a partir do que a pessoa enviou: várias fotos por folha, banner em várias folhas
    ou várias páginas do PDF por folha. O resultado é um envio novo, impresso como qualquer PDF."""
    modo = str(req.b("modo") or "")
    if modo not in MODOS_MONTAGEM:
        raise Erro("Escolha como montar.")
    ids = [str(i) for i in (req.b("uploads") or [])][:60]
    if not ids:
        raise Erro("Escolha o arquivo.")
    with LOCK:
        ups = [uma(DB.execute("SELECT * FROM uploads WHERE id=? AND usuario_id=?", (i, req.uid))) for i in ids]
        velho = uma(DB.execute("SELECT * FROM uploads WHERE id=? AND usuario_id=? AND origens<>''",
                               (str(req.b("substituir") or ""), req.uid)))
    if not all(u and os.path.isfile(u["caminho"]) for u in ups):
        raise Erro("O arquivo não está mais disponível. Envie de novo.")
    cortar = bool(req.b("cortar"))
    novo = uuid.uuid4().hex
    destino = ARQUIVOS / f"{novo}.pdf"
    try:
        if modo == "fotos":
            if not all(u["imagem"] and os.path.isfile(u["imagem"]) for u in ups):
                raise Erro("Para montar várias por folha, escolha fotos (JPG ou PNG).")
            por_folha = inteiro(req.b("por_folha") or 1, "fotos por folha", 1, 9)
            vezes = inteiro(req.b("vezes") or 1, "vezes cada foto", 1, 60)
            if len(ups) * vezes > 400:
                raise Erro("Fotos demais de uma vez. Divida em partes.")
            orientacao = str(req.b("orientacao") or "auto").lower()
            if orientacao not in ("auto", "retrato", "paisagem"):
                orientacao = "auto"
            impressao.montar_fotos([u["imagem"] for u in ups], por_folha, vezes, cortar, str(destino), orientacao)
            qtd = len(ups) * vezes
            nome = (ups[0]["nome"] if qtd == 1 else
                    f"{len(ups)} fotos" if vezes == 1 else f"{len(ups)} fotos, {vezes} vezes cada") + \
                (f" ({por_folha} por folha)" if por_folha > 1 else "")
            if qtd > 1 and len(ups) == 1:
                nome = f"{ups[0]['nome']} ({vezes} vezes, {por_folha} por folha)"
            desc = {"modo": modo, "por_folha": por_folha, "vezes": vezes, "cortar": cortar}
        elif modo == "banner":
            if len(ups) != 1 or not ups[0]["imagem"]:
                raise Erro("O banner é feito com uma foto só (JPG ou PNG).")
            folhas = inteiro(req.b("folhas") or 4, "folhas do banner", 2, 16)
            feito = impressao.montar_banner(ups[0]["imagem"], folhas, str(destino), cortar)
            plano = impressao.plano_banner(impressao.ler_imagem(ups[0]["imagem"]), folhas, cortar)
            nome = f"Banner de {ups[0]['nome']} ({plano['largura_cm']} x {plano['altura_cm']} cm)"
            desc = {"modo": modo, "folhas": folhas, "cortar": cortar, "largura_cm": plano["largura_cm"],
                    "altura_cm": plano["altura_cm"], "cols": feito["cols"], "lins": feito["lins"],
                    "posicoes": feito["posicoes"], "deitadas": feito["deitadas"]}
        else:
            u = ups[0]
            if len(ups) != 1 or u["tipo"] != "pdf":
                raise Erro("Páginas por folha só para PDF.")
            por_folha = inteiro(req.b("por_folha") or 2, "páginas por folha", 2, 4)
            try:
                intervalo, _ = impressao.interpretar_intervalo(str(req.b("intervalo") or ""), u["paginas"])
            except ErroImpressao as e:
                raise Erro(str(e))
            paginas = impressao.expandir_intervalo(intervalo, u["paginas"])
            if len(paginas) > 300:
                raise Erro("Para juntar páginas, escolha até 300 de cada vez.")
            tmp = Path(tempfile.mkdtemp(prefix="montar_", dir=str(ARQUIVOS)))
            try:
                impressao.montar_paginas(u["caminho"], paginas, por_folha, str(destino), str(tmp))
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            nome = f"{u['nome']} ({por_folha} páginas por folha)"
            desc = {"modo": modo, "por_folha": por_folha, "intervalo": intervalo}
        folhas_pdf = impressao.contar_paginas_pdf(str(destino))
    except ErroImpressao as e:
        apagar_arquivo(str(destino))
        raise Erro(str(e))
    except Erro:
        apagar_arquivo(str(destino))
        raise
    with LOCK:
        DB.execute("INSERT INTO uploads(id, usuario_id, caminho, nome, tipo, paginas, criado_em, origens) "
                   "VALUES(?,?,?,?,?,?,?,?)", (novo, req.uid, str(destino), nome[:200], "pdf", folhas_pdf, agora(),
                                                json.dumps(ids)))
        if velho:
            DB.execute("DELETE FROM uploads WHERE id=?", (velho["id"],))
            apagar_arquivo(velho["caminho"])
            apagar_previas(velho["id"])
        DB.commit()
    return {"upload": {"id": novo, "nome": nome, "paginas": folhas_pdf, "tipo": "pdf", "montagem": True},
            "montagem": desc}


def ler_escala(valor, tipo):
    """Tamanho pedido em %; valores vazios preservam compatibilidade antiga. Foto não tem escala de documento."""
    if tipo == "imagem":
        return ""
    try:
        return impressao.ler_escala(valor)
    except ErroImpressao as e:
        raise Erro(str(e))


def executar_impressao(uid, impressora_id, caminho, tipo, nome_arquivo, paginas_doc, copias, intervalo_txt,
                       frente_verso, finalidade="", descricao="", etapa="", conferencia_id=None, alem="", escala=""):
    """Confere a cota e a finalidade, registra e envia para a impressora real. Lança Erro se não puder."""
    escala = ler_escala(escala, tipo)
    mes = mes_atual()
    with LOCK:
        try:
            lic = estado_licenca()
            if not lic["pode_imprimir"]:
                raise Erro(lic["mensagem"], 403, "licenca")
            imp = imp_por_id(impressora_id)
            copias = inteiro(copias, "número de cópias", 1, int(cfg("max_copias") or 60))
            if tipo == "imagem":
                intervalo, sel = "", 1
            else:
                try:
                    intervalo, sel = impressao.interpretar_intervalo(intervalo_txt, paginas_doc)
                except ErroImpressao as e:
                    raise Erro(str(e))
            total = sel * copias
            finalidade, descricao = conferir_finalidade(uid, imp, finalidade, descricao, total, mes)
            excedente = conferir_cota(uid, imp, total, mes, alem)
            just = (alem or "").strip()[:500] if excedente else ""
            status_inicial = "enviando" if imp["sistema"] else "teste"
            cur = DB.execute(
                "INSERT INTO trabalhos(usuario_id, impressora_id, mes, arquivo, paginas_doc, paginas_sel, "
                "copias, total, intervalo, frente_verso, status, criado_em, custo_unit, finalidade, descricao, "
                "etapa, conferencia_id, excedente, justificativa, escala) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (uid, imp["id"], mes, nome_arquivo, paginas_doc, sel, copias, total, intervalo,
                 int(frente_verso), status_inicial, agora(), imp["custo_pagina"] or None, finalidade, descricao,
                 etapa, conferencia_id, excedente, just, escala))
            tid = cur.lastrowid
            DB.commit()
            sumatra = cfg("sumatra")
        except Exception:
            DB.rollback()
            raise

    erro, job = None, ""
    # no Linux, com o CUPS respondendo, a impressão é acompanhada até sair da fila (veja acompanhar_fila)
    acomp = bool(imp["sistema"]) and acompanhar.disponivel()
    pelo_contador = acomp and usa_contador(imp)
    if imp["sistema"]:
        try:
            saida = impressao.imprimir(caminho, imp["sistema"], copias, intervalo, frente_verso,
                                       imagem=(tipo == "imagem"), sumatra_cfg=sumatra, segurar=pelo_contador,
                                       escala=escala, area=area_impressora(imp) if escala else None)
            job = acompanhar.id_do_trabalho(saida, imp["sistema"]) if acomp else ""
        except ErroImpressao as e:
            erro = str(e)

    with LOCK:
        if imp["sistema"]:
            if erro:
                DB.execute("UPDATE trabalhos SET status='erro', erro=? WHERE id=?", (erro, tid))
            elif job:
                DB.execute("UPDATE trabalhos SET status='na_fila', job_sistema=?, pedido=?, fila_etapa=?, fila_motivo=? "
                           "WHERE id=?", (job, total, 1 if pelo_contador else 0,
                                          "Aguardando a vez na impressora" if pelo_contador else "Na fila da impressora", tid))
            else:
                if pelo_contador:  # não deu para saber o número: não deixa o trabalho retido para sempre
                    acompanhar.liberar_ultimo(imp["sistema"])
                DB.execute("UPDATE trabalhos SET status='impresso' WHERE id=?", (tid,))
        if excedente and not erro:
            registrar_negativo(uid, imp, excedente, just, tid, mes)
        DB.commit()
        novo = saldo(uid, imp["id"], mes)
    if job:
        ACOMP["evento"].set()
    if erro:
        raise Erro(f"Não imprimiu: {erro} Sua cota não foi descontada.", 502, "erro_impressora")
    return {"ok": True, "trabalho_id": tid, "total": total, "teste": not imp["sistema"], "excedente": excedente,
            "restante": novo["restante"], "impressora": imp["nome"], "acompanhando": bool(job),
            "custo": round(total * (imp["custo_pagina"] or 0), 2)}


def conferir_cota(uid, imp, total, mes, alem=""):
    """Confere se cabe na cota. Devolve quantas páginas passam da cota (0 quando cabe). Com cota negativa
    permitida pela gestão, deixa passar até o limite do mês se vier a justificativa (alem)."""
    s = saldo(uid, imp["id"], mes)
    if total > s["restante"]:
        falta = total - max(s["restante"], 0)
        neg = info_negativo(uid, mes)
        if neg["resta"] >= falta:
            if len((alem or "").strip()) < 5:
                raise Erro(f"{'Falta' if falta == 1 else 'Faltam'} {falta} {'página' if falta == 1 else 'páginas'} na "
                           f"{imp['nome']}. Você pode imprimir além da cota (até {neg['resta']} este mês), "
                           "escrevendo a justificativa." + (" O que passar sai da sua cota do mês que vem."
                                                            if neg["desconta"] else ""),
                           409, "pode_negativo", dados={"falta": falta, "resta": neg["resta"],
                                                        "desconta": neg["desconta"]})
            return falta
        if s["restante"] <= 0:
            msg = (f"Sua cota da {imp['nome']} acabou este mês. "
                   f"Peça páginas a colegas na aba Conversas.")
        else:
            msg = (f"Esta impressão usa {total} páginas e você tem {s['restante']} na "
                   f"{imp['nome']}. {'Falta' if falta == 1 else 'Faltam'} {falta}. Reduza as cópias ou peça páginas a colegas.")
        if neg["aumento"]:
            msg += " Ou peça aumento de cota à gestão."
        raise Erro(msg, 409, "sem_cota", dados={"falta": falta, "aumento": neg["aumento"]})
    return 0


def plano_de_prova(tipo, paginas_doc, intervalo_txt, copias, frente_verso, prova):
    """Divide a impressão em prova + resto. Devolve None quando não sobra nada para conferir."""
    if prova not in ("folha", "copia"):
        return None
    if tipo == "imagem":
        paginas = [1]
        doc = 1
    else:
        try:
            intervalo, _ = impressao.interpretar_intervalo(intervalo_txt, paginas_doc)
        except ErroImpressao as e:
            raise Erro(str(e))
        doc = paginas_doc
        paginas = impressao.expandir_intervalo(intervalo, paginas_doc)
    juntar = lambda ps: impressao.juntar_intervalo(ps, doc) if tipo != "imagem" else ""  # noqa: E731
    if prova == "folha":
        k = 2 if frente_verso and len(paginas) >= 2 else 1
        if len(paginas) <= k and copias == 1:
            return None
        prova_pags = paginas[:k]
        resto = []
        if len(paginas) > k:
            resto.append([juntar(paginas[k:]), 1])
        if copias > 1:
            resto.append([juntar(paginas), copias - 1])
    else:
        if copias <= 1:
            return None
        prova_pags = paginas
        resto = [[juntar(paginas), copias - 1]]
    return {"prova_intervalo": juntar(prova_pags), "prova_total": len(prova_pags),
            "resto": resto, "resto_total": sum(len(impressao.expandir_intervalo(i, doc)) * c for i, c in resto),
            "total": len(paginas) * copias}


def imprimir_ou_provar(uid, arq, impressora_id, copias, intervalo, frente_verso, finalidade, descricao, prova,
                       retida_id=None, alem="", escala=""):
    """Imprime tudo ou, com prova, só a primeira parte, guardando o arquivo até a pessoa conferir.
    arq: {caminho, tipo, nome, paginas}. Devolve o resultado e se o arquivo ficou guardado."""
    escala = ler_escala(escala, arq["tipo"])
    copias_n = inteiro(copias, "número de cópias", 1, int(cfg("max_copias") or 60))
    plano = plano_de_prova(arq["tipo"], arq["paginas"], intervalo, copias_n, frente_verso, prova)
    if not plano:
        with LOCK:
            if arq["tipo"] == "imagem":
                total = copias_n
            else:
                try:
                    total = impressao.interpretar_intervalo(intervalo, arq["paginas"])[1] * copias_n
                except ErroImpressao as e:
                    raise Erro(str(e))
            # com "só a 1ª folha" e até 2 páginas, a prova já é a impressão inteira
            if prova_obrigatoria(total) and not (prova == "folha" and total <= 2):
                raise Erro(f"A partir de {cfg('prova_minimo')} páginas, {L('o')} pede que você imprima uma prova "
                           "antes e confira.", 409, "prova_obrigatoria")
        r = executar_impressao(uid, impressora_id, arq["caminho"], arq["tipo"], arq["nome"], arq["paginas"],
                               copias_n, intervalo, frente_verso, finalidade, descricao, alem=alem, escala=escala)
        return r, False
    mes = mes_atual()
    with LOCK:
        imp = imp_por_id(impressora_id)
        fin, desc = conferir_finalidade(uid, imp, finalidade, descricao, plano["total"], mes)
        conferir_cota(uid, imp, plano["total"], mes, alem)
        cid = DB.execute(
            "INSERT INTO conferencias(usuario_id, caminho, tipo, nome, paginas_doc, impressora_id, frente_verso, "
            "finalidade, descricao, prova, prova_total, resto, resto_total, retida_id, status, criado_em, "
            "atualizado_em, alem, escala) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'preparando',?,?,?,?)",
            (uid, arq["caminho"], arq["tipo"], arq["nome"], arq["paginas"], imp["id"], int(frente_verso), fin, desc,
             prova, plano["prova_total"], json.dumps(plano["resto"]), plano["resto_total"], retida_id,
             agora(), agora(), (alem or "").strip()[:500], escala)).lastrowid
        DB.commit()
    try:
        os.utime(arq["caminho"])
    except OSError:
        pass
    try:
        r = executar_impressao(uid, imp["id"], arq["caminho"], arq["tipo"], arq["nome"], arq["paginas"], 1,
                               plano["prova_intervalo"], frente_verso, fin, desc, "prova", cid, alem=alem,
                               escala=escala)
    except Exception:
        with LOCK:
            DB.execute("DELETE FROM conferencias WHERE id=?", (cid,))
            DB.commit()
        raise
    with LOCK:
        DB.execute("UPDATE conferencias SET status='aguardando', trabalho_prova=?, atualizado_em=? WHERE id=?",
                   (r["trabalho_id"], agora(), cid))
        DB.commit()
        c = uma(DB.execute("SELECT * FROM conferencias WHERE id=?", (cid,)))
    r["conferencia"] = formatar_conferencia(c)
    return r, True


@rota("POST", "/api/imprimir", trava=False)
def r_imprimir(req):
    with LOCK:
        up = uma(DB.execute("SELECT * FROM uploads WHERE id=? AND usuario_id=?",
                            (str(req.b("upload_id")), req.uid)))
    if not up or not os.path.isfile(up["caminho"]):
        raise Erro("O arquivo não está mais disponível. Envie de novo.")
    r, guardado = imprimir_ou_provar(
        req.uid, up, req.b("impressora_id"), req.b("copias", 1),
        req.b("intervalo") if up["tipo"] != "imagem" else "", bool(req.b("frente_verso")),
        req.b("finalidade"), req.b("descricao"), str(req.b("prova") or ""), alem=str(req.b("alem") or ""),
        escala="" if up.get("imagem") else req.b("escala"))  # foto tem o próprio tamanho na folha
    with LOCK:
        DB.execute("DELETE FROM uploads WHERE id=?", (up["id"],))
        apagar_envio(up)
        DB.commit()
    if not guardado:
        apagar_arquivo(up["caminho"])
    return r


def lista_nomes(nomes):
    nomes = [f'"{x}"' for x in nomes]
    if len(nomes) > 3:
        return f"{len(nomes)} arquivos"
    return nomes[0] if len(nomes) == 1 else ", ".join(nomes[:-1]) + " e " + nomes[-1]


def imprimir_varios(uid, itens, impressora_id, finalidade, descricao, prova, concluir, alem=""):
    """Imprime vários arquivos na mesma impressora e com a mesma finalidade. Cada arquivo vira uma impressão
    própria (aparece com o próprio nome nos relatórios e começa numa folha nova).
    itens: [{"id", "arq": {caminho, tipo, nome, paginas}, "copias", "intervalo", "frente_verso", "retida_id"?}].
    Antes do primeiro, confere a licença, a finalidade e a cota do total: ou cabe tudo, ou nada sai.
    Se a impressora falhar no meio, os que saíram ficam contados e o erro diz quais faltam (dados.faltam)."""
    prova = prova if prova in ("folha", "copia") else ""
    max_c = int(cfg("max_copias") or 60)
    for it in itens:
        it["copias"] = inteiro(it["copias"], "número de cópias", 1, max_c)
        arq = it["arq"]
        it["escala"] = ler_escala(it.get("escala"), arq["tipo"])
        if arq["tipo"] == "imagem":
            it["intervalo"], sel = "", 1
        else:
            try:
                sel = impressao.interpretar_intervalo(it["intervalo"], arq["paginas"])[1]
            except ErroImpressao as e:
                raise Erro(f'"{arq["nome"]}": {e}')
        it["total"] = sel * it["copias"]
        # a prova escolhida vale para cada arquivo; quem passa do limite da prova obrigatória sai com a 1ª folha
        p = prova
        if p and not plano_de_prova(arq["tipo"], arq["paginas"], it["intervalo"], it["copias"], it["frente_verso"], p):
            p = ""
        if not p and prova_obrigatoria(it["total"]) and not it["total"] <= 2:
            p = "folha"
        it["prova"] = p
    total = sum(it["total"] for it in itens)
    mes = mes_atual()
    with LOCK:
        lic = estado_licenca()
        if not lic["pode_imprimir"]:
            raise Erro(lic["mensagem"], 403, "licenca")
        imp = imp_por_id(impressora_id)
        conferir_finalidade(uid, imp, finalidade, descricao, total, mes)
        conferir_cota(uid, imp, total, mes, alem)
    feitos, conferencias, ultimo = [], [], None
    for k, it in enumerate(itens):
        try:
            r, guardado = imprimir_ou_provar(uid, it["arq"], imp["id"], it["copias"], it["intervalo"],
                                             it["frente_verso"], finalidade, descricao, it["prova"],
                                             retida_id=it.get("retida_id"), alem=alem, escala=it.get("escala", ""))
        except Exception as e:
            if not feitos:
                raise
            motivo = e.msg if isinstance(e, Erro) else "erro inesperado."
            motivo = motivo.removeprefix("Não imprimiu: ").removesuffix(" Sua cota não foi descontada.")
            resto = len(itens) - k
            raise Erro(f'{lista_nomes([f["nome"] for f in feitos])} {"foi" if len(feitos) == 1 else "foram"} '
                       f'para a impressora. "{it["arq"]["nome"]}" não saiu: {motivo} '
                       + ("Ele não foi descontado; tente de novo." if resto == 1 else
                          "Ele e o outro que faltava não foram descontados; tente de novo." if resto == 2 else
                          f"Ele e os outros {resto - 1} que faltavam não foram descontados; tente de novo."),
                       getattr(e, "status", 500), "lote_parcial",
                       dados={"feitos": [f["id"] for f in feitos], "faltam": [x["id"] for x in itens[k:]]})
        concluir(it, r, guardado)
        feitos.append({"id": it["id"], "nome": it["arq"]["nome"], "total": r["total"], "prova": guardado,
                       "custo": r.get("custo") or 0})
        if guardado:
            conferencias.append(r["conferencia"])
        ultimo = r
    return {"ok": True, "lote": True, "arquivos": feitos, "total": sum(f["total"] for f in feitos),
            "custo": round(sum(f["custo"] for f in feitos), 2), "teste": ultimo["teste"],
            "acompanhando": bool(ultimo.get("acompanhando")),
            "restante": ultimo["restante"], "impressora": ultimo["impressora"], "conferencias": conferencias}


@rota("POST", "/api/imprimir-lote", trava=False)
def r_imprimir_lote(req):
    """Vários arquivos enviados pelo app, com as mesmas opções (impressora, cópias, lados, finalidade)."""
    ids = req.b("uploads")
    if not isinstance(ids, list) or not ids:
        raise Erro("Escolha os arquivos.")
    ids = list(dict.fromkeys(str(i) for i in ids))
    if len(ids) > MAX_LOTE:
        raise Erro(f"Imprima até {MAX_LOTE} arquivos de cada vez.")
    itens = []
    with LOCK:
        for i in ids:
            up = uma(DB.execute("SELECT * FROM uploads WHERE id=? AND usuario_id=?", (i, req.uid)))
            if not up or not os.path.isfile(up["caminho"]):
                raise Erro("Um dos arquivos não está mais disponível. Envie de novo.")
            itens.append({"id": up["id"], "arq": up, "copias": req.b("copias", 1), "intervalo": "",
                          "frente_verso": bool(req.b("frente_verso")),
                          "escala": "" if up.get("imagem") else req.b("escala")})  # fotos saem como sempre

    def concluir(it, r, guardado):
        up = it["arq"]
        with LOCK:
            DB.execute("DELETE FROM uploads WHERE id=?", (up["id"],))
            apagar_envio(up)
            DB.commit()
        if not guardado:
            apagar_arquivo(up["caminho"])

    return imprimir_varios(req.uid, itens, req.b("impressora_id"), req.b("finalidade"), req.b("descricao"),
                           str(req.b("prova") or ""), concluir, alem=str(req.b("alem") or ""))


# ---------------------------------------------------------------- conferência depois da prova

def horas_conferencia():
    return min(max(int(cfg("horas_fila") or 4), 1), 12)


def expirar_conferencias():
    limite = (dt.datetime.now() - dt.timedelta(hours=horas_conferencia())).strftime("%Y-%m-%d %H:%M:%S")
    for c in linhas(DB.execute("SELECT id, caminho, retida_id FROM conferencias WHERE status='aguardando' "
                               "AND atualizado_em<?", (limite,))):
        encerrar_conferencia(c, "expirada")


def encerrar_conferencia(c, status, guardar_arquivo=False):
    if not guardar_arquivo:
        apagar_arquivo(c["caminho"])
    apagar_previas(f"c{c['id']}")
    DB.execute("UPDATE conferencias SET status=?, caminho=?, atualizado_em=? WHERE id=?",
               (status, c["caminho"] if guardar_arquivo else "", agora(), c["id"]))
    if c.get("retida_id"):
        DB.execute("UPDATE retidas SET status=?, caminho='', atualizado_em=? WHERE id=? AND status='conferencia'",
                   ("impresso" if status == "concluida" else "descartado", agora(), c["retida_id"]))


def conferencias_de(uid):
    expirar_conferencias()
    return linhas(DB.execute("SELECT * FROM conferencias WHERE usuario_id=? AND status='aguardando' ORDER BY id DESC",
                             (uid,)))


def formatar_conferencia(c):
    imp = uma(DB.execute("SELECT nome, cor FROM impressoras WHERE id=?", (c["impressora_id"],))) or {}
    return {"id": c["id"], "nome": c["nome"], "prova": c["prova"], "prova_total": c["prova_total"],
            "resto_total": c["resto_total"], "impressora_id": c["impressora_id"], "impressora": imp.get("nome"),
            "cor": imp.get("cor"), "frente_verso": bool(c["frente_verso"]), "finalidade": c["finalidade"],
            "descricao": c["descricao"], "criado_em": c["criado_em"],
            "expira_em": (dt.datetime.strptime(c["atualizado_em"], "%Y-%m-%d %H:%M:%S")
                          + dt.timedelta(hours=horas_conferencia())).strftime("%Y-%m-%d %H:%M:%S")}


def conferencia_da_pessoa(uid, cid):
    expirar_conferencias()
    c = uma(DB.execute("SELECT * FROM conferencias WHERE id=? AND usuario_id=? AND status='aguardando'",
                       (cid, uid)))
    if not c or not os.path.isfile(c["caminho"]):
        raise Erro("Esta prova não está mais esperando. Ela pode ter sido concluída, cancelada ou passado do prazo.")
    return c


@rota("GET", "/api/conferencias")
def r_conferencias(req):
    return {"conferencias": [formatar_conferencia(c) for c in conferencias_de(req.uid)],
            "horas": horas_conferencia()}


@rota("POST", "/api/conferencia/continuar", trava=False)
def r_conf_continuar(req):
    """A prova saiu certa: imprime o resto."""
    cid = inteiro(req.b("id"), "prova")
    with LOCK:
        c = conferencia_da_pessoa(req.uid, cid)
        DB.execute("UPDATE conferencias SET status='imprimindo' WHERE id=?", (cid,))
        DB.commit()
    resto = json.loads(c["resto"] or "[]")
    feitos, total, ultimo = [], 0, None
    try:
        while resto:
            intervalo, copias = resto[0]
            ultimo = executar_impressao(req.uid, c["impressora_id"], c["caminho"], c["tipo"], c["nome"],
                                        c["paginas_doc"], copias, intervalo, bool(c["frente_verso"]),
                                        c["finalidade"], c["descricao"], "resto", cid,
                                        alem=str(req.b("alem") or "") or c.get("alem") or "",
                                        escala=c.get("escala") or "")
            total += ultimo["total"]
            feitos.append(ultimo["trabalho_id"])
            resto.pop(0)
            with LOCK:
                DB.execute("UPDATE conferencias SET resto=?, resto_total=resto_total-? WHERE id=?",
                           (json.dumps(resto), ultimo["total"], cid))
                DB.commit()
    except Exception:
        with LOCK:
            DB.execute("UPDATE conferencias SET status='aguardando', atualizado_em=? WHERE id=?", (agora(), cid))
            DB.commit()
        raise
    with LOCK:
        c = uma(DB.execute("SELECT * FROM conferencias WHERE id=?", (cid,)))
        if c.get("retida_id") and feitos:
            DB.execute("UPDATE retidas SET trabalho_id=? WHERE id=?", (feitos[-1], c["retida_id"]))
        encerrar_conferencia(c, "concluida")
        DB.commit()
    ultimo = ultimo or {"ok": True, "teste": False, "impressora": "", "restante": 0, "custo": 0}
    return {**ultimo, "total": total, "resto": True}


def para_envio(uid, caminho, tipo, nome, paginas):
    """Coloca um arquivo guardado de volta na tela Imprimir, para ajustar páginas, lados e cópias."""
    uid_arq = uuid.uuid4().hex
    destino = ARQUIVOS / f"{uid_arq}{Path(caminho).suffix.lower() or ('.pdf' if tipo == 'pdf' else '.png')}"
    try:
        shutil.move(str(caminho), str(destino))
        os.utime(destino)  # a limpeza de arquivos antigos conta a partir de agora
    except OSError:
        raise Erro("O arquivo não está mais disponível. Envie de novo.")
    DB.execute("INSERT INTO uploads(id, usuario_id, caminho, nome, tipo, paginas, criado_em) VALUES(?,?,?,?,?,?,?)",
               (uid_arq, uid, str(destino), nome, tipo, paginas, agora()))
    return {"id": uid_arq, "nome": nome, "paginas": paginas, "tipo": tipo}


@rota("POST", "/api/conferencia/ajustar")
def r_conf_ajustar(req):
    """A prova saiu errada: o arquivo volta para a tela Imprimir; o resto não é impresso."""
    c = conferencia_da_pessoa(req.uid, inteiro(req.b("id"), "prova"))
    up = para_envio(req.uid, c["caminho"], c["tipo"], c["nome"], c["paginas_doc"])
    encerrar_conferencia({**c, "caminho": ""}, "ajustada")
    return {"ok": True, "upload": up, "finalidade": c["finalidade"], "descricao": c["descricao"],
            "impressora_id": c["impressora_id"]}


@rota("POST", "/api/conferencia/cancelar")
def r_conf_cancelar(req):
    c = conferencia_da_pessoa(req.uid, inteiro(req.b("id"), "prova"))
    encerrar_conferencia(c, "cancelada")
    return {"ok": True}


# ---------------------------------------------------------------- impressões aguardando liberação

def nomes_computador(u):
    return {n.strip().lower() for n in (u.get("nomes_computador") or "").replace(";", ",").split(",") if n.strip()}


def expirar_retidas():
    horas = int(cfg("horas_fila") or 4)
    limite = (dt.datetime.now() - dt.timedelta(hours=horas)).strftime("%Y-%m-%d %H:%M:%S")
    for r in linhas(DB.execute("SELECT id, caminho FROM retidas WHERE status IN ('aguardando','recebendo') "
                               "AND criado_em<?", (limite,))):
        apagar_arquivo(r["caminho"])
        DB.execute("UPDATE retidas SET status='expirado', caminho='', atualizado_em=? WHERE id=?", (agora(), r["id"]))


def apagar_arquivo(caminho):
    if caminho:
        try:
            os.remove(caminho)
        except OSError:
            pass


# ---------------------------------------------------------------- prévia (só a própria pessoa vê o próprio arquivo)

PREVIAS_LOCK = threading.Semaphore(2)


def pasta_previas():
    p = ARQUIVOS / "previas"
    p.mkdir(parents=True, exist_ok=True)
    return p


def apagar_previas(chave):
    p = ARQUIVOS / "previas"
    if not p.is_dir() or not re.fullmatch(r"[0-9a-zA-Z]+", str(chave)):
        return
    for f in p.glob(f"{chave}-*.png"):
        try:
            f.unlink()
        except OSError:
            pass


def arquivo_da_previa(req):
    """Acha o arquivo pedido para a prévia, conferindo que é da pessoa. Devolve (caminho, tipo, páginas, chave)."""
    origem, ident = req.q("origem"), req.q("id") or ""
    with LOCK:
        if origem == "upload":
            a = uma(DB.execute("SELECT * FROM uploads WHERE id=? AND usuario_id=?", (ident, req.uid)))
            if a:
                return a["caminho"], a["tipo"], a["paginas"], a["id"]
        elif origem == "retida" and ident.isdigit():
            a = next((x for x in retidas_visiveis(req.usuario, req.ip) if x["id"] == int(ident)), None)
            if a:
                return a["caminho"], a["tipo"], a["paginas"], f"r{a['id']}"
        elif origem == "conferencia" and ident.isdigit():
            a = uma(DB.execute("SELECT * FROM conferencias WHERE id=? AND usuario_id=? AND status='aguardando'",
                               (int(ident), req.uid)))
            if a:
                return a["caminho"], a["tipo"], a["paginas_doc"], f"c{a['id']}"
    raise Erro("Este arquivo não está mais disponível para a prévia.", 404)


@rota("GET", "/api/previa", trava=False)
def r_previa(req):
    caminho, tipo, paginas, _ = arquivo_da_previa(req)
    return {"tipo": tipo, "paginas": paginas,
            "imagens": tipo == "imagem" or bool(impressao.achar_renderizador())}


@rota("GET", "/api/previa/pagina", trava=False)
def r_previa_pagina(req):
    caminho, tipo, paginas, chave = arquivo_da_previa(req)
    if not os.path.isfile(caminho):
        raise Erro("Este arquivo não está mais disponível para a prévia.", 404)
    if tipo == "imagem":
        dados = Path(caminho).read_bytes()
        return Resposta(dados, "image/png" if dados[:4] == b"\x89PNG" else "image/jpeg")
    pag = inteiro(req.q("p") or 1, "página", 1, max(paginas, 1))
    destino = pasta_previas() / f"{chave}-{pag}.png"
    if not destino.is_file():
        with PREVIAS_LOCK:
            if not destino.is_file() and not impressao.renderizar_pagina(caminho, pag, destino):
                raise Erro("Não deu para desenhar esta página.", 404, "sem_previa")
    return Resposta(destino.read_bytes(), "image/png")


@rota("GET", "/api/previa/pdf", trava=False)
def r_previa_pdf(req):
    caminho, tipo, paginas, chave = arquivo_da_previa(req)
    if tipo != "pdf" or not os.path.isfile(caminho):
        raise Erro("Este arquivo não está mais disponível para a prévia.", 404)
    return Resposta(Path(caminho).read_bytes(), "application/pdf",
                    {"Content-Disposition": 'inline; filename="previa.pdf"'})


def retidas_visiveis(u, ip):
    """Impressões que esta pessoa pode liberar: as que saíram do aparelho onde ela está agora
    ou as enviadas com o nome de usuário dela no computador."""
    expirar_retidas()
    nomes = nomes_computador(u)
    locais = ips_deste_computador()
    saida = []
    for r in linhas(DB.execute("SELECT * FROM retidas WHERE status='aguardando' ORDER BY id DESC")):
        if r["usuario_id"]:  # chegou com alguém conectado (ou com o login do computador dela): só ela vê
            if r["usuario_id"] == u["id"]:
                saida.append(r)
            continue
        # no computador do sistema, quem abre o app por localhost ou pelo IP da rede é o mesmo aparelho
        mesmo_aparelho = r["ip"] == ip or (r["ip"] in locais and ip in locais)
        if mesmo_aparelho or (r["usuario_so"] or "").lower() in nomes:
            saida.append(r)
    return saida


_LOCAIS = {"t": 0, "v": set()}


CONECTADO_SEG = 180  # o app aberto (mesmo em segundo plano) dá sinal a cada 30 s; o navegador pode atrasar até 1 min


def pessoas_conectadas(ip):
    """Quem está com o app aberto e desbloqueado neste aparelho agora."""
    locais = ips_deste_computador()
    agora_d = dt.datetime.now()
    limite = (agora_d - dt.timedelta(seconds=CONECTADO_SEG)).strftime("%Y-%m-%d %H:%M:%S")
    minutos = int(cfg("bloqueio_minutos") or 0)
    lim_uso = (agora_d - dt.timedelta(minutes=minutos)).strftime("%Y-%m-%d %H:%M:%S") if minutos else ""
    ids = set()
    for s in linhas(DB.execute(
            "SELECT s.ip, s.usuario_id, s.bloqueada, s.atividade_em, s.criado_em FROM sessoes s JOIN usuarios u "
            "ON u.id=s.usuario_id WHERE u.ativo=1 AND COALESCE(u.trocar_senha,0)=0 AND s.visto_em>=?", (limite,))):
        sip = s["ip"] or ""
        if not (sip == ip or (sip in locais and ip in locais)):
            continue
        if minutos and (s["bloqueada"] or (s["atividade_em"] or s["criado_em"] or "") < lim_uso):
            continue
        ids.add(s["usuario_id"])
    return ids


def dono_da_impressao(ip, usuario_so):
    """De quem é o que chegou na impressora Folha a Folha: de quem está conectado no aparelho ou de quem tem
    esse login do computador na ficha. Devolve (id ou None, problema ou None)."""
    conectados = pessoas_conectadas(ip)
    if len(conectados) == 1:
        return next(iter(conectados)), None
    if len(conectados) > 1:
        return None, ("Há mais de uma pessoa com o app Folha a Folha aberto neste aparelho. "
                      "Saia das outras contas e imprima de novo.")
    nome = (usuario_so or "").strip().lower()
    if nome:
        achados = [u["id"] for u in linhas(DB.execute(
            "SELECT id, nomes_computador FROM usuarios WHERE ativo=1 AND anonimizado=0 AND nomes_computador<>''"))
                   if nome in nomes_computador(u)]
        if len(achados) == 1:
            return achados[0], None
    return None, None


def conferir_quem_imprime(pedido, ip, versao):
    """(dono, resposta de recusa). Com "só de quem está conectado" ligado, sem dono o trabalho é recusado."""
    with LOCK:
        if cfg("ipp_so_conectado") != "1":
            return None, None  # desligado: como na 2.0, quem abrir o app no aparelho (ou tiver o login na ficha) vê
        dono, problema = dono_da_impressao(ip, pedido.op("requesting-user-name"))
    if dono:
        return dono, None
    app = ENDERECOS[0] if ENDERECOS else "o app Folha a Folha"
    msg = problema or (f"Ninguém está com o app aberto e desbloqueado neste aparelho. Abra {app}, entre com seu "
                       "usuário e senha (ou desbloqueie) e imprima de novo.")
    return None, ipp.Resposta(ipp.ERRO_CONTA, pedido.request_id, versao, msg[:255])


def ips_deste_computador():
    if time.time() - _LOCAIS["t"] > 300:
        _LOCAIS["v"] = {"127.0.0.1", "::1", "::ffff:127.0.0.1", *ips_locais()}
        _LOCAIS["t"] = time.time()
    return _LOCAIS["v"]


def sugerir_impressora(uid, r, total):
    imps = impressoras()
    if not imps:
        return None
    if r["impressora_id"] and any(i["id"] == r["impressora_id"] for i in imps):
        return r["impressora_id"]
    mes = mes_atual()
    ultima = DB.execute("SELECT impressora_id FROM trabalhos WHERE usuario_id=? ORDER BY id DESC LIMIT 1",
                        (uid,)).fetchone()
    if ultima and any(i["id"] == ultima[0] for i in imps) and saldo(uid, ultima[0], mes)["restante"] >= total:
        return ultima[0]
    for i in imps:
        if saldo(uid, i["id"], mes)["restante"] >= total:
            return i["id"]
    return imps[0]["id"]


def formatar_retida(r, uid):
    sel = r["paginas"]
    if r["tipo"] != "imagem" and r["intervalo"]:
        try:
            sel = impressao.interpretar_intervalo(r["intervalo"], r["paginas"])[1]
        except ErroImpressao:
            sel = r["paginas"]
    total = sel * (r["copias"] or 1)
    return {"id": r["id"], "nome": r["nome"], "paginas": r["paginas"], "paginas_sel": sel, "copias": r["copias"],
            "intervalo": r["intervalo"], "frente_verso": bool(r["frente_verso"]), "total": total,
            "criado_em": r["criado_em"], "usuario_so": r["usuario_so"], "tipo": r["tipo"],
            "impressora_sugerida": sugerir_impressora(uid, r, total)}


@rota("GET", "/api/retidas")
def r_retidas(req):
    return {"retidas": [formatar_retida(r, req.uid) for r in retidas_visiveis(req.usuario, req.ip)],
            "horas": int(cfg("horas_fila") or 4)}


def retida_da_pessoa(req, rid):
    r = next((x for x in retidas_visiveis(req.usuario, req.ip) if x["id"] == rid), None)
    if not r and req.usuario["papel"] == "admin":
        r = uma(DB.execute("SELECT * FROM retidas WHERE id=? AND status='aguardando'", (rid,)))
    if not r:
        raise Erro("Esta impressão não está mais aguardando. Ela pode ter sido liberada, descartada ou expirado.")
    return r


@rota("POST", "/api/retidas/liberar", trava=False)
def r_liberar(req):
    rid = inteiro(req.b("id"), "impressão")
    with LOCK:
        r = retida_da_pessoa(req, rid)
        DB.execute("UPDATE retidas SET status='liberando', atualizado_em=? WHERE id=? AND status='aguardando'",
                   (agora(), rid))
        DB.commit()
    copias = req.b("copias") or r["copias"] or 1
    lados = bool(r["frente_verso"]) if req.b("frente_verso") is None else bool(req.b("frente_verso"))
    arq = {"caminho": r["caminho"], "tipo": r["tipo"], "nome": r["nome"], "paginas": r["paginas"]}
    try:
        res, guardado = imprimir_ou_provar(req.uid, arq, req.b("impressora_id"), copias, r["intervalo"], lados,
                                           req.b("finalidade"), req.b("descricao"), str(req.b("prova") or ""),
                                           retida_id=rid, alem=str(req.b("alem") or ""),
                                           escala=req.b("escala") or "ajustar")
    except Exception:
        with LOCK:
            DB.execute("UPDATE retidas SET status='aguardando' WHERE id=? AND status='liberando'", (rid,))
            DB.commit()
        raise
    concluir_retida(req.uid, rid, r["caminho"], res, guardado)
    return res


def concluir_retida(uid, rid, caminho, res, guardado):
    with LOCK:
        if guardado:
            DB.execute("UPDATE retidas SET status='conferencia', liberado_por=?, trabalho_id=?, atualizado_em=? "
                       "WHERE id=?", (uid, res["trabalho_id"], agora(), rid))
        else:
            DB.execute("UPDATE retidas SET status='impresso', liberado_por=?, trabalho_id=?, caminho='', "
                       "atualizado_em=? WHERE id=?", (uid, res["trabalho_id"], agora(), rid))
        DB.commit()
    apagar_previas(f"r{rid}")
    if not guardado:
        apagar_arquivo(caminho)


@rota("POST", "/api/retidas/liberar-todas", trava=False)
def r_liberar_todas(req):
    """Libera de uma vez as impressões que estão esperando, na mesma impressora e com a mesma finalidade.
    Cada uma mantém as próprias cópias, páginas e lados (o app manda o que a pessoa mudou em cada cartão)."""
    pedidos = req.b("itens")
    if not isinstance(pedidos, list) or not pedidos:
        raise Erro("Nenhuma impressão escolhida.")
    if len(pedidos) > MAX_LOTE:
        raise Erro(f"Libere até {MAX_LOTE} impressões de cada vez.")
    itens, vistos = [], set()
    with LOCK:
        for p in pedidos:
            if not isinstance(p, dict):
                raise Erro("Pedido inválido.")
            rid = inteiro(p.get("id"), "impressão")
            if rid in vistos:
                continue
            vistos.add(rid)
            r = retida_da_pessoa(req, rid)
            lados = bool(r["frente_verso"]) if p.get("frente_verso") is None else bool(p.get("frente_verso"))
            itens.append({"id": rid, "retida_id": rid, "copias": p.get("copias") or r["copias"] or 1,
                          "intervalo": r["intervalo"], "frente_verso": lados, "escala": p.get("escala") or "ajustar",
                          "arq": {"caminho": r["caminho"], "tipo": r["tipo"], "nome": r["nome"], "paginas": r["paginas"]}})
        for it in itens:
            DB.execute("UPDATE retidas SET status='liberando', atualizado_em=? WHERE id=? AND status='aguardando'",
                       (agora(), it["id"]))
        DB.commit()
    try:
        return imprimir_varios(req.uid, itens, req.b("impressora_id"), req.b("finalidade"), req.b("descricao"),
                               str(req.b("prova") or ""),
                               lambda it, res, guardado: concluir_retida(req.uid, it["id"], it["arq"]["caminho"],
                                                                         res, guardado),
                               alem=str(req.b("alem") or ""))
    finally:
        # as que não chegaram a sair voltam a esperar
        with LOCK:
            DB.execute(f"UPDATE retidas SET status='aguardando' WHERE status='liberando' AND id IN "
                       f"({','.join('?' * len(itens))})", [it["id"] for it in itens])
            DB.commit()


@rota("POST", "/api/retidas/ajustar")
def r_retida_ajustar(req):
    """Leva o documento para a tela Imprimir, onde dá para escolher páginas, lados e cópias."""
    r = retida_da_pessoa(req, inteiro(req.b("id"), "impressão"))
    up = para_envio(req.uid, r["caminho"], r["tipo"], r["nome"], r["paginas"])
    DB.execute("UPDATE retidas SET status='ajustada', caminho='', liberado_por=?, atualizado_em=? WHERE id=?",
               (req.uid, agora(), r["id"]))
    apagar_previas(f"r{r['id']}")
    return {"ok": True, "upload": up, "intervalo": r["intervalo"], "copias": r["copias"] or 1,
            "frente_verso": bool(r["frente_verso"])}


@rota("POST", "/api/retidas/descartar")
def r_descartar(req):
    r = retida_da_pessoa(req, inteiro(req.b("id"), "impressão"))
    apagar_arquivo(r["caminho"])
    apagar_previas(f"r{r['id']}")
    DB.execute("UPDATE retidas SET status='descartado', caminho='', liberado_por=?, atualizado_em=? WHERE id=?",
               (req.uid, agora(), r["id"]))
    return {"ok": True}


@rota("GET", "/api/admin/retidas", auth="admin")
def r_admin_retidas(req):
    expirar_retidas()
    return {"retidas": linhas(DB.execute(
        "SELECT id, criado_em, ip, usuario_so, nome, paginas, copias, impressora_id FROM retidas "
        "WHERE status='aguardando' ORDER BY id DESC"))}


# ---------------------------------------------------------------- impressora virtual (IPP)

INICIO = int(time.time())


def fila_da_rota(caminho):
    """'/ipp/print' -> (None, nome geral); '/ipp/print/3' -> (3, nome da impressora 3)."""
    partes = caminho.rstrip("/").split("/")
    if "job" in partes:  # alguns clientes mandam para o endereço do trabalho
        partes = partes[:partes.index("job")]
    if len(partes) == 3:
        return None, "Folha a Folha"
    if len(partes) == 4 and partes[3].isdigit():
        imp = uma(DB.execute("SELECT * FROM impressoras WHERE id=? AND ativa=1", (int(partes[3]),)))
        if imp:
            return imp["id"], f"Folha a Folha - {imp['nome']}"
    raise ipp.ErroIPP("Impressora não encontrada.", ipp.ERRO_NAO_ENCONTRADO)


def uuid_fila(iid):
    base = uuid.UUID(cfg("ipp_uuid"))
    return str(base) if iid is None else str(uuid.uuid5(base, f"impressora-{iid}"))


def estado_job(r):
    st = r["status"]
    if st == "recebendo":
        return ipp.JOB_PENDENTE, "job-incoming", "Recebendo o documento."
    if st in ("aguardando", "liberando"):
        app = ENDERECOS[0] if ENDERECOS else "o app Folha a Folha"
        return ipp.JOB_CONCLUIDO, "job-completed-successfully", f"Recebido. Para imprimir, abra {app} neste aparelho e libere."
    if st == "impresso":
        return ipp.JOB_CONCLUIDO, "job-completed-successfully", "Impresso."
    if st in ("descartado", "expirado"):
        return ipp.JOB_CANCELADO, "job-canceled-by-user", "Descartado sem imprimir."
    return ipp.JOB_ABORTADO, "aborted-by-system", r["mensagem"] or "Não foi possível ler o documento."


def preparar_documento(caminho_bin, formato):
    """Converte o que chegou num arquivo imprimível. Devolve (caminho, tipo, páginas)."""
    with open(caminho_bin, "rb") as f:
        inicio = f.read(8)
    if inicio.startswith(b"%PDF") or (formato == "application/pdf" and b"%PDF" in inicio):
        destino = caminho_bin.with_suffix(".pdf")
        os.replace(caminho_bin, destino)
        return destino, "pdf", impressao.contar_paginas_pdf(str(destino))
    if raster.eh_pwg(inicio):
        destino = caminho_bin.with_suffix(".pdf")
        paginas = raster.pwg_para_pdf(caminho_bin.read_bytes(), str(destino))
        apagar_arquivo(caminho_bin)
        return destino, "pdf", paginas
    if inicio[:3] == b"\xff\xd8\xff":
        destino = caminho_bin.with_suffix(".pdf")
        impressao.imagem_para_pdf(str(caminho_bin), str(destino))
        apagar_arquivo(caminho_bin)
        return destino, "pdf", 1
    raise ipp.ErroIPP("Formato de documento não aceito. Use PDF, PWG Raster ou JPEG.", ipp.ERRO_FORMATO)


def receber_documento(rid, arquivo, formato):
    destino = FILA / f"{uuid.uuid4().hex}.bin"
    with open(destino, "wb") as f:
        shutil.copyfileobj(arquivo, f, 1024 * 1024)
    if destino.stat().st_size == 0:
        apagar_arquivo(destino)
        raise ipp.ErroIPP("O documento chegou vazio.")
    try:
        caminho, tipo, paginas = preparar_documento(destino, formato)
    except (ErroImpressao, raster.ErroRaster) as e:
        apagar_arquivo(destino)
        with LOCK:
            DB.execute("UPDATE retidas SET status='erro', mensagem=?, atualizado_em=? WHERE id=?", (str(e), agora(), rid))
            DB.commit()
        raise ipp.ErroIPP(str(e), ipp.ERRO_FORMATO)
    except ipp.ErroIPP as e:
        apagar_arquivo(destino)
        with LOCK:
            DB.execute("UPDATE retidas SET status='erro', mensagem=?, atualizado_em=? WHERE id=?", (str(e), agora(), rid))
            DB.commit()
        raise
    with LOCK:
        r = uma(DB.execute("SELECT * FROM retidas WHERE id=?", (rid,)))
        intervalo = r["intervalo"] if tipo == "pdf" and formato != "image/pwg-raster" else ""
        if intervalo:
            try:
                impressao.interpretar_intervalo(intervalo, paginas)
            except ErroImpressao:
                intervalo = ""
        DB.execute("UPDATE retidas SET status='aguardando', caminho=?, tipo=?, paginas=?, intervalo=?, "
                   "atualizado_em=? WHERE id=?", (str(caminho), tipo, paginas, intervalo, agora(), rid))
        DB.commit()
        return uma(DB.execute("SELECT * FROM retidas WHERE id=?", (rid,)))


def criar_retida(pedido, ip, impressora_id, dono=None):
    copias = pedido.job("copies", 1) or 1
    try:
        copias = max(1, min(int(copias), int(cfg("max_copias") or 60)))
    except (TypeError, ValueError):
        copias = 1
    lados = pedido.job("sides", "one-sided") or "one-sided"
    nome = (pedido.op("document-name") or pedido.op("job-name") or pedido.job("job-name") or "Documento")[:200]
    usuario = (pedido.op("requesting-user-name") or "")[:100]
    formato = pedido.op("document-format") or "application/octet-stream"
    cur = DB.execute(
        "INSERT INTO retidas(criado_em, ip, usuario_so, nome, formato, caminho, tipo, paginas, copias, intervalo, "
        "frente_verso, impressora_id, status, atualizado_em, usuario_id) VALUES(?,?,?,?,?,'','',0,?,?,?,?, 'recebendo', ?, ?)",
        (agora(), ip, usuario, nome, formato, copias, ipp.faixas_para_texto(pedido.todos("page-ranges")),
         int(lados != "one-sided"), impressora_id, agora(), dono))
    DB.commit()
    return cur.lastrowid


def resposta_job(pedido, uri, r, versao):
    resp = ipp.Resposta(ipp.OK, pedido.request_id, versao)
    resp.novo_grupo(ipp.G_TRABALHO)
    estado, motivo, msg = estado_job(r)
    criado = int(dt.datetime.strptime(r["criado_em"], "%Y-%m-%d %H:%M:%S").timestamp()) - INICIO
    resp.add_lista(ipp.atributos_trabalho(uri, r["id"], estado, r["nome"], motivo, msg, max(criado, 1)))
    return resp


def processar_ipp(pedido, arquivo, ip, host, caminho):
    versao = (2, 0) if pedido.versao[0] >= 2 else (1, 1)
    if pedido.versao[0] not in (1, 2):
        return ipp.Resposta(ipp.ERRO_VERSAO, pedido.request_id, (1, 1), "Versão de IPP não suportada.")
    with LOCK:
        impressora_id, nome = fila_da_rota(caminho)
    base = caminho.rstrip("/")
    if "/job/" in base + "/":
        base = base[:base.index("/job")]
    uri = f"ipp://{host}{base}"
    op = pedido.operacao

    if op == ipp.GET_PRINTER_ATTRIBUTES:
        with LOCK:
            fila = DB.execute("SELECT COUNT(*) FROM retidas WHERE status='aguardando'").fetchone()[0]
            local = cfg("escola")
            id_uuid = uuid_fila(impressora_id)
            fora = cfg("ipp_so_conectado") == "1" and not pessoas_conectadas(ip)
        resp = ipp.Resposta(ipp.OK, pedido.request_id, versao)
        resp.novo_grupo(ipp.G_IMPRESSORA)
        app = (ENDERECOS[0] + "/") if ENDERECOS else f"http://{host}/"
        aviso = f"Antes de imprimir, abra {app.rstrip('/')} e entre com seu usuário e senha." if fora else None
        resp.add_lista(ipp.atributos_impressora(uri, nome, f"Impressão com cota. Para imprimir, abra {app.rstrip('/')} e libere.",
                                                f"Libere em {app.rstrip('/')} · {local}"[:127], id_uuid, fila, INICIO, app, aviso))
        return resp

    if op in (ipp.VALIDATE_JOB, ipp.CLOSE_JOB, ipp.IDENTIFY_PRINTER):
        formato = pedido.op("document-format")
        if formato and formato not in ipp.FORMATOS:
            return ipp.Resposta(ipp.ERRO_FORMATO, pedido.request_id, versao, "Formato não aceito.")
        if op == ipp.VALIDATE_JOB:
            _, recusa = conferir_quem_imprime(pedido, ip, versao)
            if recusa:
                return recusa
        return ipp.Resposta(ipp.OK, pedido.request_id, versao)

    if op == ipp.PRINT_JOB:
        formato = pedido.op("document-format")
        if formato and formato not in ipp.FORMATOS:
            return ipp.Resposta(ipp.ERRO_FORMATO, pedido.request_id, versao, "Formato não aceito.")
        dono, recusa = conferir_quem_imprime(pedido, ip, versao)
        if recusa:
            return recusa
        with LOCK:
            rid = criar_retida(pedido, ip, impressora_id, dono)
        r = receber_documento(rid, arquivo, formato)
        return resposta_job(pedido, uri, r, versao)

    if op == ipp.CREATE_JOB:
        dono, recusa = conferir_quem_imprime(pedido, ip, versao)
        if recusa:
            return recusa
        with LOCK:
            rid = criar_retida(pedido, ip, impressora_id, dono)
            r = uma(DB.execute("SELECT * FROM retidas WHERE id=?", (rid,)))
        return resposta_job(pedido, uri, r, versao)

    if op in (ipp.SEND_DOCUMENT, ipp.GET_JOB_ATTRIBUTES, ipp.CANCEL_JOB):
        jid = pedido.op("job-id")
        if jid is None and pedido.op("job-uri"):
            try:
                jid = int(str(pedido.op("job-uri")).rstrip("/").rsplit("/", 1)[1])
            except (ValueError, IndexError):
                jid = None
        with LOCK:
            r = uma(DB.execute("SELECT * FROM retidas WHERE id=?", (jid,))) if jid else None
        if not r or r["ip"] != ip:
            return ipp.Resposta(ipp.ERRO_NAO_ENCONTRADO, pedido.request_id, versao, "Trabalho não encontrado.")
        if op == ipp.SEND_DOCUMENT:
            if r["status"] != "recebendo":
                return ipp.Resposta(ipp.ERRO_NAO_POSSIVEL, pedido.request_id, versao, "Trabalho já recebido.")
            formato = pedido.op("document-format") or r["formato"]
            if formato and formato not in ipp.FORMATOS:
                return ipp.Resposta(ipp.ERRO_FORMATO, pedido.request_id, versao, "Formato não aceito.")
            r = receber_documento(r["id"], arquivo, formato)
        elif op == ipp.CANCEL_JOB:
            if r["status"] not in ("recebendo", "aguardando"):
                return ipp.Resposta(ipp.ERRO_NAO_POSSIVEL, pedido.request_id, versao, "Trabalho já concluído.")
            with LOCK:
                apagar_arquivo(r["caminho"])
                DB.execute("UPDATE retidas SET status='descartado', caminho='', atualizado_em=? WHERE id=?",
                           (agora(), r["id"]))
                DB.commit()
            return ipp.Resposta(ipp.OK, pedido.request_id, versao)
        return resposta_job(pedido, uri, r, versao)

    if op == ipp.GET_JOBS:
        quais = pedido.op("which-jobs", "not-completed")
        with LOCK:
            if quais == "completed":
                rows = linhas(DB.execute("SELECT * FROM retidas WHERE ip=? AND status NOT IN ('recebendo') "
                                         "ORDER BY id DESC LIMIT 20", (ip,)))
            else:
                rows = linhas(DB.execute("SELECT * FROM retidas WHERE ip=? AND status='recebendo' "
                                         "ORDER BY id DESC LIMIT 20", (ip,)))
        resp = ipp.Resposta(ipp.OK, pedido.request_id, versao)
        for r in rows:
            estado, motivo, msg = estado_job(r)
            resp.novo_grupo(ipp.G_TRABALHO)
            resp.add_lista(ipp.atributos_trabalho(uri, r["id"], estado, r["nome"], motivo, msg, 1))
        return resp

    return ipp.Resposta(ipp.ERRO_OPERACAO, pedido.request_id, versao, "Operação não suportada.")


def info_impressora_virtual():
    porta631 = PORTA_IPP_ATIVA
    ips = ips_locais()
    ip = ips[0] if ips else "127.0.0.1"
    porta = PORTA_PRINCIPAL
    filas = [{"nome": "Folha a Folha", "caminho": "ipp/print"}]
    if cfg("filas_por_impressora") == "1":
        filas += [{"nome": f"Folha a Folha - {i['nome']}", "caminho": f"ipp/print/{i['id']}"} for i in impressoras()]
    for f in filas:
        f["windows"] = f"http://{ip}:{porta}/{f['caminho']}"
        f["linux"] = f"ipp://{ip}:{porta}/{f['caminho']}"
    return {"ip": ip, "porta": porta, "porta_631": porta631, "filas": filas, "modo": cfg("modo") or "navegador",
            "anuncio": ANUNCIO["modo"], "anunciar": cfg("anunciar_rede") == "1",
            "horas_fila": int(cfg("horas_fila") or 4), "so_conectado": cfg("ipp_so_conectado") == "1"}


# ---------------------------------------------------------------- conversas

def chave_direta(outro):
    return f"u:{outro}"


def conversas_de(uid):
    saida = []
    leit = {r["conversa"]: r["ultimo_id"] for r in
            linhas(DB.execute("SELECT conversa, ultimo_id FROM leituras WHERE usuario_id=?", (uid,)))}
    ult_mural = uma(DB.execute("SELECT m.*, u.nome AS de_nome FROM mensagens m JOIN usuarios u ON u.id=m.de_id "
                               "WHERE m.para_id IS NULL AND m.de_id NOT IN "
                               "(SELECT bloqueado_id FROM bloqueios WHERE usuario_id=?) ORDER BY m.id DESC LIMIT 1", (uid,)))
    nl = DB.execute("SELECT COUNT(*) FROM mensagens WHERE para_id IS NULL AND id>? AND de_id<>? "
                    "AND de_id NOT IN (SELECT bloqueado_id FROM bloqueios WHERE usuario_id=?)",
                    (leit.get("mural", 0), uid, uid)).fetchone()[0]
    saida.append({"chave": "mural", "nome": "Mural da equipe", "ultima": ult_mural, "nao_lidas": nl})
    meus_bloqueios = {r[0] for r in DB.execute("SELECT bloqueado_id FROM bloqueios WHERE usuario_id=?", (uid,))}
    for u in linhas(DB.execute("SELECT id, nome FROM usuarios WHERE ativo=1 AND id<>? "
                               "ORDER BY nome COLLATE NOCASE", (uid,))):
        if u["id"] in meus_bloqueios:
            saida.append({"chave": chave_direta(u["id"]), "nome": u["nome"], "ultima": None, "nao_lidas": 0,
                          "usuario_id": u["id"], "bloqueado": True})
            continue
        ult = uma(DB.execute("SELECT * FROM mensagens WHERE (de_id=? AND para_id=?) OR (de_id=? AND para_id=?) "
                             "ORDER BY id DESC LIMIT 1", (uid, u["id"], u["id"], uid)))
        nl = DB.execute("SELECT COUNT(*) FROM mensagens WHERE de_id=? AND para_id=? AND id>?",
                        (u["id"], uid, leit.get(chave_direta(u["id"]), 0))).fetchone()[0]
        if ult:
            ult["de_nome"] = u["nome"] if ult["de_id"] == u["id"] else None
        saida.append({"chave": chave_direta(u["id"]), "nome": u["nome"], "ultima": ult, "nao_lidas": nl,
                      "usuario_id": u["id"]})
    return saida


def resolver_conversa(uid, chave):
    if chave == "mural":
        return None
    if isinstance(chave, str) and chave.startswith("u:"):
        outro = inteiro(chave[2:], "conversa")
        if outro == uid:
            raise Erro("Conversa inválida.")
        usuario_ativo(outro)
        return outro
    raise Erro("Conversa inválida.")


def formatar_pedido(p, uid):
    if "solicitante_nome" not in p:
        p["solicitante_nome"] = nome_usuario(p["solicitante_id"])
    if "impressora_nome" not in p:
        imp = uma(DB.execute("SELECT nome, cor FROM impressoras WHERE id=?", (p["impressora_id"],)))
        p["impressora_nome"], p["cor"] = imp["nome"], imp["cor"]
    p["respondido_por_nome"] = nome_usuario(p["respondido_por"])
    p["destinatario_nome"] = nome_usuario(p["destinatario_id"])
    vigente = p["mes"] == mes_atual()
    if p["status"] == "pendente" and not vigente:
        p["status"] = "expirado"
    p["pode_responder"] = (p["status"] == "pendente" and p["solicitante_id"] != uid and
                           p["destinatario_id"] in (None, uid) and not p.get("reserva"))
    p["pode_cancelar"] = p["status"] == "pendente" and p["solicitante_id"] == uid
    # pedido do mural que esta pessoa tirou da tela inicial (os outros colegas continuam vendo)
    p["dispensado"] = bool(p["pode_responder"] and p["destinatario_id"] is None and DB.execute(
        "SELECT 1 FROM pedidos_ocultos WHERE usuario_id=? AND pedido_id=?", (uid, p["id"])).fetchone())
    p["conversa"] = "mural" if p["destinatario_id"] is None else chave_direta(
        p["solicitante_id"] if p["solicitante_id"] != uid else p["destinatario_id"])
    return p


@rota("GET", "/api/conversas")
def r_conversas(req):
    return {"conversas": conversas_de(req.uid)}


@rota("GET", "/api/mensagens")
def r_mensagens(req):
    chave = req.q("conversa", "mural")
    outro = resolver_conversa(req.uid, chave)
    if outro is None:
        rows = linhas(DB.execute("SELECT * FROM (SELECT * FROM mensagens WHERE para_id IS NULL AND de_id NOT IN "
                                 "(SELECT bloqueado_id FROM bloqueios WHERE usuario_id=?) "
                                 "ORDER BY id DESC LIMIT 200) ORDER BY id", (req.uid,)))
    else:
        if DB.execute("SELECT 1 FROM bloqueios WHERE usuario_id=? AND bloqueado_id=?", (req.uid, outro)).fetchone():
            return {"conversa": chave, "mensagens": [], "nome": nome_usuario(outro), "bloqueado": True}
        rows = linhas(DB.execute(
            "SELECT * FROM (SELECT * FROM mensagens WHERE (de_id=? AND para_id=?) OR (de_id=? AND para_id=?) "
            "ORDER BY id DESC LIMIT 200) ORDER BY id", (req.uid, outro, outro, req.uid)))
    nomes = {r["id"]: r["nome"] for r in linhas(DB.execute("SELECT id, nome FROM usuarios"))}
    for m in rows:
        m["de_nome"] = nomes.get(m["de_id"], "?")
        m["minha"] = m["de_id"] == req.uid
        if m["tipo"] == "pedido":
            p = uma(DB.execute("SELECT * FROM pedidos WHERE id=?", (m["ref_id"],)))
            m["pedido"] = formatar_pedido(p, req.uid) if p else None
        elif m["tipo"] == "doacao":
            mv = uma(DB.execute("SELECT m.*, i.nome AS impressora_nome, i.cor FROM movimentos m "
                                "JOIN impressoras i ON i.id=m.impressora_id WHERE m.id=?", (m["ref_id"],)))
            if mv:
                mv["de_nome"], mv["para_nome"] = nomes.get(mv["de_id"]), nomes.get(mv["para_id"])
            m["doacao"] = mv
    if rows:
        DB.execute("INSERT INTO leituras(usuario_id, conversa, ultimo_id) VALUES(?,?,?) "
                   "ON CONFLICT(usuario_id, conversa) DO UPDATE SET ultimo_id=excluded.ultimo_id",
                   (req.uid, chave, rows[-1]["id"]))
    return {"conversa": chave, "mensagens": rows,
            "nome": "Mural da equipe" if outro is None else nomes.get(outro)}


def postar(de, para, texto, tipo="texto", ref=None):
    DB.execute("INSERT INTO mensagens(de_id, para_id, texto, tipo, ref_id, criado_em) VALUES(?,?,?,?,?,?)",
               (de, para, texto, tipo, ref, agora()))


def exigir_termos(req):
    """Só quem aceitou os termos de uso (junto com o aviso de privacidade) cria conteúdo para os colegas."""
    u = req.usuario
    if not u["ciencia_privacidade"] or (u["ciencia_versao"] or 0) < AVISO_VERSAO:
        raise Erro("Leia e aceite os termos de uso para trocar mensagens e pedidos.", 403, "termos")


def checar_bloqueio(uid, outro):
    """Ninguém escreve para quem o bloqueou, nem para quem bloqueou."""
    if outro is not None and DB.execute(
            "SELECT 1 FROM bloqueios WHERE (usuario_id=? AND bloqueado_id=?) OR (usuario_id=? AND bloqueado_id=?)",
            (uid, outro, outro, uid)).fetchone():
        raise Erro("Não foi possível enviar para esta pessoa.", 403, "bloqueio")


# Filtro de linguagem: lista inicial de palavras ofensivas (o gestor acrescenta ou libera palavras em Ajustes)
PALAVRAS_OFENSIVAS = (
    "porra caralho merda bosta foda foder fodido fodida puta puto putaria viado viadinho buceta cacete cuzao cuzona "
    "arrombado arrombada babaca idiota imbecil retardado retardada otario otaria vagabundo vagabunda safado safada "
    "desgraca desgracado inutil lixo corno corna fdp vsf tnc piranha cretino cretina trouxa nojento nojenta "
    "macaco macaca crioulo nazista").split()


def palavras_filtro():
    liberadas = {sem_acento(w).lower() for w in re.split(r"[,\n;]+", cfg("filtro_liberadas") or "") if w.strip()}
    extras = [sem_acento(w).strip().lower() for w in re.split(r"[,\n;]+", cfg("filtro_extras") or "") if w.strip()]
    return [w for w in list(PALAVRAS_OFENSIVAS) + extras if w and w not in liberadas]


def filtrar_texto(texto):
    """Troca as palavras ofensivas por asteriscos (letra a letra, sem mudar o tamanho). Devolve (texto, mudou)."""
    if cfg("filtro_ligado") == "0" or not texto:
        return texto, False
    palavras = palavras_filtro()
    if not palavras:
        return texto, False
    # compara sem acento e sem diferença de maiúsculas; o texto sem acento tem o mesmo tamanho do original
    plano = "".join(sem_acento(c) if len(sem_acento(c)) == 1 else c for c in texto).lower()
    padrao = re.compile(r"(?<![a-z0-9])(" + "|".join(re.escape(w) for w in sorted(palavras, key=len, reverse=True))
                        + r")(?![a-z0-9])")
    saida, mudou, ultimo = [], False, 0
    for m in padrao.finditer(plano):
        saida.append(texto[ultimo:m.start()]); saida.append("*" * (m.end() - m.start())); ultimo = m.end(); mudou = True
    saida.append(texto[ultimo:])
    return "".join(saida), mudou


@rota("POST", "/api/mensagens")
def r_enviar(req):
    exigir_termos(req)
    outro = resolver_conversa(req.uid, req.b("conversa"))
    checar_bloqueio(req.uid, outro)
    texto = str(req.b("texto") or "").strip()[:1000]
    if not texto:
        raise Erro("Escreva uma mensagem.")
    texto, mudou = filtrar_texto(texto)
    postar(req.uid, outro, texto)
    return {"ok": True, "filtrada": mudou}


@rota("POST", "/api/pedir")
def r_pedir(req):
    exigir_termos(req)
    imp = imp_por_id(req.b("impressora_id"))
    paginas = inteiro(req.b("paginas"), "número de páginas", 1, 5000)
    texto = filtrar_texto(str(req.b("texto") or "").strip()[:500])[0]
    if modo_trocas() == "reserva" or req.b("conversa") == "reserva":
        if modo_trocas() != "reserva":
            raise Erro(f"Aqui {L('no')}, os pedidos vão para colegas ou para o mural.")
        return pedir_reserva(req, imp, paginas, texto)
    outro = resolver_conversa(req.uid, req.b("conversa"))
    checar_bloqueio(req.uid, outro)
    if modo_trocas() == "limite":
        lr = limites_troca(req.uid, imp["id"], mes_atual())
        if paginas > lr["receber"]:
            raise Erro(f"Você pode receber até {lr['max_receber']} páginas da {imp['nome']} por mês de colegas "
                       f"e ainda pode receber {lr['receber']}.", 409, "limite_troca")
    cur = DB.execute("INSERT INTO pedidos(mes, impressora_id, solicitante_id, destinatario_id, paginas, status, "
                     "criado_em) VALUES(?,?,?,?,?, 'pendente', ?)",
                     (mes_atual(), imp["id"], req.uid, outro, paginas, agora()))
    postar(req.uid, outro, texto, "pedido", cur.lastrowid)
    return {"ok": True, "pedido_id": cur.lastrowid}


def modo_trocas():
    m = cfg("modo_trocas")
    return m if m in MODOS_TROCA else "limite"


def limites_troca(uid, iid, mes):
    """Quanto a pessoa ainda pode passar e receber de colegas neste mês (None = sem limite)."""
    if modo_trocas() != "limite":
        return {"doar": None, "receber": None, "max_doar": None, "max_receber": None}
    base = DB.execute("SELECT mensal FROM cotas WHERE usuario_id=? AND impressora_id=?", (uid, iid)).fetchone()
    base = base[0] if base else 0
    doado = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND impressora_id=? "
                       "AND de_id=? AND tipo='transferencia'", (mes, iid, uid)).fetchone()[0]
    recebido = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND impressora_id=? "
                          "AND para_id=? AND tipo='transferencia'", (mes, iid, uid)).fetchone()[0]
    max_doar = base * int(cfg("limite_doar_pct") or 0) // 100
    max_receber = base * int(cfg("limite_receber_pct") or 0) // 100
    return {"doar": max(0, max_doar - doado), "receber": max(0, max_receber - recebido),
            "max_doar": max_doar, "max_receber": max_receber}


def conferir_troca(de, para, iid, paginas):
    """Aplica o estilo de troca escolhido pela gestão. Lança Erro explicando o limite."""
    if instalacao() == "central" and de and para and setor_de(de) != setor_de(para):
        raise Erro("Só dá para passar páginas para alguém do mesmo setor. A cota de cada setor é definida pela TI.",
                   409, "outro_setor")
    modo = modo_trocas()
    if modo == "reserva":
        raise Erro(f"Aqui {L('no')}, as páginas circulam pela reserva {L('do')}: quem tem sobra devolve, "
                   "quem precisa pede à reserva.", 409, "so_reserva")
    if modo != "limite":
        return
    mes, imp = mes_atual(), imp_por_id(iid)
    ld = limites_troca(de, iid, mes)
    if ld["max_doar"] == 0:
        raise Erro(f"Pela regra {L('do')}, você não pode passar páginas da {imp['nome']} a colegas.", 409, "limite_troca")
    if paginas > ld["doar"]:
        raise Erro(f"Cada pessoa pode passar até {ld['max_doar']} páginas da {imp['nome']} por mês "
                   f"({cfg('limite_doar_pct')}% da própria cota). Você ainda pode passar {ld['doar']}.",
                   409, "limite_troca")
    lr = limites_troca(para, iid, mes)
    nome = nome_usuario(para)
    if lr["max_receber"] == 0:
        raise Erro(f"{nome} não pode receber páginas da {imp['nome']} de colegas: a cota dessa pessoa nessa impressora é 0.",
                   409, "limite_troca")
    if paginas > lr["receber"]:
        raise Erro(f"{nome} pode receber até {lr['max_receber']} páginas da {imp['nome']} por mês de colegas "
                   f"e ainda pode receber {lr['receber']}.", 409, "limite_troca")


def reserva_disponivel(iid, mes):
    imp = imp_por_id(iid)
    if not imp["cota_total"]:
        return None  # impressora sem cota do grupo: a reserva não tem teto
    return resumo_impressora(imp, mes, [])["reserva"]


def transferir(de, para, iid, paginas, tipo, criado_por, obs=""):
    mes = mes_atual()
    if de is not None:
        s = saldo(de, iid, mes)
        if paginas > s["restante"]:
            raise Erro(f"Só há {max(s['restante'], 0)} páginas disponíveis para passar nesta impressora.",
                       409, "sem_cota")
    cur = DB.execute("INSERT INTO movimentos(mes, impressora_id, de_id, para_id, paginas, tipo, obs, criado_por, "
                     "criado_em) VALUES(?,?,?,?,?,?,?,?,?)",
                     (mes, iid, de, para, paginas, tipo, obs, criado_por, agora()))
    return cur.lastrowid


@rota("POST", "/api/doar")
def r_doar(req):
    exigir_termos(req)
    outro = resolver_conversa(req.uid, req.b("conversa"))
    if outro is None:
        raise Erro("Para passar páginas, abra a conversa com a pessoa.")
    checar_bloqueio(req.uid, outro)
    imp = imp_por_id(req.b("impressora_id"))
    paginas = inteiro(req.b("paginas"), "número de páginas", 1, 5000)
    texto = filtrar_texto(str(req.b("texto") or "").strip()[:500])[0]
    conferir_troca(req.uid, outro, imp["id"], paginas)
    mid = transferir(req.uid, outro, imp["id"], paginas, "transferencia", req.uid, texto)
    postar(req.uid, outro, texto, "doacao", mid)
    return {"ok": True}


def pedir_reserva(req, imp, paginas, motivo):
    mes = mes_atual()
    cur = DB.execute("INSERT INTO pedidos(mes, impressora_id, solicitante_id, destinatario_id, paginas, status, "
                     "criado_em, reserva, motivo) VALUES(?,?,?,NULL,?, 'pendente', ?, 1, ?)",
                     (mes, imp["id"], req.uid, paginas, agora(), motivo))
    pid = cur.lastrowid
    auto = int(cfg("reserva_auto") or 0)
    ja = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND impressora_id=? AND para_id=? "
                    "AND tipo='reserva' AND criado_por IS NULL", (mes, imp["id"], req.uid)).fetchone()[0]
    disp = reserva_disponivel(imp["id"], mes)
    if auto and disp is not None and ja + paginas <= auto and disp >= paginas:
        mid = transferir(None, req.uid, imp["id"], paginas, "reserva", None, f"Pedido #{pid}, liberado na hora")
        DB.execute("UPDATE pedidos SET status='aceito', respondido_em=? WHERE id=?", (agora(), pid))
        return {"ok": True, "pedido_id": pid, "liberado": True, "movimento_id": mid}
    return {"ok": True, "pedido_id": pid, "liberado": False}


@rota("GET", "/api/reserva")
def r_reserva(req):
    mes = mes_atual()
    pedidos = linhas(DB.execute(
        "SELECT p.id, p.paginas, p.status, p.motivo, p.criado_em, p.respondido_em, i.nome AS impressora_nome, i.cor "
        "FROM pedidos p JOIN impressoras i ON i.id=p.impressora_id WHERE p.reserva=1 AND p.solicitante_id=? "
        "AND p.mes=? ORDER BY p.id DESC", (req.uid, mes)))
    devolvido = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND de_id=? "
                           "AND tipo='devolucao'", (mes, req.uid)).fetchone()[0]
    return {"modo": modo_trocas(), "pedidos": pedidos, "reserva_auto": int(cfg("reserva_auto") or 0),
            "devolvido": devolvido, "aviso": aviso_troca()}


@rota("POST", "/api/devolver")
def r_devolver(req):
    imp = imp_por_id(req.b("impressora_id"))
    paginas = inteiro(req.b("paginas"), "número de páginas", 1, 5000)
    transferir(req.uid, None, imp["id"], paginas, "devolucao", req.uid, f"Devolvidas {L('ao')}")
    return {"ok": True, "restante": saldo(req.uid, imp["id"], mes_atual())["restante"]}


@rota("POST", "/api/pedido/responder")
def r_responder(req):
    pid = inteiro(req.b("id"), "pedido")
    aceitar = bool(req.b("aceitar"))
    resposta = str(req.b("resposta") or "").strip()[:500]
    p = uma(DB.execute("SELECT * FROM pedidos WHERE id=?", (pid,)))
    if not p:
        raise Erro("Pedido não encontrado.")
    p = formatar_pedido(p, req.uid)
    if p["status"] == "expirado":
        DB.execute("UPDATE pedidos SET status='expirado' WHERE id=?", (pid,))
        raise Erro("Este pedido era do mês passado e expirou.")
    if not p["pode_responder"]:
        quem = p["respondido_por_nome"]
        raise Erro(f"Este pedido já foi atendido por {quem}." if p["status"] == "aceito" and quem
                   else "Este pedido não está mais aberto.")
    destino_msg = None if p["destinatario_id"] is None else p["solicitante_id"]
    if aceitar:
        conferir_troca(req.uid, p["solicitante_id"], p["impressora_id"], p["paginas"])
        mid = transferir(req.uid, p["solicitante_id"], p["impressora_id"], p["paginas"], "transferencia",
                         req.uid, f"Pedido #{pid}")
        DB.execute("UPDATE pedidos SET status='aceito', respondido_por=?, respondido_em=? WHERE id=?",
                   (req.uid, agora(), pid))
        postar(req.uid, destino_msg, "", "doacao", mid)
    else:
        if p["destinatario_id"] is None:
            raise Erro("Pedidos do mural não precisam ser recusados — é só não atender.")
        # Recusar nunca deve depender de uma mensagem digitada: uma resposta padrão
        # permite encerrar a pendência mesmo em clientes antigos ou com diálogo incompatível.
        if len(resposta) < 3:
            resposta = "No momento não posso atender ao pedido. Nenhuma página foi transferida."
        # Atualização condicional evita duas respostas simultâneas e mantém a operação idempotente.
        cur = DB.execute("UPDATE pedidos SET status='recusado', respondido_por=?, respondido_em=? "
                         "WHERE id=? AND status='pendente'", (req.uid, agora(), pid))
        if cur.rowcount != 1:
            raise Erro("Este pedido já foi respondido por outra pessoa.", 409, "pedido_respondido")
        postar(req.uid, destino_msg, f"{req.usuario['nome']} não pôde atender ao pedido de "
               f"{p['paginas']} páginas. Resposta: {resposta}", "sistema")
    return {"ok": True}


@rota("POST", "/api/pedido/dispensar")
def r_dispensar_pedido(req):
    """Oculta um pedido publicado no mural apenas para a pessoa logada.

    Não recusa nem encerra o pedido globalmente: outros colegas ainda podem atendê-lo.
    """
    pid = inteiro(req.b("id"), "pedido")
    p = uma(DB.execute("SELECT * FROM pedidos WHERE id=?", (pid,)))
    if not p or p["status"] != "pendente" or p["destinatario_id"] is not None:
        raise Erro("Este pedido não está disponível para ser dispensado.", 409, "pedido_indisponivel")
    if p["solicitante_id"] == req.uid:
        raise Erro("Você não pode dispensar o seu próprio pedido.", 403)
    DB.execute("INSERT OR IGNORE INTO pedidos_ocultos(usuario_id, pedido_id, criado_em) VALUES(?,?,?)",
               (req.uid, pid, agora()))
    return {"ok": True, "ocultado": True}


@rota("POST", "/api/pedido/cancelar")
def r_cancelar(req):
    pid = inteiro(req.b("id"), "pedido")
    p = uma(DB.execute("SELECT * FROM pedidos WHERE id=? AND solicitante_id=?", (pid, req.uid)))
    if not p or p["status"] != "pendente":
        raise Erro("Este pedido não pode mais ser cancelado.")
    DB.execute("UPDATE pedidos SET status='cancelado', respondido_em=? WHERE id=?", (agora(), pid))
    return {"ok": True}


# ---------------------------------------------------------------- direção

def resumo_impressora(imp, mes, usuarios):
    base = DB.execute("SELECT COALESCE(SUM(c.mensal),0) FROM cotas c JOIN usuarios u ON u.id=c.usuario_id "
                      "WHERE u.ativo=1 AND c.impressora_id=?", (imp["id"],)).fetchone()[0]
    ajuste_mais = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND impressora_id=? "
                             "AND tipo IN ('ajuste','reserva') AND de_id IS NULL", (mes, imp["id"])).fetchone()[0]
    ajuste_menos = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND impressora_id=? "
                              "AND tipo IN ('ajuste','devolucao') AND para_id IS NULL", (mes, imp["id"])).fetchone()[0]
    usado = DB.execute(f"SELECT COALESCE(SUM(total),0) FROM trabalhos WHERE mes=? AND impressora_id=? "
                       f"AND status IN ({','.join('?' * len(CONTA))})", (mes, imp["id"], *CONTA)).fetchone()[0]
    testes = DB.execute("SELECT COALESCE(SUM(total),0) FROM trabalhos WHERE mes=? AND impressora_id=? "
                        "AND status='teste'", (mes, imp["id"])).fetchone()[0]
    gasto = DB.execute(f"SELECT COALESCE(SUM(t.total * {CUSTO_SQL}),0) FROM trabalhos t "
                       f"JOIN impressoras i ON i.id=t.impressora_id WHERE t.mes=? AND t.impressora_id=? "
                       f"AND t.status IN ({','.join('?' * len(CONTA))})", (mes, imp["id"], *CONTA)).fetchone()[0]
    distribuido = base + ajuste_mais - ajuste_menos
    return {**imp, "distribuido": distribuido, "usado": usado, "testes": testes, "gasto": round(gasto, 2),
            "meses": historico_impressora(imp, mes), "conferencia": conferencia(imp, mes),
            "ultima_leitura": uma(DB.execute("SELECT * FROM leituras_contador WHERE impressora_id=? "
                                             "ORDER BY criado_em DESC, id DESC LIMIT 1", (imp["id"],))),
            "reserva": (imp["cota_total"] - distribuido) if imp["cota_total"] else None,
            "restante_grupo": (imp["cota_total"] - usado) if imp["cota_total"] else None}


# Status de impressões que saíram de fato no papel (para comparar com o contador)
SAIU_NO_PAPEL = ("impresso", "estornado")


def conferencia(imp, mes):
    """Compara o contador da impressora com o que passou pelo sistema no mês."""
    a, m = map(int, mes.split("-"))
    ini_mes = f"{a:04d}-{m:02d}-01 00:00:00"
    a2, m2 = (a + 1, 1) if m == 12 else (a, m + 1)
    fim_mes = f"{a2:04d}-{m2:02d}-01 00:00:00"
    ini = uma(DB.execute("SELECT * FROM leituras_contador WHERE impressora_id=? AND criado_em<=? "
                         "ORDER BY criado_em DESC, id DESC LIMIT 1", (imp["id"], ini_mes)))
    if not ini:
        ini = uma(DB.execute("SELECT * FROM leituras_contador WHERE impressora_id=? AND criado_em>? AND criado_em<? "
                             "ORDER BY criado_em, id LIMIT 1", (imp["id"], ini_mes, fim_mes)))
    if not ini:
        return None
    fim = uma(DB.execute("SELECT * FROM leituras_contador WHERE impressora_id=? AND criado_em<? AND id<>? "
                         "AND criado_em>=? ORDER BY criado_em DESC, id DESC LIMIT 1",
                         (imp["id"], fim_mes, ini["id"], ini["criado_em"])))
    if not fim:
        return {"leituras": 1, "de": ini["criado_em"]}
    na_impressora = fim["valor"] - ini["valor"]
    sistema = DB.execute(
        f"SELECT COALESCE(SUM(total),0) FROM trabalhos WHERE impressora_id=? AND criado_em>? AND criado_em<=? "
        f"AND status IN ({','.join('?' * len(SAIU_NO_PAPEL))})",
        (imp["id"], ini["criado_em"], fim["criado_em"], *SAIU_NO_PAPEL)).fetchone()[0]
    fora = na_impressora - sistema
    return {"leituras": 2, "de": ini["criado_em"], "ate": fim["criado_em"], "contador": na_impressora,
            "sistema": sistema, "fora": fora, "zerou": na_impressora < 0,
            "valor_fora": round(max(fora, 0) * (imp["custo_pagina"] or 0), 2)}


def registrar_leitura(iid, valor, origem, modelo="", por=None, forcar=False):
    ultima = DB.execute("SELECT valor FROM leituras_contador WHERE impressora_id=? "
                        "ORDER BY criado_em DESC, id DESC LIMIT 1", (iid,)).fetchone()
    if ultima and valor < ultima[0] and not forcar:
        def milhar(x):
            return f"{x:,}".replace(",", ".")
        raise Erro(f"Este contador ({milhar(valor)}) é menor que a leitura anterior ({milhar(ultima[0])}). "
                   f"Confira o número. Se a impressora foi trocada, confirme.", 409, "contador_menor")
    DB.execute("INSERT INTO leituras_contador(impressora_id, valor, origem, modelo, criado_em, criado_por) "
               "VALUES(?,?,?,?,?,?)", (iid, valor, origem, modelo or "", agora(), por))


@rota("POST", "/api/admin/contador/ler", auth="admin", trava=False)
def r_ler_contador(req):
    with LOCK:
        imp = imp_por_id(req.b("impressora_id"))
    if not imp["endereco_ip"]:
        raise Erro("Informe o endereço IP da impressora em Editar.")
    try:
        valor, modelo = contador.ler_contador(imp["endereco_ip"], imp["snmp_comunidade"])
    except ErroContador as e:
        raise Erro(str(e), 502)
    with LOCK:
        try:
            registrar_leitura(imp["id"], valor, "automática", modelo, req.uid, forcar=bool(req.b("forcar")))
            DB.commit()
        except Exception:
            DB.rollback()
            raise
    return {"ok": True, "valor": valor, "modelo": modelo}


@rota("POST", "/api/admin/contador/anotar", auth="admin")
def r_anotar_contador(req):
    imp = imp_por_id(req.b("impressora_id"))
    valor = inteiro(req.b("valor"), "contador", 0, 10_000_000_000)
    registrar_leitura(imp["id"], valor, "manual", "", req.uid, forcar=bool(req.b("forcar")))
    return {"ok": True, "valor": valor}


def leitura_automatica():
    """Lê o contador das impressoras com IP, uma vez por hora."""
    time.sleep(20)
    while True:
        try:
            with LOCK:
                alvos = linhas(DB.execute("SELECT id, endereco_ip, snmp_comunidade FROM impressoras "
                                          "WHERE ativa=1 AND endereco_ip<>''"))
            for imp in alvos:
                try:
                    valor, modelo = contador.ler_contador(imp["endereco_ip"], imp["snmp_comunidade"])
                except ErroContador:
                    continue
                with LOCK:
                    try:
                        registrar_leitura(imp["id"], valor, "automática", modelo)
                        DB.commit()
                    except Exception:
                        DB.rollback()
        except Exception:
            pass
        time.sleep(3600)


# ---------------------------------------------------------------- acompanhamento da fila de impressão
#
# No Linux, cada impressão vai para o CUPS e fica "na_fila": as páginas ficam reservadas (contam no saldo),
# mas só valem de vez quando o CUPS diz que o trabalho terminou. Cancelado ou com erro, as páginas voltam.
# Com o IP da impressora (e "conferir pelo contador" ligado), cada trabalho é mandado retido e só é solto
# quando o anterior da mesma impressora acabou; o contador é lido antes e depois, e desconta-se o que a
# máquina contou. Nunca se desconta mais do que o pedido: cópias no vidro no meio não pesam para ninguém.

ACOMP = {"evento": threading.Event(), "mem": {}, "sem_cups_desde": None, "unidades": {}}
_ESCALA = float(os.environ.get("CI_FILA_ESCALA", 1))  # só para os testes andarem mais rápido
FILA_ESPERA_CONTADOR = 120 * _ESCALA       # segundos esperando a impressora responder antes de soltar sem contador
FILA_PARADO = 20 * _ESCALA                 # contador parado por tanto tempo, impressora em repouso: acabou
FILA_PARADO_SEM_NADA = 60 * _ESCALA        # nada contado ainda: espera mais (a impressora pode estar aquecendo)
FILA_LIMITE_CONFERIR = 1800 * _ESCALA      # depois que o CUPS terminou, não espera o contador mais que isso
FILA_LIMITE_SEM_CUPS = 6 * 3600 * _ESCALA  # CUPS sem responder por tanto tempo: conta como impresso


def usa_contador(imp):
    return bool(imp["endereco_ip"]) and bool(imp["conferir_contador"])


def _pags(n):
    return "1 página" if n == 1 else f"{n} páginas"


def ajustar_negativo(tid, paginas):
    """A parte além da cota de uma impressão diminuiu (ou sumiu) porque nem tudo saiu."""
    for tabela, cond in (("excecoes", "tipo='negativo' AND ref_id=?"), ("movimentos", "tipo='desconto' AND trabalho_id=?")):
        if paginas <= 0:
            DB.execute(f"DELETE FROM {tabela} WHERE {cond}", (tid,))
        else:
            DB.execute(f"UPDATE {tabela} SET paginas=? WHERE {cond}", (paginas, tid))


def finalizar_fila(tid, saiu, motivo=""):
    """A impressão saiu da fila: desconta o que saiu e devolve o resto."""
    with LOCK:
        t = uma(DB.execute("SELECT * FROM trabalhos WHERE id=?", (tid,)))
        if not t or t["status"] != "na_fila":
            return
        pedido = t["pedido"] or t["total"]
        saiu = max(0, min(int(saiu), pedido))
        volta = pedido - saiu
        exc = max(0, (t["excedente"] or 0) - volta)
        if saiu == 0:
            texto = (motivo + " " if motivo else "Não saiu na impressora. ") + (
                "A página voltou para a sua cota." if pedido == 1 else f"As {pedido} páginas voltaram para a sua cota.")
            DB.execute("UPDATE trabalhos SET status='erro', erro=?, excedente=0 WHERE id=?", (texto, tid))
        else:
            texto = ""
            if volta:
                texto = (f"{'Saiu' if saiu == 1 else 'Saíram'} {saiu} de {pedido} páginas na impressora. "
                         + ("A outra voltou" if volta == 1 else f"As outras {volta} voltaram") + " para a sua cota.")
                if motivo:
                    texto = motivo + " " + texto
            DB.execute("UPDATE trabalhos SET status='impresso', total=?, excedente=?, erro=? WHERE id=?",
                       (saiu, exc, texto or None, tid))
        if volta and t["excedente"]:
            ajustar_negativo(tid, exc if saiu else 0)
        DB.execute("UPDATE trabalhos SET fila_motivo='', fila_fim=?, aviso_fila=? WHERE id=?",
                   (agora(), 1 if volta else 0, tid))
        DB.commit()
    ACOMP["mem"].pop(tid, None)


def _motivo_fila(tid, texto):
    with LOCK:
        DB.execute("UPDATE trabalhos SET fila_motivo=? WHERE id=? AND status='na_fila' AND fila_motivo<>?",
                   (texto[:200], tid, texto[:200]))
        DB.commit()


def _texto_fim(st, mem):
    if mem.get("cancelado"):
        return mem["cancelado"]
    if st is None:
        return ""
    if st["estado"] == ipp.JOB_CANCELADO:
        if any("at-device" in m for m in st["motivos"]):
            return "O trabalho foi cancelado na impressora."
        return "O trabalho foi cancelado."
    if st["estado"] == ipp.JOB_ABORTADO:
        m = acompanhar.motivo(st)
        return "A impressora deu erro" + (f" ({m})" if m else "") + " e o trabalho foi interrompido."
    return ""


def _unidade(iid, ip, com):
    u = ACOMP["unidades"].get(iid)
    if not u or time.time() - u[1] > 3600:
        u = (acompanhar.unidade(ip, com), time.time())
        ACOMP["unidades"][iid] = u
    return u[0]


def rodada_fila():
    """Uma passada por tudo que está na fila. Devolve True se ainda há o que acompanhar."""
    with LOCK:
        jobs = linhas(DB.execute(
            "SELECT t.*, i.endereco_ip, i.snmp_comunidade, i.contador_confiavel FROM trabalhos t "
            "JOIN impressoras i ON i.id=t.impressora_id WHERE t.status='na_fila' ORDER BY t.id"))
    if not jobs:
        ACOMP["mem"].clear()
        return False
    agora_s = time.time()
    estados = {}
    for j in jobs:
        try:
            estados[j["id"]] = acompanhar.estado(j["job_sistema"])
        except acompanhar.SemCups:
            if ACOMP["sem_cups_desde"] is None:
                ACOMP["sem_cups_desde"] = agora_s
            if agora_s - ACOMP["sem_cups_desde"] > FILA_LIMITE_SEM_CUPS:
                for x in jobs:
                    finalizar_fila(x["id"], x["pedido"] or x["total"])
                ACOMP["sem_cups_desde"] = None
            else:
                for x in jobs:
                    _motivo_fila(x["id"], "Esperando o servidor de impressão do computador responder")
            return True
        except (TypeError, ValueError):
            estados[j["id"]] = None
    ACOMP["sem_cups_desde"] = None
    ocupadas = {j["impressora_id"] for j in jobs if j["fila_etapa"] in (0, 2)}
    for j in jobs:
        st, tid, total = estados[j["id"]], j["id"], j["pedido"] or j["total"]
        mem = ACOMP["mem"].setdefault(tid, {})
        fim = st is None or st["estado"] in acompanhar.FINAIS
        if j["fila_etapa"] == 0:
            # só o CUPS: concluído vale tudo; cancelado ou com erro vale o que ele chegou a mandar
            if st is None or st["estado"] == ipp.JOB_CONCLUIDO:
                finalizar_fila(tid, total)
            elif fim:
                finalizar_fila(tid, min(st["impressoes"] or 0, total), _texto_fim(st, mem))
            else:
                _motivo_fila(tid, acompanhar.texto_estado(st))
            continue
        ip, com = j["endereco_ip"], j["snmp_comunidade"]
        if j["fila_etapa"] == 1:
            if st is None or st["estado"] in (ipp.JOB_CANCELADO, ipp.JOB_ABORTADO):
                finalizar_fila(tid, 0, _texto_fim(st, mem) or "Cancelada antes de imprimir.")
                continue
            if st["estado"] != ipp.JOB_RETIDO:  # alguém soltou direto no computador: segue só pelo CUPS
                with LOCK:
                    DB.execute("UPDATE trabalhos SET fila_etapa=0 WHERE id=?", (tid,))
                    DB.commit()
                ocupadas.add(j["impressora_id"])
                continue
            if j["impressora_id"] in ocupadas:
                _motivo_fila(tid, "Aguardando a vez: outra impressão está saindo nesta impressora")
                continue
            try:
                valor = acompanhar.ler_valor(ip, com)
            except ErroContador:
                mem.setdefault("sem_contador_desde", agora_s)
                if agora_s - mem["sem_contador_desde"] < FILA_ESPERA_CONTADOR:
                    _motivo_fila(tid, "Esperando a impressora responder (está ligada?)")
                    ocupadas.add(j["impressora_id"])
                    continue
                valor = None
            if not acompanhar.liberar(j["job_sistema"]):
                _motivo_fila(tid, "Não consegui soltar o trabalho no servidor de impressão; tentando de novo")
                ocupadas.add(j["impressora_id"])
                continue
            with LOCK:
                DB.execute("UPDATE trabalhos SET fila_etapa=?, contador_ini=?, fila_motivo=? WHERE id=?",
                           (0 if valor is None else 2, valor, "Imprimindo", tid))
                DB.commit()
            mem.update(ultimo=valor, mudou=agora_s)
            ocupadas.add(j["impressora_id"])
            continue
        # etapa 2: imprimindo, conferindo pelo contador
        ini = j["contador_ini"] or 0
        mem.setdefault("ultimo", ini)
        mem.setdefault("mudou", agora_s)
        try:
            valor = acompanhar.ler_valor(ip, com)
        except ErroContador:
            valor = None
        if valor is not None and valor < ini:  # o contador voltou para trás (impressora trocada?): só pelo CUPS
            with LOCK:
                DB.execute("UPDATE trabalhos SET fila_etapa=0 WHERE id=?", (tid,))
                DB.commit()
            continue
        if valor is not None and valor != mem["ultimo"]:
            mem["ultimo"], mem["mudou"] = valor, agora_s
        unid = _unidade(j["impressora_id"], ip, com)
        esp = acompanhar.esperado(total, j["paginas_sel"] or 1, j["copias"] or 1, bool(j["frente_verso"]), unid)
        delta = mem["ultimo"] - ini
        if delta >= esp:
            finalizar_fila(tid, total)
            with LOCK:
                DB.execute("UPDATE impressoras SET contador_confiavel=1 WHERE id=?", (j["impressora_id"],))
                DB.commit()
            continue
        situacao, problemas = acompanhar.estado_impressora(ip, com)
        if not fim:
            texto = acompanhar.texto_estado(st)
            if problemas and ":" not in texto:
                texto = "Parada na impressora: " + ", ".join(problemas)
            _motivo_fila(tid, texto)
            continue
        mem.setdefault("fim_cups", agora_s)
        parado = agora_s - mem["mudou"]
        espera = FILA_PARADO if delta > 0 else FILA_PARADO_SEM_NADA
        # acabou quando o contador para e a impressora está em repouso; imprimindo, aquecendo ou com
        # papel enroscado, sem papel etc., ainda pode sair o resto
        pronto = (parado >= espera and not problemas and situacao not in (4, 5)
                  and (situacao == 3 or parado >= 3 * espera))
        if not pronto and agora_s - mem["fim_cups"] < FILA_LIMITE_CONFERIR:
            _motivo_fila(tid, ("Parada na impressora: " + ", ".join(problemas)) if problemas
                         else "Conferindo no contador da impressora")
            continue
        saiu = acompanhar.paginas_pelo_contador(delta, total, esp)
        concluido = st is not None and st["estado"] == ipp.JOB_CONCLUIDO
        if concluido and not j["contador_confiavel"]:
            saiu = total  # contador ainda não conferido com uma impressão completa: não arrisca
        texto = _texto_fim(st, mem)
        if not texto and saiu < total:
            texto = "A impressora não contou nenhuma página." if saiu == 0 else ""
        finalizar_fila(tid, saiu, texto)
    return True


def acompanhar_fila():
    time.sleep(2)
    while True:
        try:
            ocupado = rodada_fila()
        except Exception:
            import traceback
            traceback.print_exc()
            ocupado = True
        ACOMP["evento"].wait(float(os.environ.get("CI_FILA_INTERVALO", 2)) if ocupado else 30)
        ACOMP["evento"].clear()


def fila_do_usuario(uid):
    ativos = linhas(DB.execute(
        "SELECT t.id, t.arquivo, t.total, t.fila_motivo AS motivo, t.criado_em, i.nome AS impressora, i.cor "
        "FROM trabalhos t JOIN impressoras i ON i.id=t.impressora_id WHERE t.usuario_id=? AND t.status='na_fila' "
        "ORDER BY t.id", (uid,)))
    avisos = linhas(DB.execute(
        "SELECT t.id, t.arquivo, t.status, t.total, t.pedido, t.erro, i.nome AS impressora FROM trabalhos t "
        "JOIN impressoras i ON i.id=t.impressora_id WHERE t.usuario_id=? AND t.aviso_fila=1 ORDER BY t.id DESC LIMIT 5",
        (uid,)))
    return {"ativos": ativos, "avisos": avisos}


@rota("POST", "/api/fila/cancelar", trava=False)
def r_cancelar_fila(req):
    tid = inteiro(req.b("id"), "impressão")
    with LOCK:
        t = uma(DB.execute("SELECT * FROM trabalhos WHERE id=?", (tid,)))
        dono = t and t["usuario_id"] == req.uid
        gestor = t and req.usuario["papel"] in ("admin", "gestor") and no_escopo(req.usuario, t["usuario_id"])
    if not t or not (dono or gestor):
        raise Erro("Impressão não encontrada.", 404)
    if t["status"] != "na_fila":
        raise Erro("Esta impressão já saiu da fila da impressora.", 409)
    cancelou = acompanhar.cancelar(t["job_sistema"])
    quem = "Você cancelou" if dono else f"Cancelada por {req.usuario['nome']}"
    if t["fila_etapa"] == 1:
        finalizar_fila(tid, 0, quem + " antes de imprimir.")
    elif not cancelou:
        raise Erro("Não consegui cancelar no servidor de impressão. Cancele na fila da impressora, no computador "
                   "do sistema; as páginas que não saírem voltam sozinhas.", 502)
    else:
        ACOMP["mem"].setdefault(tid, {})["cancelado"] = quem + "."
        _motivo_fila(tid, "Cancelando")
    ACOMP["evento"].set()
    return {"ok": True}


@rota("POST", "/api/fila/visto")
def r_fila_visto(req):
    ids = req.b("ids")
    ids = [int(i) for i in (ids if isinstance(ids, list) else []) if str(i).isdigit()][:50]
    if ids:
        DB.execute(f"UPDATE trabalhos SET aviso_fila=0 WHERE usuario_id=? AND id IN ({','.join('?' * len(ids))})",
                   (req.uid, *ids))
    return {"ok": True}


def meses_anteriores(mes, qtd):
    a, m = map(int, mes.split("-"))
    saida = []
    for _ in range(qtd):
        saida.append(f"{a:04d}-{m:02d}")
        m -= 1
        if m == 0:
            a, m = a - 1, 12
    return saida


def historico_impressora(imp, mes, qtd=6):
    """Páginas e gasto dos últimos meses, e economia comparada à média de antes do sistema."""
    primeiro = DB.execute("SELECT MIN(mes) FROM trabalhos WHERE impressora_id=?", (imp["id"],)).fetchone()[0]
    if not primeiro:
        return []
    custo = imp["custo_pagina"] or 0
    base = imp["base_mensal"] or 0
    atual = mes_atual()
    saida = []
    for m in meses_anteriores(mes, qtd):
        if m < primeiro:
            break
        pag, gasto = DB.execute(
            f"SELECT COALESCE(SUM(t.total),0), COALESCE(SUM(t.total * {CUSTO_SQL}),0) FROM trabalhos t "
            f"JOIN impressoras i ON i.id=t.impressora_id WHERE t.mes=? AND t.impressora_id=? "
            f"AND t.status IN ({','.join('?' * len(CONTA))})", (m, imp["id"], *CONTA)).fetchone()
        fechado = m < atual
        parcial = m == primeiro  # mês em que o sistema começou: incompleto, não serve de comparação
        economia = None
        if base and custo and fechado and not parcial:
            economia = round((base - pag) * custo, 2)
        saida.append({"mes": m, "paginas": pag, "gasto": round(gasto, 2), "fechado": fechado,
                      "parcial": parcial, "economia": economia})
    return saida


@rota("GET", "/api/admin/painel", auth="gestor")
def r_painel(req):
    mes = ler_mes(req)
    meu = escopo(req.usuario)
    usuarios = linhas(DB.execute("SELECT id, nome, papel, ativo, anonimizado, nomes_computador, login, trocar_senha, "
                                 "COALESCE(setor_id,1) AS setor_id, ref_central FROM usuarios "
                                 "WHERE COALESCE(aprovacao,'')<>'pendente' ORDER BY ativo DESC, "
                                 "nome COLLATE NOCASE"))
    if meu is not None:
        usuarios = [u for u in usuarios if u["setor_id"] in meu]
    ativos = [u for u in usuarios if u["ativo"]]
    imps = [resumo_impressora(i, mes, ativos) for i in impressoras(so_ativas=False)]
    for u in usuarios:
        u["saldos"] = {}
        for i in imps:
            u["saldos"][i["id"]] = saldo(u["id"], i["id"], mes)
    meses = [r[0] for r in DB.execute("SELECT DISTINCT mes FROM trabalhos UNION SELECT DISTINCT mes FROM "
                                      "movimentos ORDER BY 1 DESC")]
    if mes_atual() not in meses:
        meses.insert(0, mes_atual())
    setores_vistos = sorted(meu) if meu is not None else [r[0] for r in DB.execute("SELECT id FROM setores")]
    lista_setores = []
    for sid in setores_vistos:
        st_ = setor(sid)
        lista_setores.append({"id": sid, "nome": nome_setor(sid), "caminho": caminho_setor(sid), "pai_id": st_["pai_id"],
                              "remoto": bool(st_["remoto"]), "ativo": bool(st_["ativo"]), "cota": limite_setor(st_),
                              "distribuido": distribuido_setor(sid, mes)["total"], "politica": politica_setor(st_),
                              "impressoras_remotas": linhas(DB.execute(
                                  "SELECT ref, nome FROM unidade_impressoras WHERE setor_id=? AND ativa=1 ORDER BY nome",
                                  (sid,))) if st_["remoto"] else []})
    remotas = {}
    for r in DB.execute("SELECT usuario_id, ref, mensal FROM cotas_remotas"):
        remotas.setdefault(r[0], {})[r[1]] = r[2]
    for u in usuarios:
        u["cotas_remotas"] = remotas.get(u["id"], {})
    pendentes = cadastros_pendentes() if req.usuario["papel"] == "admin" else []
    for u in pendentes:
        u["saldos"] = {i["id"]: {"base": 0, "restante": 0} for i in imps}
        u.update(papel="prof", ativo=0, setor_id=1, nomes_computador="", ref_central="", cotas_remotas={},
                 anonimizado=0, pendente=True)
    return {"mes": mes, "mes_atual": mes_atual(), "meses": meses, "impressoras": imps, "usuarios": usuarios,
            "pendentes": pendentes,
            "config": {k: cfg(k) for k in CONFIG_PADRAO if k != "finalidades" and k not in CONFIG_SECRETA},
            "endereco": ENDERECOS, "instalacao": instalacao(), "escopo": None if meu is None else sorted(meu),
            "setores": lista_setores, "politica": politica_setor((req.usuario["setor_id"] or 1) if meu is not None else 1),
            "central": info_central() if instalacao() == "unidade" else None,
            "local": info_local(), "locais": LOCAIS,
            "finalidades": {"lista": [f for f in finalidades_proprias() if f["ativa"]],
                            "fixas": [{"id": i, "nome": n, "dica": d} for i, n, d in FINALIDADES_FIXAS],
                            "sugeridas": {t: [{"nome": n, "dica": d} for _, n, d in lista]
                                          for t, lista in FINALIDADES_SUGERIDAS.items()},
                            "proprias": bool(cfg("finalidades")), "maximo": MAX_FINALIDADES}}


@rota("POST", "/api/admin/usuario", auth="gestor")
def r_salvar_usuario(req):
    eu = req.usuario
    meu = escopo(eu)
    central = instalacao() == "central"
    uid = req.b("id")
    nome = str(req.b("nome") or "").strip()[:80]
    if not nome:
        raise Erro("Informe o nome.")
    papel = str(req.b("papel") or "prof")
    papel = papel if papel in ("admin", "gestor", "prof") else "prof"
    if papel == "gestor" and not central:
        papel = "prof"
    ativo = 0 if req.b("ativo") is False else 1
    senha = req.b("senha")
    if senha is None:
        senha = req.b("pin")  # nome antigo do campo
    pedir_troca = req.b("trocar_senha") is not False
    aprovar = req.b("aprovar") is True
    login = req.b("usuario")
    atual = None
    if uid:
        uid = inteiro(uid, "usuário")
        atual = uma(DB.execute("SELECT * FROM usuarios WHERE id=?", (uid,)))
        if not atual or not no_escopo(eu, uid):
            raise Erro("Pessoa não encontrada.", 404)
        if atual["anonimizado"]:
            raise Erro("Os dados desta pessoa foram apagados. Para ela voltar, cadastre-a de novo.")
    sid = inteiro(req.b("setor_id") or (atual["setor_id"] if atual else (eu["setor_id"] if meu is not None else 1)) or 1, "setor")
    if not central:
        sid = 1
    s_ = setor(sid)
    if meu is not None:
        if atual and atual["papel"] == "admin":
            # 2.6.0: antes dava para rebaixar o gestor geral e trocar a senha dele (a instalação ficava sem ninguém)
            raise Erro("Só a TI muda a conta de um gestor geral.", 403)
        if sid not in meu:
            raise Erro("Esse setor não é seu.", 403)
        if papel == "admin" or (papel == "gestor" and not (atual and atual["papel"] == "gestor")):
            raise Erro("Só a TI escolhe os gestores.", 403)
        if politica_setor(s_)["cadastro"] == "ti" and uid != eu["id"]:
            raise Erro(f"Em {nome_setor(sid)}, quem cadastra as pessoas é a TI.", 403)
    if instalacao() == "unidade" and politica_setor(1)["cadastro"] == "ti" and (not atual or atual["ref_central"]):
        raise Erro("Nesta unidade, quem cadastra as pessoas é a TI, pela central. As mudanças chegam na próxima "
                   "sincronização.", 403)
    if s_["remoto"] and papel == "admin":
        papel = "gestor"
    if s_["remoto"]:
        pedir_troca = False  # quem é de unidade com aparelho próprio não entra na central para criar a senha
    pendente = bool(atual and atual["aprovacao"] == "pendente")
    if pendente:  # cadastro pedido na tela de entrada: só o gestor aprova; até lá, sem acesso
        if eu["papel"] != "admin":
            raise Erro("Só o gestor aprova cadastros.", 403)
        ativo = 1 if aprovar else 0
    if uid == eu["id"] and (papel != eu["papel"] or not ativo):
        raise Erro("Você não pode tirar seu próprio acesso de gestor nem se desativar.")
    antes_setores = {x: distribuido_setor(x)["total"] for x in {sid, (atual or {}).get("setor_id") or 1}}
    antes_imps = somas_impressoras()
    login = valida_login(login) if str(login or "").strip() else (atual["login"] if atual and atual["login"]
                                                                    else gerar_login(nome, uid or None))
    if login_em_uso(login, uid or None):
        raise Erro(f"O usuário {login} já é de outra pessoa. Escolha outro.", 400, "login")
    if uid:
        DB.execute("UPDATE usuarios SET nome=?, papel=?, ativo=?, setor_id=?, login=? WHERE id=?",
                   (nome, papel, ativo, sid, login, uid))
        if pendente and aprovar:
            DB.execute("UPDATE usuarios SET aprovacao='' WHERE id=?", (uid,))
        if senha:
            # senha nova dada pelo gestor (a pessoa esqueceu): vale uma vez, depois a pessoa cria a dela
            DB.execute("UPDATE usuarios SET pin_hash=?, trocar_senha=? WHERE id=?",
                       (hash_senha(valida_senha(senha, login, nome)), 1 if pedir_troca and uid != eu["id"] else 0, uid))
            DB.execute("DELETE FROM sessoes WHERE usuario_id=?" + (" AND token<>?" if uid == eu["id"] else ""),
                       (uid, eu["sessao_token"]) if uid == eu["id"] else (uid,))
        if not ativo or (central and s_["remoto"]):
            DB.execute("DELETE FROM sessoes WHERE usuario_id=?", (uid,))
    else:
        if not senha:
            raise Erro("Crie uma senha provisória para a pessoa entrar a primeira vez.", 400, "senha")
        uid = DB.execute("INSERT INTO usuarios(nome, pin_hash, papel, ativo, criado_em, setor_id, login, trocar_senha) "
                         "VALUES(?,?,?,?,?,?,?,?)", (nome, hash_senha(valida_senha(senha, login, nome)), papel, ativo,
                                                     agora(), sid, login, 1 if pedir_troca else 0)).lastrowid
    if req.b("nomes_computador") is not None:
        nomes = ",".join(sorted({n.strip().lower() for n in str(req.b("nomes_computador")).replace(";", ",").split(",")
                                 if n.strip()}))[:300]
        DB.execute("UPDATE usuarios SET nomes_computador=? WHERE id=?", (nomes, uid))
    if s_["remoto"]:
        for ref, n in (req.b("cotas_remotas") or {}).items():
            DB.execute("INSERT INTO cotas_remotas(usuario_id, ref, mensal) VALUES(?,?,?) ON CONFLICT(usuario_id, ref) "
                       "DO UPDATE SET mensal=excluded.mensal", (uid, str(ref)[:20], inteiro(n, "cota", 0, 100000)))
    else:
        for iid, n in (req.b("cotas") or {}).items():
            n = inteiro(n, "cota", 0, 100000)
            DB.execute("INSERT INTO cotas(usuario_id, impressora_id, mensal) VALUES(?,?,?) "
                       "ON CONFLICT(usuario_id, impressora_id) DO UPDATE SET mensal=excluded.mensal",
                       (uid, inteiro(iid, "impressora"), n))
    conferir_impressoras(antes_imps)
    conferir_setor(sid, antes_setores[sid], req.b("justificativa"), req.uid, motivo=f"Cotas de {nome}")
    for x in antes_setores:
        marcar_pacote(x)
    return {"ok": True, "id": uid, "login": login}


@rota("POST", "/api/admin/impressora", auth="admin")
def r_salvar_impressora(req):
    iid = req.b("id")
    nome = str(req.b("nome") or "").strip()[:80]
    if not nome:
        raise Erro("Informe o nome da impressora.")
    sistema = str(req.b("sistema") or "").strip()[:200]
    if impressao.eh_folha_a_folha(sistema):
        raise Erro("Escolha a impressora de verdade. A Folha a Folha só guarda os documentos até a liberação.")
    total = inteiro(req.b("cota_total") or 0, "cota total", 0, 1000000)
    cor = str(req.b("cor") or "#0E7C7B")[:9]
    ativa = 0 if req.b("ativa") is False else 1
    custo = valor_reais(req.b("custo_pagina"), "custo por página", 0, 50)
    base_m = inteiro(req.b("base_mensal") or 0, "média de páginas por mês", 0, 10000000)
    ip = str(req.b("endereco_ip") or "").strip()[:100]
    if ip:
        try:
            contador.separar_endereco(ip)
        except ErroContador as e:
            raise Erro(str(e))
    comunidade = (str(req.b("snmp_comunidade") or "").strip() or "public")[:60]
    pede = req.b("pede_finalidade")
    conferir = req.b("conferir_contador")
    papel = str(req.b("papel") or "")
    if papel and papel not in imposicao.PAPEIS:
        raise Erro("Papel desconhecido.")
    margens = req.b("margens")
    if margens is not None:
        if not isinstance(margens, dict):
            raise Erro("Margens inválidas.")
        try:
            margens = {k: round(float(str(margens.get(k)).replace(",", ".")), 1) for k in imposicao.LADOS}
        except (TypeError, ValueError):
            raise Erro("Preencha as quatro margens em milímetros (por exemplo, 4,2).")
        if any(not 0 <= v <= 30 for v in margens.values()):
            raise Erro("Cada margem vai de 0 a 30 mm.")
    if iid:
        if pede is not None:
            DB.execute("UPDATE impressoras SET pede_finalidade=? WHERE id=?", (1 if pede else 0, inteiro(iid, "impressora")))
        if conferir is not None:
            DB.execute("UPDATE impressoras SET conferir_contador=? WHERE id=?", (1 if conferir else 0, inteiro(iid, "impressora")))
        # outro IP ou outra impressora: o contador precisa ser conferido de novo com uma impressão completa
        DB.execute("UPDATE impressoras SET contador_confiavel=0 WHERE id=? AND (endereco_ip<>? OR sistema<>?)",
                   (inteiro(iid, "impressora"), ip, sistema))
        DB.execute("UPDATE impressoras SET nome=?, sistema=?, cota_total=?, cor=?, ativa=?, custo_pagina=?, "
                   "base_mensal=?, endereco_ip=?, snmp_comunidade=? WHERE id=?",
                   (nome, sistema, total, cor, ativa, custo, base_m, ip, comunidade, inteiro(iid, "impressora")))
        if req.b("papel") is not None:
            DB.execute("UPDATE impressoras SET papel=? WHERE id=?", (papel, inteiro(iid, "impressora")))
    else:
        ordem = DB.execute("SELECT COALESCE(MAX(ordem),0)+1 FROM impressoras").fetchone()[0]
        iid = DB.execute("INSERT INTO impressoras(nome, sistema, cota_total, cor, ativa, ordem, custo_pagina, "
                         "base_mensal, endereco_ip, snmp_comunidade) VALUES(?,?,?,?,?,?,?,?,?,?)",
                         (nome, sistema, total, cor, ativa, ordem, custo, base_m, ip, comunidade)).lastrowid
        DB.execute("UPDATE impressoras SET pede_finalidade=?, conferir_contador=?, papel=? WHERE id=?",
                   (0 if pede is False else 1, 0 if conferir is False else 1, papel, iid))
    if "margens" in (req.corpo or {}):  # null volta para as margens que a impressora informa
        m = margens or {}
        DB.execute("UPDATE impressoras SET margem_topo=?, margem_baixo=?, margem_esq=?, margem_dir=? WHERE id=?",
                   (m.get("topo"), m.get("baixo"), m.get("esq"), m.get("dir"), iid))
    return {"ok": True, "id": iid}


@rota("GET", "/api/admin/impressora/area", auth="admin", trava=False)
def r_area_impressora(req):
    """Papel e área de impressão: o que a impressora informa e o que está valendo."""
    with LOCK:
        imp = imp_por_id(inteiro(req.q("id"), "impressora"))
    return {"informada": imposicao.area_da_impressora(imp["sistema"] or ""), "valendo": area_impressora(imp),
            "papeis": [{"id": k, "nome": v[2]} for k, v in imposicao.PAPEIS.items()]}


def pdf_do_cartaz(papel_mm=(210.0, 297.0)):
    """O cartaz com o QR code do primeiro endereço deste computador na rede."""
    if not ENDERECOS:
        raise Erro("O computador do sistema não está numa rede agora: não há endereço para pôr no cartaz. "
                   "Confira o Wi-Fi ou o cabo de rede dele e tente de novo.", 409)
    try:
        return cartaz.pdf(ENDERECOS[0], nome_local(), L("do"), cadastro_permitido(), papel_mm)
    except ValueError:
        raise Erro("O endereço deste computador é grande demais para o QR code.", 409)


@rota("GET", "/api/admin/cartaz.pdf", auth="gestor", trava=False)
def r_cartaz_pdf(req):
    """Baixar o cartaz em A4, para imprimir por fora ou mandar para a equipe."""
    atualizar_enderecos()  # o endereço é lido na hora (fora da trava: pergunta ao sistema)
    with LOCK:
        dados = pdf_do_cartaz()
    return Resposta(dados, "application/pdf", {"Content-Disposition": 'attachment; filename="cartaz-folha-a-folha.pdf"'})


@rota("POST", "/api/admin/cartaz/imprimir", auth="admin", trava=False)
def r_cartaz_imprimir(req):
    """Imprime o cartaz no papel da impressora escolhida, em tamanho real. Não conta na cota de ninguém."""
    atualizar_enderecos()  # o endereço é lido na hora (fora da trava: pergunta ao sistema)
    with LOCK:
        imp = imp_por_id(req.b("impressora_id"))
        copias = inteiro(req.b("copias") or 1, "número de cópias", 1, 10)
        sumatra = cfg("sumatra")
        if not imp["sistema"]:
            raise Erro("Esta impressora está em modo teste. Escolha uma que já imprime de verdade.")
    area = area_impressora(imp)  # pode perguntar ao sistema de impressão: fica fora da trava
    with LOCK:
        dados = pdf_do_cartaz(area["papel_mm"])
    destino = FILA / f"cartaz-{secrets.token_hex(6)}.pdf"
    destino.write_bytes(dados)
    try:
        impressao._mandar(str(destino), imp["sistema"], copias, "", False, False, sumatra, False, True, area.get("media", ""))
    except ErroImpressao as e:
        raise Erro(str(e), 502)
    finally:
        try:
            destino.unlink()
        except OSError:
            pass
    return {"ok": True, "impressora": imp["nome"], "copias": copias}


@rota("POST", "/api/admin/impressora/calibrar", auth="admin", trava=False)
def r_calibrar_impressora(req):
    """Imprime a página de calibração (réguas nas quatro bordas) em tamanho real. Não conta na cota."""
    with LOCK:
        imp = imp_por_id(inteiro(req.b("id"), "impressora"))
        sumatra = cfg("sumatra")
    if not imp["sistema"]:
        raise Erro("Ligue esta impressora a uma impressora do computador antes de calibrar (está em modo teste).")
    area = area_impressora(imp)
    destino = FILA / f"calibracao-{secrets.token_hex(6)}.pdf"
    imposicao.pagina_calibracao(area, destino)
    try:
        impressao._mandar(str(destino), imp["sistema"], 1, "", False, False, sumatra, False, True, area.get("media", ""))
    except ErroImpressao as e:
        raise Erro(str(e), 502)
    finally:
        try:
            destino.unlink()
        except OSError:
            pass
    return {"ok": True}


@rota("POST", "/api/tamanho/plano", trava=False)
def r_plano_tamanho(req):
    """Como cada página do arquivo vai sair na folha desta impressora: a prévia desenha exatamente isto."""
    with LOCK:
        up = uma(DB.execute("SELECT * FROM uploads WHERE id=? AND usuario_id=?", (str(req.b("upload_id")), req.uid)))
        imp = imp_por_id(inteiro(req.b("impressora_id"), "impressora"))
    if not up or not os.path.isfile(up["caminho"]):
        raise Erro("O arquivo não está mais disponível. Envie de novo.")
    escala = ler_escala(req.b("escala") or "ajustar", up["tipo"])
    area = area_impressora(imp)
    saida = {"papel_mm": area["papel_mm"], "margens": area["margens"], "origem_margens": area["origem_margens"],
             "paginas": None}
    if not escala or up["tipo"] != "pdf" or up.get("imagem"):
        return saida
    try:
        plano, _ = impressao.plano_da_folha(up["caminho"], escala, area)
    except Exception:
        return saida  # PDF protegido sem Poppler: a impressão usa o ajuste do sistema
    saida["paginas"] = imposicao.em_mm(area, plano)[:500]
    saida["tinta"] = impressao.achar_renderizador() is not None
    return saida


@rota("POST", "/api/admin/dividir", auth="admin")
def r_dividir(req):
    imp = imp_por_id(req.b("impressora_id"))
    if not imp["cota_total"]:
        raise Erro("Defina primeiro a cota total mensal desta impressora.")
    if instalacao() == "central":
        raise Erro("Na central, a cota de cada setor é definida em Setores, e o gestor de cada um divide entre as pessoas.")
    antes = distribuido_setor(1)["total"]
    ids = [r[0] for r in DB.execute("SELECT id FROM usuarios WHERE ativo=1")]
    if not ids:
        raise Erro("Cadastre a equipe primeiro.")
    cada = imp["cota_total"] // len(ids)
    for uid in ids:
        DB.execute("INSERT INTO cotas(usuario_id, impressora_id, mensal) VALUES(?,?,?) "
                   "ON CONFLICT(usuario_id, impressora_id) DO UPDATE SET mensal=excluded.mensal",
                   (uid, imp["id"], cada))
    conferir_setor(1, antes, req.b("justificativa"), req.uid, motivo=f"Dividir a {imp['nome']}")
    return {"ok": True, "cada": cada, "sobra": imp["cota_total"] - cada * len(ids), "pessoas": len(ids)}


@rota("POST", "/api/admin/ajuste", auth="gestor")
def r_ajuste(req):
    uid = usuario_ativo(inteiro(req.b("usuario_id"), "pessoa"))["id"]
    if not no_escopo(req.usuario, uid):
        raise Erro("Pessoa não encontrada.", 404)
    imp = imp_por_id(req.b("impressora_id"))
    paginas = inteiro(req.b("paginas"), "número de páginas", -100000, 100000)
    if paginas == 0:
        raise Erro("Informe quantas páginas somar ou tirar.")
    obs = str(req.b("obs") or "").strip()[:300]
    if paginas > 0:
        sid = setor_de(uid)
        antes = distribuido_setor(sid)["total"]
        mid = transferir(None, uid, imp["id"], paginas, "ajuste", req.uid, obs)
        conferir_setor(sid, antes, req.b("justificativa") or obs, req.uid,
                       motivo=f"Páginas liberadas para {nome_usuario(uid)}")
    else:
        mid = DB.execute("INSERT INTO movimentos(mes, impressora_id, de_id, para_id, paginas, tipo, obs, "
                         "criado_por, criado_em) VALUES(?,?,?,NULL,?, 'ajuste', ?,?,?)",
                         (mes_atual(), imp["id"], uid, -paginas, obs, req.uid, agora())).lastrowid
    if uid != req.uid:
        postar(req.uid, uid, obs, "doacao", mid)
    return {"ok": True}


def meses_antes(mes, n):
    a, m = map(int, mes.split("-"))
    saida = []
    for _ in range(n):
        saida.append(f"{a:04d}-{m:02d}")
        a, m = (a - 1, 12) if m == 1 else (a, m - 1)
    return saida


@rota("GET", "/api/admin/trocas", auth="admin")
def r_trocas(req):
    mes = ler_mes(req)
    trocas = linhas(DB.execute(
        "SELECT m.de_id, m.para_id, m.paginas, m.impressora_id, d.nome AS de_nome, p.nome AS para_nome "
        "FROM movimentos m JOIN usuarios d ON d.id=m.de_id JOIN usuarios p ON p.id=m.para_id "
        "WHERE m.mes=? AND m.tipo='transferencia'", (mes,)))
    doadores, recebedores, pares = {}, {}, {}
    for t in trocas:
        for alvo, chave, nome in ((doadores, t["de_id"], t["de_nome"]), (recebedores, t["para_id"], t["para_nome"])):
            a = alvo.setdefault(chave, {"id": chave, "nome": nome, "paginas": 0, "vezes": 0})
            a["paginas"] += t["paginas"]
            a["vezes"] += 1
        par = pares.setdefault((t["de_id"], t["para_id"]), {"de": t["de_nome"], "para": t["para_nome"],
                                                            "paginas": 0, "vezes": 0})
        par["paginas"] += t["paginas"]
        par["vezes"] += 1
    ultimos = meses_antes(mes, 3)
    seguidos = {}
    for de, para, n in DB.execute(
            f"SELECT de_id, para_id, COUNT(DISTINCT mes) FROM movimentos WHERE tipo='transferencia' "
            f"AND mes IN ({','.join('?' * len(ultimos))}) GROUP BY de_id, para_id", ultimos):
        seguidos[(de, para)] = n
    frequentes = []
    for chave, par in pares.items():
        par["meses"] = seguidos.get(chave, 1)
        if par["vezes"] >= 3 or par["meses"] >= 3:
            frequentes.append(par)
    top = lambda d: sorted(d.values(), key=lambda x: (-x["paginas"], x["nome"]))[:5]  # noqa: E731
    soma = lambda tipo, campo: DB.execute(  # noqa: E731
        f"SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND tipo=? AND {campo} IS NULL",
        (mes, tipo)).fetchone()[0]
    reservas = []
    for imp in impressoras():
        r = resumo_impressora(imp, mes, [])
        reservas.append({"impressora_id": imp["id"], "nome": imp["nome"], "cor": imp["cor"], "reserva": r["reserva"]})
    pendentes = linhas(DB.execute(
        "SELECT p.id, p.paginas, p.motivo, p.criado_em, p.impressora_id, u.nome AS solicitante_nome, "
        "i.nome AS impressora_nome, i.cor FROM pedidos p JOIN usuarios u ON u.id=p.solicitante_id "
        "JOIN impressoras i ON i.id=p.impressora_id WHERE p.reserva=1 AND p.status='pendente' AND p.mes=? "
        "ORDER BY p.id", (mes_atual(),)))
    return {"mes": mes, "modo": modo_trocas(),
            "config": {"limite_doar_pct": int(cfg("limite_doar_pct") or 0),
                       "limite_receber_pct": int(cfg("limite_receber_pct") or 0),
                       "reserva_auto": int(cfg("reserva_auto") or 0)},
            "total": {"trocas": len(trocas), "paginas": sum(t["paginas"] for t in trocas),
                      "devolvidas": soma("devolucao", "para_id"), "da_reserva": soma("reserva", "de_id")},
            "doadores": top(doadores), "recebedores": top(recebedores),
            "pares": sorted(frequentes, key=lambda x: (-x["vezes"], -x["paginas"])),
            "reservas": reservas, "pendentes": pendentes, "aviso": aviso_troca()}


@rota("POST", "/api/admin/reserva/responder", auth="admin")
def r_reserva_responder(req):
    pid = inteiro(req.b("id"), "pedido")
    p = uma(DB.execute("SELECT * FROM pedidos WHERE id=? AND reserva=1", (pid,)))
    if not p or p["status"] != "pendente":
        raise Erro("Este pedido não está mais aguardando.")
    if p["mes"] != mes_atual():
        DB.execute("UPDATE pedidos SET status='expirado' WHERE id=?", (pid,))
        raise Erro("Este pedido era do mês passado e expirou.")
    if req.b("aceitar"):
        disp = reserva_disponivel(p["impressora_id"], p["mes"])
        if disp is not None and disp < p["paginas"]:
            raise Erro(f"A reserva desta impressora tem só {max(disp, 0)} páginas este mês.", 409, "sem_reserva")
        mid = transferir(None, p["solicitante_id"], p["impressora_id"], p["paginas"], "reserva", req.uid,
                         f"Pedido #{pid}")
        DB.execute("UPDATE pedidos SET status='aceito', respondido_por=?, respondido_em=? WHERE id=?",
                   (req.uid, agora(), pid))
        if p["solicitante_id"] != req.uid:
            postar(req.uid, p["solicitante_id"], "", "doacao", mid)
    else:
        DB.execute("UPDATE pedidos SET status='recusado', respondido_por=?, respondido_em=? WHERE id=?",
                   (req.uid, agora(), pid))
        if p["solicitante_id"] != req.uid:
            postar(req.uid, p["solicitante_id"],
                   f"A gestão não liberou o pedido de {p['paginas']} páginas da reserva.", "sistema")
    return {"ok": True}


@rota("POST", "/api/admin/anonimizar", auth="admin")
def r_anonimizar(req):
    """Apaga os dados pessoais de quem saiu (LGPD), mantendo os números dos relatórios."""
    uid = inteiro(req.b("id"), "pessoa")
    u = uma(DB.execute("SELECT * FROM usuarios WHERE id=?", (uid,)))
    if not u:
        raise Erro("Pessoa não encontrada.")
    if uid == req.uid:
        raise Erro("Você não pode apagar os seus próprios dados por aqui.")
    if u["anonimizado"]:
        raise Erro("Os dados desta pessoa já foram apagados.")
    if u["ativo"]:
        raise Erro("Desative a pessoa antes de apagar os dados pessoais.")
    apagar_dados_pessoais(uid)
    return {"ok": True}


def apagar_dados_pessoais(uid):
    """Troca o nome por \"Pessoa removida\", apaga login, senha, mensagens, arquivos e bloqueios; guarda só os números."""
    DB.execute("UPDATE usuarios SET nome=?, pin_hash=?, anonimizado=1, ciencia_privacidade=NULL, login=?, "
               "nomes_computador='', ativo=0, exclusao_pedida='' WHERE id=?", (f"Pessoa removida {uid}", hash_senha(secrets.token_hex(16)),
                                                  f"removido{uid}", uid))
    DB.execute("DELETE FROM sessoes WHERE usuario_id=?", (uid,))
    DB.execute("DELETE FROM leituras WHERE usuario_id=?", (uid,))
    DB.execute("DELETE FROM bloqueios WHERE usuario_id=? OR bloqueado_id=?", (uid, uid))
    DB.execute("UPDATE denuncias SET trecho='[apagado]' WHERE denunciante_id=? OR alvo_id=?", (uid, uid))
    DB.execute("UPDATE mensagens SET texto='[mensagem apagada]' WHERE de_id=? AND tipo='texto'", (uid,))
    DB.execute("UPDATE mensagens SET texto='' WHERE de_id=? AND tipo IN ('pedido','doacao')", (uid,))
    DB.execute("UPDATE movimentos SET obs='' WHERE criado_por=? AND tipo='transferencia'", (uid,))
    DB.execute("UPDATE trabalhos SET arquivo='[arquivo]', descricao='' WHERE usuario_id=?", (uid,))
    for c in linhas(DB.execute("SELECT * FROM conferencias WHERE usuario_id=? AND status='aguardando'", (uid,))):
        encerrar_conferencia(c, "cancelada")
    DB.execute("UPDATE conferencias SET nome='[arquivo]', descricao='' WHERE usuario_id=?", (uid,))
    for (caminho,) in DB.execute("SELECT caminho FROM uploads WHERE usuario_id=?", (uid,)).fetchall():
        try:
            os.remove(caminho)
        except OSError:
            pass
    DB.execute("DELETE FROM uploads WHERE usuario_id=?", (uid,))


@rota("GET", "/api/admin/trabalhos", auth="admin")
def r_admin_trabalhos(req):
    mes = ler_mes(req)
    trab = linhas(DB.execute(
        "SELECT t.*, u.nome AS usuario_nome, i.nome AS impressora_nome, i.cor, "
        f"ROUND(t.total * {CUSTO_SQL}, 2) AS custo FROM trabalhos t "
        "JOIN usuarios u ON u.id=t.usuario_id JOIN impressoras i ON i.id=t.impressora_id "
        "WHERE t.mes=? ORDER BY t.id DESC LIMIT 1000", (mes,)))
    movs = linhas(DB.execute(
        "SELECT m.*, i.nome AS impressora_nome, i.cor FROM movimentos m JOIN impressoras i ON i.id=m.impressora_id "
        "WHERE m.mes=? ORDER BY m.id DESC LIMIT 1000", (mes,)))
    for m in movs:
        m["de_nome"], m["para_nome"] = nome_usuario(m["de_id"]), nome_usuario(m["para_id"])
        m["por_nome"] = nome_usuario(m["criado_por"])
    return {"mes": mes, "trabalhos": trab, "movimentos": movs}


def filtros_relatorio(req):
    """Filtros do relatório: pessoa, impressora, finalidade e busca no nome do arquivo ou na descrição."""
    sql, params = sql_escopo(req.usuario)
    usados = {}
    st_ = req.q("setor")
    if st_ and st_.isdigit() and instalacao() == "central":
        ids = sorted(subarvore(int(st_)))
        sql += f" AND t.usuario_id IN (SELECT id FROM usuarios WHERE COALESCE(setor_id,1) IN ({','.join('?' * len(ids))}))"
        params = params + ids
        usados["setor"] = int(st_)
    pessoa = req.q("pessoa")
    if pessoa and pessoa.isdigit():
        sql += " AND t.usuario_id=?"
        params.append(int(pessoa))
        usados["pessoa"] = int(pessoa)
    imp = req.q("impressora")
    if imp and imp.isdigit():
        sql += " AND t.impressora_id=?"
        params.append(int(imp))
        usados["impressora"] = int(imp)
    fin = req.q("finalidade")
    if fin == "nenhuma":
        sql += " AND COALESCE(t.finalidade,'')=''"
        usados["finalidade"] = fin
    elif fin in finalidades_conhecidas():
        sql += " AND t.finalidade=?"
        params.append(fin)
        usados["finalidade"] = fin
    busca = " ".join((req.q("busca") or "").split())[:80]
    if busca:
        sql += " AND (t.arquivo LIKE ? OR t.descricao LIKE ?)"
        params += [f"%{busca}%", f"%{busca}%"]
        usados["busca"] = busca
    return sql, params, usados


def opcoes_finalidade(trabalhos):
    """Finalidades para o filtro: as de agora e as antigas que aparecem nas impressões do mês."""
    ativas = [{"id": i, "nome": n} for i, n, _ in finalidades_ativas()]
    if forma_finalidade() == "livre":  # no campo livre não há lista: só o texto livre e o documento pessoal
        ativas = [{"id": "livre", "nome": nome_finalidade("livre")}, {"id": "pessoal", "nome": nome_finalidade("pessoal")}]
    vistas = {t["finalidade"] for t in trabalhos if t["finalidade"]}
    ids = {f["id"] for f in ativas}
    return ativas + [{"id": i, "nome": nome_finalidade(i)} for i in sorted(vistas - ids) if i in finalidades_conhecidas()]


def dados_relatorio(req):
    """Tudo o que foi impresso no mês (ou no período), por quem e para quê, com os pontos que merecem atenção."""
    mes = ler_mes(req)
    periodo = ler_periodo(req)
    tcond, tpar = tempo_sql(periodo, mes, "t.mes", "t.criado_em")
    sql, params, usados = filtros_relatorio(req)
    todos = linhas(DB.execute(
        "SELECT t.*, u.nome AS usuario_nome, i.nome AS impressora_nome, i.cor, "
        f"ROUND(t.total * {CUSTO_SQL}, 2) AS custo FROM trabalhos t "
        "JOIN usuarios u ON u.id=t.usuario_id JOIN impressoras i ON i.id=t.impressora_id "
        f"WHERE {tcond}{sql} ORDER BY t.id DESC", (*tpar, *params)))
    conta = [t for t in todos if t["status"] in CONTA]
    totais = {"impressoes": len([t for t in conta if t["etapa"] != "resto"]), "paginas": sum(t["total"] for t in conta),
              "custo": round(sum(t["custo"] or 0 for t in conta), 2), "pessoas": len({t["usuario_id"] for t in conta}),
              "provas": len([t for t in conta if t["etapa"] == "prova"]),
              "erros": len([t for t in todos if t["status"] == "erro"])}
    por_fin = {}
    conhecidas = finalidades_conhecidas()
    for t in conta:
        f = t["finalidade"] if t["finalidade"] in conhecidas else ""
        if f == "livre":  # campo livre: uma linha para cada texto (iguais se juntam)
            d = por_fin.setdefault(("livre", (t["descricao"] or "").lower()),
                                   {"finalidade": "livre", "nome": rotulo_finalidade(t), "texto": t["descricao"] or "",
                                    "paginas": 0, "impressoes": 0, "custo": 0.0})
        else:
            d = por_fin.setdefault(f, {"finalidade": f or "nenhuma", "nome": nome_finalidade(f), "paginas": 0,
                                       "impressoes": 0, "custo": 0.0})
        d["paginas"] += t["total"]
        d["custo"] = round(d["custo"] + (t["custo"] or 0), 2)
        d["impressoes"] += t["etapa"] != "resto"
    ordem = [i for i, _, _ in finalidades_ativas()] + [i for i in conhecidas if i not in
                                                        {x for x, _, _ in finalidades_ativas()}] + [""]
    por_finalidade = sorted(por_fin.values(), key=lambda d: (-d["paginas"], ordem.index(d["finalidade"] if d["finalidade"] != "nenhuma" else "")))
    textos = [d for d in por_finalidade if "texto" in d]
    if len(textos) > MAX_TEXTOS_RELATORIO:  # muitos textos diferentes: os menores viram uma linha só
        resto = textos[MAX_TEXTOS_RELATORIO:]
        por_finalidade = [d for d in por_finalidade if not any(d is r for r in resto)]
        por_finalidade.append({"finalidade": "livre", "nome": f"Outros textos ({len(resto)})",
                               "paginas": sum(d["paginas"] for d in resto), "impressoes": sum(d["impressoes"] for d in resto),
                               "custo": round(sum(d["custo"] for d in resto), 2)})
    por_pes = {}
    for t in conta:
        d = por_pes.setdefault(t["usuario_id"], {"id": t["usuario_id"], "nome": t["usuario_nome"], "paginas": 0,
                                                 "impressoes": 0, "custo": 0.0, "pessoal": 0, "provas": 0,
                                                 "maior": 0, "por_finalidade": {}})
        d["paginas"] += t["total"]
        d["custo"] = round(d["custo"] + (t["custo"] or 0), 2)
        d["impressoes"] += t["etapa"] != "resto"
        d["provas"] += t["etapa"] == "prova"
        d["maior"] = max(d["maior"], t["total"])
        if t["finalidade"] == "pessoal":
            d["pessoal"] += t["total"]
        chave = t["finalidade"] if t["finalidade"] in conhecidas else "nenhuma"
        d["por_finalidade"][chave] = d["por_finalidade"].get(chave, 0) + t["total"]
    por_pessoa = sorted(por_pes.values(), key=lambda d: (-d["paginas"], d["nome"].lower()))
    atencao = []
    grande = int(cfg("alerta_grande") or 50)
    # impressões grandes (a prova e o resto da mesma impressão contam juntos)
    juntos = {}
    for t in conta:
        k = ("c", t["conferencia_id"]) if t["conferencia_id"] else ("t", t["id"])
        j = juntos.setdefault(k, {**t, "total_junto": 0})
        j["total_junto"] += t["total"]
    for j in sorted(juntos.values(), key=lambda x: -x["total_junto"]):
        if j["total_junto"] >= grande and len([a for a in atencao if a["tipo"] == "grande"]) < 10:
            atencao.append({"tipo": "grande", "usuario_id": j["usuario_id"], "nome": j["usuario_nome"],
                            "texto": f"{j['usuario_nome']}: \"{j['arquivo']}\" com {j['total_junto']} páginas "
                                     f"({rotulo_finalidade(j) if j['finalidade'] == 'livre' else nome_finalidade(j['finalidade']).lower()})",
                            "texto_pdf": f"{j['usuario_nome']}: uma impressão com {j['total_junto']} páginas"})
    # o mesmo arquivo várias vezes no mês
    rep_ = {}
    for t in conta:
        if t["etapa"] == "resto" or t["arquivo"] == "[arquivo]":
            continue
        k = (t["usuario_id"], (t["arquivo"] or "").strip().lower())
        r = rep_.setdefault(k, {"nome": t["usuario_nome"], "arquivo": t["arquivo"], "vezes": 0, "uid": t["usuario_id"]})
        r["vezes"] += 1
    for k, r in rep_.items():
        pags = sum(t["total"] for t in conta if (t["usuario_id"], (t["arquivo"] or "").strip().lower()) == k)
        r["paginas"] = pags
    for r in sorted(rep_.values(), key=lambda r: -r["paginas"]):
        if r["vezes"] >= 3:
            atencao.append({"tipo": "repetido", "usuario_id": r["uid"], "nome": r["nome"],
                            "texto": f"{r['nome']} imprimiu \"{r['arquivo']}\" {r['vezes']} vezes ({r['paginas']} páginas)",
                            "texto_pdf": f"{r['nome']} imprimiu o mesmo arquivo {r['vezes']} vezes ({r['paginas']} páginas)"})
    # muito acima da média da equipe
    if "pessoa" not in usados and len(por_pessoa) >= 3:
        media = sum(d["paginas"] for d in por_pessoa) / len(por_pessoa)
        for d in por_pessoa:
            if media and d["paginas"] >= 2 * media and d["paginas"] >= grande:
                vezes = f"{d['paginas'] / media:.1f}".replace(".", ",")
                atencao.append({"tipo": "media", "usuario_id": d["id"], "nome": d["nome"],
                                "texto": f"{d['nome']} imprimiu {vezes} vezes a média da equipe "
                                         f"({d['paginas']} páginas; a média foi {round(media)})"})
    mcond, mpar = tempo_sql(periodo, mes, "m.mes", "m.criado_em")
    movs = linhas(DB.execute(
        "SELECT m.*, i.nome AS impressora_nome, i.cor FROM movimentos m JOIN impressoras i ON i.id=m.impressora_id "
        f"WHERE {mcond}" + (" AND (m.de_id=? OR m.para_id=?)" if "pessoa" in usados else "") +
        (" AND m.impressora_id=?" if "impressora" in usados else "") + " ORDER BY m.id DESC LIMIT 1000",
        (*mpar, *([usados["pessoa"]] * 2 if "pessoa" in usados else []),
         *([usados["impressora"]] if "impressora" in usados else []))))
    for m in movs:
        m["de_nome"], m["para_nome"] = nome_usuario(m["de_id"]), nome_usuario(m["para_id"])
    for t in todos:
        t["finalidade_nome"] = rotulo_finalidade(t) if t["finalidade"] else ""
    pcond, ppar = tempo_sql(periodo, mes, "mes", "criado_em")
    pessoas = linhas(DB.execute("SELECT id, nome, ativo FROM usuarios WHERE anonimizado=0 OR id IN "
                                f"(SELECT usuario_id FROM trabalhos WHERE {pcond}) ORDER BY ativo DESC, nome COLLATE NOCASE",
                                ppar))
    if escopo(req.usuario) is not None:
        pessoas = [x for x in pessoas if no_escopo(req.usuario, x["id"])]
    return {"mes": mes, "periodo": periodo, "filtros": usados, "totais": totais, "por_finalidade": por_finalidade,
            "por_pessoa": por_pessoa, "atencao": atencao, "trabalhos": todos[:500], "total_lista": len(todos),
            "movimentos": movs, "alerta_grande": grande, "excecoes": excecoes_do_mes(req.usuario, mes, periodo),
            "opcoes": {"pessoas": pessoas,
                       "impressoras": [{"id": i["id"], "nome": i["nome"]} for i in impressoras(so_ativas=False)],
                       "finalidades": opcoes_finalidade(conta)}}


@rota("GET", "/api/admin/relatorio", auth="gestor")
def r_admin_relatorio(req):
    return dados_relatorio(req)


def texto_filtros(usados):
    """Os filtros do relatório, escritos para o PDF."""
    partes = []
    if "setor" in usados:
        partes.append(f"setor {nome_setor(usados['setor'])}")
    if "pessoa" in usados:
        partes.append(f"pessoa {nome_usuario(usados['pessoa'])}")
    if "impressora" in usados:
        achou = [i["nome"] for i in impressoras(so_ativas=False) if i["id"] == usados["impressora"]]
        partes.append(f"impressora {achou[0] if achou else '?'}")
    if "finalidade" in usados:
        partes.append("finalidade não informada" if usados["finalidade"] == "nenhuma"
                      else f"finalidade {nome_finalidade(usados['finalidade']).lower()}")
    if "busca" in usados:
        partes.append(f"busca \"{usados['busca']}\"")
    return "Filtros: " + "; ".join(partes) if partes else ""


def pdf_do_relatorio(req, papel_mm=(210.0, 297.0)):
    """O relatório de uma folha (números, finalidades, quem imprimiu e pontos de atenção). Sem nomes de arquivos."""
    r = dados_relatorio(req)
    if r["periodo"]:
        quando = r["periodo"]["rotulo"]
    else:
        quando = f"{MESES_PT[int(r['mes'][5:7]) - 1]} de {r['mes'][:4]}"
    return relatorio_pdf.pdf({"lugar": nome_local(), "quando": quando, "filtros": texto_filtros(r["filtros"]),
                              "gerado_em": agora(), "totais": r["totais"], "por_finalidade": r["por_finalidade"],
                              "por_pessoa": r["por_pessoa"], "atencao": r["atencao"], "alerta_grande": r["alerta_grande"]},
                             papel_mm), r


def nome_arquivo_relatorio(r, extensao):
    quando = f"{r['periodo']['de']}_a_{r['periodo']['ate']}" if r["periodo"] else r["mes"]
    return f"relatorio-{quando}.{extensao}"


@rota("GET", "/api/admin/relatorio.pdf", auth="gestor")
def r_relatorio_pdf(req):
    """Baixar o relatório em PDF (A4), com os mesmos filtros e o mesmo período da tela."""
    dados, r = pdf_do_relatorio(req)
    return Resposta(dados, "application/pdf",
                    {"Content-Disposition": f'attachment; filename="{nome_arquivo_relatorio(r, "pdf")}"'})


@rota("POST", "/api/admin/relatorio/imprimir", auth="admin", trava=False)
def r_relatorio_imprimir(req):
    """Imprime o relatório no papel da impressora escolhida. Não conta na cota de ninguém. Os filtros e o
    período vêm no endereço, como no relatório da tela."""
    with LOCK:
        imp = imp_por_id(req.b("impressora_id"))
        copias = inteiro(req.b("copias") or 1, "número de cópias", 1, 10)
        sumatra = cfg("sumatra")
        if not imp["sistema"]:
            raise Erro("Esta impressora está em modo teste. Escolha uma que já imprime de verdade.")
    area = area_impressora(imp)  # pode perguntar ao sistema de impressão: fica fora da trava
    with LOCK:
        dados, _ = pdf_do_relatorio(req, area["papel_mm"])
    destino = FILA / f"relatorio-{secrets.token_hex(6)}.pdf"
    destino.write_bytes(dados)
    try:
        impressao._mandar(str(destino), imp["sistema"], copias, "", False, False, sumatra, False, True, area.get("media", ""))
    except ErroImpressao as e:
        raise Erro(str(e), 502)
    finally:
        try:
            destino.unlink()
        except OSError:
            pass
    return {"ok": True, "impressora": imp["nome"], "copias": copias}


@rota("POST", "/api/admin/estornar", auth="gestor")
def r_estornar(req):
    tid = inteiro(req.b("id"), "trabalho")
    t = uma(DB.execute("SELECT * FROM trabalhos WHERE id=?", (tid,)))
    if t and not no_escopo(req.usuario, t["usuario_id"]):
        t = None
    if not t or t["status"] not in ("impresso", "teste"):
        raise Erro("Só dá para devolver páginas de impressões concluídas.")
    DB.execute("UPDATE trabalhos SET status='estornado', erro=? WHERE id=?",
               (f"Páginas devolvidas por {req.usuario['nome']} em {agora()}", tid))
    return {"ok": True}


@rota("POST", "/api/admin/apagar-testes", auth="admin")
def r_apagar_testes(req):
    n = DB.execute("DELETE FROM trabalhos WHERE status='teste'").rowcount
    return {"ok": True, "apagados": n}


@rota("GET", "/api/admin/sistema", auth="admin")
def r_sistema(req):
    s = situacao_cache(cfg("sumatra"), cfg("soffice"))
    expirar_retidas()
    aguardando = linhas(DB.execute(
        "SELECT id, criado_em, ip, usuario_so, nome, paginas, copias FROM retidas WHERE status='aguardando' "
        "ORDER BY id DESC"))
    return {**s, "virtual": info_impressora_virtual(), "aguardando": aguardando, "pasta": str(BASE),
            "acompanha": acompanhar.disponivel()}


_SIT = {"t": 0, "v": None}


def situacao_cache(sumatra, soffice):
    if time.time() - _SIT["t"] > 15 or _SIT["v"] is None:
        _SIT["v"] = impressao.situacao_ferramentas(sumatra, soffice)
        _SIT["t"] = time.time()
    return _SIT["v"]


@rota("POST", "/api/admin/config", auth="admin")
def r_config(req):
    antes = (cfg("filas_por_impressora"), cfg("anunciar_rede"), cfg("escola"), cfg("modo"))
    for k in CONFIG_PADRAO:
        if k in req.corpo and k not in CONFIG_INTERNA:
            if k == "finalidades":
                DB.execute("UPDATE config SET valor=? WHERE chave='finalidades'", (preparar_finalidades(req.corpo[k]),))
                continue
            v = str(req.corpo[k]).strip()[:300]
            if k == "tipo_local" and v not in LOCAIS:
                raise Erro("Escolha onde o Folha a Folha é usado: empresa, escola ou outra organização.")
            if k == "escola":
                v = v[:120]
                if instalacao() == "unidade":
                    continue  # o nome da unidade vem da central
            if k == "negativo":
                v = str(inteiro(v or 0, "limite da cota negativa", 0, 10000))
                if v != "0" and not politica_setor(1)["pode_negativo"]:
                    raise Erro("A TI não permite cota negativa nesta unidade.", 403)
            if k == "termos_url":
                v = str(v or "").strip()[:300]
                if v and not re.match(r"^https://[^\s]+$", v):
                    raise Erro("O endereço dos termos de uso precisa começar com https://", 400, k)
            if k in ("filtro_extras", "filtro_liberadas"):
                v = ", ".join(w.strip() for w in re.split(r"[,\n;]+", str(v or "")) if w.strip())[:2000]
            if k in ("aumento", "negativo_desconta", "confirmar_impressora", "cadastro_aberto", "filtro_ligado"):
                v = "0" if v in ("0", "False", "false", "") else "1"
            if k == "aviso_pct":
                v = str(inteiro(v, "percentual de aviso", 10, 100))
            if k == "max_copias":
                v = str(inteiro(v, "máximo de cópias", 1, 1000))
            if k == "reter_mensagens_meses":
                v = str(inteiro(v, "prazo das mensagens", 1, 120))
            if k == "horas_fila":
                v = str(inteiro(v, "tempo de espera das impressões", 1, 72))
            if k in ("filas_por_impressora", "anunciar_rede", "ipp_so_conectado"):
                v = "1" if str(v) in ("1", "true", "True") else "0"
            if k == "modo_trocas" and v not in MODOS_TROCA:
                raise Erro("Estilo de troca desconhecido.")
            if k == "limite_doar_pct":
                v = str(inteiro(v, "limite para passar", 0, 100))
            if k == "limite_receber_pct":
                v = str(inteiro(v, "limite para receber", 0, 500))
            if k == "reserva_auto":
                v = str(inteiro(v, "páginas liberadas na hora", 0, 5000))
            if k == "modo" and v not in MODOS:
                raise Erro("Estilo de instalação desconhecido.")
            if k == "finalidade" and v not in MODOS_FINALIDADE:
                raise Erro("Escolha onde pedir a finalidade.")
            if k == "finalidade_forma" and v not in FORMAS_FINALIDADE:
                raise Erro("Escolha como perguntar para que é a impressão: campo livre ou lista.")
            if k == "descricao" and v not in MODOS_DESCRICAO:
                raise Erro("Escolha quando pedir a descrição.")
            if k == "previa" and v not in MODOS_PREVIA:
                raise Erro("Escolha como fica a prévia.")
            if k == "prova" and v not in MODOS_PROVA:
                raise Erro("Escolha como fica a impressão de prova.")
            if k == "prova_minimo":
                v = str(inteiro(v, "número de páginas para a prova", 2, 10000))
            if k == "bloqueio_minutos":
                v = str(inteiro(v or 0, "tempo para bloquear a tela", 0, 480))
            if k == "alerta_grande":
                v = str(inteiro(v, "tamanho de impressão para destacar", 1, 100000))
            if k == "limite_pessoal" and v != "":
                v = str(inteiro(v, "limite de páginas pessoais", 0, 100000))
            if k == "site_empresa" and v and not re.match(r"https?://", v):
                v = "https://" + v
            DB.execute("UPDATE config SET valor=? WHERE chave=?", (v, k))
    marcadas = req.b("pede_finalidade")
    if isinstance(marcadas, dict):
        for iid, sim in marcadas.items():
            DB.execute("UPDATE impressoras SET pede_finalidade=? WHERE id=?", (1 if sim else 0, inteiro(iid, "impressora")))
    _SIT["t"] = 0
    if antes != (cfg("filas_por_impressora"), cfg("anunciar_rede"), cfg("escola"), cfg("modo")) and SERVIDOR["ativo"]:
        DB.commit()
        threading.Thread(target=aplicar_modo, daemon=True).start()
    return {"ok": True}


def celula_csv(v):
    """Texto que começa com = + - ou @ viraria fórmula no Excel e no Calc: ganha um apóstrofo na frente.
    Número escrito como texto (-3,50) fica como está."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") and not re.fullmatch(r"-?\d+(,\d+)?", v):
        return "'" + v
    return v


class EscritorCSV:
    """csv.writer com ponto e vírgula que protege cada célula (celula_csv)."""

    def __init__(self, buf):
        self._w = csv.writer(buf, delimiter=";")

    def writerow(self, linha):
        self._w.writerow([celula_csv(x) for x in linha])


@rota("GET", "/api/admin/relatorio.csv", auth="gestor")
def r_relatorio(req):
    mes = ler_mes(req)
    periodo = ler_periodo(req)
    quando = "do período" if periodo else "do mês"
    tcond, tpar = tempo_sql(periodo, mes, "t.mes", "t.criado_em")
    imps = impressoras(so_ativas=False)
    buf = io.StringIO()
    w = EscritorCSV(buf)
    meu = escopo(req.usuario)
    sql, params, usados = filtros_relatorio(req)
    if periodo:  # a cota é do mês: num período livre, a tabela por pessoa mostra só o que foi impresso
        w.writerow([f"Período: {periodo['rotulo']}"])
        w.writerow([])
        w.writerow(["Impressões por pessoa no período"])
        w.writerow(["Pessoa", "Impressões", "Páginas", "Gasto (R$)"])
        esc, esc_par = sql_escopo(req.usuario)
        for u in linhas(DB.execute(
                "SELECT u.nome AS nome, COUNT(*) AS impressoes, SUM(t.total) AS paginas, "
                f"SUM(t.total * {CUSTO_SQL}) AS custo FROM trabalhos t JOIN usuarios u ON u.id=t.usuario_id "
                f"JOIN impressoras i ON i.id=t.impressora_id WHERE {tcond} AND t.status IN ({','.join('?' * len(CONTA))})"
                f"{esc} GROUP BY t.usuario_id ORDER BY u.nome COLLATE NOCASE", (*tpar, *CONTA, *esc_par))):
            w.writerow([u["nome"], u["impressoes"], u["paginas"], moeda_csv(u["custo"])])
    else:
        cab = ["Pessoa"]
        for i in imps:
            cab += [f"{i['nome']} - cota do mês", f"{i['nome']} - recebidas", f"{i['nome']} - passadas",
                    f"{i['nome']} - impressas", f"{i['nome']} - saldo", f"{i['nome']} - gasto (R$)"]
        w.writerow(cab)
        for u in linhas(DB.execute("SELECT id, nome, COALESCE(setor_id,1) AS sid FROM usuarios ORDER BY nome COLLATE NOCASE")):
            if meu is not None and u["sid"] not in meu:
                continue
            linha = [u["nome"]]
            for i in imps:
                s = saldo(u["id"], i["id"], mes)
                linha += [s["base"], s["recebido"], s["cedido"], s["usado"], s["restante"], moeda_csv(s["gasto"])]
            w.writerow(linha)
    w.writerow([])
    w.writerow([f"Impressões {quando}" + (" (com filtro)" if usados else "")])
    w.writerow(["Data", "Pessoa", "Impressora", "Arquivo", "Finalidade", "Descrição", "Páginas", "Cópias",
                "Frente e verso", "Total", "Custo (R$)", "Etapa", "Situação", "Além da cota", "Justificativa"])
    etapas = {"prova": "Prova", "resto": "Resto depois da prova"}
    situacoes = {"impresso": "Impresso", "teste": "Modo teste", "erro": "Não imprimiu", "estornado": "Páginas devolvidas",
                 "enviando": "Enviando", "na_fila": "Na fila da impressora"}
    por_fin = {}
    for t in linhas(DB.execute(
            f"SELECT t.*, u.nome AS un, i.nome AS inome, t.total * {CUSTO_SQL} AS custo FROM trabalhos t "
            f"JOIN usuarios u ON u.id=t.usuario_id JOIN impressoras i ON i.id=t.impressora_id "
            f"WHERE {tcond}{sql} ORDER BY t.id", (*tpar, *params))):
        fin = rotulo_finalidade(t) if t["finalidade"] else ""
        w.writerow([t["criado_em"], t["un"], t["inome"], t["arquivo"], fin,
                    "" if t["finalidade"] == "livre" else (t["descricao"] or ""), t["paginas_sel"],
                    t["copias"], "Sim" if t["frente_verso"] else "Não", t["total"], moeda_csv(t["custo"]),
                    etapas.get(t["etapa"] or "", ""), situacoes.get(t["status"], t["status"]),
                    t["excedente"] or "", t["justificativa"] or ""])
        if t["status"] in CONTA:
            d = por_fin.setdefault(fin or "Não informada", [0, 0.0])
            d[0] += t["total"]
            d[1] += t["custo"] or 0
    w.writerow([])
    w.writerow([f"Páginas por finalidade" + (" (com filtro)" if usados else "")])
    w.writerow(["Finalidade", "Páginas", "Custo (R$)"])
    for nome, (pags, custo) in sorted(por_fin.items(), key=lambda x: -x[1][0]):
        w.writerow([nome, pags, moeda_csv(custo)])
    w.writerow([])
    w.writerow([f"Trocas, devoluções e liberações {quando}"])
    w.writerow(["Data", "Tipo", "De", "Para", "Impressora", "Páginas"])
    nomes_tipo = {"transferencia": "Troca entre colegas", "ajuste": "Ajuste da gestão",
                  "devolucao": f"Devolução {L('ao')}", "reserva": "Liberação da reserva",
                  "aumento": "Aumento de cota", "desconto": "Desconto do mês anterior (cota negativa)"}
    mcond, mpar = tempo_sql(periodo, mes, "m.mes", "m.criado_em")
    for m in linhas(DB.execute(
            "SELECT m.*, d.nome AS dn, p.nome AS pn, i.nome AS inome FROM movimentos m "
            "LEFT JOIN usuarios d ON d.id=m.de_id LEFT JOIN usuarios p ON p.id=m.para_id "
            f"JOIN impressoras i ON i.id=m.impressora_id WHERE {mcond} ORDER BY m.id", mpar)):
        w.writerow([m["criado_em"], nomes_tipo.get(m["tipo"], m["tipo"]), m["dn"] or L("nome"), m["pn"] or L("nome"),
                    m["inome"], m["paginas"]])
    w.writerow([])
    w.writerow([f"Exceções {quando} (com justificativa)"])
    w.writerow(["Data", "Tipo", "Setor", "Pessoa", "Impressora", "Páginas", "Justificativa", "Decisão", "Registrado por"])
    for x in excecoes_do_mes(req.usuario, mes, periodo):
        w.writerow([x["criado_em"], x["rotulo"], x["setor"], x["pessoa"] or "", x["impressora"] or "", x["paginas"],
                    x["justificativa"] or "", x["decisao"] or "", x["por_nome"] or ""])
    w.writerow([])
    w.writerow([f"Custo por impressora {quando}"])
    w.writerow(["Impressora", "Custo por página (R$)", "Páginas", "Gasto (R$)",
                "Média de páginas/mês antes do sistema"])
    esc, esc_par = sql_escopo(req.usuario)
    for i in imps:
        if periodo:
            r = linhas(DB.execute(
                f"SELECT COALESCE(SUM(t.total),0) AS usado, COALESCE(SUM(t.total * {CUSTO_SQL}),0) AS gasto "
                f"FROM trabalhos t JOIN impressoras i ON i.id=t.impressora_id WHERE {tcond} AND t.impressora_id=? "
                f"AND t.status IN ({','.join('?' * len(CONTA))}){esc}", (*tpar, i["id"], *CONTA, *esc_par)))[0]
        else:
            r = resumo_impressora(i, mes, [])
        w.writerow([i["nome"], moeda_csv(i["custo_pagina"] or 0, 4), r["usado"], moeda_csv(r["gasto"]),
                    i["base_mensal"] or ""])
    nome = f"impressoes-{periodo['de']}_a_{periodo['ate']}" if periodo else f"impressoes-{mes}"
    return Resposta("﻿" + buf.getvalue(), "text/csv; charset=utf-8",
                    {"Content-Disposition": f'attachment; filename="{nome}.csv"'})


def moeda_csv(v, casas=2):
    """Número com vírgula decimal, como o Excel em português espera."""
    txt = f"{float(v or 0):.{casas}f}"
    if casas > 2:
        txt = txt.rstrip("0")
        if len(txt.split(".")[1]) < 2:
            txt = f"{float(v or 0):.2f}"
    return txt.replace(".", ",")


# ================================================================ 2.0: setores, cotas delegadas, exceções e central

INSTALACOES = ("local", "central", "unidade")
POLITICA_PADRAO = {"cadastro": "gestor", "exceder": False, "pode_negativo": False,
                   "aumento": True, "negativo": 0, "negativo_desconta": True}
TENTATIVAS_ADESAO = {}


def instalacao():
    v = cfg("instalacao")
    return v if v in INSTALACOES else "local"


def fmt(x):
    return f"{int(x):,}".replace(",", ".")


def proximo_mes(mes):
    a, m = map(int, mes.split("-"))
    return f"{a + (m == 12)}-{m % 12 + 1:02d}"


def mes_anterior(mes):
    a, m = map(int, mes.split("-"))
    return f"{a - (m == 1)}-{(m - 2) % 12 + 1:02d}"


def mes_curto(mes):
    return f"{mes[5:]}/{mes[:4]}"


def setor(sid):
    r = uma(DB.execute("SELECT * FROM setores WHERE id=?", (int(sid or 1),)))
    if not r:
        raise Erro("Setor não encontrado.", 404)
    return r


def setor_de(uid):
    r = DB.execute("SELECT COALESCE(setor_id,1) FROM usuarios WHERE id=?", (uid,)).fetchone()
    return r[0] if r else 1


def nome_setor(sid):
    if (sid or 1) == 1:
        return nome_local()
    r = DB.execute("SELECT nome FROM setores WHERE id=?", (sid,)).fetchone()
    return r[0] if r else ""


def caminho_setor(sid):
    nomes, atual, vistos = [], sid, set()
    while atual and atual != 1 and atual not in vistos:
        vistos.add(atual)
        r = DB.execute("SELECT nome, pai_id FROM setores WHERE id=?", (atual,)).fetchone()
        if not r:
            break
        nomes.append(r[0])
        atual = r[1]
    return " › ".join(reversed(nomes)) or nome_local()


def subarvore(sid):
    ids, fila = {sid}, [sid]
    while fila:
        for (f,) in DB.execute("SELECT id FROM setores WHERE pai_id=?", (fila.pop(),)):
            if f not in ids:
                ids.add(f)
                fila.append(f)
    return ids


def escopo(u):
    """Setores que a pessoa administra: None = todos (gestor geral; na central, a TI)."""
    if u["papel"] == "admin":
        return None
    if u["papel"] == "gestor":
        return subarvore(u["setor_id"] or 1)
    return set()


def no_escopo(u, uid):
    e = escopo(u)
    return e is None or setor_de(uid) in e


def sql_escopo(u, coluna="t.usuario_id"):
    """Trecho de SQL que limita aos setores do gestor."""
    e = escopo(u)
    if e is None:
        return "", []
    return (f" AND {coluna} IN (SELECT id FROM usuarios WHERE COALESCE(setor_id,1) IN ({','.join('?' * len(e))}))",
            sorted(e))


def politica_setor(s):
    """Regras do setor. As da raiz (instalação local, central ou unidade) ficam nos ajustes; na unidade,
    o que pode passar do limite vem assinado pela central."""
    if not isinstance(s, dict):
        s = setor(s)
    pol = dict(POLITICA_PADRAO)
    if s["id"] == 1:
        pol.update({"aumento": cfg("aumento") != "0", "negativo": int(cfg("negativo") or 0),
                    "negativo_desconta": cfg("negativo_desconta") != "0", "exceder": True, "pode_negativo": True})
        if instalacao() == "unidade":
            cap = (pacote_atual() or {}).get("politica") or {}
            pol.update({"exceder": bool(cap.get("exceder")), "pode_negativo": bool(cap.get("pode_negativo")),
                        "cadastro": cap.get("cadastro") or "gestor"})
    else:
        try:
            p = json.loads(s.get("politica") or "{}")
        except ValueError:
            p = {}
        pol.update({k: p[k] for k in POLITICA_PADRAO if k in p})
    if not pol["pode_negativo"]:
        pol["negativo"] = 0
    return pol


def preparar_politica(valor, atual):
    p = dict(atual)
    if not isinstance(valor, dict):
        return p
    for k in ("exceder", "pode_negativo", "aumento", "negativo_desconta"):
        if k in valor:
            p[k] = bool(valor[k])
    if "cadastro" in valor:
        p["cadastro"] = "ti" if valor["cadastro"] == "ti" else "gestor"
    if "negativo" in valor:
        p["negativo"] = inteiro(valor["negativo"] or 0, "limite da cota negativa", 0, 10000)
    return p


def info_negativo(uid, mes):
    pol = politica_setor(setor_de(uid))
    usado = DB.execute(f"SELECT COALESCE(SUM(excedente),0) FROM trabalhos WHERE usuario_id=? AND mes=? "
                       f"AND status IN ({','.join('?' * len(CONTA))})", (uid, mes, *CONTA)).fetchone()[0]
    lim = int(pol["negativo"] or 0)
    desconto = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND de_id=? AND tipo='desconto'",
                          (mes, uid)).fetchone()[0]
    return {"limite": lim, "usado": usado, "resta": max(0, lim - usado), "desconta": bool(pol["negativo_desconta"]),
            "aumento": bool(pol["aumento"]), "descontado_mes": desconto}


def registrar_excecao(tipo, mes, sid, uid, iid, paginas, justificativa, decisao, por, ref=None):
    DB.execute("INSERT INTO excecoes(mes, tipo, setor_id, usuario_id, impressora_id, paginas, justificativa, decisao, "
               "por_id, ref_id, criado_em) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
               (mes, tipo, sid, uid, iid, paginas, (justificativa or "")[:500], (decisao or "")[:300], por, ref, agora()))


def registrar_negativo(uid, imp, paginas, justificativa, tid, mes):
    """Impressão além da cota: fica registrada com a justificativa e, se a gestão escolheu, sai do mês seguinte."""
    neg = info_negativo(uid, mes)
    registrar_excecao("negativo", mes, setor_de(uid), uid, imp["id"], paginas, justificativa,
                      "Desconta no mês seguinte" if neg["desconta"] else "Sem desconto", uid, tid)
    if neg["desconta"]:
        DB.execute("INSERT INTO movimentos(mes, impressora_id, de_id, para_id, paginas, tipo, obs, criado_por, "
                   "criado_em, trabalho_id) VALUES(?,?,?,NULL,?,'desconto',?,?,?,?)",
                   (proximo_mes(mes), imp["id"], uid, paginas,
                    f"Impressão além da cota em {mes_curto(mes)}: {justificativa}"[:300], uid, agora(), tid))


def membros_setor(sid, ativos=True):
    return [r[0] for r in DB.execute("SELECT id FROM usuarios WHERE COALESCE(setor_id,1)=?" +
                                     (" AND ativo=1" if ativos else ""), (sid,))]


def distribuido_setor(sid, mes=None):
    """O que o setor já entregou: cotas das pessoas do próprio setor (todas as impressoras), cotas dos setores
    de baixo e, no mês, o que a gestão liberou a mais (aumentos e páginas liberadas)."""
    mes = mes or mes_atual()
    pessoas = membros_setor(sid)
    base = extra = 0
    if pessoas:
        ph = ",".join("?" * len(pessoas))
        base = DB.execute(f"SELECT COALESCE(SUM(mensal),0) FROM cotas WHERE usuario_id IN ({ph})", pessoas).fetchone()[0]
        base += DB.execute(f"SELECT COALESCE(SUM(mensal),0) FROM cotas_remotas WHERE usuario_id IN ({ph})",
                           pessoas).fetchone()[0]
        extra = DB.execute(f"SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND de_id IS NULL AND "
                           f"tipo IN ('aumento','ajuste') AND para_id IN ({ph})", [mes, *pessoas]).fetchone()[0]
    filhos = DB.execute("SELECT COALESCE(SUM(cota),0) FROM setores WHERE pai_id=? AND ativo=1", (sid,)).fetchone()[0]
    return {"pessoas": base, "setores": filhos, "extra": extra, "total": base + filhos + extra}


def limite_setor(s):
    """Páginas por mês que o setor pode entregar (None = sem limite próprio)."""
    if s["id"] == 1:
        if instalacao() == "unidade":
            pac = pacote_atual()
            return int(pac.get("cota") or 0) if pac else 0
        return None
    return int(s["cota"] or 0)


def conferir_setor(sid, antes, justificativa, por, motivo=""):
    """Depois de uma mudança: se o setor passou da própria cota (e a mudança aumentou o que ele entrega),
    só segue se quem está acima deixou passar, com a justificativa registrada."""
    s = setor(sid)
    lim = limite_setor(s)
    if lim is None:
        return
    d = distribuido_setor(sid)["total"]
    if d <= lim or d <= antes:
        return
    nome = nome_setor(sid)
    dados = {"limite": lim, "total": d, "setor": nome}
    if not politica_setor(s)["exceder"]:
        raise Erro(f"Passa da cota de {nome}: são {fmt(lim)} páginas por mês e ficaria {fmt(d)}. "
                   "Diminua de alguém ou peça mais à TI.", 409, "setor_cheio", dados=dados)
    just = str(justificativa or "").strip()
    if len(just) < 5:
        raise Erro(f"Passa da cota de {nome}: são {fmt(lim)} páginas por mês e ficaria {fmt(d)}. "
                   "A TI permite passar, mas é preciso escrever a justificativa.", 409, "justificar_setor", dados=dados)
    registrar_excecao("setor_acima", mes_atual(), sid, None, None, d - lim, just, motivo, por)
    if s["id"] != 1:
        marcar_pacote(sid)


def somas_impressoras():
    return {r[0]: r[1] for r in DB.execute(
        "SELECT c.impressora_id, COALESCE(SUM(c.mensal),0) FROM cotas c JOIN usuarios u ON u.id=c.usuario_id "
        "WHERE u.ativo=1 GROUP BY c.impressora_id")}


def conferir_impressoras(antes):
    """A soma das cotas das pessoas numa impressora não pode passar da cota do grupo (se houver)."""
    for iid, soma in somas_impressoras().items():
        imp = uma(DB.execute("SELECT * FROM impressoras WHERE id=?", (iid,)))
        if imp and imp["cota_total"] and soma > imp["cota_total"] and soma > antes.get(iid, 0):
            raise Erro(f"A soma das cotas na {imp['nome']} ficaria {fmt(soma)}, mais que a cota do grupo "
                       f"({fmt(imp['cota_total'])}). Diminua de alguém ou aumente a cota do grupo em Impressoras.",
                       409, "impressora_cheia")


# ---------------------------------------------------------------- aumento de cota

def aumentos_de(uid):
    return [{"id": a["id"], "impressora": a["imp_nome"], "paginas": a["paginas"], "status": a["status"],
             "aprovadas": a["aprovadas"], "decisao": a["decisao"], "justificativa": a["justificativa"],
             "criado_em": a["criado_em"], "respondido_em": a["respondido_em"]}
            for a in linhas(DB.execute(
                "SELECT a.*, i.nome AS imp_nome FROM aumentos a LEFT JOIN impressoras i ON i.id=a.impressora_id "
                "WHERE a.usuario_id=? AND (a.status='pendente' OR a.mes=?) ORDER BY a.id DESC LIMIT 10",
                (uid, mes_atual())))]


@rota("POST", "/api/aumento/pedir")
def r_pedir_aumento(req):
    if not politica_setor(setor_de(req.uid))["aumento"]:
        raise Erro("Aqui a gestão não recebe pedidos de aumento de cota.", 403, "sem_aumento")
    imp = imp_por_id(req.b("impressora_id"))
    paginas = inteiro(req.b("paginas"), "número de páginas", 1, 10000)
    just = " ".join(str(req.b("justificativa") or "").split())[:500]
    if len(just) < 5:
        raise Erro("Escreva para que você precisa das páginas.")
    if DB.execute("SELECT 1 FROM aumentos WHERE usuario_id=? AND impressora_id=? AND status='pendente'",
                  (req.uid, imp["id"])).fetchone():
        raise Erro("Você já tem um pedido de aumento esperando resposta nesta impressora.")
    aid = DB.execute("INSERT INTO aumentos(mes, usuario_id, impressora_id, paginas, justificativa, status, criado_em) "
                     "VALUES(?,?,?,?,?, 'pendente', ?)", (mes_atual(), req.uid, imp["id"], paginas, just, agora())).lastrowid
    return {"ok": True, "id": aid}


@rota("POST", "/api/aumento/cancelar")
def r_cancelar_aumento(req):
    aid = inteiro(req.b("id"), "pedido")
    DB.execute("UPDATE aumentos SET status='cancelado', respondido_em=? WHERE id=? AND usuario_id=? AND status='pendente'",
               (agora(), aid, req.uid))
    return {"ok": True}


@rota("GET", "/api/admin/aumentos", auth="gestor")
def r_aumentos(req):
    extra, params = sql_escopo(req.usuario, "a.usuario_id")
    lista = linhas(DB.execute(
        "SELECT a.*, u.nome AS pessoa, i.nome AS impressora, r.nome AS respondido_nome FROM aumentos a "
        "JOIN usuarios u ON u.id=a.usuario_id LEFT JOIN impressoras i ON i.id=a.impressora_id "
        f"LEFT JOIN usuarios r ON r.id=a.respondido_por WHERE a.status IN ('pendente','aprovado','recusado'){extra} "
        "ORDER BY a.status='pendente' DESC, a.id DESC LIMIT 60", params))
    mes = mes_atual()
    for a in lista:
        sid = setor_de(a["usuario_id"])
        a["setor"] = nome_setor(sid)
        s = saldo(a["usuario_id"], a["impressora_id"], mes)
        a["restante"] = s["restante"]
        lim = limite_setor(setor(sid))
        d = distribuido_setor(sid)["total"]
        a["setor_sobra"] = None if lim is None else lim - d
        a["setor_exceder"] = politica_setor(sid)["exceder"]
    return {"aumentos": lista}


@rota("POST", "/api/admin/aumento/responder", auth="gestor")
def r_responder_aumento(req):
    aid = inteiro(req.b("id"), "pedido")
    a = uma(DB.execute("SELECT * FROM aumentos WHERE id=?", (aid,)))
    if not a or not no_escopo(req.usuario, a["usuario_id"]):
        raise Erro("Pedido não encontrado.", 404)
    if a["status"] != "pendente":
        raise Erro("Este pedido já foi respondido.")
    decisao = " ".join(str(req.b("decisao") or "").split())[:300]
    imp = imp_por_id(a["impressora_id"])
    sid = setor_de(a["usuario_id"])
    mes = mes_atual()
    if req.b("aprovar"):
        paginas = inteiro(req.b("paginas") or a["paginas"], "páginas aprovadas", 1, a["paginas"])
        antes = distribuido_setor(sid)["total"]
        mid = transferir(None, a["usuario_id"], imp["id"], paginas, "aumento", req.uid,
                         f"Aumento de cota: {a['justificativa']}"[:300])
        conferir_setor(sid, antes, req.b("justificativa_setor"), req.uid,
                       motivo=f"Aumento de {paginas} páginas para {nome_usuario(a['usuario_id'])}")
        DB.execute("UPDATE aumentos SET status='aprovado', aprovadas=?, decisao=?, respondido_por=?, respondido_em=? "
                   "WHERE id=?", (paginas, decisao, req.uid, agora(), aid))
        registrar_excecao("aumento", mes, sid, a["usuario_id"], imp["id"], paginas, a["justificativa"],
                          decisao or "Aprovado", req.uid, aid)
        postar(req.uid, a["usuario_id"], f"Aumento de cota aprovado: {paginas} páginas na {imp['nome']}."
               + (f" {decisao}" if decisao else ""), "doacao", mid)
        return {"ok": True, "aprovadas": paginas}
    if len(decisao) < 3:
        raise Erro("Escreva o motivo para não aprovar. A pessoa vai ler.")
    DB.execute("UPDATE aumentos SET status='recusado', decisao=?, respondido_por=?, respondido_em=? WHERE id=?",
               (decisao, req.uid, agora(), aid))
    registrar_excecao("aumento_recusado", mes, sid, a["usuario_id"], imp["id"], a["paginas"], a["justificativa"],
                      decisao, req.uid, aid)
    postar(req.uid, a["usuario_id"], f"Pedido de aumento de {a['paginas']} páginas na {imp['nome']} não aprovado: "
           f"{decisao}")
    return {"ok": True}


def excecoes_do_mes(u, mes, periodo=None):
    tcond, tpar = tempo_sql(periodo, mes, "x.mes", "x.criado_em")
    extra, params = "", []
    e = escopo(u)
    if e is not None:
        extra = f" AND x.setor_id IN ({','.join('?' * len(e))})"
        params = sorted(e)
    rot = {"negativo": "Além da cota", "aumento": "Aumento aprovado", "aumento_recusado": "Aumento não aprovado",
           "setor_acima": "Setor acima da cota"}
    saida = []
    for x in linhas(DB.execute(
            "SELECT x.*, u.nome AS pessoa, i.nome AS impressora, p.nome AS por_nome FROM excecoes x "
            "LEFT JOIN usuarios u ON u.id=x.usuario_id LEFT JOIN impressoras i ON i.id=x.impressora_id "
            f"LEFT JOIN usuarios p ON p.id=x.por_id WHERE {tcond}{extra} ORDER BY x.id DESC", (*tpar, *params))):
        x["rotulo"] = rot.get(x["tipo"], x["tipo"])
        x["setor"] = nome_setor(x["setor_id"] or 1)
        saida.append(x)
    return saida


# ---------------------------------------------------------------- setores (instalação central)

def resumo_remoto(s, mes):
    try:
        r = json.loads(s.get("resumo") or "{}")
    except ValueError:
        r = {}
    return (r.get("meses") or {}).get(mes) or {}


def uso_setor(sids, mes):
    """Páginas e excedentes do mês nos setores servidos por esta central (os remotos vêm do relatório)."""
    ph = ",".join("?" * len(sids))
    r = DB.execute(f"SELECT COALESCE(SUM(t.total),0), COALESCE(SUM(t.excedente),0) FROM trabalhos t JOIN usuarios u "
                   f"ON u.id=t.usuario_id WHERE t.mes=? AND COALESCE(u.setor_id,1) IN ({ph}) AND t.status IN "
                   f"({','.join('?' * len(CONTA))})", (mes, *sids, *CONTA)).fetchone()
    paginas, excedente = r[0], r[1]
    for s in linhas(DB.execute(f"SELECT * FROM setores WHERE remoto=1 AND id IN ({ph})", list(sids))):
        rr = resumo_remoto(s, mes)
        paginas += int(rr.get("paginas") or 0)
        excedente += int(rr.get("excedente") or 0)
    return paginas, excedente


def precisa_central():
    if instalacao() != "central":
        raise Erro("Isto é da instalação central da TI.", 403)


@rota("GET", "/api/admin/setores", auth="admin")
def r_setores(req):
    precisa_central()
    mes = ler_mes(req)
    todos = linhas(DB.execute("SELECT * FROM setores ORDER BY pai_id IS NOT NULL, ordem, nome COLLATE NOCASE"))
    saida = []
    for s in todos:
        sub = subarvore(s["id"])
        pag, exc = uso_setor(sub, mes)
        gestores = [r[0] for r in DB.execute("SELECT nome FROM usuarios WHERE setor_id=? AND papel='gestor' AND ativo=1 "
                                             "ORDER BY nome COLLATE NOCASE", (s["id"],))]
        d = distribuido_setor(s["id"], mes)
        pol = politica_setor(s)
        rr = resumo_remoto(s, mes) if s["remoto"] else {}
        try:
            topo = json.loads(s["resumo"] or "{}") if s["remoto"] else {}
        except ValueError:
            topo = {}
        saida.append({
            "id": s["id"], "nome": nome_setor(s["id"]), "pai_id": s["pai_id"], "caminho": caminho_setor(s["id"]),
            "cota": limite_setor(s), "remoto": bool(s["remoto"]), "ativo": bool(s["ativo"]), "politica": pol,
            "gestores": gestores, "pessoas": len(membros_setor(s["id"])), "distribuido": d, "usado": pag,
            "excedente": exc, "ultimo_contato": s["ultimo_contato"], "aparelho": s["aparelho"],
            "aderido": bool(s["token_hash"]), "codigo_ativo": bool(s["adesao_hash"]) and (s["adesao_ate"] or "") > agora(),
            "impressoras_remotas": linhas(DB.execute("SELECT ref, nome, ativa FROM unidade_impressoras WHERE setor_id=? "
                                                     "ORDER BY nome", (s["id"],))) if s["remoto"] else [],
            "remoto_resumo": {"distribuido": topo.get("distribuido"), "pessoas": topo.get("pessoas"),
                              "por_finalidade": rr.get("por_finalidade") or {}, "custo": rr.get("custo"),
                              "versao_app": topo.get("versao_app"), "gerado_em": topo.get("gerado_em")}
                             if s["remoto"] else None,
            "pacote_versao": s["pacote_versao"]})
    return {"mes": mes, "setores": saida, "endereco": ENDERECOS, "excecoes": excecoes_do_mes(req.usuario, mes)}


def marcar_pacote(sid):
    DB.execute("UPDATE setores SET pacote_versao=COALESCE(pacote_versao,0)+1 WHERE id=? AND remoto=1", (sid,))


@rota("POST", "/api/admin/setor", auth="admin")
def r_salvar_setor(req):
    precisa_central()
    sid = req.b("id")
    nome = " ".join(str(req.b("nome") or "").split())[:80]
    if not nome:
        raise Erro("Dê um nome ao setor.")
    pai = setor(req.b("pai_id") or 1)
    if pai["remoto"]:
        raise Erro("Uma unidade com aparelho próprio não tem setores dentro dela.")
    cota = inteiro(req.b("cota") or 0, "cota do setor", 0, 10000000)
    remoto = 1 if req.b("remoto") else 0
    ativo = 0 if req.b("ativo") is False else 1
    antes_pai = distribuido_setor(pai["id"])["total"]
    if sid:
        s = setor(sid)
        if s["id"] == 1:
            raise Erro("O nome geral muda em Ajustes, Geral.")
        if pai["id"] in subarvore(s["id"]):
            raise Erro("Um setor não pode ficar dentro dele mesmo.")
        if remoto and DB.execute("SELECT 1 FROM setores WHERE pai_id=? AND ativo=1", (s["id"],)).fetchone():
            raise Erro("Este setor tem setores dentro dele. Só um setor sem subdivisões pode ter aparelho próprio.")
        if not ativo and (membros_setor(s["id"]) or DB.execute("SELECT 1 FROM setores WHERE pai_id=? AND ativo=1",
                                                               (s["id"],)).fetchone()):
            raise Erro("Antes de desativar, mude as pessoas e os setores de dentro dele para outro lugar.")
        pol = preparar_politica(req.b("politica"), politica_setor(s))
        DB.execute("UPDATE setores SET nome=?, pai_id=?, cota=?, remoto=?, ativo=?, politica=? WHERE id=?",
                   (nome, pai["id"], cota, remoto, ativo, json.dumps(pol), s["id"]))
    else:
        pol = preparar_politica(req.b("politica"), dict(POLITICA_PADRAO))
        sid = DB.execute("INSERT INTO setores(nome, pai_id, cota, remoto, ativo, politica, criado_em, pacote_versao) "
                         "VALUES(?,?,?,?,?,?,?,1)", (nome, pai["id"], cota, remoto, ativo, json.dumps(pol), agora())).lastrowid
    conferir_setor(pai["id"], antes_pai, req.b("justificativa"), req.uid, motivo=f"Cota de {nome}")
    marcar_pacote(sid)
    return {"ok": True, "id": sid}


def codigo_legivel():
    letras = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    c = "".join(secrets.choice(letras) for _ in range(12))
    return f"{c[:4]}-{c[4:8]}-{c[8:]}"


def hash_texto(t):
    return hashlib.sha256(t.encode()).hexdigest()


@rota("POST", "/api/admin/setor/adesao", auth="admin")
def r_codigo_adesao(req):
    precisa_central()
    s = setor(req.b("id"))
    if not s["remoto"]:
        raise Erro("Só unidades com aparelho próprio recebem código.")
    codigo = codigo_legivel()
    ate = (dt.datetime.now() + dt.timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
    DB.execute("UPDATE setores SET adesao_hash=?, adesao_ate=? WHERE id=?", (hash_texto(codigo.replace("-", "")), ate, s["id"]))
    segredo_central()
    return {"codigo": codigo, "ate": ate, "endereco": ENDERECOS[0] if ENDERECOS else ""}


@rota("GET", "/api/admin/setor/arquivo", auth="admin")
def r_arquivo_adesao(req):
    """Arquivo para ligar a unidade sem internet (pendrive). Gera uma chave nova: o aparelho antigo da unidade
    deixa de sincronizar."""
    precisa_central()
    s = setor(req.q("id"))
    if not s["remoto"]:
        raise Erro("Só unidades com aparelho próprio recebem o arquivo.")
    token = secrets.token_urlsafe(32)
    DB.execute("UPDATE setores SET token_hash=?, adesao_hash='' WHERE id=?", (hash_texto(token), s["id"]))
    DB.commit()
    s = setor(s["id"])
    corpo = {"tipo": "folha-a-folha-adesao", "versao": 1, "unidade_id": s["id"], "token": token,
             "chave_publica": publica_central(), "central": nome_local(),
             "endereco": ENDERECOS[0] if ENDERECOS else "", "pacote": pacote_assinado(s)}
    nome = re.sub(r"[^A-Za-z0-9]+", "-", unicodedata.normalize("NFKD", s["nome"]).encode("ascii", "ignore").decode()).strip("-")
    return Resposta(json.dumps(corpo, ensure_ascii=False, indent=1).encode(), "application/json",
                    {"Content-Disposition": f'attachment; filename="folha-a-folha-adesao-{nome or s["id"]}.json"'})


@rota("POST", "/api/admin/setor/relatorio", auth="admin")
def r_carregar_relatorio(req):
    """Relatório que a unidade sem internet mandou por pendrive."""
    precisa_central()
    rel = req.b("relatorio")
    if isinstance(rel, str):
        try:
            rel = json.loads(rel)
        except ValueError:
            raise Erro("Arquivo inválido.")
    if not isinstance(rel, dict) or not isinstance(rel.get("dados"), dict):
        raise Erro("Este arquivo não é um relatório de unidade do Folha a Folha.")
    s = setor(rel["dados"].get("unidade_id"))
    guardar_relatorio(s, rel)
    return {"ok": True, "unidade": s["nome"]}


@rota("POST", "/api/admin/setor/desligar", auth="admin")
def r_desligar_unidade(req):
    precisa_central()
    s = setor(req.b("id"))
    DB.execute("UPDATE setores SET token_hash='', adesao_hash='' WHERE id=?", (s["id"],))
    return {"ok": True}


# ---------------------------------------------------------------- central: chaves, pacote e relatório

def segredo_central():
    seg = cfg("central_segredo")
    if not seg:
        seg = secrets.token_bytes(32).hex()
        DB.execute("UPDATE config SET valor=? WHERE chave='central_segredo'", (seg,))
        DB.execute("UPDATE config SET valor=? WHERE chave='central_publica'",
                   (licenca.publica_de(bytes.fromhex(seg)).hex(),))
    return bytes.fromhex(seg)


def publica_central():
    segredo_central()
    return cfg("central_publica")


def canonico(dados):
    return json.dumps(dados, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def pacote_assinado(s):
    pol = politica_setor(s)
    pessoas = None
    if pol["cadastro"] == "ti":
        pessoas = []
        for u in linhas(DB.execute("SELECT id, nome, pin_hash, papel, ativo, login FROM usuarios WHERE setor_id=? "
                                   "AND anonimizado=0 AND COALESCE(aprovacao,'')='' ORDER BY id", (s["id"],))):
            cotas = {r[0]: r[1] for r in DB.execute("SELECT ref, mensal FROM cotas_remotas WHERE usuario_id=?", (u["id"],))}
            pessoas.append({"ref": str(u["id"]), "nome": u["nome"], "pin_hash": u["pin_hash"], "login": u["login"],
                            "papel": "admin" if u["papel"] == "gestor" else "prof", "ativo": bool(u["ativo"]),
                            "cotas": cotas})
    dados = {"tipo": "pacote", "versao": int(s["pacote_versao"] or 1), "unidade_id": s["id"], "unidade": s["nome"],
             "caminho": caminho_setor(s["id"]), "central": nome_local(), "tipo_local": cfg("tipo_local"),
             "emitido_em": agora(), "cota": int(s["cota"] or 0),
             "politica": {k: pol[k] for k in ("cadastro", "exceder", "pode_negativo")}, "pessoas": pessoas}
    return {"dados": dados, "assinatura": licenca.assinar(segredo_central(), canonico(dados)).hex()}


def guardar_relatorio(s, rel):
    dados = rel.get("dados") or {}
    if not s["remoto"] or not s["token_hash"]:
        raise Erro("Esta unidade não está ligada à central.", 403)
    esperado = hmac.new(s["token_hash"].encode(), canonico(dados), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(esperado, str(rel.get("mac") or "")):
        raise Erro("O relatório não confere com a chave desta unidade.", 403)
    try:
        anterior = json.loads(s["resumo"] or "{}")
    except ValueError:
        anterior = {}
    if (anterior.get("gerado_em") or "") > (dados.get("gerado_em") or ""):
        return
    DB.execute("UPDATE setores SET resumo=?, ultimo_contato=?, aparelho=? WHERE id=?",
               (json.dumps(dados, ensure_ascii=False), agora(), str(dados.get("aparelho") or "")[:80], s["id"]))
    for i in dados.get("impressoras") or []:
        DB.execute("INSERT INTO unidade_impressoras(setor_id, ref, nome, ativa) VALUES(?,?,?,?) ON CONFLICT(setor_id, ref) "
                   "DO UPDATE SET nome=excluded.nome, ativa=excluded.ativa",
                   (s["id"], str(i.get("ref"))[:20], str(i.get("nome") or "")[:80], 1 if i.get("ativa", True) else 0))
    for x in dados.get("excecoes") or []:
        ref = int(x.get("id") or 0)
        if DB.execute("SELECT 1 FROM excecoes WHERE setor_id=? AND tipo=? AND ref_id=? AND por_id IS NULL",
                      (s["id"], "setor_acima", ref)).fetchone():
            continue
        registrar_excecao("setor_acima", str(x.get("mes") or mes_atual())[:7], s["id"], None, None,
                          int(x.get("paginas") or 0), x.get("justificativa"), x.get("decisao") or "Na unidade", None, ref)


@rota("POST", "/api/central/adesao", auth=None)
def r_central_adesao(req):
    if instalacao() != "central":
        raise Erro("Este endereço não é de uma central do Folha a Folha.", 404)
    ip = req.ip
    falhas = [t for t in TENTATIVAS_ADESAO.get(ip, []) if t > time.time() - 600]
    if len(falhas) >= 10:
        raise Erro("Muitas tentativas com código errado. Espere alguns minutos.", 429)
    codigo = re.sub(r"[^A-Z0-9]", "", str(req.b("codigo") or "").upper())
    s = uma(DB.execute("SELECT * FROM setores WHERE adesao_hash=? AND remoto=1 AND ativo=1", (hash_texto(codigo),))) if codigo else None
    if not s or (s["adesao_ate"] or "") < agora():
        TENTATIVAS_ADESAO[ip] = falhas + [time.time()]
        raise Erro("Código de adesão errado ou vencido. Peça um novo à TI.", 403)
    token = secrets.token_urlsafe(32)
    DB.execute("UPDATE setores SET token_hash=?, adesao_hash='', aparelho=?, ultimo_contato=? WHERE id=?",
               (hash_texto(token), str(req.b("aparelho") or "")[:80], agora(), s["id"]))
    s = setor(s["id"])
    return {"unidade_id": s["id"], "token": token, "chave_publica": publica_central(), "central": nome_local(),
            "pacote": pacote_assinado(s)}


@rota("POST", "/api/central/sincronizar", auth=None)
def r_central_sincronizar(req):
    if instalacao() != "central":
        raise Erro("Este endereço não é de uma central do Folha a Folha.", 404)
    try:
        s = setor(req.b("unidade_id"))
    except Erro:
        raise Erro("Unidade não encontrada na central.", 403)
    token = str(req.b("token") or "")
    if not s["token_hash"] or not hmac.compare_digest(s["token_hash"], hash_texto(token)):
        raise Erro("A chave desta unidade não vale mais. Ligue o aparelho de novo com um código da TI.", 403, "token")
    rel = req.b("relatorio")
    if isinstance(rel, dict) and rel.get("dados"):
        guardar_relatorio(s, rel)
    else:
        DB.execute("UPDATE setores SET ultimo_contato=? WHERE id=?", (agora(), s["id"]))
    return {"ok": True, "pacote": pacote_assinado(setor(s["id"])), "hora": agora()}


# ---------------------------------------------------------------- unidade: pacote, relatório e sincronização

_PACOTE_MEMO = {}


def pacote_atual():
    """Dados do último pacote da central, só se a assinatura conferir (quem mexer no banco perde o pacote)."""
    texto, chave = cfg("central_pacote"), cfg("central_chave")
    if not texto or not chave:
        return None
    memo = _PACOTE_MEMO.get((texto, chave))
    if memo is not None:
        return memo or None
    try:
        pac = json.loads(texto)
        ok = licenca.conferir(bytes.fromhex(chave), canonico(pac["dados"]), bytes.fromhex(pac["assinatura"]))
    except (ValueError, KeyError, TypeError):
        ok = False
    _PACOTE_MEMO.clear()
    _PACOTE_MEMO[(texto, chave)] = pac["dados"] if ok else {}
    return pac["dados"] if ok else None


def aplicar_pacote(pac, chave_hex=None, unidade=None):
    """Confere a assinatura da central e aplica: nome da unidade, cota, regras e, se a TI cadastra, as pessoas."""
    chave = chave_hex or cfg("central_chave")
    dados = pac.get("dados") if isinstance(pac, dict) else None
    if not isinstance(dados, dict) or not chave:
        raise Erro("Pacote da central inválido.")
    try:
        ok = licenca.conferir(bytes.fromhex(chave), canonico(dados), bytes.fromhex(str(pac.get("assinatura") or "")))
    except ValueError:
        ok = False
    if not ok:
        raise Erro("A assinatura do pacote não confere: ele não veio da central desta unidade.", 403)
    unidade = str(unidade or cfg("central_unidade"))
    if unidade and str(dados.get("unidade_id")) != unidade:
        raise Erro("Este pacote é de outra unidade.", 403)
    atual = pacote_atual()
    if atual and int(atual.get("versao") or 0) > int(dados.get("versao") or 0):
        return False
    DB.execute("UPDATE config SET valor=? WHERE chave='central_pacote'", (json.dumps(pac, ensure_ascii=False),))
    DB.execute("UPDATE config SET valor=? WHERE chave='central_nome'", (str(dados.get("central") or "")[:120],))
    DB.execute("UPDATE config SET valor=? WHERE chave='escola'", (str(dados.get("unidade") or "")[:120],))
    if dados.get("tipo_local") in LOCAIS:
        DB.execute("UPDATE config SET valor=? WHERE chave='tipo_local'", (dados["tipo_local"],))
    DB.execute("UPDATE setores SET cota=? WHERE id=1", (int(dados.get("cota") or 0),))
    if isinstance(dados.get("pessoas"), list):
        sincronizar_pessoas(dados["pessoas"])
    return True


def sincronizar_pessoas(lista):
    """A TI cadastra as pessoas da unidade: cria, atualiza e desativa quem veio da central (ref_central)."""
    vistos = set()
    printers = {str(r[0]) for r in DB.execute("SELECT id FROM impressoras")}
    for p in lista:
        ref = str(p.get("ref") or "")[:20]
        if not ref:
            continue
        vistos.add(ref)
        papel = "admin" if p.get("papel") == "admin" else "prof"
        ativo = 1 if p.get("ativo", True) else 0
        u = uma(DB.execute("SELECT * FROM usuarios WHERE ref_central=?", (ref,)))
        nome_p = str(p.get("nome") or "")[:80]
        try:
            login = valida_login(p.get("login") or "")
        except Erro:
            login = ""
        if not login or login_em_uso(login, u["id"] if u else None):
            login = (u["login"] if u and u["login"] else "") or gerar_login(nome_p, u["id"] if u else None)
        if u:
            if u["pin_hash"] != p.get("pin_hash") or not ativo:
                DB.execute("DELETE FROM sessoes WHERE usuario_id=?", (u["id"],))
            DB.execute("UPDATE usuarios SET nome=?, pin_hash=?, papel=?, ativo=?, login=?, trocar_senha=0 WHERE id=?",
                       (nome_p, p.get("pin_hash") or u["pin_hash"], papel, ativo, login, u["id"]))
            uid = u["id"]
        else:
            uid = DB.execute("INSERT INTO usuarios(nome, pin_hash, papel, ativo, criado_em, ref_central, setor_id, login) "
                             "VALUES(?,?,?,?,?,?,1,?)", (nome_p, p.get("pin_hash") or "",
                                                         papel, ativo, agora(), ref, login)).lastrowid
        for iref, n in (p.get("cotas") or {}).items():
            if str(iref) in printers:
                DB.execute("INSERT INTO cotas(usuario_id, impressora_id, mensal) VALUES(?,?,?) ON CONFLICT(usuario_id, "
                           "impressora_id) DO UPDATE SET mensal=excluded.mensal", (uid, int(iref), max(0, int(n or 0))))
    for u in linhas(DB.execute("SELECT id, ref_central FROM usuarios WHERE ref_central<>'' AND ativo=1")):
        if u["ref_central"] not in vistos:
            DB.execute("UPDATE usuarios SET ativo=0 WHERE id=?", (u["id"],))
            DB.execute("DELETE FROM sessoes WHERE usuario_id=?", (u["id"],))


def montar_relatorio():
    """Números da unidade para a central: páginas, custo, finalidades e exceções. Sem nomes de arquivos
    e sem o detalhe por pessoa, que ficam aqui com o gestor da unidade."""
    mes = mes_atual()
    meses = {}
    for m in (mes, mes_anterior(mes)):
        ts = linhas(DB.execute(f"SELECT t.impressora_id, t.total, t.excedente, t.finalidade, {CUSTO_SQL} AS cu FROM trabalhos t "
                               f"JOIN impressoras i ON i.id=t.impressora_id WHERE t.mes=? AND t.status IN "
                               f"({','.join('?' * len(CONTA))})", (m, *CONTA)))
        por_fin, por_imp = {}, {}
        for t in ts:
            f = nome_finalidade(t["finalidade"]) if t["finalidade"] else "Sem finalidade"
            por_fin[f] = por_fin.get(f, 0) + t["total"]
            por_imp[str(t["impressora_id"])] = por_imp.get(str(t["impressora_id"]), 0) + t["total"]
        aum = DB.execute("SELECT COALESCE(SUM(paginas),0) FROM movimentos WHERE mes=? AND tipo='aumento'", (m,)).fetchone()[0]
        meses[m] = {"paginas": sum(t["total"] for t in ts), "custo": round(sum(t["total"] * (t["cu"] or 0) for t in ts), 2),
                    "excedente": sum(t["excedente"] or 0 for t in ts), "impressoes": len(ts), "aumentos": aum,
                    "por_finalidade": por_fin, "por_impressora": por_imp,
                    "negativos": DB.execute("SELECT COUNT(*) FROM excecoes WHERE mes=? AND tipo='negativo'", (m,)).fetchone()[0]}
    imps = []
    for i in impressoras(so_ativas=False):
        ult = DB.execute("SELECT valor, criado_em FROM leituras_contador WHERE impressora_id=? ORDER BY criado_em DESC "
                         "LIMIT 1", (i["id"],)).fetchone()
        imps.append({"ref": str(i["id"]), "nome": i["nome"], "ativa": bool(i["ativa"]), "cota_total": i["cota_total"],
                     "contador": ult[0] if ult else None, "contador_em": ult[1] if ult else None})
    exc = [{"id": x["id"], "mes": x["mes"], "paginas": x["paginas"], "justificativa": x["justificativa"],
            "decisao": x["decisao"]}
           for x in linhas(DB.execute("SELECT * FROM excecoes WHERE tipo='setor_acima' AND mes IN (?,?) ORDER BY id",
                                      (mes, mes_anterior(mes))))]
    pac = pacote_atual() or {}
    dados = {"tipo": "relatorio", "unidade_id": int(cfg("central_unidade") or 0), "gerado_em": agora(),
             "versao_app": VERSAO, "aparelho": socket.gethostname()[:60], "pacote_versao": pac.get("versao"),
             "meses": meses, "impressoras": imps, "distribuido": distribuido_setor(1)["total"],
             "pessoas": len(membros_setor(1)), "excecoes": exc}
    chave = hash_texto(cfg("central_token"))
    return {"dados": dados, "mac": hmac.new(chave.encode(), canonico(dados), hashlib.sha256).hexdigest()}


def normalizar_url(url):
    url = str(url or "").strip().rstrip("/")
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    if url and not re.match(r"^https?://[^\s/]+(:\d+)?(/.*)?$", url, re.I):
        raise Erro("Endereço da central inválido. Exemplo: http://10.0.0.5:8080")
    return url


def chamar_central(url, caminho, corpo, timeout=20):
    import urllib.error
    import urllib.request
    pedido = urllib.request.Request(url.rstrip("/") + caminho, data=json.dumps(corpo).encode(),
                                    headers={"Content-Type": "application/json", "X-Pedido": "ci"})
    try:
        with urllib.request.urlopen(pedido, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("erro")
        except Exception:
            msg = None
        raise Erro(f"A central respondeu: {msg or e.code}", 502, "central")
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise Erro(f"Não consegui falar com a central em {url}. Confira o endereço e a rede "
                   f"({getattr(e, 'reason', e)}).", 502, "central")


def ligar_unidade(adesao, url=""):
    """Guarda a chave da unidade e aplica o primeiro pacote (adesão pelo código ou pelo arquivo do pendrive)."""
    for k in ("unidade_id", "token", "chave_publica", "pacote"):
        if not adesao.get(k):
            raise Erro("Os dados de adesão estão incompletos.")
    aplicar_pacote(adesao["pacote"], adesao["chave_publica"], adesao["unidade_id"])
    for k, v in (("central_url", url), ("central_unidade", str(adesao["unidade_id"])),
                 ("central_token", adesao["token"]), ("central_chave", adesao["chave_publica"]),
                 ("central_nome", adesao.get("central") or ""), ("central_erro", ""), ("central_ultimo", agora())):
        DB.execute("UPDATE config SET valor=? WHERE chave=?", (v, k))
    _PACOTE_MEMO.clear()


def ler_arquivo_adesao(valor):
    if isinstance(valor, str):
        try:
            valor = json.loads(valor)
        except ValueError:
            raise Erro("Arquivo da central inválido.")
    if not isinstance(valor, dict) or valor.get("tipo") != "folha-a-folha-adesao":
        raise Erro("Este arquivo não é um arquivo de adesão do Folha a Folha.")
    return valor


SINCRONIZANDO = threading.Lock()


def sincronizar_com_central():
    """A unidade chama a central: manda o relatório e recebe o pacote (cotas e regras)."""
    if not SINCRONIZANDO.acquire(blocking=False):
        return {"ok": False, "erro": "Já está sincronizando."}
    try:
        with LOCK:
            url, unidade, token = cfg("central_url"), cfg("central_unidade"), cfg("central_token")
            if instalacao() != "unidade" or not url or not token:
                return {"ok": False, "erro": "Esta unidade não tem endereço da central (está ligada só por arquivo)."}
            rel = montar_relatorio()
        try:
            resp = chamar_central(url, "/api/central/sincronizar", {"unidade_id": unidade, "token": token,
                                                                     "relatorio": rel})
        except Erro as e:
            with LOCK:
                DB.execute("UPDATE config SET valor=? WHERE chave='central_erro'", (e.msg,))
                DB.commit()
            return {"ok": False, "erro": e.msg}
        with LOCK:
            try:
                mudou = aplicar_pacote(resp.get("pacote") or {})
                erro = ""
                try:
                    dif = abs((dt.datetime.fromisoformat(resp.get("hora")) - dt.datetime.now()).total_seconds())
                    if dif > 600:
                        erro = (f"O relógio deste aparelho está {round(dif / 60)} minutos diferente do da central. "
                                "Acerte a data e a hora: a virada do mês e a licença dependem dela.")
                except (TypeError, ValueError):
                    pass
                DB.execute("UPDATE config SET valor=? WHERE chave='central_erro'", (erro,))
                DB.execute("UPDATE config SET valor=? WHERE chave='central_ultimo'", (agora(),))
                DB.commit()
            except Erro as e:
                DB.rollback()
                DB.execute("UPDATE config SET valor=? WHERE chave='central_erro'", (e.msg,))
                DB.commit()
                return {"ok": False, "erro": e.msg}
        return {"ok": True, "mudou": bool(mudou)}
    finally:
        SINCRONIZANDO.release()


def laco_central():
    time.sleep(8)
    while True:
        try:
            if instalacao() == "unidade" and cfg("central_url"):
                sincronizar_com_central()
        except Exception:
            import traceback
            traceback.print_exc()
        try:
            minutos = max(1, int(cfg("central_intervalo") or 5))
        except ValueError:
            minutos = 5
        time.sleep(minutos * 60)


def info_central():
    pac = pacote_atual()
    return {"instalacao": instalacao(), "url": cfg("central_url"), "unidade_id": cfg("central_unidade"),
            "central": cfg("central_nome"), "ultimo": cfg("central_ultimo"), "erro": cfg("central_erro"),
            "pacote_ok": bool(pac), "versao_pacote": (pac or {}).get("versao"), "cota": (pac or {}).get("cota"),
            "politica": (pac or {}).get("politica") or {}, "caminho": (pac or {}).get("caminho"),
            "distribuido": distribuido_setor(1)["total"],
            "pela_ti": isinstance((pac or {}).get("pessoas"), list)}


@rota("GET", "/api/admin/central", auth="admin")
def r_info_central(req):
    return info_central()


@rota("POST", "/api/admin/central/sincronizar", auth="admin", trava=False)
def r_sincronizar_agora(req):
    r = sincronizar_com_central()
    with LOCK:
        return {**r, "central": info_central()}


@rota("POST", "/api/admin/central/arquivo", auth="admin")
def r_carregar_arquivo_central(req):
    """Pendrive: arquivo de adesão (liga ou religa a unidade) ou pacote novo da central."""
    if instalacao() != "unidade":
        raise Erro("Isto é para o aparelho de uma unidade.", 403)
    valor = req.b("arquivo")
    if isinstance(valor, str):
        try:
            valor = json.loads(valor)
        except ValueError:
            raise Erro("Arquivo inválido.")
    if isinstance(valor, dict) and valor.get("tipo") == "folha-a-folha-adesao":
        ligar_unidade(valor, cfg("central_url") or normalizar_url(valor.get("endereco") or ""))
        return {"ok": True, "central": info_central()}
    if isinstance(valor, dict) and valor.get("dados"):
        aplicar_pacote(valor)
        _PACOTE_MEMO.clear()
        return {"ok": True, "central": info_central()}
    raise Erro("Este arquivo não veio da central.")


@rota("GET", "/api/admin/central/relatorio", auth="admin")
def r_baixar_relatorio_central(req):
    if instalacao() != "unidade":
        raise Erro("Isto é para o aparelho de uma unidade.", 403)
    rel = montar_relatorio()
    return Resposta(json.dumps(rel, ensure_ascii=False, indent=1).encode(), "application/json",
                    {"Content-Disposition": f'attachment; filename="folha-a-folha-relatorio-{mes_atual()}.json"'})


@rota("POST", "/api/admin/central/endereco", auth="admin")
def r_endereco_central(req):
    if instalacao() != "unidade":
        raise Erro("Isto é para o aparelho de uma unidade.", 403)
    DB.execute("UPDATE config SET valor=? WHERE chave='central_url'", (normalizar_url(req.b("url")),))
    return {"ok": True}


@rota("POST", "/api/admin/setor/politica", auth="gestor")
def r_politica_setor(req):
    """Gestor do setor (ou a TI): aceitar pedidos de aumento e cota negativa das pessoas do setor."""
    sid = inteiro(req.b("setor_id") or req.usuario["setor_id"] or 1, "setor")
    e = escopo(req.usuario)
    if e is not None and sid not in e:
        raise Erro("Esse setor não é seu.", 403)
    if sid == 1:
        raise Erro("As regras gerais mudam em Ajustes.")
    s = setor(sid)
    atual = politica_setor(s)
    novo = dict(atual)
    pedido = req.b("politica") or {}
    for k in ("aumento", "negativo_desconta"):
        if k in pedido:
            novo[k] = bool(pedido[k])
    if "negativo" in pedido:
        n_ = inteiro(pedido["negativo"] or 0, "limite da cota negativa", 0, 10000)
        if n_ and not atual["pode_negativo"]:
            raise Erro("A TI não permite cota negativa neste setor.", 403)
        novo["negativo"] = n_
    if e is None:
        novo = preparar_politica(pedido, novo)
    DB.execute("UPDATE setores SET politica=? WHERE id=?", (json.dumps(novo), sid))
    return {"ok": True, "politica": politica_setor(sid)}


class Resposta:
    def __init__(self, texto, tipo, cabecalhos=None):
        self.dados = texto if isinstance(texto, bytes) else texto.encode("utf-8")
        self.tipo = tipo
        self.cabecalhos = cabecalhos or {}


# ================================================================ HTTP

class Servidor(ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        # o aparelho fechou a página (ou perdeu o Wi-Fi) no meio de uma resposta: não é erro do sistema
        if isinstance(sys.exc_info()[1], (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, TimeoutError)):
            return
        super().handle_error(request, client_address)


TIPOS = {".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml",
         ".json": "application/json", ".webmanifest": "application/manifest+json", ".png": "image/png"}


_ESTATICOS = {}  # caminho -> (data, tamanho, bytes, gzip, etag); refeito quando o arquivo muda


def arquivo_estatico(alvo):
    st = alvo.stat()
    c = _ESTATICOS.get(str(alvo))
    if not c or c[0] != st.st_mtime_ns or c[1] != st.st_size:
        dados = alvo.read_bytes()
        comprimido = gzip.compress(dados, 6, mtime=0) if len(dados) > 1024 else None
        c = (st.st_mtime_ns, st.st_size, dados, comprimido, '"' + hashlib.sha1(dados).hexdigest()[:20] + '"')
        _ESTATICOS[str(alvo)] = c
    return c


class Handler(BaseHTTPRequestHandler):
    server_version = "FolhaAFolha/" + VERSAO
    protocol_version = "HTTP/1.1"
    timeout = float(os.environ.get("CI_TIMEOUT") or 120)  # conexão parada por mais que isso é fechada

    def log_message(self, fmt, *args):
        if os.environ.get("CI_LOG"):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def token_sessao(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        return c["sessao"].value if "sessao" in c else None

    def usuario_logado(self):
        token = self.token_sessao()
        if not token:
            return None
        r = uma(DB.execute("SELECT u.*, s.criado_em AS sessao_em, s.atividade_em AS sessao_atividade, "
                           "s.bloqueada AS sessao_bloqueada, s.token AS sessao_token, s.ip AS sessao_ip, "
                           "s.visto_em AS sessao_visto FROM sessoes s JOIN usuarios u ON "
                           "u.id=s.usuario_id WHERE s.token=? AND u.ativo=1", (token,)))
        if not r:
            return None
        criado = dt.datetime.strptime(r["sessao_em"], "%Y-%m-%d %H:%M:%S")
        if (dt.datetime.now() - criado).days > DIAS_SESSAO:
            return None
        # de onde e quando o app deu sinal por último: a impressora Folha a Folha só aceita de quem está com ele aberto
        ip, visto = self.client_address[0], r["sessao_visto"] or ""
        limite = (dt.datetime.now() - dt.timedelta(seconds=15)).strftime("%Y-%m-%d %H:%M:%S")
        if r["sessao_ip"] != ip or visto < limite:
            DB.execute("UPDATE sessoes SET ip=?, visto_em=? WHERE token=?", (ip, agora(), token))
            DB.commit()
        return r

    def enviar(self, status, corpo, tipo="application/json; charset=utf-8", extras=None, cookies=()):
        self.send_response(status)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(corpo)))
        if "Cache-Control" not in (extras or {}):
            self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extras or {}).items():
            self.send_header(k, v)
        for c in cookies:
            self.send_header("Set-Cookie", c)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(corpo)

    def json(self, status, obj, cookies=()):
        self.enviar(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), cookies=cookies)

    def do_GET(self):
        self.tratar("GET")

    def do_HEAD(self):
        self.tratar("GET")

    def do_POST(self):
        self.tratar("POST")

    def tratar(self, metodo):
        url = urlparse(self.path)
        if metodo == "POST" and (url.path.rstrip("/") == "/ipp/print" or url.path.startswith("/ipp/print/")):
            return self.ipp(url.path)
        if url.path.startswith("/api/"):
            return self.api(metodo, url)
        if metodo != "GET":
            self.close_connection = True
            return self.json(405, {"erro": "Método não permitido."})
        return self.estatico(url.path)

    def estatico(self, caminho):
        if caminho in ("/", ""):
            caminho = "/index.html"
        alvo = (WEB / caminho.lstrip("/")).resolve()
        if WEB.resolve() not in alvo.parents or not alvo.is_file():
            alvo = WEB / "index.html"
        tipo = TIPOS.get(alvo.suffix) or mimetypes.guess_type(str(alvo))[0] or "application/octet-stream"
        if tipo.startswith("text/") or alvo.suffix in (".js", ".json", ".svg", ".webmanifest"):
            tipo += "; charset=utf-8"
        _, _, dados, comprimido, etag = arquivo_estatico(alvo)
        # a tela sempre confere se mudou (no-cache), mas só baixa de novo se mudou (ETag) e vai comprimida
        extras = {"Cache-Control": "no-cache", "ETag": etag, "Vary": "Accept-Encoding"}
        tem = [x.strip().removeprefix("W/") for x in (self.headers.get("If-None-Match") or "").split(",")]
        if etag in tem:
            return self.enviar(304, b"", tipo, extras)
        if comprimido and "gzip" in (self.headers.get("Accept-Encoding") or "").lower():
            extras["Content-Encoding"] = "gzip"
            dados = comprimido
        self.enviar(200, dados, tipo, extras)

    def corpo_em_arquivo(self, limite=LIMITE_IPP):
        """Lê o corpo do pedido (Content-Length ou chunked) para um arquivo temporário."""
        tmp = tempfile.TemporaryFile()
        total = 0
        if "chunked" in (self.headers.get("Transfer-Encoding") or "").lower():
            while True:
                linha = self.rfile.readline(1024).strip()
                tam = int(linha.split(b";")[0] or b"0", 16)
                if tam == 0:
                    while self.rfile.readline(1024).strip():
                        pass
                    break
                total += tam
                if total > limite:
                    raise ipp.ErroIPP("Documento grande demais.", ipp.ERRO_NAO_POSSIVEL)
                restante = tam
                while restante:
                    b = self.rfile.read(min(restante, 1024 * 1024))
                    if not b:
                        raise ipp.ErroIPP("Conexão interrompida.")
                    tmp.write(b)
                    restante -= len(b)
                self.rfile.readline(8)
        else:
            restante = int(self.headers.get("Content-Length") or 0)
            if restante > limite:
                raise ipp.ErroIPP("Documento grande demais.", ipp.ERRO_NAO_POSSIVEL)
            while restante:
                b = self.rfile.read(min(restante, 1024 * 1024))
                if not b:
                    raise ipp.ErroIPP("Conexão interrompida.")
                tmp.write(b)
                restante -= len(b)
        tmp.seek(0)
        return tmp

    def ipp(self, caminho):
        req_id = 0
        try:
            with LOCK:
                ligada = modo_impressora()
            if not ligada:
                self.close_connection = True
                return self.enviar(404, "Impressora Folha a Folha desligada: o estilo escolhido é só pelo navegador."
                                   .encode("utf-8"), "text/plain; charset=utf-8")
            if not (self.headers.get("Content-Type") or "").lower().startswith("application/ipp"):
                self.close_connection = True  # o corpo não foi lido
                return self.enviar(400, b"Use application/ipp", "text/plain")
            with self.corpo_em_arquivo() as arquivo:
                pedido = ipp.ler_requisicao(arquivo)
                req_id = pedido.request_id
                host = self.headers.get("Host") or f"{self.server.server_address[0]}:{self.server.server_address[1]}"
                resp = processar_ipp(pedido, arquivo, self.client_address[0], host, caminho)
        except ipp.ErroIPP as e:
            resp = ipp.Resposta(e.status, req_id, (1, 1), str(e))
        except (ConnectionError, BrokenPipeError, TimeoutError):
            self.close_connection = True
            return
        except Exception as e:
            import traceback
            traceback.print_exc()
            resp = ipp.Resposta(ipp.ERRO_INTERNO, req_id, (1, 1), f"Erro interno: {e}")
        try:
            self.enviar(200, resp.bytes(), "application/ipp")
        except (ConnectionError, BrokenPipeError):
            return

    def ler_corpo(self, bruto=False):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = -1
        if n < 0:
            self.close_connection = True
            raise Erro("Pedido inválido.", 400)
        if n > LIMITE_UPLOAD:
            self.close_connection = True  # o corpo não vai ser lido: a conexão não pode ser reaproveitada
            raise Erro("Arquivo grande demais (máximo 60 MB).", 413)
        dados = self.rfile.read(n) if n else b""
        if bruto:
            return dados
        if not dados:
            return {}
        try:
            obj = json.loads(dados.decode("utf-8"))
        except ValueError:
            raise Erro("Pedido inválido.")
        return obj if isinstance(obj, dict) else {}

    def api(self, metodo, url):
        entrada = ROTAS.get((metodo, url.path))
        if not entrada:
            if metodo == "POST":
                self.close_connection = True  # idem: o corpo deste pedido fica sem ler
            return self.json(404, {"erro": "Endereço não encontrado."})
        func, auth, trava = entrada
        try:
            if metodo == "POST" and self.headers.get("X-Pedido") != "ci":
                self.close_connection = True  # idem
                raise Erro("Pedido recusado.", 403)
            corpo = self.ler_corpo(bruto=(url.path == "/api/upload")) if metodo == "POST" else {}
            with LOCK:
                usuario = self.usuario_logado()
                travada = bool(usuario) and url.path not in LIVRES_NO_BLOQUEIO and \
                    conferir_bloqueio(usuario, self.headers.get("X-Atividade") == "1")
            if auth and not usuario:
                raise Erro("Entre de novo com seu usuário e sua senha.", 401, "sessao")
            if auth and travada:
                raise Erro("A tela foi bloqueada por falta de uso. Digite sua senha para continuar.", 401, "bloqueado")
            if auth and usuario["trocar_senha"] and url.path not in LIVRES_NA_TROCA:
                raise Erro("Crie sua senha antes de continuar.", 403, "trocar_senha")
            if auth == "admin" and usuario["papel"] != "admin":
                raise Erro("Somente o gestor pode fazer isso." if instalacao() != "central"
                           else "Somente a TI (gestor geral) pode fazer isso.", 403)
            if auth == "gestor" and usuario["papel"] not in ("admin", "gestor"):
                raise Erro("Somente o gestor pode fazer isso.", 403)
            req = Req(self, usuario, parse_qs(url.query), corpo)
            if trava:
                with LOCK:
                    try:
                        res = func(req)
                        DB.commit()
                    except Exception:
                        DB.rollback()
                        raise
            else:
                res = func(req)
            if isinstance(res, Resposta):
                return self.enviar(200, res.dados, res.tipo, res.cabecalhos)
            return self.json(200, res, cookies=req.novos_cookies)
        except Erro as e:
            return self.json(e.status, {**(e.dados or {}), "erro": e.msg, "codigo": e.codigo})
        except (ConnectionError, BrokenPipeError, TimeoutError):
            self.close_connection = True  # aparelho que sumiu ou parou no meio do pedido
            return
        except Exception as e:  # erro inesperado
            import traceback
            traceback.print_exc()
            try:
                return self.json(500, {"erro": "Algo deu errado no sistema. Tente de novo; se continuar, avise o gestor."})
            except Exception:
                return


# ================================================================ digitalização

def _criar_previa_digitalizacao(paginas, pdf, pasta, token):
    """Cria uma imagem leve da primeira página para a prévia no navegador.

    A prévia é uma imagem e não depende do visualizador PDF do dispositivo cliente.
    Tenta primeiro rasterizar o PDF com Poppler/MuPDF/Ghostscript; se não houver
    renderizador, usa a própria imagem entregue pelo driver WIA/SANE.
    """
    base = Path(pasta) / f"{token}-preview"
    try:
        renderizada = impressao.renderizar_imagem(str(pdf), 1, str(base), 96)
        if renderizada and Path(renderizada).is_file() and Path(renderizada).stat().st_size:
            return Path(renderizada)
    except Exception:
        # A prévia é acessória: a ausência de um renderizador não invalida o PDF.
        pass

    if not paginas:
        return None
    origem = Path(paginas[0])
    extensao = origem.suffix.lower()
    if extensao not in (".png", ".jpg", ".jpeg") or not origem.is_file():
        return None
    if extensao == ".jpeg":
        extensao = ".jpg"
    destino = Path(pasta) / f"{token}-preview{extensao}"
    try:
        shutil.copy2(origem, destino)
        return destino if destino.is_file() and destino.stat().st_size else None
    except OSError:
        return None


@rota("GET", "/api/scanners", auth="user", trava=False)
def r_listar_scanners(req):
    """Descobre scanners pelo WIA/SANE, independentemente das filas de impressão."""
    return scanner.listar()


@rota("POST", "/api/scanners/opcoes", auth="user", trava=False)
def r_opcoes_scanner(req):
    dispositivo = str(req.b("id") or "").strip()
    if not dispositivo or len(dispositivo) > 1024:
        raise Erro("Escolha um scanner.")
    try:
        return {"ok": True, "opcoes": scanner.opcoes(dispositivo)}
    except scanner.ErroDigitalizacao as exc:
        raise Erro(str(exc), 400)


# Sessões com uma digitalização em andamento: o tempo sem uso não conta enquanto o scanner trabalha
# (um lote de 50 folhas no alimentador passa fácil dos 5 minutos do bloqueio por falta de uso).
SESSOES_DIGITALIZANDO = set()
# Lotes sendo mexidos agora (acrescentar, concluir, descartar): um de cada vez por lote
LOTES_EM_USO = set()
LOCK_LOTES = threading.Lock()
EXTENSOES_PAGINA = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")


def _comecar_digitalizacao(req):
    token = req.usuario.get("sessao_token") if req.usuario else None
    if token:
        SESSOES_DIGITALIZANDO.add(token)
    return token


def _terminar_digitalizacao(token):
    """O tempo sem uso recomeça a contar do fim da digitalização. Uma tela que já estava bloqueada
    (a pessoa bloqueou, ou o app bloqueou antes) continua bloqueada: só a senha desbloqueia."""
    if not token:
        return
    SESSOES_DIGITALIZANDO.discard(token)
    with LOCK:
        DB.execute("UPDATE sessoes SET atividade_em=?, visto_em=? WHERE token=? AND COALESCE(bloqueada, 0)=0",
                   (agora(), agora(), token))
        DB.commit()


def _usar_lote(uid, lote):
    with LOCK_LOTES:
        if (uid, lote) in LOTES_EM_USO:
            raise Erro("Este documento está sendo atualizado. Aguarde um instante e tente de novo.", 409)
        LOTES_EM_USO.add((uid, lote))


def _soltar_lote(uid, lote):
    with LOCK_LOTES:
        LOTES_EM_USO.discard((uid, lote))


def _lote_valido(valor):
    lote = str(valor or "").strip()
    if not re.fullmatch(r"[0-9a-f]{32}", lote):
        raise Erro("Lote inválido.")
    return lote


def _id_scanner(valor):
    dispositivo = str(valor or "").strip()
    if not dispositivo or len(dispositivo) > 1024:
        raise Erro("Escolha um scanner.")
    return dispositivo


def _paginas_lote(pasta):
    if not pasta.is_dir():
        return []
    return sorted(p for p in pasta.glob("pagina-*") if p.is_file() and p.suffix.lower() in EXTENSOES_PAGINA)


def _meta_lote(pasta):
    """Resolução de cada página do lote, para o PDF sair no tamanho real."""
    try:
        dados = json.loads((pasta / "meta.json").read_text("utf-8"))
        return dados if isinstance(dados, dict) else {}
    except (OSError, ValueError):
        return {}


def _dpi_pedido(req):
    try:
        dpi = int(req.b("dpi") or 0)
    except (TypeError, ValueError):
        return 0
    return dpi if 30 <= dpi <= scanner.LIMITE_DPI else 0


@rota("POST", "/api/digitalizar", auth="user", trava=False)
def r_digitalizar(req):
    """Executa uma digitalização no computador servidor e prepara o arquivo para baixar."""
    dispositivo = _id_scanner(req.b("scanner_id"))
    formato = str(req.b("formato") or "pdf").lower()
    if formato not in ("pdf", "bmp", "jpg", "png", "tif"):
        raise Erro("Formato de saída inválido.")
    usuario_dir = DIGITALIZACOES / str(req.uid)
    usuario_dir.mkdir(parents=True, exist_ok=True)
    token = secrets.token_hex(16)
    trabalho = Path(tempfile.mkdtemp(prefix="scan-", dir=str(usuario_dir)))
    destino = None
    try:
        if not LOCK_DIGITALIZACAO.acquire(blocking=False):
            raise Erro("Outro usuário está usando o scanner. Aguarde a digitalização terminar e tente novamente.", 409)
        sessao = _comecar_digitalizacao(req)
        try:
            try:
                paginas = scanner.digitalizar(dispositivo, req.corpo, trabalho)
            except scanner.ErroDigitalizacao as exc:
                raise Erro(str(exc), 502)
        finally:
            LOCK_DIGITALIZACAO.release()
            _terminar_digitalizacao(sessao)
        if not paginas:
            raise Erro("O scanner não produziu nenhuma página.", 502)
        aviso = getattr(paginas, "aviso", "")
        total_bytes = sum(p.stat().st_size for p in paginas if p.is_file())
        if total_bytes > 300 * 1024 * 1024:
            raise Erro("A digitalização ficou maior que 300 MB. Reduza a resolução ou a quantidade de páginas.", 413)
        qtd = len(paginas)
        previa_disponivel = False
        if formato == "pdf":
            extensao = "pdf"
            destino = usuario_dir / f"{token}.{extensao}"
            try:
                impressao.montar_pdf_digitalizacao([str(p) for p in paginas], str(destino), str(req.b("papel") or "auto"),
                                                   _dpi_pedido(req))
            except Exception as exc:
                destino.unlink(missing_ok=True)
                raise Erro(f"Não foi possível montar o PDF da digitalização: {exc}", 502)
            # A prévia é uma imagem independente: não exige suporte a PDF embutido
            # no navegador do celular/tablet/computador que acessa o Folha a Folha.
            previa = _criar_previa_digitalizacao(paginas, destino, usuario_dir, token)
            previa_disponivel = bool(previa)
            mime = "application/pdf"
            nome = "folha-a-folha-digitalizacao.pdf"
        elif qtd == 1:
            extensao = formato
            destino = usuario_dir / f"{token}.{extensao}"
            shutil.copy2(paginas[0], destino)
            mime = {"bmp": "image/bmp", "jpg": "image/jpeg", "png": "image/png", "tif": "image/tiff"}[formato]
            nome = f"folha-a-folha-digitalizacao.{extensao}"
        else:
            extensao = "zip"
            destino = usuario_dir / f"{token}.{extensao}"
            import zipfile
            with zipfile.ZipFile(destino, "w", compression=zipfile.ZIP_DEFLATED) as z:
                for i, caminho in enumerate(paginas, 1):
                    z.write(caminho, f"pagina-{i:03d}.{formato}")
            mime = "application/zip"
            nome = f"folha-a-folha-digitalizacao-{formato.upper()}.zip"
        tamanho_final = destino.stat().st_size
        if tamanho_final > 300 * 1024 * 1024:
            destino.unlink(missing_ok=True)
            raise Erro("O arquivo final ficou maior que 300 MB. Reduza a resolução ou a quantidade de páginas.", 413)
        return {"ok": True, "arquivo_id": token, "nome": nome, "paginas": qtd,
                "formato": formato.upper() if formato == "pdf" else ("ZIP de " + formato.upper() if qtd > 1 else formato.upper()),
                "mime": mime, "tamanho": tamanho_final, "aviso": aviso,
                "previa_disponivel": previa_disponivel if formato == "pdf" else None}
    finally:
        shutil.rmtree(trabalho, ignore_errors=True)


@rota("POST", "/api/digitalizar/lote/adicionar", auth="user", trava=False)
def r_digitalizar_lote_adicionar(req):
    """Acrescenta páginas de uma nova passagem do scanner ao lote multipágina."""
    dispositivo = _id_scanner(req.b("scanner_id"))
    lote = str(req.b("lote_id") or "").strip()
    lote = _lote_valido(lote) if lote else secrets.token_hex(16)
    try:
        pedidas = int(req.b("paginas") or 1)
    except (TypeError, ValueError):
        raise Erro("Informe uma quantidade válida de páginas.")
    usuario_dir = DIGITALIZACOES / str(req.uid)
    usuario_dir.mkdir(parents=True, exist_ok=True)
    pasta_lote = usuario_dir / ("lote-" + lote)
    _usar_lote(req.uid, lote)
    try:
        pasta_lote.mkdir(parents=True, exist_ok=True)
        existentes = _paginas_lote(pasta_lote)
        if len(existentes) >= scanner.LIMITE_PAGINAS:
            raise Erro("O documento já tem o limite de 100 páginas. Conclua o PDF ou descarte algumas.", 413)
        trabalho = Path(tempfile.mkdtemp(prefix="scan-lote-", dir=str(usuario_dir)))
        try:
            if not LOCK_DIGITALIZACAO.acquire(blocking=False):
                raise Erro("Outro usuário está usando o scanner. Aguarde e tente novamente.", 409)
            sessao = _comecar_digitalizacao(req)
            try:
                config = dict(req.corpo or {})
                config["formato"] = "pdf"  # guarda imagens sem perdas para montar o PDF ao finalizar
                config["paginas"] = max(1, min(scanner.LIMITE_PAGINAS - len(existentes), pedidas))
                try:
                    novas = scanner.digitalizar(dispositivo, config, trabalho)
                except scanner.ErroDigitalizacao as exc:
                    raise Erro(str(exc), 502)
            finally:
                LOCK_DIGITALIZACAO.release()
                _terminar_digitalizacao(sessao)
            if not novas:
                raise Erro("O scanner não produziu páginas.", 502)
            meta = _meta_lote(pasta_lote)
            dpi = _dpi_pedido(req)
            for caminho in list(novas)[:scanner.LIMITE_PAGINAS - len(existentes)]:
                nome = f"pagina-{len(existentes) + 1:03d}{caminho.suffix.lower()}"
                shutil.copy2(caminho, pasta_lote / nome)
                existentes.append(pasta_lote / nome)
                meta[nome] = dpi
            (pasta_lote / "meta.json").write_text(json.dumps(meta), "utf-8")
            return {"ok": True, "lote_id": lote, "paginas": len(existentes),
                    "arquivos": [p.name for p in existentes], "aviso": getattr(novas, "aviso", "")}
        finally:
            shutil.rmtree(trabalho, ignore_errors=True)
    finally:
        _soltar_lote(req.uid, lote)


def _ler_ajuste(ajuste, i):
    """Giro (0, 90, 180, 270, no sentido horário, como na tela) e recorte (frações de 0 a 0,4)."""
    if not isinstance(ajuste, dict):
        raise Erro(f"Configuração inválida na página {i}.")
    try:
        giro = int(float(ajuste.get("rotacao") or 0)) % 360
    except (TypeError, ValueError, OverflowError):
        raise Erro(f"Giro inválido na página {i}.")
    if giro not in (0, 90, 180, 270):
        raise Erro(f"Giro inválido na página {i}: use 90, 180 ou 270 graus.")
    recorte = ajuste.get("recorte") or {}
    if not isinstance(recorte, dict):
        raise Erro(f"Recorte inválido na página {i}.")
    try:
        corte = tuple(max(0.0, min(40.0, float(recorte.get(k) or 0))) / 100
                      for k in ("esquerda", "topo", "direita", "baixo"))
    except (TypeError, ValueError, OverflowError):
        raise Erro(f"Recorte inválido na página {i}.")
    if corte[0] + corte[2] > 0.8 or corte[1] + corte[3] > 0.8:
        raise Erro(f"O recorte da página {i} está muito pequeno.")
    return giro, corte


def _editar_pagina(Image, arquivo, giro, corte, base, i):
    """Gira e recorta uma página. Preto e branco e cinza continuam assim (PNG, nítido e pequeno);
    colorido vira JPEG de boa qualidade. A resolução da imagem é mantida."""
    with Image.open(arquivo) as original:
        if original.width * original.height > 150_000_000:
            raise Erro(f"A página {i} é grande demais para girar ou recortar. Digitalize em 600 DPI ou menos, "
                       "ou conclua sem editar esta página.", 413)
        dpi = original.info.get("dpi")
        imagem = original if original.mode in ("1", "L", "RGB") else original.convert("RGB")
        if giro:
            imagem = imagem.rotate(-giro, expand=True)  # PIL gira no sentido anti-horário; a tela, no horário
        w, h = imagem.size
        esq, topo, dir_, baixo = corte
        if any(corte):
            imagem = imagem.crop((int(w * esq), int(h * topo), int(w * (1 - dir_)), int(h * (1 - baixo))))
        extra = {"dpi": tuple(round(float(x)) for x in dpi[:2])} if dpi else {}
        if imagem.mode in ("1", "L"):
            destino = base.with_suffix(".png")
            imagem.save(destino, "PNG", optimize=True, **extra)
        else:
            destino = base.with_suffix(".jpg")
            imagem.save(destino, "JPEG", quality=92, **extra)
    return destino


@rota("POST", "/api/digitalizar/lote/finalizar", auth="user", trava=False)
def r_digitalizar_lote_finalizar(req):
    """Aplica rotação/recorte por página e monta um único PDF multipágina.
    O lote só é apagado depois que o PDF fica pronto: um erro não faz perder as páginas escaneadas."""
    lote = _lote_valido(req.b("lote_id"))
    pasta = DIGITALIZACOES / str(req.uid) / ("lote-" + lote)
    paginas = _paginas_lote(pasta)
    if not paginas:
        raise Erro("Adicione pelo menos uma página antes de concluir.")
    ajustes = req.b("ajustes") or [{}] * len(paginas)
    if not isinstance(ajustes, list) or len(ajustes) != len(paginas):
        raise Erro("As configurações das páginas estão incompletas. Atualize a tela e tente de novo.")
    pedidos = [_ler_ajuste(a, i) for i, a in enumerate(ajustes, 1)]
    Image = None
    if any(g or any(c) for g, c in pedidos):
        try:
            from PIL import Image
        except ImportError:
            raise Erro("Para girar ou recortar páginas, instale o Pillow no computador do Folha a Folha "
                       "(Ubuntu/Mint: sudo apt install python3-pil; Windows: py -m pip install Pillow). "
                       "Sem giro e sem recorte, o PDF sai normalmente.", 503)
        Image.MAX_IMAGE_PIXELS = 160_000_000  # páginas do próprio scanner; o limite real é o de _editar_pagina
    papel = str(req.b("papel") or "auto")
    meta = _meta_lote(pasta)
    _usar_lote(req.uid, lote)
    try:
        token = secrets.token_hex(16)
        trabalho = Path(tempfile.mkdtemp(prefix="final-", dir=str(pasta.parent)))
        try:
            saidas, dpis = [], []
            for i, (arquivo, (giro, corte)) in enumerate(zip(paginas, pedidos), 1):
                dpis.append(int(meta.get(arquivo.name) or 0))
                if not giro and not any(corte):
                    saidas.append(arquivo)  # sem edição: a página entra como saiu do scanner, sem recompressão
                    continue
                try:
                    saidas.append(_editar_pagina(Image, arquivo, giro, corte, trabalho / f"editada-{i:03d}", i))
                except Erro:
                    raise
                except Exception as exc:
                    raise Erro(f"Não foi possível editar a página {i}: {exc}", 502)
            destino = DIGITALIZACOES / str(req.uid) / f"{token}.pdf"
            try:
                impressao.montar_pdf_digitalizacao([str(x) for x in saidas], str(destino), papel, dpis)
            except Exception as exc:
                destino.unlink(missing_ok=True)
                raise Erro(f"Não foi possível montar o PDF da digitalização: {exc}", 502)
            previa = _criar_previa_digitalizacao(saidas, destino, destino.parent, token)
        finally:
            shutil.rmtree(trabalho, ignore_errors=True)
        shutil.rmtree(pasta, ignore_errors=True)
        return {"ok": True, "arquivo_id": token, "nome": "folha-a-folha-digitalizacao.pdf",
                "paginas": len(saidas), "formato": "PDF", "mime": "application/pdf",
                "tamanho": destino.stat().st_size, "previa_disponivel": bool(previa)}
    finally:
        _soltar_lote(req.uid, lote)


@rota("POST", "/api/digitalizar/lote/descartar", auth="user", trava=False)
def r_digitalizar_lote_descartar(req):
    """Apaga as páginas de um documento em montagem (não ficam esperando a limpeza de 12 horas)."""
    lote = _lote_valido(req.b("lote_id"))
    _usar_lote(req.uid, lote)
    try:
        shutil.rmtree(DIGITALIZACOES / str(req.uid) / ("lote-" + lote), ignore_errors=True)
    finally:
        _soltar_lote(req.uid, lote)
    return {"ok": True}


@rota("GET", "/api/digitalizar/lote/aberto", auth="user", trava=False)
def r_digitalizar_lote_aberto(req):
    """O documento em montagem mais recente desta pessoa: a tela retoma depois de recarregar a página
    (o celular costuma recarregar a aba quando a pessoa troca de aplicativo)."""
    pasta = DIGITALIZACOES / str(req.uid)
    lotes = [p for p in pasta.glob("lote-*") if p.is_dir() and _paginas_lote(p)] if pasta.is_dir() else []
    if not lotes:
        return {"lote_id": None, "paginas": 0}
    lote = max(lotes, key=lambda p: p.stat().st_mtime)
    return {"lote_id": lote.name[5:], "paginas": len(_paginas_lote(lote))}


@rota("GET", "/api/digitalizar/lote/pagina", auth="user", trava=False)
def r_digitalizar_lote_pagina(req):
    lote = str(req.q("lote") or "")
    pagina = inteiro(req.q("pagina") or 1, "página", 1, 100)
    if not re.fullmatch(r"[0-9a-f]{32}", lote): raise Erro("Lote inválido.", 404)
    pasta = DIGITALIZACOES / str(req.uid) / ("lote-" + lote)
    arquivo = next(iter(sorted(pasta.glob(f"pagina-{pagina:03d}.*"))), None) if pasta.is_dir() else None
    if not arquivo: raise Erro("Página não encontrada.", 404)
    tipo = "image/png" if arquivo.suffix.lower()==".png" else "image/jpeg"
    return Resposta(arquivo.read_bytes(), tipo, {"Cache-Control":"no-store"})


@rota("GET", "/api/digitalizar/visualizar", auth="user", trava=False)
def r_visualizar_digitalizacao(req):
    token = str(req.q("id") or "")
    if not re.fullmatch(r"[0-9a-f]{32}", token):
        raise Erro("Esta digitalização não está mais disponível.", 404)
    pasta = DIGITALIZACOES / str(req.uid)
    pdf = pasta / f"{token}.pdf"

    # PDF de digitalização: devolve uma imagem da primeira página para <img>.
    # Isso funciona mesmo em navegadores que só oferecem um botão externo "Abrir PDF".
    if pdf.is_file():
        previa = next((pasta / f"{token}-preview.{ext}" for ext in ("jpg", "png")
                       if (pasta / f"{token}-preview.{ext}").is_file()), None)
        if previa is None:  # compatibilidade com arquivos temporários do primeiro build de correção
            previa = next((pasta / f"{token}.preview.{ext}" for ext in ("jpg", "png")
                           if (pasta / f"{token}.preview.{ext}").is_file()), None)
        if previa is None:
            # Compatibilidade com PDFs criados antes desta correção: tenta renderizar
            # a primeira página sob demanda, se Poppler/MuPDF/Ghostscript estiver instalado.
            base = pasta / f"{token}-preview"
            try:
                renderizada = impressao.renderizar_imagem(str(pdf), 1, str(base), 96)
                if renderizada and Path(renderizada).is_file():
                    previa = Path(renderizada)
            except Exception:
                previa = None
        if previa is None:
            raise Erro("A prévia desta digitalização não está disponível. O PDF original continua disponível no botão Baixar arquivo.", 404)
        tipo_previa = "image/jpeg" if previa.suffix.lower() in (".jpg", ".jpeg") else "image/png"
        return Resposta(previa.read_bytes(), tipo_previa,
                        {"Content-Disposition": 'inline; filename="previa-digitalizacao' + previa.suffix + '"'})

    caminho = next((pasta / f"{token}.{ext}" for ext in ("jpg", "png")
                    if (pasta / f"{token}.{ext}").is_file()), None)
    if not caminho:
        raise Erro("Não há prévia disponível para este arquivo.", 404)
    tipo = "image/jpeg" if caminho.suffix.lower() == ".jpg" else "image/png"
    return Resposta(caminho.read_bytes(), tipo, {"Content-Disposition": "inline"})


@rota("GET", "/api/digitalizar/baixar", auth="user", trava=False)
def r_baixar_digitalizacao(req):
    token = str(req.q("id") or "")
    if not re.fullmatch(r"[0-9a-f]{32}", token):
        raise Erro("Esta digitalização não está mais disponível.", 404)
    pasta = DIGITALIZACOES / str(req.uid)
    caminho = next((pasta / f"{token}.{ext}" for ext in ("pdf", "bmp", "jpg", "png", "tif", "zip")
                    if (pasta / f"{token}.{ext}").is_file()), None)
    if not caminho:
        raise Erro("O arquivo da digitalização expirou ou já foi apagado. Digitalize novamente.", 404)
    tipo = {"pdf": "application/pdf", "bmp": "image/bmp", "jpg": "image/jpeg", "png": "image/png",
            "tif": "image/tiff", "zip": "application/zip"}[caminho.suffix.lstrip(".")]
    nome = "folha-a-folha-digitalizacao." + caminho.suffix.lstrip(".")
    if caminho.suffix == ".zip":
        nome = "folha-a-folha-digitalizacao-imagens.zip"
    return Resposta(caminho.read_bytes(), tipo, {"Content-Disposition": f'attachment; filename="{nome}"'})


# ================================================================ manutenção

def apagar_mensagens_antigas():
    """Apaga mensagens mais antigas que o prazo configurado (LGPD: guardar só o necessário)."""
    meses = int(cfg("reter_mensagens_meses") or 12)
    limite = (dt.datetime.now() - dt.timedelta(days=30 * meses)).strftime("%Y-%m-%d %H:%M:%S")
    return DB.execute("DELETE FROM mensagens WHERE criado_em < ?", (limite,)).rowcount


def limpeza_periodica():
    while True:
        try:
            limite = time.time() - 12 * 3600
            for p in ARQUIVOS.iterdir():
                try:
                    if p.stat().st_mtime < limite:
                        if p.is_dir():
                            shutil.rmtree(p, ignore_errors=True)
                        else:
                            p.unlink()
                except OSError:
                    pass
            for p in (ARQUIVOS / "previas").glob("*.png") if (ARQUIVOS / "previas").is_dir() else []:
                try:
                    if p.stat().st_mtime < limite:
                        p.unlink()
                except OSError:
                    pass
            for p in FILA.iterdir():  # sobras de quedas de energia: nada fica mais de 3 dias
                try:
                    if p.stat().st_mtime < time.time() - 73 * 3600:
                        p.unlink()
                except OSError:
                    pass
            for pasta_scan in DIGITALIZACOES.iterdir():
                try:
                    if pasta_scan.is_dir():
                        for arquivo_scan in pasta_scan.iterdir():
                            try:
                                if arquivo_scan.stat().st_mtime < limite:
                                    if arquivo_scan.is_dir():
                                        shutil.rmtree(arquivo_scan, ignore_errors=True)
                                    else:
                                        arquivo_scan.unlink()
                            except OSError:
                                pass
                        if not any(pasta_scan.iterdir()):
                            pasta_scan.rmdir()
                except OSError:
                    pass
            with LOCK:
                lim = (dt.datetime.now() - dt.timedelta(hours=12)).strftime("%Y-%m-%d %H:%M:%S")
                DB.execute("DELETE FROM uploads WHERE criado_em<?", (lim,))
                # pedidos dispensados que já foram atendidos, cancelados ou expiraram não precisam mais da marca
                DB.execute("DELETE FROM pedidos_ocultos WHERE pedido_id NOT IN "
                           "(SELECT id FROM pedidos WHERE status='pendente' AND mes=?)", (mes_atual(),))
                lim_s = (dt.datetime.now() - dt.timedelta(days=DIAS_SESSAO)).strftime("%Y-%m-%d %H:%M:%S")
                DB.execute("DELETE FROM sessoes WHERE criado_em<?", (lim_s,))
                apagar_mensagens_antigas()
                expirar_retidas()
                expirar_conferencias()
                DB.commit()
        except Exception:
            pass
        time.sleep(3600)


def ips_locais():
    """Endereços deste computador na rede local, o principal primeiro.
    Ficam de fora os internos (127.x, como o 127.0.1.1 que o Ubuntu põe no nome do computador)
    e os automáticos (169.254.x), que não servem para os celulares."""
    principal = None
    ips = set()
    falsa = os.environ.get("CI_IPS_ARQUIVO")
    if falsa:  # só nos testes: a rede é um arquivo com os endereços, o principal primeiro (vazio = sem rede)
        try:
            lidos = open(falsa, encoding="utf-8").read().split()
        except OSError:
            lidos = []
        return ordenar_ips(set(lidos), lidos[0] if lidos else None)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        principal = s.getsockname()[0]
        ips.add(principal)
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    if os.name != "nt" and shutil.which("hostname"):
        try:  # Linux: todos os endereços da máquina, mesmo numa rede sem roteador
            saida = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=3).stdout
            ips.update(p for p in saida.split() if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", p))
        except (OSError, subprocess.SubprocessError):
            pass
    return ordenar_ips(ips, principal)


def ordenar_ips(ips, principal):
    validos = [ip for ip in ips if not ip.startswith(("127.", "169.254.", "0."))]

    def ordem(ip):
        # 192.168 e 10.x são as redes locais mais comuns; 172.16-31 costuma ser rede interna de programas (Docker)
        faixa = 0 if ip.startswith("192.168.") else 1 if ip.startswith("10.") else \
            2 if re.match(r"172\.(1[6-9]|2\d|3[01])\.", ip) else 3
        return (ip != principal, faixa, ip)
    return sorted(validos, key=ordem) or ["127.0.0.1"]


ENDERECOS = []
PORTA_PRINCIPAL = 8080
PORTA_IPP_ATIVA = False
ANUNCIO = {"modo": None, "objeto": None, "porta": None, "ip": None}
SERVIDOR = {"ativo": False, "host": "0.0.0.0", "porta_ipp": 0, "srv_ipp": None}
TROCA = threading.Lock()
REDE = threading.Lock()
INTERVALO_REDE = float(os.environ.get("CI_INTERVALO_REDE", 10))  # segundos entre uma conferência da rede e outra


def atualizar_enderecos():
    """Relê os endereços deste computador que servem para os outros aparelhos (2.6.1).
    Antes eram lidos uma vez só, ao ligar: se o programa ligasse antes de a rede estar pronta, a tela e o cartaz
    ficavam com http://127.0.0.1 até ele ser religado. Sem rede, a lista fica vazia."""
    global ENDERECOS
    with REDE:
        novos = [f"http://{ip}:{PORTA_PRINCIPAL}" for ip in ips_locais() if not ip.startswith("127.")]
        if novos != ENDERECOS:
            ENDERECOS = novos
            _LOCAIS["t"] = 0  # quem é "este computador" também muda
    return ENDERECOS


def ip_da_rede():
    """O endereço principal deste computador na rede, ou None quando ele está sem rede."""
    lista = ENDERECOS
    return lista[0].split("//")[1].rsplit(":", 1)[0] if lista else None


def vigiar_rede():
    """A rede pode ficar pronta depois do programa (Wi-Fi que só conecta mais tarde) ou mudar de endereço.
    A lista de endereços e o anúncio no Wi-Fi acompanham, sem religar o programa."""
    ultimo_erro = None
    while True:
        time.sleep(INTERVALO_REDE)
        try:
            atualizar_enderecos()
            if SERVIDOR["ativo"] and ANUNCIO["porta"] and ip_da_rede() != ANUNCIO["ip"]:
                with TROCA:
                    reiniciar_anuncio()
            ultimo_erro = None
        except Exception as e:  # a conferência nunca derruba o programa; o motivo aparece uma vez só
            if str(e) != ultimo_erro:
                ultimo_erro = str(e)
                print(f"Aviso: não deu para conferir a rede ({e}).", flush=True)


def ligar_porta_ipp():
    global PORTA_IPP_ATIVA
    pedida = SERVIDOR["porta_ipp"]
    if SERVIDOR["srv_ipp"] or not pedida or pedida == PORTA_PRINCIPAL:
        return
    try:
        srv = Servidor((SERVIDOR["host"], pedida), Handler)
    except OSError:
        return
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    SERVIDOR["srv_ipp"] = srv
    PORTA_IPP_ATIVA = True


def desligar_porta_ipp():
    global PORTA_IPP_ATIVA
    srv = SERVIDOR["srv_ipp"]
    if srv:
        srv.shutdown()
        srv.server_close()
    SERVIDOR["srv_ipp"] = None
    PORTA_IPP_ATIVA = False


def aplicar_modo():
    """Liga ou desliga a impressora Folha a Folha (porta 631 e anúncio) conforme o estilo escolhido."""
    with TROCA:
        with LOCK:
            impressora = modo_impressora()
        if impressora:
            ligar_porta_ipp()
        else:
            desligar_porta_ipp()
        ANUNCIO["porta"] = SERVIDOR["porta_ipp"] if PORTA_IPP_ATIVA else PORTA_PRINCIPAL
        reiniciar_anuncio()


def reiniciar_anuncio():
    """Refaz o anúncio no Wi-Fi depois de mudar as filas, o nome da escola, a rede ou ligar/desligar."""
    if ANUNCIO["objeto"]:
        ANUNCIO["objeto"].parar()
        ANUNCIO["objeto"], ANUNCIO["modo"] = None, None
    with LOCK:
        ligado = cfg("anunciar_rede") == "1" and modo_impressora()
    atualizar_enderecos()
    ANUNCIO["ip"] = ip_da_rede()  # o endereço que valia desta vez: vigiar_rede refaz o anúncio quando ele muda
    if ligado:
        iniciar_anuncio(ANUNCIO["porta"])


def iniciar_anuncio(porta):
    ip = ip_da_rede()
    if not ip:
        return
    with LOCK:
        escola, id_uuid = cfg("escola"), cfg("ipp_uuid")
        servicos = [("Folha a Folha", "ipp/print", None)]
        if cfg("filas_por_impressora") == "1":
            servicos += [(f"Folha a Folha - {i['nome']}", f"ipp/print/{i['id']}", i["id"]) for i in impressoras()]
    txt_base = {"txtvers": 1, "qtotal": 1, "ty": "Folha a Folha", "product": "(Folha a Folha)",
                "pdl": "application/pdf,image/pwg-raster,image/jpeg", "Color": "T", "Duplex": "T", "Copies": "T",
                "kind": "document", "note": f"Libere em {ip}:{PORTA_PRINCIPAL}"[:60], "PaperMax": "legal-A4", "priority": 50,
                "adminurl": f"http://{ip}:{PORTA_PRINCIPAL}/"}
    lista = []
    for nome, caminho, iid in servicos:
        u = str(uuid.UUID(id_uuid)) if iid is None else str(uuid.uuid5(uuid.UUID(id_uuid), f"impressora-{iid}"))
        lista.append((nome, caminho, {**txt_base, "UUID": u}))
    an = mdns.Anunciante(mdns.Registros(ip, porta, lista))
    ANUNCIO["modo"] = an.iniciar()
    ANUNCIO["objeto"] = an


def main():
    global ENDERECOS, PORTA_PRINCIPAL, PORTA_IPP_ATIVA
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Folha a Folha")
    ap.add_argument("--porta", type=int, default=int(os.environ.get("CI_PORTA", 8080)))
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--porta-ipp", type=int, default=int(os.environ.get("CI_PORTA_IPP", 631)),
                    help="porta padrão das impressoras (631). Use 0 para não abrir.")
    a = ap.parse_args()
    PORTA_PRINCIPAL = a.porta
    abrir_banco()
    threading.Thread(target=limpeza_periodica, daemon=True).start()
    threading.Thread(target=leitura_automatica, daemon=True).start()
    threading.Thread(target=laco_central, daemon=True).start()
    threading.Thread(target=acompanhar_fila, daemon=True).start()
    atualizar_enderecos()
    srv = Servidor((a.host, a.porta), Handler)
    srv.daemon_threads = True
    SERVIDOR.update(host=a.host, porta_ipp=a.porta_ipp, ativo=True)
    aplicar_modo()
    threading.Thread(target=vigiar_rede, daemon=True).start()
    with LOCK:
        impressora, lic = modo_impressora(), estado_licenca()
    print("=" * 60)
    print(" Folha a Folha está funcionando!")
    print(" No celular ou computador (mesma rede), abra:")
    for e in ENDERECOS:
        print("    ", e)
    if not ENDERECOS:
        print("     (este computador ainda não está numa rede: o endereço aparece em Gestão, Resumo do mês, quando a rede ligar)")
    print(f" Neste computador: http://localhost:{a.porta}")
    ip0 = ENDERECOS[0].split("//")[1].split(":")[0] if ENDERECOS else "localhost"
    if impressora:
        print(" Estilo impressora. Impressora Folha a Folha para os computadores e celulares:")
        print(f"     http://{ip0}:{a.porta}/ipp/print")
        if PORTA_IPP_ATIVA:
            print(f"     (também na porta padrão {a.porta_ipp}, para celulares Android)")
        if ANUNCIO["modo"]:
            print("     Anunciada no Wi-Fi: os aparelhos acham sozinhos.")
    else:
        print(" Estilo navegador: a equipe envia os arquivos pelo app.")
    print(f" {lic['mensagem']}")
    print(" Deixe esta janela aberta. Para desligar, feche-a ou aperte Ctrl+C.")
    print("=" * 60, flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nDesligando...")
    finally:
        srv.server_close()
        desligar_porta_ipp()
        if ANUNCIO["objeto"]:
            ANUNCIO["objeto"].parar()


if __name__ == "__main__":
    main()
