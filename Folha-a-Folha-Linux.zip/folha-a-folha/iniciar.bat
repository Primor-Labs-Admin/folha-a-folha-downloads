@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Folha a Folha

rem Procura o Python: primeiro o inicializador "py", depois "python"
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  where python >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY goto sem_python

rem O Pillow e opcional: so serve para girar e recortar paginas escaneadas antes de gerar o PDF
%PY% -c "import PIL" >nul 2>nul
if errorlevel 1 (
  echo Instalando o componente para girar e recortar paginas escaneadas ^(Pillow^)...
  %PY% -m pip install --user -r requirements.txt
  if errorlevel 1 echo Aviso: o Pillow nao foi instalado. O Folha a Folha funciona sem ele; so nao gira nem recorta paginas escaneadas.
)

%PY% servidor.py %*
goto fim

:sem_python
echo.
echo O Python nao foi encontrado neste computador.
echo Instale o "Python Install Manager" pela Microsoft Store
echo ou pelo site https://www.python.org/downloads/
echo Depois feche esta janela e abra o iniciar.bat de novo.
echo.

:fim
pause
