"""Parte que conversa com as impressoras e conta páginas.

Funciona em Windows e Linux usando só a biblioteca padrão do Python.
- Linux (e macOS): imprime com o comando `lp` do CUPS.
- Windows: imprime com o SumatraPDF (gratuito, portátil).
- Arquivos do Word/LibreOffice são convertidos em PDF pelo LibreOffice, se estiver instalado.
"""
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path

WINDOWS = os.name == "nt"
PASTA_APP = Path(__file__).resolve().parent

EXT_PDF = {".pdf"}
EXT_IMAGEM = {".jpg", ".jpeg", ".png"}
EXT_OFFICE = {".doc", ".docx", ".odt", ".rtf", ".ppt", ".pptx", ".odp", ".xls", ".xlsx", ".ods"}


class ErroImpressao(Exception):
    pass


# ---------------------------------------------------------------- ferramentas

def _sem_janela():
    """No Windows, evita abrir janelas pretas ao chamar programas."""
    if WINDOWS:
        return {"creationflags": 0x08000000}  # CREATE_NO_WINDOW
    return {}


def achar_sumatra(caminho_config=""):
    candidatos = []
    if caminho_config:
        candidatos.append(caminho_config)
    candidatos.append(str(PASTA_APP / "ferramentas" / "SumatraPDF.exe"))
    for var in ("LOCALAPPDATA", "ProgramFiles", "ProgramFiles(x86)"):
        base = os.environ.get(var)
        if base:
            candidatos.append(os.path.join(base, "SumatraPDF", "SumatraPDF.exe"))
    for c in candidatos:
        if c and os.path.isfile(c):
            return c
    achado = shutil.which("SumatraPDF") or shutil.which("SumatraPDF.exe")
    return achado


def achar_soffice(caminho_config=""):
    candidatos = []
    if caminho_config:
        candidatos.append(caminho_config)
    if WINDOWS:
        for var in ("ProgramFiles", "ProgramFiles(x86)"):
            base = os.environ.get(var)
            if base:
                candidatos.append(os.path.join(base, "LibreOffice", "program", "soffice.exe"))
    for c in candidatos:
        if c and os.path.isfile(c):
            return c
    return shutil.which("soffice") or shutil.which("libreoffice")


def listar_impressoras():
    """Nomes das impressoras instaladas no computador."""
    nomes = []
    try:
        if WINDOWS:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
                 "Get-Printer | Select-Object -ExpandProperty Name"],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=20, **_sem_janela())
            nomes = [l.strip() for l in r.stdout.splitlines() if l.strip()]
            if not nomes:
                r = subprocess.run(["wmic", "printer", "get", "name"],
                                   capture_output=True, text=True, errors="replace", timeout=20,
                                   **_sem_janela())
                nomes = [l.strip() for l in r.stdout.splitlines()[1:] if l.strip()]
        elif shutil.which("lpstat"):
            r = subprocess.run(["lpstat", "-e"], capture_output=True, text=True, timeout=10)
            nomes = [l.strip() for l in r.stdout.splitlines() if l.strip()]
            if not nomes:
                r = subprocess.run(["lpstat", "-a"], capture_output=True, text=True, timeout=10)
                nomes = [l.split()[0] for l in r.stdout.splitlines() if l.strip()]
    except Exception:
        pass
    # a própria Folha a Folha pode aparecer instalada neste computador; mandar para ela daria volta infinita
    return [n for n in nomes if not eh_folha_a_folha(n)]


def eh_folha_a_folha(nome):
    return bool(re.search(r"folha.?a.?folha", nome or "", re.I))


def situacao_ferramentas(sumatra_cfg="", soffice_cfg=""):
    sumatra = achar_sumatra(sumatra_cfg) if WINDOWS else None
    rend = achar_renderizador()
    return {
        "sistema": "Windows" if WINDOWS else ("macOS" if sys.platform == "darwin" else "Linux"),
        "windows": WINDOWS,
        "lp": bool(shutil.which("lp")) if not WINDOWS else None,
        "sumatra": sumatra,
        "soffice": achar_soffice(soffice_cfg),
        "previa": rend[1] if rend else None,
        "impressoras": listar_impressoras(),
    }


# ---------------------------------------------------------------- foto (JPG ou PNG) vira PDF de uma página

A4 = (595.28, 841.89)
MARGEM_FOTO = 18  # pontos (cerca de 6 mm), como a margem que quase toda impressora exige

# Como desenhar a foto para ela ficar em pé, conforme a orientação gravada pela câmera (EXIF 1 a 8).
# Cada matriz leva o quadrado da imagem guardada para o quadrado da imagem como deve ser vista.
_ORIENTACAO = {1: (1, 0, 0, 1, 0, 0), 2: (-1, 0, 0, 1, 1, 0), 3: (-1, 0, 0, -1, 1, 1), 4: (1, 0, 0, -1, 0, 1),
               5: (0, -1, -1, 0, 1, 1), 6: (0, -1, 1, 0, 0, 1), 7: (0, 1, 1, 0, 0, 0), 8: (0, 1, -1, 0, 1, 0)}


def _orientacao_exif(t):
    if t[:2] == b"II":
        e = "little"
    elif t[:2] == b"MM":
        e = "big"
    else:
        return 1
    off = int.from_bytes(t[4:8], e)
    if off + 2 > len(t):
        return 1
    for k in range(int.from_bytes(t[off:off + 2], e)):
        p = off + 2 + 12 * k
        if p + 12 > len(t):
            break
        if int.from_bytes(t[p:p + 2], e) == 0x0112:
            v = int.from_bytes(t[p + 8:p + 10], e)
            return v if 1 <= v <= 8 else 1
    return 1


def _jpeg(dados):
    """Lê do JPEG o tamanho, as cores e a orientação, sem decodificar a imagem."""
    i, n = 2, len(dados)
    adobe, orient = False, 1
    while i < n - 3:
        if dados[i] != 0xFF:
            i += 1
            continue
        marca = dados[i + 1]
        if marca == 0xFF:
            i += 1
            continue
        if marca in (0xD8, 0x01) or 0xD0 <= marca <= 0xD7:
            i += 2
            continue
        tam = int.from_bytes(dados[i + 2:i + 4], "big")
        seg = dados[i + 4:i + 2 + tam]
        if marca in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF) and len(seg) >= 6:
            alt, larg, comp = int.from_bytes(seg[1:3], "big"), int.from_bytes(seg[3:5], "big"), seg[5]
            if not larg or not alt or comp not in (1, 3, 4):
                break
            cores = {1: b"/DeviceGray", 3: b"/DeviceRGB", 4: b"/DeviceCMYK"}[comp]
            extra = b" /Decode [1 0 1 0 1 0 1 0]" if comp == 4 and adobe else b""
            dicio = (b"/Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s /BitsPerComponent 8%s "
                     b"/Filter /DCTDecode" % (larg, alt, cores, extra))
            return {"larg": larg, "alt": alt, "orient": orient, "dicio": dicio, "dados": dados, "mascara": None}
        if marca == 0xEE and seg[:5] == b"Adobe":
            adobe = True
        elif marca == 0xE1 and seg[:6] == b"Exif\x00\x00":
            orient = _orientacao_exif(seg[6:])
        elif marca == 0xDA:
            break
        i += 2 + tam
    raise ErroImpressao("Não consegui ler esta foto. Tente salvá-la de novo como JPG ou PDF.")


def _desfiltrar(dados, larg_bytes, alt, bpp):
    """Desfaz os filtros de linha do PNG (Sub, Up, Average, Paeth)."""
    saida = bytearray(larg_bytes * alt)
    ant = bytearray(larg_bytes)
    pos = 0
    for y in range(alt):
        f = dados[pos]
        linha = bytearray(dados[pos + 1:pos + 1 + larg_bytes])
        pos += 1 + larg_bytes
        if f == 1:
            for i in range(bpp, larg_bytes):
                linha[i] = (linha[i] + linha[i - bpp]) & 255
        elif f == 2:
            for i in range(larg_bytes):
                linha[i] = (linha[i] + ant[i]) & 255
        elif f == 3:
            for i in range(larg_bytes):
                linha[i] = (linha[i] + (((linha[i - bpp] if i >= bpp else 0) + ant[i]) >> 1)) & 255
        elif f == 4:
            for i in range(larg_bytes):
                a = linha[i - bpp] if i >= bpp else 0
                b = ant[i]
                c = ant[i - bpp] if i >= bpp else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                linha[i] = (linha[i] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        elif f != 0:
            raise ErroImpressao("Esta imagem PNG está com defeito. Tente salvá-la como JPG ou PDF.")
        saida[y * larg_bytes:(y + 1) * larg_bytes] = linha
        ant = linha
    return saida


def _png(dados):
    ilegivel = "Não consegui ler esta imagem. Tente salvá-la como JPG ou PDF."
    if dados[:8] != b"\x89PNG\r\n\x1a\n":
        raise ErroImpressao(ilegivel)
    pos, ihdr, plte, trns, idat = 8, None, b"", None, []
    while pos + 8 <= len(dados):
        tam = int.from_bytes(dados[pos:pos + 4], "big")
        tipo = dados[pos + 4:pos + 8]
        corpo = dados[pos + 8:pos + 8 + tam]
        pos += 12 + tam
        if tipo == b"IHDR":
            ihdr = corpo
        elif tipo == b"PLTE":
            plte = corpo
        elif tipo == b"tRNS":
            trns = corpo
        elif tipo == b"IDAT":
            idat.append(corpo)
        elif tipo == b"IEND":
            break
    if not ihdr or not idat:
        raise ErroImpressao(ilegivel)
    larg, alt = int.from_bytes(ihdr[0:4], "big"), int.from_bytes(ihdr[4:8], "big")
    bd, ct, entrelacado = ihdr[8], ihdr[9], ihdr[12]
    if entrelacado:
        raise ErroImpressao("Esta imagem PNG é do tipo entrelaçado, que o sistema não lê. Salve como JPG ou PDF.")
    comprimido = b"".join(idat)
    canais = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ct)
    if canais is None or bd not in (1, 2, 4, 8, 16):
        raise ErroImpressao(ilegivel)
    base = {"larg": larg, "alt": alt, "orient": 1, "mascara": None}
    if ct in (0, 2) or (ct == 3 and trns is None):
        # sem transparência: o PDF lê os dados do PNG como estão
        if ct == 3:
            n = len(plte) // 3
            cores = b"[/Indexed /DeviceRGB %d <%s>]" % (n - 1, plte[:n * 3].hex().encode())
        else:
            cores = b"/DeviceGray" if ct == 0 else b"/DeviceRGB"
        base["dicio"] = (b"/Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s /BitsPerComponent %d "
                         b"/Filter /FlateDecode /DecodeParms << /Predictor 15 /Colors %d /BitsPerComponent %d "
                         b"/Columns %d >>" % (larg, alt, cores, bd, canais, bd, larg))
        base["dados"] = comprimido
        return base
    # com transparência: separa a cor e o canal de transparência (que vira a "máscara suave" do PDF).
    # Só aqui a imagem é descompactada na memória; sem transparência (fotos comuns e páginas escaneadas
    # em 600 dpi ou mais), os dados passam direto para o PDF e não há limite de tamanho.
    if larg * alt > 25_000_000:
        raise ErroImpressao("Imagem grande demais. Reduza o tamanho ou salve como JPG.")
    if ct == 3:
        if bd != 8:
            raise ErroImpressao(ilegivel)
        idx = bytes(_desfiltrar(zlib.decompress(comprimido), larg, alt, 1))
        pal = plte + bytes(768 - len(plte))
        tr = (trns + b"\xff" * 256)[:256]
        cor = bytearray(larg * alt * 3)
        for k in range(3):
            cor[k::3] = idx.translate(bytes(pal[k::3][:256]))
        alfa = idx.translate(tr)
        espaco = b"/DeviceRGB"
    else:
        if ct in (0, 2) or bd < 8:
            raise ErroImpressao(ilegivel)
        passo = canais * (2 if bd == 16 else 1)
        bruto = _desfiltrar(zlib.decompress(comprimido), larg * passo, alt, passo)
        alto = bytes(bruto[0::2]) if bd == 16 else bytes(bruto)  # 16 bits: fica o byte mais significativo
        cor_canais = canais - 1
        cor = bytearray(larg * alt * cor_canais)
        for k in range(cor_canais):
            cor[k::cor_canais] = alto[k::canais]
        alfa = alto[cor_canais::canais]
        espaco = b"/DeviceRGB" if cor_canais == 3 else b"/DeviceGray"
    base["dicio"] = (b"/Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s /BitsPerComponent 8 "
                     b"/Filter /FlateDecode" % (larg, alt, espaco))
    base["dados"] = zlib.compress(bytes(cor), 6)
    base["mascara"] = (b"/Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceGray "
                       b"/BitsPerComponent 8 /Filter /FlateDecode" % (larg, alt), zlib.compress(alfa, 6))
    return base


def ler_imagem(caminho):
    """JPG ou PNG pronto para entrar num PDF. Também diz o tamanho como a foto deve ser vista (em pé ou deitada)."""
    with open(caminho, "rb") as f:
        dados = f.read()
    if dados[:3] == b"\xff\xd8\xff":
        info = _jpeg(dados)
    elif dados[:8] == b"\x89PNG\r\n\x1a\n":
        info = _png(dados)
    else:
        raise ErroImpressao("Envie a foto em JPG ou PNG.")
    info["vis_l"], info["vis_a"] = (info["alt"], info["larg"]) if info["orient"] >= 5 else (info["larg"], info["alt"])
    return info


class _PDF:
    """Monta um PDF simples: páginas com imagens, linhas e texto."""

    def __init__(self):
        self.objs = [b"", b""]  # 1 = catálogo, 2 = árvore de páginas
        self.paginas = []
        self.fonte = None

    def add(self, corpo):
        self.objs.append(corpo)
        return len(self.objs)

    def stream(self, dicio, dados):
        return self.add(b"<< " + dicio + b" /Length %d >>\nstream\n" % len(dados) + dados + b"\nendstream")

    def imagem(self, info):
        extra = b""
        if info.get("mascara"):
            extra = b" /SMask %d 0 R" % self.stream(*info["mascara"])
        return self.stream(info["dicio"] + extra, info["dados"])

    def com_fonte(self):
        if not self.fonte:
            self.fonte = self.add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        return self.fonte

    def pagina(self, larg, alt, conteudo, imagens):
        xo = b" ".join(b"/%s %d 0 R" % (k.encode(), v) for k, v in imagens.items())
        fonte = b" /Font << /F1 %d 0 R >>" % self.fonte if self.fonte else b""
        c = self.stream(b"", conteudo.encode("latin-1") if isinstance(conteudo, str) else conteudo)
        self.paginas.append(self.add(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Resources << "
                                     b"/XObject << %s >>%s >> /Contents %d 0 R >>" % (larg, alt, xo, fonte, c)))

    def salvar(self, destino):
        if not self.paginas:
            raise ErroImpressao("Nada para imprimir.")
        self.objs[0] = b"<< /Type /Catalog /Pages 2 0 R >>"
        self.objs[1] = b"<< /Type /Pages /Kids [%s] /Count %d >>" % (
            b" ".join(b"%d 0 R" % p for p in self.paginas), len(self.paginas))
        saida = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        posicoes = []
        for i, o in enumerate(self.objs, 1):
            posicoes.append(len(saida))
            saida += b"%d 0 obj\n" % i + o + b"\nendobj\n"
        xref = len(saida)
        saida += b"xref\n0 %d\n0000000000 65535 f \n" % (len(self.objs) + 1)
        saida += b"".join(b"%010d 00000 n \n" % p for p in posicoes)
        saida += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(self.objs) + 1, xref)
        with open(destino, "wb") as f:
            f.write(saida)
        return str(destino)


def _texto_pdf(t):
    return t.encode("cp1252", "replace").replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)").decode("latin-1")


def _desenho(info, nome, x, y, w, h, girar=False):
    """Comandos para desenhar a imagem em pé (ou girada 90°) na caixa x, y, w, h."""
    m = _ORIENTACAO[info["orient"]]
    giro = "0 -1 1 0 0 1 cm " if girar else ""
    return (f"q {w:.3f} 0 0 {h:.3f} {x:.3f} {y:.3f} cm {giro}{m[0]} {m[1]} {m[2]} {m[3]} {m[4]} {m[5]} cm "
            f"/{nome} Do Q ")


def _corte(x, y, w, h):
    return f"q {x:.3f} {y:.3f} {w:.3f} {h:.3f} re W n "


def imagem_para_pdf(caminho, destino, orientacao="auto"):
    """Transforma uma foto em PDF A4 na orientação escolhida (retrato, paisagem ou automática)."""
    return montar_fotos([caminho], 1, 1, False, destino, orientacao)

# ---------------------------------------------------------------- montagens: fotos por folha, banner, páginas por folha

GRADES_FOTOS = {1: (1, 1), 2: (1, 2), 4: (2, 2), 6: (2, 3), 9: (3, 3)}  # colunas, linhas (folha em pé)
GRADES_BANNER = {2: [(1, 2), (2, 1)], 4: [(2, 2)], 6: [(2, 3), (3, 2)], 9: [(3, 3)], 12: [(3, 4), (4, 3)], 16: [(4, 4)]}
ESPACO = 10  # pontos entre as fotos da mesma folha


def _grade(larg, alt, cols, lins):
    """Caixas (x, y, w, h) da grade, de cima para baixo e da esquerda para a direita."""
    cw = (larg - 2 * MARGEM_FOTO - (cols - 1) * ESPACO) / cols
    ch = (alt - 2 * MARGEM_FOTO - (lins - 1) * ESPACO) / lins
    caixas = []
    for i in range(lins):
        for j in range(cols):
            caixas.append((MARGEM_FOTO + j * (cw + ESPACO), alt - MARGEM_FOTO - (i + 1) * ch - i * ESPACO, cw, ch))
    return caixas


def _linhas_de_corte(larg, alt, cols, lins):
    """Tracejado claro no meio do espaço entre as fotos, para recortar."""
    if cols * lins == 1:
        return ""
    cmd = "q 0.75 G 0.5 w [3 3] 0 d "
    cw = (larg - 2 * MARGEM_FOTO - (cols - 1) * ESPACO) / cols
    ch = (alt - 2 * MARGEM_FOTO - (lins - 1) * ESPACO) / lins
    for j in range(1, cols):
        x = MARGEM_FOTO + j * cw + (j - 0.5) * ESPACO
        cmd += f"{x:.2f} {MARGEM_FOTO / 2:.2f} m {x:.2f} {alt - MARGEM_FOTO / 2:.2f} l S "
    for i in range(1, lins):
        y = alt - MARGEM_FOTO - i * ch - (i - 0.5) * ESPACO
        cmd += f"{MARGEM_FOTO / 2:.2f} {y:.2f} m {larg - MARGEM_FOTO / 2:.2f} {y:.2f} l S "
    return cmd + "Q "


def _colocar(info, nome, caixa, cortar, pode_girar=True):
    cx, cy, cw, ch = caixa
    iw, ih = info["vis_l"], info["vis_a"]
    # gira 90° só quando a foto fica bem maior assim (como o assistente de fotos do Windows)
    reto, deitado = min(cw / iw, ch / ih), min(cw / ih, ch / iw)
    girar = pode_girar and deitado > reto * 1.15
    vw, vh = (ih, iw) if girar else (iw, ih)  # como fica depois de girar
    esc = (max if cortar else min)(cw / vw, ch / vh)
    w, h = vw * esc, vh * esc
    x, y = cx + (cw - w) / 2, cy + (ch - h) / 2
    cmd = _desenho(info, nome, x, y, w, h, girar)
    return (_corte(cx, cy, cw, ch) + cmd + "Q ") if cortar else cmd


def resolucao_imagem(caminho):
    """Pontos por polegada gravados na imagem (PNG pHYs ou JPEG JFIF), ou 0 se não houver."""
    try:
        with open(caminho, "rb") as f:
            cab = f.read(256 * 1024)
    except OSError:
        return 0
    dpi = 0
    if cab[:8] == b"\x89PNG\r\n\x1a\n":
        pos = 8
        while pos + 8 <= len(cab):
            tam = int.from_bytes(cab[pos:pos + 4], "big")
            tipo = cab[pos + 4:pos + 8]
            if tipo == b"pHYs" and tam >= 9:
                x = int.from_bytes(cab[pos + 8:pos + 12], "big")
                if cab[pos + 16] == 1:  # pontos por metro
                    dpi = x * 0.0254
                break
            if tipo in (b"IDAT", b"IEND"):
                break
            pos += 12 + tam
    elif cab[:3] == b"\xff\xd8\xff":
        i = cab.find(b"JFIF\x00")
        if 0 < i < 40 and len(cab) >= i + 12:
            unidade, x = cab[i + 7], int.from_bytes(cab[i + 8:i + 10], "big")
            dpi = x if unidade == 1 else x * 2.54 if unidade == 2 else 0
    return round(dpi) if 50 <= dpi <= 2400 else 0


def montar_pdf_digitalizacao(imagens, destino, papel="auto", dpi=0):
    """Cria um PDF multipágina com as páginas escaneadas.
    Com a resolução conhecida (gravada na imagem ou a pedida ao scanner), cada página do PDF tem o
    tamanho real do que foi escaneado: imprimir o PDF dá uma cópia 1:1, como numa copiadora.
    Sem resolução, a imagem é encaixada no papel escolhido, com margem."""
    papeis = {
        "A4": A4,
        "A5": (419.53, 595.28),
        "Letter": (612.0, 792.0),
        "Legal": (612.0, 1008.0),
        "A3": (841.89, 1190.55),
    }
    tamanho = papeis.get(papel, A4)
    if not imagens:
        raise ErroImpressao("Nenhuma página foi recebida do scanner.")
    dpis = list(dpi) if isinstance(dpi, (list, tuple)) else [dpi] * len(imagens)
    pdf = _PDF()
    for indice, arquivo in enumerate(imagens):
        info = ler_imagem(arquivo)
        nome = f"Scan{indice}"
        ref = pdf.imagem(info)
        res = resolucao_imagem(arquivo) or (int(dpis[indice] or 0) if indice < len(dpis) else 0)
        larg_real = info["vis_l"] * 72 / res if res else 0
        alt_real = info["vis_a"] * 72 / res if res else 0
        # tamanho real só quando faz sentido: de 2 cm a 60 cm de lado (resolução errada dá páginas absurdas)
        if res and 57 <= larg_real <= 1701 and 57 <= alt_real <= 1701:
            pdf.pagina(larg_real, alt_real, _desenho(info, nome, 0, 0, larg_real, alt_real), {nome: ref})
            continue
        larg, alt = (tamanho[1], tamanho[0]) if info["vis_l"] > info["vis_a"] else tamanho
        caixa = (MARGEM_FOTO, MARGEM_FOTO, larg - 2 * MARGEM_FOTO, alt - 2 * MARGEM_FOTO)
        conteudo = _colocar(info, nome, caixa, False, pode_girar=False)
        pdf.pagina(larg, alt, conteudo, {nome: ref})
    return pdf.salvar(destino)


def montar_fotos(fotos, por_folha, vezes, cortar, destino, orientacao="auto"):
    """Várias fotos em A4; orientacao controla a folha quando há uma foto por página."""
    if por_folha not in GRADES_FOTOS:
        raise ErroImpressao("Escolha 1, 2, 4, 6 ou 9 fotos por folha.")
    infos = [ler_imagem(f) for f in fotos]
    pdf = _PDF()
    nomes = [f"Im{i}" for i in range(len(infos))]
    refs = {n: pdf.imagem(i) for n, i in zip(nomes, infos)}
    fila = [k for k in range(len(infos)) for _ in range(max(1, vezes))]
    if por_folha == 1:
        for k in fila:
            info = infos[k]
            paisagem = orientacao == "paisagem" or (orientacao == "auto" and info["vis_l"] > info["vis_a"])
            larg, alt = (A4[1], A4[0]) if paisagem else A4
            caixa = (MARGEM_FOTO, MARGEM_FOTO, larg - 2 * MARGEM_FOTO, alt - 2 * MARGEM_FOTO)
            pdf.pagina(larg, alt, _colocar(info, nomes[k], caixa, cortar, pode_girar=False), {nomes[k]: refs[nomes[k]]})
        return pdf.salvar(destino)
    cols, lins = GRADES_FOTOS[por_folha]
    if orientacao == "paisagem":
        cols, lins = lins, cols
        larg, alt = A4[1], A4[0]
    else:
        larg, alt = A4
    caixas = _grade(larg, alt, cols, lins)
    for ini in range(0, len(fila), por_folha):
        parte = fila[ini:ini + por_folha]
        cmd = "".join(_colocar(infos[k], nomes[k], caixas[i], cortar) for i, k in enumerate(parte))
        cmd += _linhas_de_corte(larg, alt, cols, lins)
        usados = {nomes[k]: refs[nomes[k]] for k in set(parte)}
        pdf.pagina(larg, alt, cmd, usados)
    return pdf.salvar(destino)


def plano_banner(info, folhas, cortar=False):
    """Escolhe a grade e a posição das folhas (em pé ou deitadas) que deixam a imagem maior."""
    if folhas not in GRADES_BANNER:
        raise ErroImpressao("Escolha 2, 4, 6, 9, 12 ou 16 folhas para o banner.")
    iw, ih = info["vis_l"], info["vis_a"]
    melhor = None
    for cols, lins in GRADES_BANNER[folhas]:
        for larg, alt in (A4, (A4[1], A4[0])):
            cw, ch = larg - 2 * MARGEM_FOTO, alt - 2 * MARGEM_FOTO
            esc = min(cols * cw / iw, lins * ch / ih)  # a melhor grade é a que mostra a imagem inteira maior
            if not melhor or esc > melhor["esc"] + 1e-6:
                melhor = {"esc": esc, "cols": cols, "lins": lins, "larg": larg, "alt": alt, "cw": cw, "ch": ch}
    if cortar:  # preenche todas as folhas, cortando o que sobra da imagem
        melhor["esc"] = max(melhor["cols"] * melhor["cw"] / iw, melhor["lins"] * melhor["ch"] / ih)
        melhor["largura_cm"] = round(melhor["cols"] * melhor["cw"] / 72 * 2.54)
        melhor["altura_cm"] = round(melhor["lins"] * melhor["ch"] / 72 * 2.54)
    else:
        melhor["largura_cm"] = round(iw * melhor["esc"] / 72 * 2.54)
        melhor["altura_cm"] = round(ih * melhor["esc"] / 72 * 2.54)
    return melhor


def montar_banner(foto, folhas, destino, cortar=False):
    """Uma imagem ampliada em várias folhas, com marcas de corte e a posição de cada folha."""
    info = ler_imagem(foto)
    pl = plano_banner(info, folhas, cortar)
    cols, lins, cw, ch, m = pl["cols"], pl["lins"], pl["cw"], pl["ch"], MARGEM_FOTO
    W, H = cols * cw, lins * ch
    w, h = info["vis_l"] * pl["esc"], info["vis_a"] * pl["esc"]
    ox, oy = (W - w) / 2, (H - h) / 2
    pdf = _PDF()
    pdf.com_fonte()
    ref = pdf.imagem(info)
    posicoes = []
    for i in range(lins):
        for j in range(cols):
            x0, y0 = j * cw, H - (i + 1) * ch  # canto de baixo desta folha no banner
            if ox + w <= x0 or ox >= x0 + cw or oy + h <= y0 or oy >= y0 + ch:
                continue  # folha que ficaria em branco não é impressa
            posicoes.append([i, j])
            cmd = _corte(m, m, cw, ch) + _desenho(info, "Im", ox - x0 + m, oy - y0 + m, w, h) + "Q "
            # marcas de corte nos cantos da área da imagem
            cmd += "q 0.45 G 0.5 w "
            for cx in (m, m + cw):
                for cy in (m, m + ch):
                    dx = -1 if cx == m else 1
                    dy = -1 if cy == m else 1
                    cmd += (f"{cx + dx * 2:.2f} {cy:.2f} m {cx + dx * 12:.2f} {cy:.2f} l S "
                            f"{cx:.2f} {cy + dy * 2:.2f} m {cx:.2f} {cy + dy * 12:.2f} l S ")
            cmd += "Q "
            rotulo = _texto_pdf(f"Banner {pl['largura_cm']} x {pl['altura_cm']} cm: linha {i + 1} de {lins}, "
                                f"coluna {j + 1} de {cols}. Corte nas marcas e junte as folhas.")
            cmd += f"q 0.45 g BT /F1 7 Tf {m + 14:.2f} {m / 2 - 2.5:.2f} Td ({rotulo}) Tj ET Q "
            pdf.pagina(pl["larg"], pl["alt"], cmd, {"Im": ref})
    pdf.salvar(destino)
    return {"caminho": str(destino), "cols": cols, "lins": lins, "posicoes": posicoes,
            "deitadas": pl["larg"] > pl["alt"]}


def renderizar_imagem(pdf, pagina, destino_sem_ext, dpi):
    """Desenha uma página do PDF como imagem (JPG ou PNG) na resolução pedida, para montar páginas por folha."""
    rend = achar_renderizador()
    if not rend:
        return None
    prog, cam = rend
    base = Path(destino_sem_ext)
    if prog == "pdftoppm":
        cmd = [cam, "-f", str(pagina), "-l", str(pagina), "-r", str(dpi), "-cropbox", "-jpeg", "-jpegopt", "quality=88",
               "-singlefile", str(pdf), str(base)]
        saida = base.with_suffix(".jpg")
    elif prog == "mutool":
        saida = base.with_suffix(".png")
        cmd = [cam, "draw", "-q", "-r", str(dpi), "-c", "rgb", "-o", str(saida), str(pdf), str(pagina)]
    else:
        saida = base.with_suffix(".jpg")
        cmd = [cam, "-q", "-dSAFER", "-dBATCH", "-dNOPAUSE", "-dUseCropBox", "-sDEVICE=jpeg", "-dJPEGQ=88", f"-r{dpi}",
               "-dTextAlphaBits=4", "-dGraphicsAlphaBits=4", f"-dFirstPage={pagina}", f"-dLastPage={pagina}",
               f"-sOutputFile={saida}", str(pdf)]
    try:
        subprocess.run(cmd, capture_output=True, timeout=90, **_sem_janela())
    except (subprocess.TimeoutExpired, OSError):
        return None
    return str(saida) if saida.is_file() and saida.stat().st_size > 0 else None


def montar_paginas(pdf, paginas, por_folha, destino, pasta_tmp):
    """Junta 2 ou 4 páginas do PDF em cada folha (como "páginas por folha" do Windows)."""
    if por_folha not in (2, 4):
        raise ErroImpressao("Escolha 2 ou 4 páginas por folha.")
    if not achar_renderizador():
        raise ErroImpressao("Para juntar páginas, instale no computador do sistema o Poppler ou o Ghostscript "
                            "(veja o LEIA-ME).")
    dpi = 200 if por_folha == 2 else 150
    infos = []
    for k, p in enumerate(paginas):
        arq = renderizar_imagem(pdf, p, Path(pasta_tmp) / f"pag{k:04d}", dpi)
        if not arq:
            raise ErroImpressao(f"Não deu para preparar a página {p}.")
        infos.append(ler_imagem(arq))
    deitadas = infos[0]["vis_l"] > infos[0]["vis_a"]
    if por_folha == 2:
        larg, alt = A4 if deitadas else (A4[1], A4[0])
        cols, lins = (1, 2) if deitadas else (2, 1)
    else:
        larg, alt = (A4[1], A4[0]) if deitadas else A4
        cols, lins = 2, 2
    caixas = _grade(larg, alt, cols, lins)
    folha = _PDF()
    for ini in range(0, len(infos), por_folha):
        cmd, usados = "", {}
        for i, info in enumerate(infos[ini:ini + por_folha]):
            nome = f"P{ini + i}"
            usados[nome] = folha.imagem(info)
            cx, cy, cw, ch = caixas[i]
            esc = min(cw / info["vis_l"], ch / info["vis_a"])
            w, h = info["vis_l"] * esc, info["vis_a"] * esc
            x, y = cx + (cw - w) / 2, cy + (ch - h) / 2
            cmd += _desenho(info, nome, x, y, w, h)
            cmd += f"q 0.7 G 0.4 w {x:.2f} {y:.2f} {w:.2f} {h:.2f} re S Q "
        folha.pagina(larg, alt, cmd, usados)
    return folha.salvar(destino)


# ---------------------------------------------------------------- prévia das páginas

_REND = {"t": 0, "v": None}


def achar_renderizador():
    """Programa que desenha uma página do PDF como imagem, para a prévia.
    Procura na pasta "ferramentas" e no sistema: pdftoppm (Poppler), mutool (MuPDF) ou Ghostscript."""
    import time
    if time.time() - _REND["t"] < 60:
        return _REND["v"]
    ferr = PASTA_APP / "ferramentas"
    candidatos = []
    for prog, nomes in (("pdftoppm", ["pdftoppm.exe", "pdftoppm"]), ("mutool", ["mutool.exe", "mutool"]),
                        ("gs", ["gswin64c.exe", "gswin32c.exe", "gs"])):
        for nome in nomes:
            for c in (ferr / nome, ferr / "bin" / nome):
                if c.is_file():
                    candidatos.append((prog, str(c)))
            achado = shutil.which(nome)
            if achado:
                candidatos.append((prog, achado))
    if WINDOWS:
        for var in ("ProgramFiles", "ProgramFiles(x86)"):
            base = os.environ.get(var)
            if base and os.path.isdir(os.path.join(base, "gs")):
                for v in sorted(os.listdir(os.path.join(base, "gs")), reverse=True):
                    for nome in ("gswin64c.exe", "gswin32c.exe"):
                        c = os.path.join(base, "gs", v, "bin", nome)
                        if os.path.isfile(c):
                            candidatos.append(("gs", c))
    _REND["v"] = candidatos[0] if candidatos else None
    _REND["t"] = time.time()
    return _REND["v"]


def renderizar_pagina(pdf, pagina, destino, lado=420):
    """Desenha a página (começando em 1) como PNG cabendo num quadrado de `lado` pixels.
    Devolve True se conseguiu; False se não houver programa para isso."""
    rend = achar_renderizador()
    if not rend:
        return False
    prog, cam = rend
    destino = Path(destino)
    if prog == "pdftoppm":
        cmd = [cam, "-f", str(pagina), "-l", str(pagina), "-cropbox", "-png", "-scale-to", str(lado), "-singlefile",
               str(pdf), str(destino.with_suffix(""))]
    elif prog == "mutool":
        cmd = [cam, "draw", "-q", "-o", str(destino), "-w", str(lado), "-h", str(lado), str(pdf), str(pagina)]
    else:
        cmd = [cam, "-q", "-dSAFER", "-dBATCH", "-dNOPAUSE", "-dUseCropBox", "-sDEVICE=png16m", "-r50",
               "-dTextAlphaBits=4", "-dGraphicsAlphaBits=4", f"-dFirstPage={pagina}", f"-dLastPage={pagina}",
               f"-sOutputFile={destino}", str(pdf)]
    try:
        subprocess.run(cmd, capture_output=True, timeout=40, **_sem_janela())
    except (subprocess.TimeoutExpired, OSError):
        return False
    return destino.is_file() and destino.stat().st_size > 0


def expandir_intervalo(intervalo, total):
    """'1-3,5' -> [1, 2, 3, 5]. Vazio = todas."""
    if not intervalo:
        return list(range(1, total + 1))
    saida = []
    for parte in intervalo.split(","):
        a, _, b = parte.partition("-")
        saida.extend(range(int(a), int(b or a) + 1))
    return saida


def juntar_intervalo(paginas, total):
    """[1, 2, 3, 5] -> '1-3,5'. Todas as páginas do arquivo -> ''."""
    paginas = sorted(set(paginas))
    if paginas == list(range(1, total + 1)):
        return ""
    faixas, ini, ant = [], paginas[0], paginas[0]
    for p in paginas[1:]:
        if p == ant + 1:
            ant = p
            continue
        faixas.append((ini, ant))
        ini = ant = p
    faixas.append((ini, ant))
    return ",".join(f"{a}-{b}" if a != b else str(a) for a, b in faixas)


# ---------------------------------------------------------------- páginas

def tipo_arquivo(nome):
    ext = Path(nome).suffix.lower()
    if ext in EXT_PDF:
        return "pdf"
    if ext in EXT_IMAGEM:
        return "imagem"
    if ext in EXT_OFFICE:
        return "office"
    return None


def _dict_envolvente(t, pos):
    """Devolve o trecho do dicionário PDF << ... >> que contém a posição pos."""
    i, prof = pos, 0
    inicio = None
    while i > 0:
        par = t[i - 1:i + 1]
        if par == b">>":
            prof += 1
            i -= 2
            continue
        if par == b"<<":
            if prof == 0:
                inicio = i - 1
                break
            prof -= 1
            i -= 2
            continue
        i -= 1
    if inicio is None:
        return b""
    j, prof = inicio + 2, 1
    while j < len(t) - 1 and prof > 0:
        par = t[j:j + 2]
        if par == b"<<":
            prof += 1
            j += 2
        elif par == b">>":
            prof -= 1
            j += 2
        else:
            j += 1
    return t[inicio:j]


def _contar_pdf_manual(dados):
    textos = [dados]
    for m in re.finditer(rb"stream\r?\n", dados):
        ini = m.end()
        fim = dados.find(b"endstream", ini)
        if fim < 0:
            continue
        bloco = dados[ini:fim]
        try:
            textos.append(zlib.decompressobj().decompress(bloco))
        except Exception:
            pass
    maior = 0
    folhas = 0
    for t in textos:
        for m in re.finditer(rb"/Type\s*/Pages\b", t):
            d = _dict_envolvente(t, m.start())
            c = re.search(rb"/Count\s+(\d+)", d)
            if c:
                maior = max(maior, int(c.group(1)))
        folhas += len(re.findall(rb"/Type\s*/Page(?![a-zA-Z])", t))
    return maior or folhas


def contar_paginas_pdf(caminho):
    with open(caminho, "rb") as f:
        dados = f.read()
    if not dados.startswith(b"%PDF") and b"%PDF" not in dados[:1024]:
        raise ErroImpressao("O arquivo não parece ser um PDF válido.")
    if not os.environ.get("CI_SEM_PYPDF"):
        try:  # se o pypdf estiver instalado, é mais preciso
            import pypdf  # noqa
            leitor = pypdf.PdfReader(io.BytesIO(dados))
            if leitor.is_encrypted:
                try:
                    leitor.decrypt("")
                except Exception:
                    pass
            return len(leitor.pages)
        except ImportError:
            pass
        except Exception:
            pass
    n = _contar_pdf_manual(dados)
    if n <= 0:
        raise ErroImpressao("Não consegui contar as páginas deste PDF. Tente salvá-lo de novo como PDF.")
    return n


def converter_para_pdf(caminho, soffice):
    """Converte Word/LibreOffice/PowerPoint em PDF. Devolve o caminho do PDF."""
    if not soffice:
        raise ErroImpressao(
            "Para imprimir arquivos do Word, Excel ou PowerPoint é preciso o LibreOffice no computador do sistema. "
            "Por enquanto, salve o arquivo como PDF e envie de novo.")
    pasta = Path(tempfile.mkdtemp(prefix="conv_", dir=str(Path(caminho).parent)))
    perfil = pasta / "perfil"
    cmd = [soffice, f"-env:UserInstallation={perfil.as_uri()}", "--headless", "--norestore",
           "--convert-to", "pdf", "--outdir", str(pasta), str(caminho)]
    try:
        subprocess.run(cmd, capture_output=True, timeout=120, **_sem_janela())
    except subprocess.TimeoutExpired:
        raise ErroImpressao("A conversão do arquivo demorou demais. Tente enviar em PDF.")
    pdf = pasta / (Path(caminho).stem + ".pdf")
    if not pdf.is_file():
        raise ErroImpressao("Não consegui converter o arquivo em PDF. Salve como PDF e envie de novo.")
    destino = Path(caminho).with_suffix(".pdf")
    shutil.move(str(pdf), str(destino))
    shutil.rmtree(pasta, ignore_errors=True)
    if Path(caminho) != destino:
        try:
            os.remove(caminho)  # o original não serve mais: a impressora e a prévia usam o PDF
        except OSError:
            pass
    return str(destino)


def interpretar_intervalo(texto, total):
    """'1-3, 5' -> ('1-3,5', 4). Texto vazio = todas as páginas."""
    texto = (texto or "").strip().replace(" ", "").replace(";", ",")
    if not texto:
        return "", total
    paginas = set()
    for parte in texto.split(","):
        if not parte:
            continue
        m = re.fullmatch(r"(\d+)(?:-(\d+))?", parte)
        if not m:
            raise ErroImpressao(f"Não entendi as páginas \"{parte}\". Use algo como 1-3,5.")
        a = int(m.group(1))
        b = int(m.group(2) or a)
        if a > b:
            a, b = b, a
        if a < 1 or b > total:
            raise ErroImpressao(f"O arquivo tem {total} página(s). Escolha páginas entre 1 e {total}.")
        paginas.update(range(a, b + 1))
    if not paginas:
        return "", total
    if len(paginas) == total:
        return "", total
    ordenadas = sorted(paginas)
    faixas, ini, ant = [], ordenadas[0], ordenadas[0]
    for p in ordenadas[1:]:
        if p == ant + 1:
            ant = p
            continue
        faixas.append((ini, ant))
        ini = ant = p
    faixas.append((ini, ant))
    norm = ",".join(f"{a}-{b}" if a != b else str(a) for a, b in faixas)
    return norm, len(paginas)


# ---------------------------------------------------------------- tamanho na folha (escala)

ESCALA_MIN, ESCALA_MAX = 25, 200


def ler_escala(valor):
    """Tamanho na folha pedido pela pessoa.
    "" e "caber": o ajuste automático do sistema de impressão (clientes antigos e jobs sem escolha).
    "ajustar": o maior tamanho, até 100%, em que tudo o que tem tinta cabe na área que a impressora alcança.
    "25" a "200": porcentagem do tamanho original ("original", de clientes antigos, é 100)."""
    t = str(valor if valor is not None else "").strip().lower().rstrip("%").strip()
    if t in ("", "caber"):
        return ""
    if t == "ajustar":
        return "ajustar"
    if t == "original":
        return "100"
    try:
        n = int(round(float(t.replace(",", "."))))
    except ValueError:
        raise ErroImpressao("Escolha o tamanho na folha.")
    if not ESCALA_MIN <= n <= ESCALA_MAX:
        raise ErroImpressao(f"O tamanho na folha vai de {ESCALA_MIN}% a {ESCALA_MAX}% do original.")
    return str(n)


def plano_da_folha(caminho, escala, area, paginas=None):
    """Plano (imposicao.planejar) de cada página do PDF neste tamanho e nesta impressora.
    paginas: as páginas desejadas (1, 2...) ou None para todas. Devolve (plano, tamanhos vistos em pontos)."""
    import escala as esc
    import imposicao
    modo, pct = ("ajustar", 100) if escala == "ajustar" else ("pct", int(escala))
    rend = achar_renderizador()
    try:
        med = esc.medidas(Path(caminho).read_bytes())
    except esc.NaoDa:
        med = _medidas_poppler(caminho)
        if med is None:
            raise
    tintas = imposicao.tinta(caminho, len(med), rend)
    if paginas:
        med = [med[p - 1] for p in paginas]
        tintas = [tintas[p - 1] for p in paginas] if tintas else None
    return imposicao.planejar(med, tintas, area, modo, pct), med


def _medidas_poppler(caminho):
    """Tamanho de cada página vista pelo pdfinfo (lê PDF protegido só para abrir). None sem Poppler."""
    rend = achar_renderizador()
    info = shutil.which("pdfinfo")
    if not info and rend and rend[0] == "pdftoppm":  # o Poppler da pasta ferramentas
        vizinho = Path(rend[1]).with_name("pdfinfo" + (".exe" if WINDOWS else ""))
        info = str(vizinho) if vizinho.is_file() else None
    if not info:
        return None
    total = contar_paginas_pdf(caminho)
    try:
        r = subprocess.run([info, "-f", "1", "-l", str(total), str(caminho)], capture_output=True, text=True,
                           errors="replace", timeout=60, **_sem_janela())
    except (subprocess.TimeoutExpired, OSError):
        return None
    tam = {int(m.group(1)): (float(m.group(2)), float(m.group(3)))
           for m in re.finditer(r"Page\s+(\d+)\s+size:\s*([\d.]+)\s*x\s*([\d.]+)", r.stdout)}
    giro = {int(m.group(1)): int(m.group(2)) % 360 for m in re.finditer(r"Page\s+(\d+)\s+rot:\s*(\d+)", r.stdout)}
    if len(tam) != total:
        return None
    return [(tam[p][1], tam[p][0]) if giro.get(p) in (90, 270) else tam[p] for p in range(1, total + 1)]


def pdf_na_folha(caminho, escala, intervalo, area):
    """Cópia do PDF com cada página do tamanho do papel da impressora e o conteúdo no tamanho pedido,
    no lugar certo da folha (imposicao.py). Devolve (caminho da cópia, intervalo a imprimir nela).
    Quem chama apaga a cópia depois. Primeiro sem perder nitidez (escala.impor). PDF protegido por senha
    ou danificado: desenha as páginas escolhidas como imagem em 300 dpi, se houver Poppler, MuPDF ou
    Ghostscript."""
    import escala as esc
    import imposicao
    origem = Path(caminho)
    destino = origem.with_name(f"{origem.stem}-folha{escala}-{os.getpid()}-{id(origem)}.pdf")
    papel_pt = tuple(v * imposicao.MM for v in area["papel_mm"])
    try:
        plano, _ = plano_da_folha(caminho, escala, area)
        destino.write_bytes(esc.impor(origem.read_bytes(), papel_pt, plano))
        return str(destino), intervalo
    except esc.NaoDa:
        pass
    if not achar_renderizador():
        raise ErroImpressao("Não deu para preparar o tamanho na folha: este PDF é protegido ou está danificado, "
                            "e falta o Poppler ou o Ghostscript no computador do sistema.")
    total = contar_paginas_pdf(caminho)
    paginas = expandir_intervalo(intervalo, total) if intervalo else list(range(1, total + 1))
    if len(paginas) > 200:
        raise ErroImpressao("Este PDF é protegido: para imprimir, escolha até 200 páginas de cada vez.")
    try:
        plano, _ = plano_da_folha(caminho, escala, area, paginas)
    except esc.NaoDa:
        plano = None
    dpi = 300 if len(paginas) <= 30 else 200
    tmp = Path(tempfile.mkdtemp(prefix="folha_", dir=str(origem.parent)))
    try:
        folha = _PDF()
        W, H = papel_pt
        for k, p in enumerate(paginas):
            arq = renderizar_imagem(caminho, p, tmp / f"p{k:04d}", dpi)
            if not arq:
                raise ErroImpressao(f"Não deu para preparar a página {p}.")
            info = ler_imagem(arq)
            w, h = info["vis_l"] * 72 / dpi, info["vis_a"] * 72 / dpi
            col = plano[k] if plano else imposicao.planejar(
                [(w, h)], None, area, "ajustar" if escala == "ajustar" else "pct",
                100 if escala == "ajustar" else int(escala))[0]
            m = esc._mult((w, 0, 0, h, 0, 0), esc.matriz_na_folha((w, h), col))
            nome = f"P{k}"
            conteudo = (f"q 0 0 {W:.3f} {H:.3f} re W n q {m[0]:.5f} {m[1]:.5f} {m[2]:.5f} {m[3]:.5f} "
                        f"{m[4]:.3f} {m[5]:.3f} cm /{nome} Do Q Q ")
            folha.pagina(W, H, conteudo, {nome: folha.imagem(info)})
            os.remove(arq)
        folha.salvar(str(destino))
    except Exception:
        try:
            destino.unlink()
        except OSError:
            pass
        raise
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return str(destino), ""


# ---------------------------------------------------------------- impressão

def imprimir(caminho, impressora, copias=1, intervalo="", frente_verso=False,
             imagem=False, sumatra_cfg="", segurar=False, escala="", area=None):
    """Envia o arquivo para a impressora do sistema. Lança ErroImpressao se falhar.
    segurar=True (só Linux) deixa o trabalho retido na fila do CUPS até ser solto (acompanhar.liberar).
    escala: "" deixa o sistema de impressão ajustar (como antes da 2.3); "ajustar" ou uma porcentagem
    montam cada página no papel da impressora, no tamanho e no lugar exatos (imposicao.py), e o
    sistema de impressão não mexe em mais nada. area: papel e margens (imposicao.area_da_impressora).
    Devolve o que o programa de impressão respondeu (no Linux, traz o número do trabalho)."""
    if not impressora:
        raise ErroImpressao("Esta impressora ainda não foi ligada a uma impressora do computador.")
    copias = max(1, int(copias))
    escala = "" if imagem else ler_escala(escala)
    copia = None
    sem_encolher = bool(escala)
    media = ""
    if escala:
        import imposicao
        area = area or imposicao.area_da_impressora(impressora)
        media = area.get("media", "")
        try:
            copia, intervalo = pdf_na_folha(caminho, escala, intervalo, area)
        except Exception as e:
            if not isinstance(e, ErroImpressao):
                print(f"[impressao] não deu para montar {os.path.basename(str(caminho))} na folha "
                      f"({type(e).__name__}: {e})", file=sys.stderr, flush=True)
            if escala != "ajustar":
                if isinstance(e, ErroImpressao):
                    raise
                raise ErroImpressao(f"Não deu para preparar este PDF em {escala}%. Escolha Ajustar à folha "
                                    "e imprima de novo.") from e
            # Ajustar à folha é o padrão: se este PDF não deixa montar a folha (protegido por senha e sem
            # Poppler/Ghostscript para desenhá-lo, ou com alguma estrutura que o app não conhece), imprime
            # com o ajuste automático do sistema de impressão, em vez de recusar a impressão.
            copia, sem_encolher = None, False
    try:
        return _mandar(copia or caminho, impressora, copias, intervalo, frente_verso, imagem, sumatra_cfg, segurar,
                       sem_encolher, media)
    finally:
        if copia:  # o lp e o SumatraPDF já leram o arquivo quando voltam
            try:
                os.remove(copia)
            except OSError:
                pass


def _mandar(caminho, impressora, copias, intervalo, frente_verso, imagem, sumatra_cfg, segurar, sem_encolher, media=""):
    if WINDOWS:
        sumatra = achar_sumatra(sumatra_cfg)
        if not sumatra:
            raise ErroImpressao(
                "O SumatraPDF não foi encontrado no computador do sistema. "
                "Peça ao gestor para instalá-lo (veja o LEIA-ME).")
        ajustes = []
        if intervalo:
            ajustes.append(intervalo)
        ajustes.append(f"{copias}x")
        ajustes.append("duplexlong" if frente_verso else "simplex")
        ajustes.append("fit" if imagem else "noscale" if sem_encolher else "shrink")
        papel_sumatra = {"iso_a4_210x297mm": "A4", "na_letter_8.5x11in": "letter", "na_legal_8.5x14in": "legal",
                         "iso_a5_148x210mm": "A5", "iso_a3_297x420mm": "A3"}.get(media)
        if papel_sumatra:
            ajustes.append(f"paper={papel_sumatra}")
        cmd = [sumatra, "-print-to", impressora, "-print-settings", ",".join(ajustes),
               "-silent", caminho]
    else:
        if not shutil.which("lp"):
            raise ErroImpressao("O comando 'lp' (CUPS) não está instalado neste computador.")
        cmd = ["lp", "-d", impressora, "-n", str(copias)]
        if intervalo:
            cmd += ["-o", f"page-ranges={intervalo}"]
        cmd += ["-o", "sides=two-sided-long-edge" if frente_verso else "sides=one-sided"]
        if imagem:
            cmd += ["-o", "fit-to-page"]
        elif sem_encolher:  # a folha já vem montada: o CUPS não encolhe, não amplia, não gira
            cmd += ["-o", "print-scaling=none", "-o", "fit-to-page=false"]
        if media and not imagem:
            cmd += ["-o", f"media={media}"]
        if segurar:
            cmd += ["-H", "hold"]
        cmd.append(caminho)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=180,
                           **_sem_janela())
    except subprocess.TimeoutExpired:
        raise ErroImpressao("A impressora demorou demais para responder.")
    except OSError as e:
        raise ErroImpressao(f"Não consegui chamar o programa de impressão: {e}")
    if r.returncode != 0:
        detalhe = (r.stderr or r.stdout or "").strip()[:300]
        raise ErroImpressao(f"A impressora recusou o trabalho. {detalhe}".strip())
    return (r.stdout or "").strip()
