'use strict';
/* Folha a Folha — telas (sem bibliotecas externas, funciona offline na rede local) */

const $app = document.getElementById('app');
const E = {
  inicio: null, eu: null, colegas: null,
  imp: null, ultimoResultado: null,
  digitalizar: null,
  chat: { chave: null, assinatura: '' },
  direcao: { mes: null, dados: null, sistema: null },
  historicoMes: null,
  entrar: { usuario: null, pin: '' },
  bloqueado: false, acao: false, ultimaAcao: Date.now(),
};
let timerEu = null, timerChat = null;

// Uso de verdade (toque, tecla, rolagem) mantém a sessão aberta; a atualização automática da tela, não.
['pointerdown', 'keydown', 'touchstart', 'wheel', 'scroll'].forEach((ev) => document.addEventListener(ev, () => {
  if (E.bloqueado) return;
  E.acao = true; E.ultimaAcao = Date.now();
}, { capture: true, passive: true }));
setInterval(() => {
  const min = E.eu && E.eu.bloqueio_minutos;
  if (!min || E.bloqueado || !E.eu) return;
  if (E.digitalizar && E.digitalizar.digitalizando) { E.ultimaAcao = Date.now(); return; }  // o scanner está trabalhando
  if (Date.now() - E.ultimaAcao > min * 60000) { api('/api/bloquear', {}).catch(() => {}); mostrarBloqueio(); }
}, 10000);

/* ================================================================ utilidades */

function h(tag, a, ...filhos) {
  const el = document.createElement(tag);
  let valor;
  if (a) for (const [k, v] of Object.entries(a)) {
    if (v == null || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') {
      for (const [p, s] of Object.entries(v)) p.startsWith('--') ? el.style.setProperty(p, s) : (el.style[p] = s);
    }
    else if (k === 'value') valor = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const f of filhos.flat(Infinity)) {
    if (f == null || f === false) continue;
    el.append(f instanceof Node ? f : String(f));
  }
  if (valor !== undefined) el.value = valor;
  return el;
}

// Palavras do tipo de lugar (escola, empresa ou organização), vindas do servidor
const LOCAL_PADRAO = { tipo: 'outro', nome: 'Organização', o: 'a organização', do: 'da organização', ao: 'à organização', no: 'na organização', rotulo: 'Nome da organização', exemplo: 'Ex.: Associação Bem Viver', padrao: 'Nossa organização', exemplo_desc: 'Ex.: lista de presença da assembleia', rotulo_funcao: 'Sua função ou setor (opcional)', exemplo_funcao: 'Ex.: Secretaria, período da manhã', exemplo_aumento: 'Ex.: material da assembleia de sábado', exemplo_alem: 'Ex.: documento urgente para a reunião de hoje' };
function L(k) { const l = (E.eu && E.eu.local) || (E.inicio && E.inicio.local) || LOCAL_PADRAO; return l[k] != null ? l[k] : LOCAL_PADRAO[k]; }
function Lc(k) { const t = L(k); return t[0].toUpperCase() + t.slice(1); }

const SVGNS = 'http://www.w3.org/2000/svg';
const ICONES = {
  inicio: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v10h13V10"/><path d="M10 20v-5h4v5"/>',
  imprimir: '<path d="M6.5 9V3.5h11V9"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v6.5H7z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7h.01"/>',
  digitalizar: '<path d="M4 4h16v16H4z"/><path d="M7 8h10M7 12h10M7 16h6"/><path d="M2 7V3h4M18 3h4v4M22 17v4h-4M6 21H2v-4"/>',
  conversas: '<path d="M4 5.5h16v10.5H10l-5 4v-4H4z"/>',
  historico: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  direcao: '<path d="M4 7h9M17 7h3M4 12h3M11 12h9M4 17h11M19 17h1"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="17" r="2"/>',
  voltar: '<path d="M15 5l-7 7 7 7"/>',
  enviar: '<path d="M4.5 12 20 4.5 15 20l-3-6.5z"/><path d="M12 13.5 20 4.5"/>',
  arquivo: '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/>',
};
function icone(nome) {
  const s = document.createElementNS(SVGNS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor');
  s.setAttribute('stroke-width', '2'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true'); s.innerHTML = ICONES[nome] || '';
  return s;
}

class ErroApi extends Error { constructor(msg, status, codigo, dados) { super(msg); this.status = status; this.codigo = codigo; this.dados = dados || {}; } }

async function api(caminho, corpo, extra = {}) {
  const opcoes = { method: corpo === undefined ? 'GET' : 'POST', headers: { 'X-Pedido': 'ci' }, credentials: 'same-origin' };
  if (E.acao) { opcoes.headers['X-Atividade'] = '1'; E.acao = false; }
  if (corpo instanceof Blob) { opcoes.body = corpo; Object.assign(opcoes.headers, extra.headers || {}); }
  else if (corpo !== undefined) { opcoes.body = JSON.stringify(corpo); opcoes.headers['Content-Type'] = 'application/json'; }
  let r;
  try { r = await fetch(caminho, opcoes); }
  catch (e) { throw new ErroApi('Sem conexão com o computador do sistema. Confira se o aparelho está na mesma rede (Wi-Fi) que ele.', 0); }
  let dados = {};
  try { dados = await r.json(); } catch (e) { /* vazio */ }
  if (!r.ok) {
    if (r.status === 401 && dados.codigo === 'sessao') { sairLocal(); }
    if (r.status === 401 && dados.codigo === 'bloqueado') { mostrarBloqueio(); }
    if (r.status === 403 && dados.codigo === 'trocar_senha' && !document.querySelector('.entrada.criar-senha')) { iniciar(); }
    throw new ErroApi(dados.erro || 'Algo deu errado.', r.status, dados.codigo, dados);
  }
  return dados;
}

/* Sem conexão: a tela mostra a hora dos últimos dados, em vez de parecer atual */
function mostrarSemRede(sem) {
  const el = document.getElementById('sem-rede');
  if (!el) return;
  if (!sem) { E.ultimoOk = new Date(); el.hidden = true; return; }
  const hora = (E.ultimoOk || new Date()).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  el.textContent = `Sem conexão com o computador do sistema. Os dados na tela são das ${hora}.`;
  el.hidden = false;
}

let timerAviso;
function avisar(msg, erro = false) {
  const a = document.getElementById('aviso');
  a.textContent = msg; a.className = 'visivel' + (erro ? ' erro' : '');
  clearTimeout(timerAviso);
  timerAviso = setTimeout(() => { a.className = ''; }, erro ? 5000 : 3000);
}

const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const MESES_CURTOS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
function nomeMes(m) { const [a, n] = m.split('-').map(Number); return `${MESES[n - 1]} de ${a}`; }
function mesTitulo(m) { const t = nomeMes(m); return t[0].toUpperCase() + t.slice(1); }
function data(ts) { return new Date(ts.replace(' ', 'T')); }
function hora(ts) { const d = data(ts); return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
function diaCurto(ts) { const d = data(ts); return `${d.getDate()} de ${MESES_CURTOS[d.getMonth()]}`; }
function rotuloDia(ts) {
  const d = data(ts), hoje = new Date(); const ontem = new Date(); ontem.setDate(hoje.getDate() - 1);
  if (d.toDateString() === hoje.toDateString()) return 'Hoje';
  if (d.toDateString() === ontem.toDateString()) return 'Ontem';
  return diaCurto(ts);
}
function n(x) { return Number(x || 0).toLocaleString('pt-BR'); }
function pag(x) { return `${n(x)} ${Math.abs(x) === 1 ? 'página' : 'páginas'}`; }
function reais(v) { return Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
function precoPagina(v) { return Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2, maximumFractionDigits: 4 }); }
function mesCurto(m) { const [a, k] = m.split('-').map(Number); return `${MESES_CURTOS[k - 1]}/${a}`; }
function iniciais(nome) { const p = String(nome).trim().split(/\s+/); return ((p[0] || '')[0] + ((p[1] || '')[0] || '')).toUpperCase(); }
function curto(nome) { return String(nome).replace(/^impressora\s+(da|do|de)\s+/i, ''); }
function ultimosMeses(mesAtual, qtd) {
  const [a, m] = mesAtual.split('-').map(Number); const lista = [];
  for (let i = 0; i < qtd; i++) { const d = new Date(a, m - 1 - i, 1); lista.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`); }
  return lista;
}

function contarIntervalo(txt, total) {
  txt = (txt || '').replace(/\s|;/g, (c) => (c === ';' ? ',' : ''));
  if (!txt) return { ok: true, qtd: total };
  const pags = new Set();
  for (const parte of txt.split(',')) {
    if (!parte) continue;
    const m = parte.match(/^(\d+)(?:-(\d+))?$/);
    if (!m) return { ok: false, msg: `Não entendi "${parte}". Use algo como 1-3, 5.` };
    let a = +m[1], b = +(m[2] || m[1]); if (a > b) [a, b] = [b, a];
    if (a < 1 || b > total) return { ok: false, msg: `O arquivo tem ${pag(total)}. Use números de 1 a ${total}.` };
    for (let i = a; i <= b; i++) pags.add(i);
  }
  return pags.size ? { ok: true, qtd: pags.size } : { ok: true, qtd: total };
}

/* ================================================================ folhas (janelas de baixo) */

function folha(construir, aoFechar) {
  const veu = h('div', { class: 'veu' });
  const f = h('div', { class: 'folha', role: 'dialog', 'aria-modal': 'true' });
  const anexar = f.append.bind(f);
  f.append = (...itens) => anexar(...itens.flat(Infinity).filter((x) => x != null && x !== false));
  veu.append(f);
  const tecla = (e) => { if (e.key === 'Escape') fechar(); };
  function fechar() { veu.remove(); document.removeEventListener('keydown', tecla); if (aoFechar) { const f_ = aoFechar; aoFechar = null; f_(); } }
  veu.addEventListener('click', (e) => { if (e.target === veu) fechar(); });
  document.addEventListener('keydown', tecla);
  construir(f, fechar);
  document.body.append(veu);
  const alvo = f.querySelector('[autofocus]'); if (alvo) focarDepois(alvo, 60);
  return fechar;
}

function confirmar(titulo, texto, botao, perigo = false) {
  return new Promise((ok) => {
    folha((f, fechar) => {
      f.append(
        h('h2', null, titulo),
        texto ? h('p', { class: 'mudo', style: { marginTop: '8px' } }, texto) : null,
        h('div', { class: 'rodape' },
          h('button', { class: 'btn claro', onclick: () => { fechar(); ok(false); } }, 'Voltar'),
          h('button', { class: 'btn' + (perigo ? ' perigo' : ''), onclick: () => { fechar(); ok(true); } }, botao)));
    });
  });
}

function botaoCarregando(btn, texto) {
  btn.disabled = true; btn.dataset.texto = btn.textContent;
  btn.replaceChildren(h('span', { class: 'carregando' }), texto || '');
}
function botaoPronto(btn) { btn.disabled = false; btn.textContent = btn.dataset.texto || 'OK'; }

/* ================================================================ moldura */

function moldura(titulo, sub, conteudo, opcoes = {}) {
  const eu = E.eu;
  const topo = h('header', { class: 'topo' },
    opcoes.voltar ? h('button', { class: 'voltar', 'aria-label': 'Voltar', onclick: () => { location.hash = opcoes.voltar; } }, icone('voltar')) : null,
    h('div', { class: 'titulo' }, h('h1', null, titulo), sub ? h('div', { class: 'sub' }, sub) : null),
    opcoes.semEu ? null : h('button', { class: 'eu-botao', 'aria-label': `Minha conta: ${eu.usuario.nome}`, onclick: folhaPerfil }, iniciais(eu.usuario.nome)));
  const tela = h('main', { class: 'tela' + (opcoes.compositor ? ' com-compositor' : '') }, topo, conteudo);
  const partes = [tela];
  if (opcoes.compositor) partes.push(opcoes.compositor); else partes.push(abas());
  $app.replaceChildren(...partes);
}

function abas() {
  const atual = (location.hash.slice(1).split('/')[0]) || 'inicio';
  const aba = (id, nome, ic, extra) => h('a', { href: '#' + id, 'aria-current': (atual === id || (id === 'conversas' && atual === 'conversa') || (id === 'gestao' && atual === 'direcao')) ? 'page' : null }, icone(ic), nome, extra);
  const nl = E.eu.nao_lidas;
  return h('div', { class: 'abas' }, h('nav', { 'aria-label': 'Menu' },
    aba('inicio', 'Início', 'inicio'),
    aba('imprimir', 'Imprimir', 'imprimir', h('span', { id: 'bolinha-fila', class: 'bolinha fila' + (E.eu.retidas ? '' : ' oculto') }, E.eu.retidas || '')),
    aba('digitalizar', 'Escanear', 'digitalizar'),
    aba('sobre', 'Sobre', 'info'),
    aba('conversas', 'Conversas', 'conversas', nl ? h('span', { class: 'bolinha', id: 'bolinha' }, nl > 99 ? '99+' : nl) : h('span', { id: 'bolinha', class: 'bolinha oculto' })),
    aba('historico', 'Histórico', 'historico'),
    E.eu.usuario.gestor ? aba('gestao', 'Gestão', 'direcao') : null));
}

function atualizarBolinha() {
  const b = document.getElementById('bolinha'); if (!b) return;
  const nl = E.eu.nao_lidas; b.textContent = nl > 99 ? '99+' : nl; b.classList.toggle('oculto', !nl);
  const f = document.getElementById('bolinha-fila');
  if (f) { f.textContent = E.eu.retidas || ''; f.classList.toggle('oculto', !E.eu.retidas); }
}

/* ================================================================ roteamento */

window.addEventListener('hashchange', render);
document.addEventListener('visibilitychange', () => { if (!document.hidden && E.eu) { atualizarEu(true); receberDoCelular(); } });

async function iniciar() {
  try { E.inicio = await api('/api/inicio'); }
  catch (e) { $app.replaceChildren(h('div', { class: 'entrada' }, h('div', { class: 'faixa erro' }, e.message))); return; }
  if (!E.inicio.configurado) return telaConfigurar();
  if (!E.inicio.logado) return telaEntrar();
  if (E.inicio.bloqueado) { E.bloqueadoNome = E.inicio.bloqueado_nome; return mostrarBloqueio(); }
  if (E.inicio.trocar_senha) return telaCriarSenha(E.inicio.login);
  try { E.eu = await api('/api/eu'); } catch (e) { if (E.bloqueado) return; return telaEntrar(); }
  E.ultimaAcao = Date.now();
  comecarAtualizacoes();
  irParaLiberacao();
  render();
  verificarCiencia();
}

/* Quem imprimiu na Folha a Folha e abre (ou volta para) o app cai direto na tela de liberar. */
function irParaLiberacao() {
  const rota = location.hash.slice(1).split('/')[0] || 'inicio';
  if (E.eu && E.eu.retidas && rota === 'inicio' && !document.querySelector('.veu')) {
    history.replaceState(null, '', '#imprimir');
    return true;
  }
  return false;
}

function verificarCiencia() {
  if (E.eu && !E.eu.ciencia) folhaPrivacidade(E.eu.privacidade, true);
}

function avisoPrivacidade(info) {
  const empresa = info.empresa || 'A empresa responsável';
  const item = (titulo, texto) => h('div', { class: 'item-priv' }, h('strong', null, titulo), h('p', { class: 'mudo pequeno' }, texto));
  return h('div', { class: 'privacidade' },
    h('p', null, `${info.escola} decide como seus dados são usados. ${empresa} opera o sistema por conta ${L('do')}.`),
    item('Nome', `Identifica você nas cotas, impressões e conversas. Pode ser apagado quando você sair ${L('do')}.`),
    item('Usuário e senha', 'A senha fica guardada só como resumo protegido, no computador do sistema. Nem a gestão consegue vê-la.'),
    item('Impressões e trocas de páginas', 'Nome do arquivo, páginas, cópias, data, custo e a finalidade que você informa (com a descrição, se houver). A gestão vê essa lista por pessoa, para controlar o uso das impressoras e prestar contas.'),
    item('Mensagens', `São apagadas automaticamente depois de ${info.reter_meses} ${info.reter_meses === 1 ? 'mês' : 'meses'}.`),
    item('Bloqueios e denúncias', 'Quem você bloqueia fica só na sua conta. Uma denúncia guarda o trecho da mensagem, quem denunciou e quem escreveu, e só a gestão vê. Ela é encerrada quando a gestão decide.'),
    item('Excluir a conta', 'Você pode pedir a exclusão no menu do seu nome. A gestão apaga seu nome, usuário, senha, mensagens e arquivos; os números de impressão ficam nos relatórios, sem o seu nome.'),
    item('Arquivos enviados', `Servem só para imprimir e para você ver a prévia, e são apagados logo depois. Na impressão de prova, o arquivo espera você conferir e é apagado quando você termina. O que não for impresso é apagado sozinho em até ${info.horas_arquivos || 12} horas. A gestão não abre seus arquivos, e ninguém da empresa que mantém o sistema os abre.`),
    h('p', { class: 'pequeno', style: { marginTop: '12px' } },
      `Seus dados ficam no computador ${L('do')} e não são vendidos nem usados em publicidade. Para pedir acesso, correção ou apagamento, fale com a gestão`,
      info.contato_escola ? ` (${info.contato_escola})` : '',
      info.contato_privacidade ? ` ou escreva para ${info.contato_privacidade}` : '', '.'));
}

const REGRAS_CONVIVENCIA = [
  'Trate todas as pessoas com respeito. Não use mensagens, pedidos nem o mural para ofender, ameaçar, humilhar ou perseguir ninguém.',
  'Não envie conteúdo sexual, violento, de ódio, discriminatório ou ilegal.',
  'Não se passe por outra pessoa e não exponha dados pessoais de colegas.',
  'Não use o app para propaganda, venda ou spam, nem para trocar páginas por dinheiro.',
];

function blocoTermos(info) {
  const url = info && info.termos_url;
  return h('div', { class: 'termos-uso' },
    h('h3', { style: { fontSize: '16px', fontWeight: '800', margin: '18px 0 6px' } }, 'Termos de uso e regras de convivência'),
    h('p', { class: 'mudo pequeno' }, 'Ao usar as mensagens, o mural e os pedidos de páginas, você concorda com estas regras:'),
    h('ul', { class: 'pequeno', style: { margin: '6px 0 0 18px' } }, REGRAS_CONVIVENCIA.map((r) => h('li', null, r))),
    h('p', { class: 'pequeno', style: { marginTop: '8px' } },
      'Palavras ofensivas são trocadas por asteriscos. Você pode bloquear um colega e denunciar mensagens à gestão, que pode apagá-las e desativar quem desrespeitar estas regras. Você também pode pedir a exclusão da sua conta, no menu do seu nome.'),
    url ? h('p', { class: 'pequeno', style: { marginTop: '8px' } }, 'Texto completo: ', h('a', { href: url, target: '_blank', rel: 'noopener' }, url)) : null);
}

function folhaPrivacidade(info, pedirCiencia) {
  folha((f, fechar) => {
    const rodape = pedirCiencia
      ? h('div', { class: 'rodape' }, h('button', {
        class: 'btn largo',
        onclick: async (e) => {
          botaoCarregando(e.currentTarget);
          try { await api('/api/ciencia', {}); E.eu.ciencia = true; } catch (err) { /* aparece de novo no próximo acesso */ }
          fechar();
        },
      }, 'Entendi e aceito os termos'))
      : h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Fechar'));
    f.append(h('h2', null, pedirCiencia && E.eu && E.eu.ciencia_mudou ? 'Termos de uso e privacidade' : 'Seus dados no Folha a Folha'),
      pedirCiencia && E.eu && E.eu.ciencia_mudou ? h('p', { class: 'faixa info', style: { marginTop: '10px' } }, 'Há termos de uso novos, com regras de convivência, e o aviso de privacidade ficou mais completo. Leia e aceite para continuar usando mensagens e pedidos.') : null,
      avisoPrivacidade(info), blocoTermos(info), rodape);
  });
}

function telaSobre() {
  moldura('Sobre', 'Conheça o Folha a Folha', h('div', { class: 'bloco sobre-app' },
    h('h2', null, 'Folha a Folha'),
    h('p', null, 'Controle de cotas de impressão para empresas, escolas e outras organizações.'),
    h('p', null, 'Desenvolvido por Alysson Christiano Primor, com auxílio de inteligência artificial.'),
    h('p', null, h('strong', null, 'Contato: '), h('a', { class: 'link-texto', href: 'mailto:diceflowsoftware@gmail.com' }, 'diceflowsoftware@gmail.com')),
    E.inicio && E.inicio.versao ? h('p', null, `Versão ${E.inicio.versao}`) : null,
    h('p', { class: 'dica' }, 'O Folha a Folha utiliza os drivers nativos de impressão e digitalização disponíveis no computador servidor. Os dados e documentos são processados conforme as configurações da instalação.')));
}

function folhaSobre() {
  const p = E.eu.privacidade;
  folha((f, fechar) => f.append(
    h('h2', null, 'Folha a Folha'),
    h('p', { class: 'mudo' }, 'Controle de cotas de impressão para empresas, escolas e outras organizações.'),
    E.eu.licenca ? h('p', { style: { marginTop: '12px' } }, E.eu.licenca.mensagem) : null,
    p.empresa ? h('p', { style: { marginTop: '12px' } }, `Licenciado e mantido por ${p.empresa}${p.cnpj ? `, CNPJ ${p.cnpj}` : ''}.`) : null,
    h('p', { style: { marginTop: '12px' } }, 'Sistema desenvolvido com o uso de inteligência artificial.'),
    h('p', { class: 'dica' }, `Versão ${E.inicio.versao}`),
    h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Fechar'))));
}

let ticks = 0;
function comecarAtualizacoes() {
  clearInterval(timerEu);
  // visível: atualiza a cada 6 s; em segundo plano (a pessoa foi imprimir em outro programa), só avisa a cada 30 s
  // que o app continua aberto, porque a impressora Folha a Folha só aceita de quem está com ele aberto
  timerEu = setInterval(() => {
    ticks += 1;
    if (!document.hidden) atualizarEu();
    else if (ticks % 5 === 0 && !E.bloqueado) api('/api/presenca').catch(() => {});
  }, 6000);
}
document.addEventListener('visibilitychange', () => { if (!document.hidden && E.eu && !E.bloqueado) atualizarEu(); });

async function atualizarEu(forcar) {
  try {
    const antes = JSON.stringify(E.eu);
    const filaAntes = E.eu ? E.eu.retidas : 0;
    E.eu = await api('/api/eu');
    mostrarSemRede(false);
    atualizarBolinha();
    const rota = location.hash.slice(1).split('/')[0] || 'inicio';
    if (E.eu.retidas > (filaAntes || 0) && irParaLiberacao()) { render(); return; }
    if (rota === 'imprimir' && E.eu.retidas !== filaAntes && !document.querySelector('.veu')) carregarRetidas();
    if ((forcar || antes !== JSON.stringify(E.eu)) && rota === 'inicio' && !document.querySelector('.veu')) telaInicio();
  } catch (e) { if (e && e.status === 0) mostrarSemRede(true); /* tenta de novo depois */ }
}

/* ---------------------------------------------------------------- compartilhar do celular (app Android) */

// No app Android, "Compartilhar > Folha a Folha" deixa o arquivo guardado no aparelho e o app oferece a ponte
// window.FafNativo (pendentes, ler, concluir). A tela busca o arquivo, monta um File e o envia como se a pessoa
// o tivesse escolhido em "Escolher arquivos". Em navegador a ponte não existe e nada disto roda.
let lendoCompartilhados = false;
const PARTE_COMPARTILHADO = 1024 * 1024;

async function lerCompartilhado(ponte, it) {
  const partes = [];
  for (let ini = 0; ini < it.tamanho; ini += PARTE_COMPARTILHADO) {
    const b64 = ponte.ler(it.id, ini, PARTE_COMPARTILHADO);
    if (!b64) throw new Error('parte vazia');
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    partes.push(bytes);
    await new Promise((r) => setTimeout(r, 0));  // deixa a tela respirar entre as partes
  }
  return new File(partes, it.nome, { type: it.tipo || '' });
}

async function receberDoCelular() {
  const ponte = window.FafNativo;
  if (!ponte || lendoCompartilhados || !E.eu || E.bloqueado) return;
  let lista = [];
  try { lista = JSON.parse(ponte.pendentes() || '[]'); } catch (e) { return; }
  if (!lista.length) return;
  lendoCompartilhados = true;
  const arquivos = [], falhas = [];
  try {
    for (const it of lista) {
      if (it.grande) falhas.push(`"${it.nome}": arquivo grande demais (máximo 60 MB).`);
      else {
        try { arquivos.push(await lerCompartilhado(ponte, it)); }
        catch (e) { falhas.push(`"${it.nome}": não consegui abrir o arquivo compartilhado.`); }
      }
      try { ponte.concluir(it.id); } catch (e) { /* o app apaga a cópia sozinho */ }
    }
  } finally { lendoCompartilhados = false; }
  if (falhas.length) avisar(falhas.join(' '), true);
  if (!arquivos.length) return;
  E.paraEnviar = (E.paraEnviar || []).concat(arquivos);
  if (E.ultimoResultado) { avisar('Arquivo recebido. Ele entra quando você voltar para Imprimir.'); return; }
  if (location.hash.startsWith('#imprimir')) telaImprimir(); else location.hash = '#imprimir';
}
window.fafCompartilhado = () => { receberDoCelular(); };

function render() {
  if (E.bloqueado) return telaBloqueio();
  if (!E.eu) return;
  receberDoCelular();
  clearInterval(timerChat); timerChat = null;
  document.querySelectorAll('.veu').forEach((v) => v.remove());
  const [rota, arg] = location.hash.slice(1).split('/');
  window.scrollTo(0, 0);
  switch (rota) {
    case 'imprimir': return telaImprimir();
    case 'digitalizar': return telaDigitalizar();
    case 'sobre': return telaSobre();
    case 'conversas': return telaConversas();
    case 'conversa': return telaConversa(decodeURIComponent(arg || 'mural'));
    case 'historico': return telaHistorico();
    case 'gestao': case 'direcao': return E.eu.usuario.gestor ? telaDirecao(arg || 'resumo') : telaInicio();
    default: return telaInicio();
  }
}

function sairLocal() {
  E.eu = null; E.bloqueado = false; clearInterval(timerEu); clearInterval(timerChat);
  // Recarrega a página: num computador compartilhado, nada da pessoa anterior (arquivo escolhido para
  // imprimir, digitalização, conversas, painel da gestão) fica na memória para quem entrar depois.
  location.replace(location.pathname);
}

/* ================================================================ primeira configuração e entrada */

const INSTALACOES = {
  local: ['Só este lugar', 'Uma empresa, escola ou setor. Você é o gestor e decide tudo aqui: pessoas, cotas e impressoras.'],
  central: ['Central da TI', 'A TI cuida de vários setores ou unidades: dá a cota de cada um, escolhe os gestores e liga as unidades que têm aparelho próprio.'],
  unidade: ['Unidade de uma central', 'Este aparelho fica numa unidade (filial, escola, posto de atendimento) e recebe as cotas da TI pela rede ou por pendrive.'],
};

function telaConfigurar() {
  const locais = E.inicio.locais || { outro: LOCAL_PADRAO };
  const st = { tipo: '', modo: 'impressora', instalacao: 'local', arquivo: null };
  const escola = h('input', { type: 'text', autocomplete: 'organization', placeholder: 'Ex.: Contabilidade Silva, Escola Pequenos Passos', maxlength: '120' });
  const rotuloNome = h('span', null, 'Nome da empresa, escola ou organização');
  const nome = h('input', { type: 'text', autocomplete: 'name', placeholder: 'Ex.: Marta Souza' });
  const login = h('input', { type: 'text', autocomplete: 'username', autocapitalize: 'off', spellcheck: 'false', maxlength: '40', placeholder: 'Ex.: marta.souza' });
  let loginMexido = false;
  login.oninput = () => { loginMexido = true; };
  nome.oninput = () => { if (!loginMexido) login.value = sugerirLogin(nome.value); };
  const pin = campoSenha('new-password');
  const pin2 = campoSenha('new-password');
  const urlCentral = h('input', { type: 'text', autocapitalize: 'off', spellcheck: 'false', placeholder: 'Ex.: http://10.0.0.5:8080' });
  const codigo = h('input', { type: 'text', autocapitalize: 'characters', spellcheck: 'false', placeholder: 'Ex.: ABCD-EFGH-JKLM', maxlength: '20' });
  const arquivo = h('input', { type: 'file', accept: '.json,application/json', class: 'oculto', id: 'arq-adesao' });
  const nomeArquivo = h('span', { class: 'mudo pequeno' }, 'Nenhum arquivo escolhido');
  arquivo.onchange = async () => { const a = arquivo.files[0]; st.arquivo = a ? await a.text() : null; nomeArquivo.textContent = a ? a.name : 'Nenhum arquivo escolhido'; };
  const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '16px' } });
  const btn = h('button', { class: 'btn largo', type: 'submit', style: { marginTop: '24px' } }, 'Começar a usar');
  const tipos = h('div', { class: 'segmentos tipos-local', role: 'radiogroup', 'aria-label': 'Onde vai ser usado' }, [['empresa', 'Empresa'], ['escola', 'Escola'], ['outro', 'Outra organização']].map(([v, t]) => {
    const b = h('button', { type: 'button', role: 'radio', 'aria-checked': 'false', 'aria-pressed': 'false' }, t);
    b.onclick = () => {
      st.tipo = v;
      tipos.querySelectorAll('button').forEach((x) => { const sim = x === b; x.setAttribute('aria-pressed', String(sim)); x.setAttribute('aria-checked', String(sim)); });
      const l = locais[v] || LOCAL_PADRAO;
      rotuloNome.textContent = st.instalacao === 'central' ? 'Nome da organização (ex.: Grupo Silva, Prefeitura de São José)' : l.rotulo;
      escola.placeholder = l.exemplo;
      erro.classList.add('oculto');
    };
    return b;
  }));
  const blocoLugar = h('div', null,
    h('div', { class: 'campo' }, h('span', null, 'Onde vai ser usado? (escolha uma opção)'), tipos,
      h('div', { class: 'dica' }, 'Muda só as palavras das telas e as finalidades sugeridas. As regras são as mesmas.')),
    h('label', { class: 'campo' }, rotuloNome, escola));
  const blocoUnidade = h('div', { class: 'oculto' },
    h('div', { class: 'bloco', style: { marginTop: '16px' } },
      h('p', { style: { marginTop: '0' } }, 'A TI cadastra a unidade na central e passa o endereço e um código. Sem internet, ela entrega um arquivo para trazer no pendrive.'),
      h('label', { class: 'campo' }, h('span', null, 'Endereço da central'), urlCentral),
      h('label', { class: 'campo' }, h('span', null, 'Código de adesão'), codigo),
      h('div', { class: 'campo' }, h('span', null, 'Ou o arquivo da central (sem internet)'),
        h('div', { class: 'linha-botoes' }, h('label', { class: 'btn claro pequeno', for: 'arq-adesao' }, 'Escolher arquivo', arquivo), nomeArquivo))));
  const rotuloNomePessoa = h('span', null, 'Seu nome');
  const instal = h('div', { class: 'estilos', role: 'radiogroup', 'aria-label': 'Tipo de instalação' });
  const desenharInstal = () => instal.replaceChildren(...Object.entries(INSTALACOES).map(([id, [nomeI, texto]]) => h('button', {
    type: 'button', role: 'radio', 'aria-checked': st.instalacao === id ? 'true' : 'false', class: 'estilo' + (st.instalacao === id ? ' marcado' : ''),
    onclick: () => {
      st.instalacao = id; desenharInstal();
      blocoLugar.classList.toggle('oculto', id === 'unidade'); blocoUnidade.classList.toggle('oculto', id !== 'unidade');
      rotuloNome.textContent = id === 'central' ? 'Nome da organização (ex.: Grupo Silva, Prefeitura de São José)' : (locais[st.tipo] || {}).rotulo || 'Nome da empresa, escola ou organização';
      rotuloNomePessoa.textContent = id === 'central' ? 'Seu nome (você fica como TI, o gestor geral)' : id === 'unidade' ? 'Seu nome (gestor deste aparelho)' : 'Seu nome';
      intro.textContent = TEXTOS_INTRO[id];
      erro.classList.add('oculto');
    },
  }, h('span', { class: 'estilo-nome' }, nomeI), h('span', { class: 'estilo-texto' }, texto))));
  const TEXTOS_INTRO = {
    local: 'Você será o gestor: cadastra a equipe, define as cotas e liga as impressoras. Depois disso, cada pessoa entra com o próprio usuário e senha.',
    central: 'Você será a TI: cria os setores e as unidades, dá a cota de cada um e escolhe os gestores, que cuidam das pessoas de cada setor.',
    unidade: 'Este aparelho vai receber da TI o nome da unidade, a cota e as regras. Você será o gestor dele aqui.',
  };
  const intro = h('p', null, TEXTOS_INTRO.local);
  desenharInstal();
  const form = h('form', {
    onsubmit: async (e) => {
      e.preventDefault(); erro.classList.add('oculto');
      const mostrar = (t) => { erro.textContent = t; erro.classList.remove('oculto'); };
      if (st.instalacao !== 'unidade' && !st.tipo) { tipos.scrollIntoView({ block: 'center', behavior: 'smooth' }); tipos.querySelector('button').focus(); return mostrar('Escolha onde o Folha a Folha vai ser usado.'); }
      if (st.instalacao === 'unidade' && !st.arquivo && (!urlCentral.value.trim() || !codigo.value.trim())) return mostrar('Informe o endereço da central e o código, ou escolha o arquivo da central.');
      if (pin.input.value !== pin2.input.value) return mostrar('As duas senhas não são iguais.');
      botaoCarregando(btn, st.instalacao === 'unidade' ? 'Falando com a central…' : 'Preparando…');
      try {
        await api('/api/configurar', {
          instalacao: st.instalacao, tipo_local: st.tipo || 'outro', escola: escola.value, nome: nome.value, usuario: login.value, senha: pin.input.value, modo: st.modo,
          central_url: urlCentral.value, codigo: codigo.value, arquivo: st.arquivo,
        });
        location.hash = st.instalacao === 'central' ? '#gestao/setores' : '#gestao/impressoras'; iniciar();
      } catch (err) { mostrar(err.message); botaoPronto(btn); }
    },
  },
  h('div', { class: 'campo' }, h('span', null, 'Como vai ser esta instalação?'), instal),
  blocoLugar, blocoUnidade,
  h('label', { class: 'campo' }, rotuloNomePessoa, nome),
  h('label', { class: 'campo' }, h('span', null, 'Seu usuário (para entrar)'), login, h('div', { class: 'dica' }, 'Letras, números e ponto, sem espaços.')),
  h('label', { class: 'campo' }, h('span', null, `Crie uma senha (pelo menos ${SENHA_MIN} caracteres)`), pin.caixa),
  h('label', { class: 'campo' }, h('span', null, 'Repita a senha'), pin2.caixa),
  h('div', { class: 'campo' }, h('span', null, 'Como a equipe vai imprimir?'), escolhaEstilo(st),
    h('div', { class: 'dica' }, 'Dá para trocar depois, em Gestão, Impressoras.')),
  erro, btn,
  h('p', { class: 'dica', style: { textAlign: 'center', marginTop: '16px' } }, 'Você tem 90 dias de avaliação. Para continuar depois, insira a chave de ativação em Gestão, Ajustes.'));
  $app.replaceChildren(h('div', { class: 'entrada' },
    h('div', { class: 'marca-app' }, h('img', { src: 'icone.svg', alt: '' }), h('div', null, h('h1', null, 'Folha a Folha'), h('p', { class: 'mudo' }, 'Primeira configuração'))),
    intro, form));
}

const ESTILOS = {
  impressora: ['Como impressora', 'Recomendado', 'Cada computador e celular instala a impressora "Folha a Folha". A pessoa imprime de qualquer programa e libera no app. O envio de arquivo pelo app continua valendo.'],
  navegador: ['Só pelo navegador', 'Mais simples', 'Nada é instalado nos aparelhos. A pessoa abre o app no navegador e envia os arquivos (PDF, foto, Word, Excel ou PowerPoint).'],
};

function escolhaEstilo(st, aoMudar) {
  const caixa = h('div', { class: 'estilos', role: 'radiogroup' });
  const desenhar = () => caixa.replaceChildren(...Object.entries(ESTILOS).map(([id, [nome, selo, texto]]) => h('button', {
    type: 'button', role: 'radio', 'aria-checked': st.modo === id ? 'true' : 'false', class: 'estilo' + (st.modo === id ? ' marcado' : ''),
    onclick: () => { st.modo = id; desenhar(); if (aoMudar) aoMudar(id); },
  }, h('span', { class: 'estilo-nome' }, nome, h('span', { class: 'selo ' + (id === 'impressora' ? 'ok' : 'teste') }, selo)), h('span', { class: 'estilo-texto' }, texto))));
  desenhar();
  return caixa;
}

const SENHA_MIN = 8;

/* Põe o cursor no campo, mas só se a pessoa ainda não clicou em outro: quem digita rápido não perde o que escreveu. */
function focarDepois(el, ms = 50) {
  setTimeout(() => {
    if (!el.isConnected) return;
    const at = document.activeElement;
    const tela = el.form || el.closest('.veu, .entrada');
    if (at && at !== document.body && tela && tela.contains(at)) return;
    el.focus();
  }, ms);
}

/* Usuário sugerido a partir do nome, igual ao do servidor: "Ana Maria Silva" vira "ana.silva". */
function sugerirLogin(nome) {
  const partes = String(nome || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
    .replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((p) => p && !['da', 'de', 'do', 'das', 'dos', 'e'].includes(p));
  const base = (partes.length > 1 ? [partes[0], partes[partes.length - 1]] : partes).join('.');
  return base.length >= 3 ? base : (base ? base + '.usuario' : '');
}

/* Campo de senha com o botão de mostrar o que foi digitado. */
function campoSenha(autocomplete) {
  const input = h('input', { type: 'password', autocomplete, autocapitalize: 'off', spellcheck: 'false', maxlength: '128' });
  const ver = h('button', { type: 'button', class: 'btn-texto pequeno ver-senha', 'aria-label': 'Mostrar a senha' }, 'Mostrar');
  ver.onclick = () => { const mostrar = input.type === 'password'; input.type = mostrar ? 'text' : 'password'; ver.textContent = mostrar ? 'Esconder' : 'Mostrar'; ver.setAttribute('aria-label', mostrar ? 'Esconder a senha' : 'Mostrar a senha'); input.focus(); };
  return { input, caixa: h('span', { class: 'caixa-senha' }, input, ver) };
}

function cabecalhoEntrada() {
  return h('div', { class: 'marca-app' }, h('img', { src: 'icone.svg', alt: '' }), h('div', null, h('h1', null, E.inicio.escola), h('p', { class: 'mudo' }, 'Folha a Folha')));
}

function telaEntrar() {
  const usuario = h('input', { type: 'text', name: 'username', autocomplete: 'username', autocapitalize: 'off', spellcheck: 'false', maxlength: '120', autofocus: true });
  const senha = campoSenha('current-password');
  const erro = h('div', { class: 'faixa erro oculto', role: 'alert', style: { marginTop: '14px' } });
  const btn = h('button', { class: 'btn largo', type: 'submit', style: { marginTop: '18px' } }, 'Entrar');
  const form = h('form', {
    class: 'form-entrar',
    onsubmit: async (e) => {
      e.preventDefault(); erro.classList.add('oculto');
      if (!usuario.value.trim() || !senha.input.value) { erro.textContent = 'Digite seu usuário e sua senha.'; erro.classList.remove('oculto'); return; }
      botaoCarregando(btn, 'Entrando…');
      try {
        const r = await api('/api/login', { usuario: usuario.value, senha: senha.input.value });
        E.inicio.logado = true;
        if (r.trocar_senha) return telaCriarSenha(r.login);
        E.eu = await api('/api/eu'); comecarAtualizacoes(); irParaLiberacao(); render(); verificarCiencia();
      } catch (err) {
        erro.textContent = err.message; erro.classList.remove('oculto'); botaoPronto(btn);
        senha.input.value = ''; senha.input.focus();
      }
    },
  },
  h('label', { class: 'campo' }, h('span', null, 'Usuário'), usuario),
  h('label', { class: 'campo' }, h('span', null, 'Senha'), senha.caixa),
  erro, btn);
  $app.replaceChildren(h('div', { class: 'entrada' },
    cabecalhoEntrada(),
    h('h2', { style: { fontSize: '18px' } }, 'Entrar'),
    form,
    E.inicio.pin_antigo ? h('div', { class: 'faixa info', style: { marginTop: '18px' } },
      h('p', null, h('strong', null, 'Primeira vez depois da atualização?'), ' Em Usuário, digite seu nome como está cadastrado. Em Senha, seu PIN de antes. Em seguida o app mostra o seu usuário e pede uma senha nova.')) : null,
    E.inicio.cadastro_aberto ? h('div', { class: 'bloco chamada-cadastro', style: { marginTop: '22px', textAlign: 'center' } },
      h('p', { style: { margin: '0 0 10px' } }, h('strong', null, 'Ainda não tem cadastro?')),
      h('button', { class: 'btn claro largo', type: 'button', onclick: () => telaCadastro() }, 'Criar meu cadastro')) : null,
    h('p', { class: 'dica', style: { textAlign: 'center', marginTop: '18px' } }, 'Esqueceu a senha? Peça uma nova ao gestor.'),
    h('p', { style: { textAlign: 'center', marginTop: '8px' } }, h('button', { class: 'btn-texto', onclick: () => folhaPrivacidade(E.inicio.privacidade, false) }, 'Aviso de privacidade')),
    E.inicio.versao ? h('p', { class: 'dica versao-entrada', style: { textAlign: 'center', marginTop: '14px' } }, `Versão ${E.inicio.versao}`) : null));
  focarDepois(usuario);
}

/* Cadastro pedido pela própria pessoa: entra sem cota e espera o gestor aprovar. */
function telaCadastro() {
  const nome = h('input', { type: 'text', autocomplete: 'name', maxlength: '80', autofocus: true });
  const login = h('input', { type: 'text', name: 'username', autocomplete: 'username', autocapitalize: 'off', spellcheck: 'false', maxlength: '40', placeholder: 'Ex.: ana.silva' });
  let loginMexido = false;
  login.oninput = () => { loginMexido = true; };
  nome.oninput = () => { if (!loginMexido) login.value = sugerirLogin(nome.value); };
  const senha = campoSenha('new-password');
  const repete = campoSenha('new-password');
  const obs = h('input', { type: 'text', maxlength: '120', placeholder: L('exemplo_funcao') });
  const erro = h('div', { class: 'faixa erro oculto', role: 'alert', style: { marginTop: '14px' } });
  const btn = h('button', { class: 'btn largo', type: 'submit', style: { marginTop: '18px' } }, 'Enviar cadastro');
  const form = h('form', {
    class: 'form-cadastro',
    onsubmit: async (e) => {
      e.preventDefault(); erro.classList.add('oculto');
      const mostrar = (t) => { erro.textContent = t; erro.classList.remove('oculto'); erro.scrollIntoView({ block: 'center' }); };
      if (nome.value.trim().split(/\s+/).length < 2) return mostrar('Escreva seu nome e sobrenome.');
      if (senha.input.value.length < SENHA_MIN) return mostrar(`A senha precisa ter pelo menos ${SENHA_MIN} caracteres.`);
      if (senha.input.value !== repete.input.value) return mostrar('As duas senhas não são iguais.');
      botaoCarregando(btn, 'Enviando…');
      try {
        const r = await api('/api/cadastro', { nome: nome.value, usuario: login.value, senha: senha.input.value, obs: obs.value });
        telaCadastroEnviado(r.login, nome.value);
      } catch (err) { mostrar(err.message); botaoPronto(btn); }
    },
  },
  h('label', { class: 'campo' }, h('span', null, 'Nome completo'), nome),
  h('label', { class: 'campo' }, h('span', null, 'Usuário (é com ele que você vai entrar)'), login, h('div', { class: 'dica' }, 'Letras, números e ponto, sem espaços. O app sugere a partir do nome.')),
  h('label', { class: 'campo' }, h('span', null, `Senha (pelo menos ${SENHA_MIN} caracteres)`), senha.caixa),
  h('label', { class: 'campo' }, h('span', null, 'Repita a senha'), repete.caixa),
  h('label', { class: 'campo' }, h('span', null, L('rotulo_funcao')), obs, h('div', { class: 'dica' }, 'Ajuda o gestor a saber quem é você.')),
  erro, btn);
  $app.replaceChildren(h('div', { class: 'entrada cadastro' },
    cabecalhoEntrada(),
    h('h2', { style: { fontSize: '18px' } }, 'Criar meu cadastro'),
    h('p', { class: 'mudo pequeno' }, 'Depois de enviar, o gestor aprova o cadastro e define as suas cotas de impressão. Até lá, o app ainda não abre para você.'),
    form,
    h('p', { style: { textAlign: 'center', marginTop: '18px' } },
      h('button', { class: 'btn-texto', onclick: () => folhaPrivacidade(E.inicio.privacidade, false) }, 'Aviso de privacidade'), ' · ',
      h('button', { class: 'btn-texto', onclick: () => telaEntrar() }, 'Já tenho cadastro'))));
  focarDepois(nome);
}

function telaCadastroEnviado(login, nome) {
  $app.replaceChildren(h('div', { class: 'entrada cadastro-enviado' },
    cabecalhoEntrada(),
    h('div', { class: 'faixa ok', style: { marginTop: '8px' } }, h('strong', null, 'Cadastro enviado!'), ` Tudo certo, ${String(nome || '').split(' ')[0]}.`),
    h('div', { class: 'bloco' },
      h('p', { style: { margin: '0' } }, 'Seu usuário é'),
      h('p', { class: 'login-grande' }, login),
      h('p', { class: 'mudo pequeno', style: { margin: '0' } }, 'Anote. Quando o gestor aprovar e definir as suas cotas, é só entrar com ele e com a senha que você criou.')),
    h('button', { class: 'btn largo', style: { marginTop: '18px' }, onclick: () => telaEntrar() }, 'Voltar para a entrada')));
}

/* Primeiro acesso (senha dada pelo gestor ou PIN antigo): a pessoa cria a própria senha. */
function telaCriarSenha(login) {
  const nova = campoSenha('new-password');
  const repete = campoSenha('new-password');
  const erro = h('div', { class: 'faixa erro oculto', role: 'alert', style: { marginTop: '14px' } });
  const btn = h('button', { class: 'btn largo', type: 'submit', style: { marginTop: '18px' } }, 'Salvar e entrar');
  const form = h('form', {
    onsubmit: async (e) => {
      e.preventDefault(); erro.classList.add('oculto');
      const mostrar = (t) => { erro.textContent = t; erro.classList.remove('oculto'); };
      if (nova.input.value.length < SENHA_MIN) return mostrar(`A senha precisa ter pelo menos ${SENHA_MIN} caracteres.`);
      if (nova.input.value !== repete.input.value) return mostrar('As duas senhas não são iguais.');
      botaoCarregando(btn, 'Salvando…');
      try {
        await api('/api/senha', { nova: nova.input.value });
        E.inicio.trocar_senha = false;
        E.eu = await api('/api/eu'); comecarAtualizacoes(); irParaLiberacao(); render(); verificarCiencia();
        avisar('Senha criada. Use seu usuário e essa senha para entrar.');
      } catch (err) { mostrar(err.message); botaoPronto(btn); }
    },
  },
  h('label', { class: 'campo' }, h('span', null, `Senha nova (pelo menos ${SENHA_MIN} caracteres)`), nova.caixa),
  h('label', { class: 'campo' }, h('span', null, 'Repita a senha nova'), repete.caixa),
  h('p', { class: 'dica' }, 'Dica: uma frase curta que só você conhece, como "cafe-com-leite-7", é fácil de lembrar e difícil de adivinhar.'),
  erro, btn);
  $app.replaceChildren(h('div', { class: 'entrada criar-senha' },
    cabecalhoEntrada(),
    h('h2', { style: { fontSize: '18px' } }, 'Crie sua senha'),
    h('div', { class: 'bloco' },
      h('p', { style: { margin: '0' } }, 'Seu usuário é'),
      h('p', { class: 'login-grande' }, login || ''),
      h('p', { class: 'mudo pequeno', style: { margin: '0' } }, 'Anote: é com ele e com a senha que você vai criar agora que você entra no app.')),
    form,
    h('p', { style: { textAlign: 'center', marginTop: '20px' } },
      h('button', { class: 'btn-texto', onclick: async () => { try { await api('/api/sair', {}); } catch (e) { /* */ } sairLocal(); } }, 'Sair'))));
  focarDepois(nova.input);
}

/* ---------------------------------------------------------------- tela bloqueada por falta de uso */

function mostrarBloqueio() {
  if (E.bloqueado && document.querySelector('.entrada.bloqueio')) return;
  if (E.eu) E.bloqueadoNome = E.eu.usuario.nome;
  E.bloqueado = true;
  clearInterval(timerEu); clearInterval(timerChat); timerChat = null;
  document.querySelectorAll('.veu').forEach((v) => v.remove());
  telaBloqueio();
}

function telaBloqueio() {
  const nome = E.bloqueadoNome || 'você';
  const senha = campoSenha('current-password');
  const erro = h('div', { class: 'faixa erro oculto', role: 'alert', style: { marginTop: '14px' } });
  const btn = h('button', { class: 'btn largo', type: 'submit', style: { marginTop: '18px' } }, 'Continuar');
  const min = (E.eu && E.eu.bloqueio_minutos) || null;
  const form = h('form', {
    onsubmit: async (e) => {
      e.preventDefault(); erro.classList.add('oculto');
      if (!senha.input.value) return;
      botaoCarregando(btn, 'Conferindo…');
      try {
        await api('/api/desbloquear', { senha: senha.input.value });
        E.bloqueado = false; E.ultimaAcao = Date.now();
        E.eu = await api('/api/eu'); comecarAtualizacoes(); render(); verificarCiencia();
      } catch (err) { erro.textContent = err.message; erro.classList.remove('oculto'); botaoPronto(btn); senha.input.value = ''; senha.input.focus(); }
    },
  }, h('label', { class: 'campo' }, h('span', null, 'Senha'), senha.caixa), erro, btn);
  $app.replaceChildren(h('div', { class: 'entrada bloqueio' },
    h('div', { style: { textAlign: 'center' } },
      h('span', { class: 'avatar', style: { width: '64px', height: '64px', fontSize: '22px', margin: '0 auto 12px', background: 'var(--papel)' } }, iniciais(nome)),
      h('h1', null, 'Tela bloqueada'),
      h('p', { class: 'mudo', style: { marginTop: '6px' } }, `${nome}${min ? `, o app ficou ${min} ${min === 1 ? 'minuto' : 'minutos'} sem uso` : ', o app ficou parado'}. Assim ninguém usa a sua cota. Digite sua senha para continuar.`)),
    form,
    h('p', { style: { textAlign: 'center', marginTop: '24px' } },
      h('button', {
        class: 'btn-texto',
        onclick: async () => { try { await api('/api/sair', {}); } catch (e) { /* */ } sairLocal(); },
      }, `Não sou ${String(nome).split(' ')[0]}: trocar de pessoa`))));
  focarDepois(senha.input);
}

function folhaPerfil() {
  folha((f, fechar) => {
    const atual = campoSenha('current-password');
    const novo = campoSenha('new-password');
    const novo2 = campoSenha('new-password');
    const btn = h('button', { class: 'btn claro largo', style: { marginTop: '14px' } }, 'Trocar senha');
    btn.onclick = async () => {
      if (novo.input.value !== novo2.input.value) return avisar('As duas senhas novas não são iguais.', true);
      botaoCarregando(btn);
      try { await api('/api/senha', { atual: atual.input.value, nova: novo.input.value }); avisar('Senha trocada. Os outros aparelhos onde você estava precisam entrar de novo.'); fechar(); }
      catch (e) { avisar(e.message, true); botaoPronto(btn); }
    };
    const c = E.eu.controle, pr = E.eu.prefs;
    const prefProva = h('input', { type: 'checkbox', checked: pr.prova_sempre });
    const prefFv = h('input', { type: 'checkbox', checked: pr.frente_verso });
    const prefPrevia = h('input', { type: 'checkbox', checked: pr.previa });
    const prefPersonalizado = h('input', { type: 'checkbox', checked: !!pr.tamanho_original });
    const salvarPref = async () => {
      try { const r = await api('/api/preferencias', { prova_sempre: prefProva.checked, frente_verso: prefFv.checked, previa: prefPrevia.checked, tamanho_original: prefPersonalizado.checked }); E.eu.prefs = r.prefs; E.imp = null; avisar('Preferência salva.'); }
      catch (e) { avisar(e.message, true); }
    };
    [prefProva, prefFv, prefPrevia, prefPersonalizado].forEach((x) => { x.onchange = salvarPref; });
    const interr = (titulo, dica, el) => h('label', { class: 'interruptor' }, h('span', null, h('strong', null, titulo), h('div', { class: 'dica', style: { marginTop: '0' } }, dica)), el);
    f.append(
      h('h2', null, E.eu.usuario.nome),
      h('p', { class: 'mudo' }, `${E.eu.usuario.admin ? 'Gestor' : 'Usuário'} · entra como `, h('strong', null, E.eu.usuario.login || '')),
      h('div', { class: 'bloco', style: { marginTop: '16px' } },
        h('strong', null, 'Como eu imprimo'),
        interr('Frente e verso já marcado', 'Se desligado, toda impressão começa em só frente.', prefFv),
        interr('Começar no tamanho original (100%)', 'A tela de impressão começa em Outro tamanho, 100%, em vez de Ajustar à folha.', prefPersonalizado),
        c.prova !== 'desligada' ? interr('Começar sempre com uma prova', 'Sai a primeira folha; o resto só depois que você conferir.', prefProva) : null,
        c.previa === 'opcional' ? interr('Ver a prévia antes de imprimir', 'Mostra as folhas como vão sair e pede para conferir.', prefPrevia) : null,
        c.previa === 'obrigatoria' ? h('p', { class: 'dica' }, `${Lc('o')} pede que todos confiram a prévia antes de imprimir.`) : null),
      E.eu.usuario.senha_pela_ti ? h('p', { class: 'dica', style: { marginTop: '16px' } }, 'Sua senha é cuidada pela TI, na central. Para trocar, fale com ela.') : h('div', null,
        h('label', { class: 'campo' }, h('span', null, 'Senha atual'), atual.caixa),
        h('label', { class: 'campo' }, h('span', null, `Senha nova (pelo menos ${SENHA_MIN} caracteres)`), novo.caixa),
        h('label', { class: 'campo' }, h('span', null, 'Repita a senha nova'), novo2.caixa),
        btn),
      h('div', { class: 'linha-botoes', style: { marginTop: '12px' } },
        h('button', { class: 'btn claro', onclick: () => { fechar(); folhaPrivacidade(E.eu.privacidade, false); } }, 'Privacidade'),
        h('button', { class: 'btn claro', onclick: () => { fechar(); folhaPrivacidade(E.eu.privacidade, false); } }, 'Termos de uso'),
        h('button', { class: 'btn claro', onclick: () => { fechar(); folhaBloqueados(); } }, 'Pessoas bloqueadas'),
        h('button', { class: 'btn claro', onclick: () => { fechar(); folhaSobre(); } }, 'Sobre')),
      h('div', { class: 'linha-botoes', style: { marginTop: '8px' } },
        h('button', { class: 'btn claro', onclick: () => { fechar(); folhaExcluirConta(); } }, 'Excluir minha conta')),
      h('div', { class: 'rodape' },
        h('button', { class: 'btn perigo', onclick: async () => { try { await api('/api/sair', {}); } catch (e) { /* */ } fechar(); sairLocal(); } }, 'Sair deste aparelho')));
  });
}

/* ================================================================ início */

function cartaoPilha(s) {
  const frac = s.cota > 0 ? Math.max(0, Math.min(1, s.restante / s.cota)) : 0;
  const selo = s.estado === 'esgotado' ? h('span', { class: 'selo esgotado' }, 'Acabou')
    : s.estado === 'alerta' ? h('span', { class: 'selo alerta' }, 'Está acabando') : null;
  const det = [`Já usou ${pag(s.usado)}` + (s.custo_pagina > 0 ? ` (${reais(s.gasto)})` : '')];
  if (s.recebido) det.push(`recebeu ${n(s.recebido)}`);
  if (s.cedido) det.push(`passou ${n(s.cedido)}`);
  return h('section', { class: `pilha-card ${s.estado}`, style: { '--cor': s.cor } },
    h('div', { class: 'pilha', 'aria-hidden': 'true' }, frac > 0 ? h('div', { class: 'folhas', style: { height: `${frac * 100}%` } }) : null),
    h('div', { class: 'info' },
      h('div', { class: 'nome' }, s.nome, selo, s.teste ? h('span', { class: 'selo teste' }, 'Modo teste') : null),
      h('div', { class: 'grande' }, n(Math.max(0, s.restante))),
      h('div', { class: 'de' }, s.cota > 0 ? `páginas restantes de ${n(s.cota)} este mês` : 'Nenhuma página liberada este mês'),
      h('div', { class: 'detalhes' }, det.join(', '))));
}

function faixaPedido(p) {
  const btnSim = h('button', { class: 'btn pequeno cor', style: { '--cor': p.cor } }, `Passar ${pag(p.paginas)}`);
  btnSim.onclick = () => responderPedido(p, true, btnSim);
  const btnNao = p.destinatario_id ? h('button', { class: 'btn claro pequeno' }, 'Não posso atender') : null;
  if (btnNao) btnNao.onclick = () => responderPedido(p, false, btnNao);
  const btnDispensar = !p.destinatario_id ? h('button', { class: 'btn claro pequeno' }, 'Dispensar pedido') : null;
  if (btnDispensar) btnDispensar.onclick = async () => {
    if (!(await confirmar('Dispensar este pedido?', 'Ele deixará de aparecer nas suas pendências, mas continuará visível para os demais colegas no mural.', 'Dispensar'))) return;
    botaoCarregando(btnDispensar);
    try { await api('/api/pedido/dispensar', { id: p.id }); avisar('Pedido dispensado das suas pendências.'); await atualizarEu(true); }
    catch (e) { avisar(e.message, true); botaoPronto(btnDispensar); }
  };
  return h('div', { class: 'faixa pedido' },
    h('p', null, `${p.solicitante_nome} pediu ${pag(p.paginas)} da ${p.impressora_nome}${p.destinatario_id ? '' : ', no mural'}.`),
    h('div', { class: 'linha-botoes' }, btnSim, btnNao, btnDispensar,
      h('a', { class: 'btn claro pequeno', href: '#conversa/' + encodeURIComponent(p.conversa) }, 'Ver conversa')));
}

function telaInicio() {
  const eu = E.eu;
  const algumAcabando = eu.saldos.some((s) => s.estado === 'alerta' || s.estado === 'esgotado');
  moldura(`Olá, ${eu.usuario.nome.split(' ')[0]}`, `${eu.escola}, ${nomeMes(eu.mes)}`, h('div', null,
    faixaLicenca(),
    eu.cadastros_pendentes ? h('a', { class: 'faixa info faixa-cadastros', href: '#gestao/equipe' },
      h('strong', null, eu.cadastros_pendentes === 1 ? '1 cadastro esperando aprovação' : `${eu.cadastros_pendentes} cadastros esperando aprovação`),
      h('span', null, ' Toque para aprovar e definir as cotas.')) : null,
    eu.denuncias_abertas ? h('a', { class: 'faixa info', href: '#gestao/moderacao' },
      h('strong', null, eu.denuncias_abertas === 1 ? '1 denúncia ou pedido de exclusão de conta' : `${eu.denuncias_abertas} denúncias ou pedidos de exclusão de conta`),
      h('span', null, ' Toque para ver.')) : null,
    faixasFila(),
    blocoConferencias(),
    eu.retidas ? h('a', { class: 'faixa aguardando', href: '#imprimir' }, icone('imprimir'),
      h('span', null, h('strong', null, eu.retidas === 1 ? '1 impressão aguardando você' : `${eu.retidas} impressões aguardando você`),
        h('span', { class: 'pequeno' }, 'Toque para escolher a impressora e liberar.'))) : null,
    eu.pedidos.slice(0, 3).map(faixaPedido),
    faixasAumento(),
    eu.negativo && eu.negativo.descontado_mes ? h('div', { class: 'faixa info' }, `Este mês começou com ${pag(eu.negativo.descontado_mes)} a menos, pelo que passou da cota no mês passado.`) : null,
    eu.saldos.length ? eu.saldos.map(cartaoPilha) : h('div', { class: 'bloco vazio' }, 'Nenhuma impressora ativa. Fale com a gestão.'),
    eu.retidas ? null : h('div', { class: 'acao-principal' }, h('a', { class: 'btn largo', href: '#imprimir' }, icone('imprimir'), 'Imprimir um arquivo')),
    algumAcabando ? h('div', { class: 'faixa info', style: { marginTop: '16px' } },
      h('p', null, E.eu.trocas.modo === 'reserva' ? `Suas páginas estão acabando? Peça à reserva ${L('do')}.` : 'Suas páginas estão acabando? Peça a colegas que tenham sobrando.'),
      h('div', { class: 'linha-botoes', style: { marginTop: '10px' } }, h('button', { class: 'btn claro pequeno', onclick: () => folhaPedir({}) }, 'Pedir páginas'),
        eu.negativo && eu.negativo.aumento ? h('button', { class: 'btn claro pequeno', onclick: () => folhaAumento({}) }, 'Pedir aumento à gestão') : null)) : null));
}

function faixasFila() {
  const f = E.eu.fila || { ativos: [], avisos: [] };
  const ativos = f.ativos.map((t) => h('div', { class: 'faixa info fila-item' },
    h('p', null, h('strong', { style: { wordBreak: 'break-word' } }, t.arquivo), ` · ${pag(t.total)} na ${curto(t.impressora)}`),
    h('p', { class: 'pequeno mudo', style: { marginTop: '4px' } }, `${t.motivo || 'Na fila da impressora'}. As páginas só ficam descontadas de vez quando saírem.`),
    h('div', { class: 'linha-botoes', style: { marginTop: '10px' } },
      h('button', { class: 'btn claro pequeno', onclick: (e) => cancelarFila(t, e.currentTarget) }, 'Cancelar impressão'))));
  const av = f.avisos;
  const avisos = av.length ? h('div', { class: 'faixa info fila-aviso' },
    av.map((t) => h('p', { style: { marginBottom: '6px' } }, h('strong', { style: { wordBreak: 'break-word' } }, t.arquivo), ': ', t.erro || 'Algumas páginas voltaram para a sua cota.')),
    h('div', { class: 'linha-botoes', style: { marginTop: '8px' } }, h('button', {
      class: 'btn claro pequeno',
      onclick: async (e) => { botaoCarregando(e.currentTarget); try { await api('/api/fila/visto', { ids: av.map((t) => t.id) }); } catch (x) { /* tenta de novo depois */ } atualizarEu(true); },
    }, 'Entendi'))) : null;
  return [avisos, ...ativos];
}

async function cancelarFila(t, btn) {
  if (!(await confirmar(`Cancelar “${t.arquivo}”?`, 'O que ainda não saiu na impressora volta para a sua cota.', 'Cancelar impressão', true))) return;
  if (btn) botaoCarregando(btn);
  try { await api('/api/fila/cancelar', { id: t.id }); avisar('Cancelando. O que não saiu volta para a sua cota.'); await atualizarEu(true); if (location.hash.startsWith('#historico')) telaHistorico(); if (location.hash.startsWith('#gestao')) recarregarDirecao(); }
  catch (e) { avisar(e.message, true); if (btn) botaoPronto(btn); }
}

async function responderPedido(p, aceitar, btn) {
  let resposta = '';
  if (aceitar) {
    const ok = await confirmar(`Passar ${pag(p.paginas)} para ${p.solicitante_nome}?`,
      `As páginas saem da sua cota da ${p.impressora_nome} deste mês. ${E.eu.trocas.aviso}`, `Passar ${n(p.paginas)}`);
    if (!ok) return;
  } else {
    resposta = await pedirTexto({ titulo: 'Responder ao pedido',
      texto: `O pedido de ${pag(p.paginas)} da ${p.impressora_nome} será encerrado sem transferência. Se quiser, escreva uma mensagem; se deixar em branco, enviaremos uma resposta padrão.`,
      rotulo: 'Mensagem (opcional)', placeholder: 'Ex.: Não posso ceder essa quantidade; meu limite de transferência é 50 páginas.',
      botao: 'Recusar pedido', minimo: 0 });
    if (resposta === null) return;
    if (!resposta.trim()) resposta = 'No momento não posso atender ao pedido. Nenhuma página foi transferida.';
  }
  if (btn) botaoCarregando(btn);
  try {
    await api('/api/pedido/responder', { id: p.id, aceitar, resposta });
    avisar(aceitar ? `Pronto! ${p.solicitante_nome} recebeu ${pag(p.paginas)}.` : 'Resposta enviada. O pedido saiu das pendências.');
    await atualizarEu(true);
    if (location.hash.startsWith('#conversa/')) recarregarChat(true);
  } catch (e) { avisar(e.message, true); if (btn) botaoPronto(btn); }
}

/* ================================================================ imprimir */

function faixaLicenca() {
  const lic = E.eu.licenca;
  if (!lic) return null;
  const parada = lic.estado === 'bloqueada';
  const mostrar = E.eu.usuario.admin ? ['avaliacao_fim', 'vencendo', 'carencia', 'bloqueada'].includes(lic.estado) : parada;
  if (!mostrar) return null;
  const conteudo = [h('strong', null, parada ? 'Impressão parada' : 'Licença do Folha a Folha'), h('span', null, lic.mensagem)];
  if (E.eu.usuario.admin) conteudo.push(h('span', { class: 'pequeno' }, parada ? 'Toque para inserir a chave.' : 'Toque para ver a licença.'));
  return E.eu.usuario.admin
    ? h('a', { class: 'faixa licenca ' + (parada ? 'parada' : 'atencao'), href: '#gestao/ajustes' }, ...conteudo)
    : h('div', { class: 'faixa licenca parada', role: 'alert' }, ...conteudo);
}


function telaDigitalizar() {
  const st = E.digitalizar || (E.digitalizar = {
    scanners: null, scannerId: '', opcoes: null, buscando: false, buscandoOpcoes: false,
    erro: '', aviso: '', digitalizando: false, origem: 'auto', modo: 'Color', dpi: 300,
    papel: 'auto', formato: 'pdf', paginas: 1, brilho: 0, contraste: 0, resultado: null, loteId: '', paginasLote: 0, ajustesPaginas: [],
  });
  const redesenhar = () => { if (location.hash.startsWith('#digitalizar')) telaDigitalizar(); };
  const nomeOrigem = (v) => ({ auto: 'Automática', flatbed: 'Mesa de vidro', adf: 'Alimentador (frente)', duplex: 'Alimentador (frente e verso)' }[v] || v);

  async function carregarOpcoes() {
    if (!st.scannerId) return;
    st.buscandoOpcoes = true; st.opcoes = null; st.erro = ''; redesenhar();
    try {
      const r = await api('/api/scanners/opcoes', { id: st.scannerId });
      st.opcoes = r.opcoes || {};
      const origens = st.opcoes.origens || [{ valor: 'auto', nome: 'Automática' }];
      if (!origens.some((o) => o.valor === st.origem)) st.origem = 'auto';
      const modos = st.opcoes.modos || ['Color', 'Gray', 'Lineart'];
      if (!modos.includes(st.modo)) st.modo = modos.includes('Color') ? 'Color' : modos[0];
      const dpis = Array.isArray(st.opcoes.dpi) && st.opcoes.dpi.length ? st.opcoes.dpi.map(Number) : [75, 100, 150, 200, 300, 600, 1200];
      if (!dpis.includes(Number(st.dpi))) st.dpi = dpis.includes(300) ? 300 : dpis[0];
    } catch (e) { st.erro = e.message; }
    st.buscandoOpcoes = false; redesenhar();
  }

  async function carregarScanners() {
    st.buscando = true; st.erro = ''; st.aviso = ''; redesenhar();
    try {
      const r = await api('/api/scanners');
      st.scanners = r.scanners || []; st.aviso = r.aviso || '';
      if (!st.scanners.some((d) => d.id === st.scannerId)) st.scannerId = st.scanners[0] ? st.scanners[0].id : '';
      if (st.scannerId) await carregarOpcoes();
      else st.opcoes = null;
    } catch (e) { st.scanners = []; st.erro = e.message; }
    st.buscando = false; redesenhar();
  }

  const ajusteVazio = () => ({ rotacao: 0, recorte: { esquerda: 0, topo: 0, direita: 0, baixo: 0 } });

  async function fazerDigitalizacao() {
    if (!st.scannerId || !st.opcoes || st.digitalizando) return;
    // PDF: as páginas vão para o documento em montagem (várias passagens, girar e recortar).
    // Imagem (JPG, PNG, TIFF, BMP): sai direto no formato escolhido, uma imagem por página.
    const emDocumento = st.formato === 'pdf' || !!st.loteId;
    st.digitalizando = true; st.erro = ''; if (emDocumento) st.resultado = null; redesenhar();
    const corpo = { scanner_id: st.scannerId, origem: st.origem, modo: st.modo, dpi: st.dpi, papel: st.papel,
      paginas: st.paginas, brilho: st.brilho, contraste: st.contraste };
    try {
      if (emDocumento) {
        const r = await api('/api/digitalizar/lote/adicionar', { ...corpo, lote_id: st.loteId || '', formato: 'pdf' });
        st.loteId = r.lote_id; st.paginasLote = r.paginas;
        while (st.ajustesPaginas.length < r.paginas) st.ajustesPaginas.push(ajusteVazio());
        if (r.aviso) avisar(r.aviso, true);
        else avisar(`O documento tem ${pag(r.paginas)}. Você pode digitalizar mais ou concluir o PDF.`);
      } else {
        st.resultado = await api('/api/digitalizar', { ...corpo, formato: st.formato });
        if (st.resultado.aviso) avisar(st.resultado.aviso, true);
      }
    } catch (e) { st.erro = e.message; }
    st.digitalizando = false; E.ultimaAcao = Date.now(); redesenhar();
  }

  async function descartarLote() {
    if (!st.loteId) return;
    const texto = st.paginasLote === 1 ? 'A página digitalizada será apagada' : `As ${pag(st.paginasLote)} digitalizadas serão apagadas`;
    if (!(await confirmar('Descartar o documento?', `${texto} do computador do sistema.`, 'Descartar', true))) return;
    try { await api('/api/digitalizar/lote/descartar', { lote_id: st.loteId }); } catch (e) { /* a limpeza automática apaga depois */ }
    st.loteId = ''; st.paginasLote = 0; st.ajustesPaginas = []; redesenhar();
  }

  async function retomarLote() {
    st.retomado = true;
    try {
      const r = await api('/api/digitalizar/lote/aberto');
      if (r.lote_id && !st.loteId) {
        st.loteId = r.lote_id; st.paginasLote = r.paginas;
        while (st.ajustesPaginas.length < r.paginas) st.ajustesPaginas.push(ajusteVazio());
        avisar(`Você tem um documento em montagem com ${pag(r.paginas)}. Continue de onde parou.`);
        redesenhar();
      }
    } catch (e) { /* sem documento para retomar */ }
  }

  const etapaScan = (num, titulo) => h('div', { class: 'etapa' }, h('span', { class: 'n' }, num), h('h2', null, titulo));
  const lista = st.scanners || [];
  const selecionarScanner = h('select', { value: st.scannerId },
    lista.map((d) => h('option', { value: d.id }, d.nome || d.id)));
  selecionarScanner.disabled = st.buscando || !lista.length;
  selecionarScanner.onchange = () => {
    st.scannerId = selecionarScanner.value; st.opcoes = null; st.resultado = null;
    st.origem = 'auto'; carregarOpcoes();
  };
  const botaoAtualizar = h('button', { class: 'btn claro pequeno', type: 'button', onclick: carregarScanners },
    st.buscando ? 'Procurando…' : 'Atualizar lista');
  botaoAtualizar.disabled = st.buscando || st.digitalizando;

  const conteudo = [
    faixaLicenca(),
    h('div', { class: 'faixa info' },
      h('strong', null, 'Digitalização independente da impressão'),
      h('p', { class: 'pequeno', style: { marginTop: '4px' } },
        'O Folha a Folha procura scanners pelo driver de digitalização do computador. A impressora pode estar oculta na rede e ainda assim o scanner aparecer aqui. Digitalizar não consome cota de impressão.')),
    etapaScan(1, 'Escolha o scanner'),
    h('div', { class: 'bloco' },
      h('label', { class: 'campo', style: { marginTop: '0' } }, h('span', null, 'Scanner ou multifuncional'), selecionarScanner),
      h('div', { class: 'linha-botoes', style: { marginTop: '10px' } }, botaoAtualizar),
      st.buscando ? h('p', { class: 'dica' }, h('span', { class: 'carregando' }), ' Consultando os scanners conectados…') : null,
      st.aviso && !lista.length ? h('div', { class: 'faixa erro', style: { marginTop: '12px', marginBottom: '0' } }, st.aviso) : null,
      !lista.length && !st.buscando && !st.aviso && !st.erro ? h('p', { class: 'dica' }, 'Nenhum scanner foi encontrado neste computador.') : null,
      st.erro ? h('div', { class: 'faixa erro', style: { marginTop: '12px', marginBottom: '0' } }, st.erro) : null,
      lista.length ? h('p', { class: 'dica' }, `Driver detectado: ${(st.scanners.find((d) => d.id === st.scannerId) || {}).fabricante || 'driver nativo'}.`) : null),
  ];

  if (st.buscandoOpcoes) {
    conteudo.push(h('div', { class: 'bloco', style: { marginTop: '16px' } }, h('span', { class: 'carregando' }), ' Lendo os recursos deste scanner…'));
  } else if (st.opcoes && st.scannerId) {
    const op = st.opcoes;
    const origens = op.origens && op.origens.length ? op.origens : [{ valor: 'auto', nome: 'Automática' }];
    const modos = op.modos && op.modos.length ? op.modos : ['Color', 'Gray', 'Lineart'];
    const dpiMax = Number(op.max_dpi || 1200);
    const dpis = Array.isArray(op.dpi) && op.dpi.length ? op.dpi.map(Number) : [75, 100, 150, 200, 300, 600, 1200].filter((x) => x <= dpiMax);
    const permiteDpi = dpis.some((x) => x > 0);
    if (!dpis.length) dpis.push(300);
    if (!dpis.includes(st.dpi)) st.dpi = dpis.includes(300) ? 300 : dpis[0];
    const campoSelect = (rotulo, valor, opcoes, onchange, dica) => h('label', { class: 'campo' },
      h('span', null, rotulo),
      h('select', { value: valor, onchange }, opcoes.map((o) => h('option', { value: o.value }, o.label))),
      dica ? h('div', { class: 'dica' }, dica) : null);
    const origem = campoSelect('Origem do documento', st.origem,
      origens.map((o) => ({ value: o.valor, label: o.nome || nomeOrigem(o.valor) })),
      (e) => { st.origem = e.currentTarget.value; redesenhar(); },
      'Mesa de vidro para folhas soltas; alimentador para várias páginas. Frente e verso aparece quando o driver oferece duplex.');
    const modo = campoSelect('Modo de cor', st.modo,
      modos.map((m) => ({ value: m, label: ({ Color: 'Colorido', Gray: 'Tons de cinza', Lineart: 'Preto e branco (linha)', Default: 'Padrão do scanner' }[m] || m) })),
      (e) => { st.modo = e.currentTarget.value; });
    const dpi = campoSelect('Resolução', String(st.dpi),
      dpis.sort((a, b) => a - b).map((v) => ({ value: String(v), label: v === 0 ? 'Padrão do driver' : `${v} DPI${v === 300 ? ' — recomendado' : ''}` })),
      (e) => { st.dpi = Number(e.currentTarget.value); }, permiteDpi ? `O limite informado pelo driver é ${dpiMax} DPI.` : 'Este driver não permite alterar a resolução; será usado o ajuste padrão dele.');
    const tamanhos = op.tamanhos && op.tamanhos.length ? op.tamanhos : ['auto'];
    if (!tamanhos.includes(st.papel)) st.papel = 'auto';
    const papel = campoSelect('Tamanho do papel', st.papel,
      tamanhos.map((t) => ({ value: t, label: (({ auto: 'Automático / padrão do scanner', A4: 'A4', A5: 'A5', A3: 'A3', Letter: 'Carta (Letter)', Legal: 'Ofício (Legal)' })[t] || t) })),
      (e) => { st.papel = e.currentTarget.value; }, 'Os tamanhos exibidos são os que o driver informa como disponíveis.');
    const formatos = (op.formatos && op.formatos.length ? op.formatos : ['jpg', 'png', 'tif']).map((x) => String(x).toLowerCase());
    const formatosSaida = [];
    if (formatos.some((x) => ['bmp', 'jpg', 'png', 'tif'].includes(x))) formatosSaida.push({ value: 'pdf', label: 'PDF — documento (página única ou multipágina)' });
    if (formatos.includes('bmp')) formatosSaida.push({ value: 'bmp', label: 'BMP — bitmap sem compressão' });
    if (formatos.includes('jpg')) formatosSaida.push({ value: 'jpg', label: 'JPEG / JPG — fotografia' });
    if (formatos.includes('png')) formatosSaida.push({ value: 'png', label: 'PNG — imagem sem perdas' });
    if (formatos.includes('tif')) formatosSaida.push({ value: 'tif', label: 'TIFF — imagem de alta qualidade' });
    if (!formatosSaida.some((x) => x.value === st.formato)) st.formato = formatosSaida[0] ? formatosSaida[0].value : 'pdf';
    if (st.loteId) st.formato = 'pdf';
    const formato = campoSelect('Formato', st.formato, formatosSaida,
      (e) => { st.formato = e.currentTarget.value; redesenhar(); },
      st.loteId ? 'Há um documento em montagem: as páginas novas entram nele, em PDF. Conclua ou descarte para escolher outro formato.'
        : st.formato === 'pdf' ? 'Em PDF, dá para digitalizar em várias passagens, girar e recortar páginas e juntar tudo num documento só.'
          : 'Em imagem, cada página vira um arquivo. Várias páginas chegam num arquivo ZIP.');
    if (st.loteId) formato.querySelector('select').disabled = true;
    const alimentador = st.origem === 'adf' || st.origem === 'duplex';
    const paginas = h('input', { type: 'number', min: '1', max: '100', value: st.paginas, inputmode: 'numeric' });
    paginas.onchange = () => { st.paginas = Math.max(1, Math.min(100, Number(paginas.value) || 1)); paginas.value = st.paginas; };
    const blocoPaginas = alimentador ? h('label', { class: 'campo' }, h('span', null, 'Quantidade de páginas'), paginas,
      h('div', { class: 'dica' }, 'Limite de 100 páginas por digitalização. No duplex, cada folha frente e verso gera duas páginas no arquivo.')) : null;
    const controleFaixa = (rotulo, chave, suporta) => {
      if (!suporta) return null;
      const valor = h('output', { class: 'num' }, st[chave]);
      const controle = h('input', { type: 'range', min: '-100', max: '100', step: '1', value: st[chave] });
      controle.oninput = () => { st[chave] = Number(controle.value); valor.textContent = st[chave]; };
      return h('label', { class: 'campo faixa-ajuste' }, h('span', null, rotulo, valor), controle,
        h('div', { class: 'dica' }, '0 mantém o ajuste padrão do driver; valores negativos reduzem e positivos aumentam.'));
    };
    const listaLote = st.loteId ? h('div', { class: 'bloco scan-lote', style: { marginTop: '14px' } },
      h('h3', null, `Documento em montagem: ${pag(st.paginasLote)}`),
      ...Array.from({ length: st.paginasLote }, (_, idx) => {
        const a = st.ajustesPaginas[idx] || { rotacao: 0, recorte: {} };
        const campoRecorte = (nome, chave) => h('label', { class: 'campo' }, h('span', null, nome + ' (%)'),
          h('input', { type: 'number', min: '0', max: '40', step: '1', value: (a.recorte || {})[chave] || 0,
            onchange: (ev) => { a.recorte = a.recorte || {}; a.recorte[chave] = Math.max(0, Math.min(40, Number(ev.currentTarget.value) || 0)); } }));
        return h('div', { class: 'scan-pagina-edicao', style: { borderTop: '1px solid var(--linha)', paddingTop: '12px', marginTop: '12px' } },
          h('div', { class: 'linha-botoes', style: { alignItems: 'center' } },
            h('strong', null, `Página ${idx + 1}`),
            h('span', { class: 'scan-miniatura-caixa' }, h('img', { src: `/api/digitalizar/lote/pagina?lote=${encodeURIComponent(st.loteId)}&pagina=${idx + 1}`, class: 'scan-miniatura', alt: `Página ${idx + 1}`, style: { transform: `rotate(${a.rotacao}deg)${a.rotacao % 180 ? ' scale(.7)' : ''}` } })),
            h('button', { class: 'btn claro pequeno', type: 'button', 'aria-label': `Girar a página ${idx + 1} para a esquerda`, onclick: () => { a.rotacao = (a.rotacao + 270) % 360; redesenhar(); } }, '↶ Girar'),
            h('button', { class: 'btn claro pequeno', type: 'button', 'aria-label': `Girar a página ${idx + 1} para a direita`, onclick: () => { a.rotacao = (a.rotacao + 90) % 360; redesenhar(); } }, 'Girar ↷'),
            h('span', { class: 'dica' }, `${a.rotacao}°`)),
          h('details', { style: { marginTop: '8px' } }, h('summary', null, 'Recortar página (margens em %)'),
            h('div', { class: 'grade-campos' }, campoRecorte('Superior', 'topo'), campoRecorte('Direita', 'direita'), campoRecorte('Inferior', 'baixo'), campoRecorte('Esquerda', 'esquerda'))));
      }),
      h('button', { class: 'btn largo', style: { marginTop: '14px' }, onclick: finalizarLote }, 'Concluir e gerar PDF multipágina'),
      h('button', { class: 'btn claro largo', style: { marginTop: '8px' }, onclick: descartarLote }, 'Descartar documento')) : null;
    async function finalizarLote() {
      if (!st.loteId || st.digitalizando) return;
      st.digitalizando = true; st.erro = ''; redesenhar();
      try { st.resultado = await api('/api/digitalizar/lote/finalizar', { lote_id: st.loteId, papel: st.papel, ajustes: st.ajustesPaginas.slice(0, st.paginasLote) });
        st.loteId = ''; st.paginasLote = 0; st.ajustesPaginas = []; avisar('PDF multipágina criado.');
      } catch (e) { st.erro = e.message; }
      st.digitalizando = false; redesenhar();
    }
    const ajustes = h('details', { class: 'bloco scan-avancado' },
      h('summary', null, 'Ajustes avançados'),
      controleFaixa('Brilho', 'brilho', !!op.brilho),
      controleFaixa('Contraste', 'contraste', !!op.contraste),
      h('p', { class: 'dica' }, 'Brilho e contraste são enviados ao driver apenas quando ele declara suporte.'));
    const botaoDigitalizar = h('button', { class: 'btn largo', type: 'button', style: { marginTop: '18px' }, onclick: fazerDigitalizacao },
      st.digitalizando ? 'Digitalizando…' : (st.loteId ? 'Digitalizar e acrescentar ao documento' : 'Digitalizar'));
    botaoDigitalizar.disabled = st.digitalizando || !st.scannerId;
    conteudo.push(
      etapaScan(2, 'Configurações da digitalização'),
      h('div', { class: 'bloco' }, origem,
        h('div', { class: 'lado-a-lado' }, modo, dpi),
        papel, formato, blocoPaginas, ajustes,
        st.digitalizando ? h('div', { class: 'faixa info', style: { marginTop: '14px', marginBottom: '0' } },
          h('span', { class: 'carregando' }), ' O scanner está trabalhando. A digitalização pode levar alguns minutos.') : null,
        botaoDigitalizar,
        listaLote));
  }

  if (st.resultado) {
    const r = st.resultado;
    const visualizar = r.formato === 'PDF' || (['JPG', 'PNG'].includes(r.formato) && r.paginas === 1);
    const url = `/api/digitalizar/visualizar?id=${encodeURIComponent(r.arquivo_id)}`;
    let previa;
    if (visualizar) {
      const imagemPrevia = h('img', {
        class: 'scan-previa-img', src: url, alt: r.formato === 'PDF' ? 'Prévia da primeira página do PDF digitalizado' : 'Prévia da imagem digitalizada',
        loading: 'lazy'
      });
      imagemPrevia.addEventListener('error', () => {
        imagemPrevia.replaceWith(h('div', { class: 'faixa erro' },
          'Não foi possível mostrar a prévia. O arquivo original continua disponível para baixar.'));
      }, { once: true });
      previa = h('div', { class: 'scan-previa-wrap' },
        r.formato === 'PDF' ? h('p', { class: 'dica' },
          r.paginas > 1 ? `Prévia da primeira página de um PDF com ${pag(r.paginas)}.` : 'Prévia do documento digitalizado.') : null,
        imagemPrevia);
    } else {
      previa = h('p', { class: 'dica' }, r.paginas > 1
        ? 'As páginas foram reunidas em um arquivo ZIP. Ao baixar, você encontrará uma imagem separada para cada página.'
        : 'Este formato não tem prévia no navegador. Baixe o arquivo para abri-lo.');
    }
    conteudo.push(h('section', { class: 'secao' },
      etapaScan(3, 'Digitalização pronta'),
      h('div', { class: 'bloco scan-resultado' },
        h('div', { class: 'faixa ok' }, `Foram digitalizadas ${pag(r.paginas)} em ${r.formato}.`),
        previa,
        h('a', { class: 'btn largo', href: `/api/digitalizar/baixar?id=${encodeURIComponent(r.arquivo_id)}`, download: r.nome },
          'Baixar arquivo'),
        h('button', { class: 'btn claro largo', style: { marginTop: '8px' }, onclick: () => { st.resultado = null; redesenhar(); } },
          'Fazer outra digitalização'))));
  }
  moldura('Escanear', 'Digitalize documentos e imagens', h('div', null, ...conteudo));
  if (!st.scanners && !st.buscando) carregarScanners();
  if (!st.retomado) retomarLote();
}

function telaImprimir() {
  if (E.ultimoResultado) return telaResultado();
  const st = E.imp || (E.imp = { upload: null, impressora_id: null, copias: 1, modo: 'todas', intervalo: '', frente_verso: E.eu.prefs.frente_verso, enviando: false, finalidade: '', descricao: '', prova: provaInicial(), escala: escalaInicial() });
  if (st.escala == null) st.escala = escalaInicial();
  const saldos = E.eu.saldos;
  if (!st.impressora_id || !saldos.find((s) => s.impressora_id === st.impressora_id)) {
    const comSaldo = saldos.find((s) => s.restante > 0) || saldos[0];
    st.impressora_id = comSaldo ? comSaldo.impressora_id : null;
  }
  const saldoAtual = () => saldos.find((s) => s.impressora_id === st.impressora_id);
  if (st.upload && !st.origem) {
    // chegou de "Ajustar" ou "Mais opções": o arquivo é a própria origem
    st.origem = { ids: [st.upload.id], foto: !!st.upload.foto, paginas: st.upload.paginas, nome: st.upload.nome, upload: st.upload, qtd: 1, renderizador: st.upload.renderizador !== false };
  }
  if (!st.mont) st.mont = { tipo: 'fotos', por_folha: 1, vezes: 1, cortar: false, folhas: 4, pdf_por_folha: 1 };
  if (!st.orientacaoPapel) st.orientacaoPapel = 'auto';  // foto deitada sai em folha deitada
  const og = st.origem;
  const montado = () => !!(st.upload && st.upload.montagem);
  const redesenhar = () => { if (E.imp !== st || !location.hash.startsWith('#imprimir')) return; const y = window.scrollY; telaImprimir(); window.scrollTo(0, y); };

  async function remontar(imediato) {
    clearTimeout(st.timerMontar);
    const fazer = async () => {
      const m = st.mont;
      let corpo = null;
      if (og.foto && m.tipo === 'banner') corpo = { modo: 'banner', folhas: m.folhas, cortar: m.cortar };
      else if (og.foto) corpo = { modo: 'fotos', por_folha: m.por_folha, vezes: m.vezes, cortar: m.cortar };
      else if (!og.foto && m.pdf_por_folha > 1) corpo = { modo: 'paginas', por_folha: m.pdf_por_folha, intervalo: st.modo === 'algumas' ? st.intervalo : '' };
      const seq = (st.seqMontar = (st.seqMontar || 0) + 1);
      if (!corpo) { st.upload = og.upload; st.montagem = null; st.montando = false; redesenhar(); return; }
      st.montando = true; redesenhar();
      try {
        const r = await api('/api/montar', { ...corpo, orientacao: st.orientacaoPapel || 'auto', uploads: og.ids, substituir: montado() ? st.upload.id : null });
        if (seq !== st.seqMontar) return;
        st.upload = r.upload; st.montagem = r.montagem;
      } catch (e) { if (seq !== st.seqMontar) return; avisar(e.message, true); }
      st.montando = false; redesenhar();
    };
    if (imediato) fazer(); else st.timerMontar = setTimeout(fazer, 450);
  }

  // 1. arquivo (um, várias fotos para montar ou vários documentos de uma vez)
  const entrada = h('input', { type: 'file', multiple: true, accept: aceitarArquivos(), class: 'oculto', id: 'arq' });
  entrada.onchange = () => { if (entrada.files.length) enviarArquivos(entrada.files, false); };
  const entradaMais = h('input', { type: 'file', multiple: true, accept: aceitarArquivos(), class: 'oculto', id: 'arq-mais' });
  entradaMais.onchange = () => { if (entradaMais.files.length) enviarArquivos(entradaMais.files, true); };
  const temArq = !!(st.upload || st.lote);
  const falhasEnvio = st.falhasEnvio && st.falhasEnvio.length
    ? h('div', { class: 'faixa erro', style: { marginTop: '12px', marginBottom: '0' } }, st.falhasEnvio.length === 1 ? 'Não entrou: ' : 'Não entraram: ', st.falhasEnvio.join(' ')) : null;
  let blocoArquivo;
  if (st.enviando) {
    blocoArquivo = h('div', { class: 'arquivo-area' }, h('span', { class: 'carregando' }), h('strong', null, 'Enviando e contando as páginas…'), h('span', { class: 'mudo pequeno' }, st.enviando));
  } else if (!st.upload && !st.lote) {
    blocoArquivo = h('div', null, h('label', { class: 'arquivo-area', for: 'arq' }, icone('arquivo'), h('strong', null, 'Escolher arquivos'), h('span', { class: 'mudo pequeno' }, 'Um ou vários: PDF, fotos (JPG ou PNG), Word, Excel ou PowerPoint'), entrada), falhasEnvio);
    blocoArquivo.querySelector('svg').style.cssText = 'width:36px;height:36px';
  } else if (st.lote) {
    const totalPags = st.lote.reduce((a, u) => a + u.paginas, 0);
    blocoArquivo = h('div', { class: 'bloco lote' },
      h('div', { class: 'lote-topo' }, h('strong', null, `${st.lote.length} arquivos`), h('span', { class: 'mudo pequeno' }, `${pag(totalPags)} ao todo`)),
      h('ul', { class: 'lote-lista' }, st.lote.map((u, i) => h('li', null,
        h('div', { class: 'icone-doc' }, extensaoDe(u.nome)),
        h('div', { class: 'lote-nome' }, h('div', { class: 'nome-arq' }, u.nome), h('div', { class: 'mudo pequeno' }, pag(u.paginas))),
        h('button', { type: 'button', class: 'btn-icone', 'aria-label': `Tirar ${u.nome}`, title: 'Tirar da lista', onclick: () => tirarDoLote(i) }, '×')))),
      falhasEnvio,
      h('div', { class: 'linha-botoes', style: { marginTop: '12px' } },
        st.lote.length < (E.eu.max_lote || 20) ? h('label', { class: 'btn claro pequeno', for: 'arq-mais' }, '+ Mais arquivos', entradaMais) : null,
        h('label', { class: 'btn claro pequeno', for: 'arq' }, 'Trocar tudo', entrada)));
  } else {
    const ext = og.qtd > 1 ? 'IMG' : (og.nome.split('.').pop() || '').toUpperCase().slice(0, 4);
    const folhas = st.upload.paginas;
    const resumo = st.montando ? 'Montando as folhas…'
      : montado() ? `${n(folhas)} ${folhas === 1 ? 'folha' : 'folhas'}${st.montagem && st.montagem.modo === 'banner' ? `, banner de ${st.montagem.largura_cm} × ${st.montagem.altura_cm} cm` : ''}`
        : og.foto ? '1 folha' : pag(og.paginas);
    blocoArquivo = h('div', { class: 'bloco arquivo-escolhido' },
      h('div', { class: 'icone-doc' }, ext),
      h('div', { style: { flex: '1', minWidth: '0' } }, h('div', { class: 'nome-arq' }, og.nome), h('div', { class: 'mudo pequeno' }, resumo)),
      h('div', { class: 'botoes-arq' },
        h('label', { class: 'btn claro pequeno', for: 'arq' }, 'Trocar', entrada),
        !og.foto && !st.montando ? h('label', { class: 'btn claro pequeno', for: 'arq-mais' }, '+ Mais', entradaMais) : null));
    if (falhasEnvio) blocoArquivo = h('div', null, blocoArquivo, falhasEnvio);
  }

  async function orientarFotosDoLote() {
    const originais = st.loteOriginais || st.lote || [];
    if (!originais.some((u) => u && u.foto)) return;
    st.orientando = true;
    redesenhar();
    const atualizados = [];
    st.loteOrientados = st.loteOrientados || {};
    try {
      for (const u of originais) {
        if (!u || !u.foto) { atualizados.push(u); continue; }
        const anterior = st.loteOrientados[u.id] || null;
        const r = await api('/api/montar', {
          modo: 'fotos', uploads: [u.id], por_folha: 1, vezes: 1, cortar: false,
          orientacao: st.orientacaoPapel || 'auto', substituir: anterior,
        });
        st.loteOrientados[u.id] = r.upload.id;
        atualizados.push(r.upload);
      }
      st.lote = atualizados;
    } catch (e) {
      avisar(`Não foi possível aplicar a orientação às fotos: ${e.message}`, true);
    } finally {
      st.orientando = false;
      redesenhar();
    }
  }

  function tirarDoLote(i) {
    const original = st.loteOriginais && st.loteOriginais[i];
    st.lote.splice(i, 1);
    if (st.loteOriginais) st.loteOriginais.splice(i, 1);
    if (original && st.loteOrientados) delete st.loteOrientados[original.id];
    if (st.lote.length === 0) { st.lote = null; st.loteOriginais = null; st.loteOrientados = {}; }
    else if (st.lote.length === 1) {
      const atual = st.lote[0];
      const fonte = st.loteOriginais && st.loteOriginais[0];
      st.upload = atual;
      st.origem = fonte ? { ids: [fonte.id], foto: !!fonte.foto, paginas: fonte.paginas, nome: fonte.nome, upload: fonte, qtd: 1, renderizador: fonte.renderizador !== false } : null;
      st.lote = null; st.loteOriginais = null; st.loteOrientados = {}; st.mont = { tipo: 'fotos', por_folha: 1, vezes: 1, cortar: false, folhas: 4, pdf_por_folha: 1 };
    }
    st.falhasEnvio = null;
    redesenhar();
  }

  // 2. impressora
  const escolhas = h('div', { class: 'escolha' }, saldos.map((s) => {
    const b = h('button', { type: 'button', 'aria-pressed': String(s.impressora_id === st.impressora_id), style: { '--cor': s.cor } },
      h('span', { class: 'marca' }), h('span', { class: 'nome' }, s.nome, s.teste ? h('span', { class: 'selo teste' }, 'Modo teste') : null),
      h('span', { class: 'qtd num' }, `${n(Math.max(0, s.restante))} disponíveis`));
    b.onclick = () => { st.impressora_id = s.impressora_id; escolhas.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); atualizarConta(); if (campoTam && campoTam.replanejar) campoTam.replanejar(); };
    return b;
  }));

  // 3. cópias e páginas
  const saida = h('output', { class: 'num' }, st.copias);
  const mudar = (d) => { st.copias = Math.max(1, Math.min(E.eu.max_copias, st.copias + d)); saida.textContent = st.copias; atualizarConta(); };
  const passo = h('div', { class: 'passo' },
    h('button', { type: 'button', 'aria-label': 'Menos uma cópia', onclick: () => mudar(-1) }, '−'), saida,
    h('button', { type: 'button', 'aria-label': 'Mais uma cópia', onclick: () => mudar(1) }, '+'));
  const campoIntervalo = h('input', { type: 'text', inputmode: 'text', autocapitalize: 'off', autocorrect: 'off', autocomplete: 'off', spellcheck: 'false', enterkeyhint: 'done', placeholder: 'Ex.: 1-3, 5', value: st.intervalo, 'aria-label': 'Intervalo de páginas. Use hífen e vírgula, por exemplo 1-3, 5.' });
  campoIntervalo.oninput = () => { st.intervalo = campoIntervalo.value; if (st.mont.pdf_por_folha > 1) remontar(); else atualizarConta(); };
  const blocoIntervalo = h('label', { class: 'campo' + (st.modo === 'algumas' ? '' : ' oculto') }, h('span', null, 'Quais páginas?'), campoIntervalo,
    h('div', { class: 'dica' }, 'Use traço para sequências e vírgula para separar.'));
  const segs = h('div', { class: 'segmentos' }, ['todas', 'algumas'].map((m) => {
    const b = h('button', { type: 'button', 'aria-pressed': String(st.modo === m) }, m === 'todas' ? 'Todas as páginas' : 'Escolher páginas');
    b.onclick = () => { st.modo = m; segs.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); blocoIntervalo.classList.toggle('oculto', m !== 'algumas'); if (m === 'algumas') campoIntervalo.focus(); if (st.mont.pdf_por_folha > 1 && (m === 'todas' || st.intervalo)) remontar(); else atualizarConta(); };
    return b;
  }));
  const ehBanner = !!(st.montagem && st.montagem.modo === 'banner');
  if (ehBanner) st.frente_verso = false;
  const fv = h('input', { type: 'checkbox', checked: st.frente_verso });
  fv.onchange = () => { st.frente_verso = fv.checked; atualizarConta(); };
  const multiPagina = !st.lote && og && !og.foto && og.paginas > 1;
  // tamanho na folha: para documentos (fotos e banner já têm o próprio "Tamanho na folha")
  const escalaVale = st.lote ? st.lote.some((u) => !u.foto && u.tipo !== 'imagem') : !!(st.upload && og && !og.foto);
  const escalaEnviar = () => (escalaVale ? st.escala || '' : '');
  const campoTam = escalaVale && !st.montando ? campoEscala(st, {
    pagina: !st.lote && og.renderizador ? `/api/previa/pagina?origem=upload&id=${encodeURIComponent(st.upload.id)}&p=1` : null,
    lote: !!st.lote,
  }) : null;
  const campoOrientacao = h('label', { class: 'campo' },
    h('span', null, 'Orientação do papel'),
    h('select', {
      value: st.orientacaoPapel || 'auto',
      disabled: !!(st.orientando || st.montando),
      onchange: (e) => {
        const valor = e.currentTarget.value;
        if (valor === st.orientacaoPapel) return;
        st.orientacaoPapel = valor;
        if (og && og.foto) remontar(true);
        else if (st.lote && (st.loteOriginais || st.lote).some((u) => u && u.foto)) orientarFotosDoLote();
        else redesenhar();
      },
    }, [['auto', 'Automática (conforme a foto)'], ['retrato', 'Retrato (vertical)'], ['paisagem', 'Paisagem (horizontal)']].map(([v,l]) => h('option', { value:v }, l))),
    h('small', { class: 'dica' }, 'Aplicada a fotos JPG e PNG. PDFs mantêm a orientação original.'));
  const pagsSel = () => (!st.upload || st.upload.tipo === 'imagem' ? [1] : paginasIntervalo(st.modo === 'algumas' && !montado() ? st.intervalo : '', st.upload.paginas));
  const itensLote = () => (st.lote || []).map((u) => ({ pags: paginasIntervalo('', u.paginas), copias: st.copias, fv: st.frente_verso }));
  const prova = st.lote ? campoProvaLote(st, itensLote, () => atualizarConta())
    : st.upload ? campoProva(st, () => ({ pags: pagsSel(), copias: st.copias, fv: st.frente_verso }), () => atualizarConta()) : null;
  let blocoFin = null;

  const conta = h('div', { class: 'conta', 'aria-live': 'polite' });
  const erroImp = h('div', { class: 'faixa erro oculto', style: { marginTop: '12px' } });
  const btnPedir = h('button', { class: 'btn claro largo oculto', style: { marginTop: '10px' } }, 'Pedir páginas a colegas');
  const btnAumento = h('button', { class: 'btn claro largo oculto', style: { marginTop: '10px' } }, 'Pedir aumento à gestão');
  const btnImprimir = h('button', { class: 'btn largo', style: { marginTop: '12px' } }, 'Imprimir');
  const confImp = confirmaImpressora(st, () => atualizarConta());

  function calculo() {
    if (st.lote) {
      const sel = st.lote.reduce((a, u) => a + u.paginas, 0);
      const s = saldoAtual();
      const usar = sel * st.copias;
      return { sel, usar, s, sobra: s ? s.restante - usar : -usar };
    }
    if (!st.upload) return null;
    const total = st.upload.paginas;
    let sel = total;
    if (st.upload.tipo === 'pdf' && st.modo === 'algumas' && !montado()) {
      const r = contarIntervalo(st.intervalo, total);
      if (!r.ok) return { invalido: r.msg };
      sel = r.qtd;
    }
    const s = saldoAtual();
    const usar = sel * st.copias;
    return { sel, usar, s, sobra: s ? s.restante - usar : -usar };
  }

  function atualizarConta() {
    const c = calculo();
    erroImp.classList.add('oculto');
    btnPedir.classList.add('oculto'); btnAumento.classList.add('oculto');
    if (blocoFin) { const s = saldoAtual(); blocoFin.classList.toggle('oculto', !(s && s.pede_finalidade)); }
    if (prova) prova.atualizar();
    if (st.montando) { conta.classList.remove('oculto'); encher(conta, h('div', { class: 'linha' }, h('span', null, h('span', { class: 'carregando' }), ' Montando as folhas…'))); btnImprimir.disabled = true; btnImprimir.textContent = 'Aguarde…'; return; }
    if (st.orientando) { conta.classList.remove('oculto'); encher(conta, h('div', { class: 'linha' }, h('span', null, h('span', { class: 'carregando' }), ' Aplicando a orientação às fotos…'))); btnImprimir.disabled = true; btnImprimir.textContent = 'Aguarde…'; return; }
    if (!c) { conta.classList.add('oculto'); btnImprimir.disabled = true; btnImprimir.textContent = 'Imprimir'; return; }
    conta.classList.remove('oculto');
    if (c.invalido) {
      conta.className = 'conta falta'; conta.replaceChildren(h('div', { class: 'linha' }, c.invalido));
      btnImprimir.disabled = true; return;
    }
    const alem = alemDaCota(c.s, c.usar);
    const falta = c.sobra < 0 && !alem.pode;
    conta.className = 'conta' + (falta ? ' falta' : alem.pode ? ' alem' : '');
    const custo = c.s ? c.s.custo_pagina : 0;
    conta.replaceChildren(...[
      st.lote ? h('div', { class: 'linha' }, h('span', null, 'Arquivos'), h('span', null, n(st.lote.length))) : null,
      h('div', { class: 'linha' }, h('span', null, st.lote ? 'Páginas dos arquivos' : montado() ? 'Folhas montadas' : st.modo === 'algumas' ? 'Páginas escolhidas' : 'Páginas do arquivo'), h('span', null, n(c.sel))),
      h('div', { class: 'linha' }, h('span', null, 'Cópias'), h('span', null, `× ${n(st.copias)}`)),
      c.sel > 1 || st.copias > 1 ? h('div', { class: 'linha' }, h('span', null, 'Lados'), h('span', null, st.frente_verso ? 'Frente e verso' : 'Só frente')) : null,
      h('div', { class: 'linha total' }, h('span', null, 'Vai usar'), h('span', null, pag(c.usar))),
      custo > 0 ? h('div', { class: 'linha' }, h('span', null, `Custo (${precoPagina(custo)} por página)`), h('span', null, reais(c.usar * custo))) : null,
      alem.pode ? h('div', { class: 'linha' }, h('span', null, 'Além da cota (com justificativa)'), h('span', null, pag(alem.falta))) : null,
      alem.pode && alem.desconta ? h('div', { class: 'linha dica-linha' }, h('span', null, 'Sai da sua cota do mês que vem.')) : null,
      alem.pode ? null : h('div', { class: 'linha' }, h('span', null, falta ? 'Faltam' : 'Você fica com'), h('span', null, falta ? pag(-c.sobra) : pag(c.sobra))),
    ].filter(Boolean));
    confImp.atualizar();
    btnImprimir.disabled = falta || st.enviando || !confImp.ok();
    const plano = st.lote ? planoLote(itensLote(), st.prova) : planoProva(pagsSel(), st.copias, st.frente_verso, st.prova);
    btnImprimir.textContent = falta ? 'Páginas insuficientes'
      : previaAtiva() ? 'Conferir e imprimir'
        : alem.pode ? 'Imprimir além da cota'
        : st.lote ? (plano ? `Imprimir ${pag(plano.prova)} agora` : `Imprimir os ${st.lote.length} arquivos (${pag(c.usar)})`)
          : plano ? `Imprimir a prova (${pag(plano.prova)})` : `Imprimir ${pag(c.usar)}`;
    if (c.sobra < 0) {
      btnPedir.classList.remove('oculto');
      btnPedir.onclick = () => folhaPedir({ impressora_id: st.impressora_id, paginas: alem.falta || -c.sobra });
      if (E.eu.negativo && E.eu.negativo.aumento) {
        btnAumento.classList.remove('oculto');
        btnAumento.onclick = () => folhaAumento({ impressora_id: st.impressora_id, paginas: alem.falta || -c.sobra });
      }
    }
  }

  async function tratarErro(e) {
    erroImp.textContent = e.message; erroImp.classList.remove('oculto');
    if (e.codigo === 'sem_cota' || e.codigo === 'pessoal') { await atualizarEu(); atualizarConta(); erroImp.textContent = e.message; erroImp.classList.remove('oculto'); }
    if (/Envie de novo/.test(e.message)) { document.querySelectorAll('.veu').forEach((v) => v.remove()); st.upload = null; st.lote = null; telaImprimir(); avisar(e.message, true); }
    if (e.codigo === 'lote_parcial' && st.lote) {
      // os que saíram já foram contados; ficam na lista só os que faltam, para tentar de novo
      const faltam = new Set(e.dados.faltam || []);
      st.lote = st.lote.filter((u) => faltam.has(u.id));
      if (st.lote.length === 1) { st.upload = st.lote[0]; st.origem = null; st.lote = null; }
      document.querySelectorAll('.veu').forEach((v) => v.remove());
      await atualizarEu(); redesenhar();
      const er = document.querySelector('.secao .faixa.erro'); if (er) { er.textContent = e.message; er.classList.remove('oculto'); er.scrollIntoView({ block: 'center' }); }
    }
  }

  btnImprimir.onclick = async () => {
    const c = calculo(); if (!c || c.invalido || !confImp.ok()) return;
    const s = saldoAtual();
    const pede = !!(s && s.pede_finalidade);
    const prob = problemaFinalidade(st, c.usar, pede);
    if (prob) {
      erroImp.textContent = prob; erroImp.classList.remove('oculto');
      if (blocoFin) blocoFin.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    if (st.lote) {
      const enviarLote = async () => {
        const r = await apiImprimir('/api/imprimir-lote', {
          uploads: st.lote.map((u) => u.id), impressora_id: st.impressora_id, copias: st.copias, frente_verso: st.frente_verso,
          finalidade: pede ? st.finalidade : '', descricao: st.descricao, prova: st.prova, escala: escalaEnviar(),
        });
        E.ultimoResultado = r; E.imp = null;
        await atualizarEu(); telaImprimir();
      };
      if (previaAtiva()) {
        folhaConfirmarLote({
          itens: st.lote.map((u) => ({ origem: 'upload', id: u.id, nome: u.nome, foto: !!u.foto || u.tipo === 'imagem', paginas: u.paginas, pags: paginasIntervalo('', u.paginas), copias: st.copias, fv: st.frente_verso })),
          prova: () => st.prova, impressora: s.nome, finalidade: pede ? st.finalidade : '', descricao: st.descricao, escala: escalaEnviar(),
          mudarLados: (v) => { st.frente_verso = v; fv.checked = v; atualizarConta(); },
          enviar: async () => { try { await enviarLote(); } catch (e) { tratarErro(e); throw e; } },
        });
        return;
      }
      botaoCarregando(btnImprimir, 'Enviando para a impressora…');
      try { await enviarLote(); } catch (e) { botaoPronto(btnImprimir); tratarErro(e); }
      return;
    }
    const enviar = async () => {
      const r = await apiImprimir('/api/imprimir', {
        upload_id: st.upload.id, impressora_id: st.impressora_id, copias: st.copias,
        intervalo: st.modo === 'algumas' && !montado() ? st.intervalo : '', frente_verso: st.frente_verso,
        finalidade: pede ? st.finalidade : '', descricao: st.descricao, prova: st.prova, escala: escalaEnviar(),
      });
      E.ultimoResultado = r; E.imp = null;
      await atualizarEu(); telaImprimir();
    };
    if (previaAtiva()) {
      // a prévia desenha a folha como ela vai sair: se o cálculo ainda não chegou (clicou logo depois de mudar), espera por ele
      const chavePlano = `${st.upload.id}|${st.impressora_id}|${st.escala}`;
      let plano = escalaVale && st.plano && st.plano.chave === chavePlano ? st.plano : null;
      if (escalaVale && !plano) {
        botaoCarregando(btnImprimir, 'Preparando a prévia…');
        try { plano = await api('/api/tamanho/plano', { upload_id: st.upload.id, impressora_id: st.impressora_id, escala: st.escala }); plano.chave = chavePlano; st.plano = plano; } catch (e) { plano = null; }
        botaoPronto(btnImprimir);
      }
      folhaConfirmar({
        origem: 'upload', id: st.upload.id, nome: st.upload.nome, tipo: st.upload.tipo, paginasDoc: st.upload.paginas,
        pags: pagsSel(), copias: st.copias, fv: st.frente_verso, prova: () => st.prova, impressora: s.nome,
        finalidade: pede ? st.finalidade : '', descricao: st.descricao, escala: escalaVale ? escalaEnviar() : null,
        plano,
        banner: st.montagem && st.montagem.modo === 'banner' ? st.montagem : null,
        mudarLados: (v) => { st.frente_verso = v; fv.checked = v; atualizarConta(); },
        enviar: async () => { try { await enviar(); } catch (e) { tratarErro(e); throw e; } },
      });
      return;
    }
    botaoCarregando(btnImprimir, 'Enviando para a impressora…');
    try { await enviar(); } catch (e) { botaoPronto(btnImprimir); tratarErro(e); }
  };

  const etapa = (num, titulo) => h('div', { class: 'etapa' }, h('span', { class: 'n' }, num), h('h2', null, titulo));
  const comImpressora = E.eu.modo === 'impressora';
  const caixaRetidas = comImpressora ? h('div', { id: 'retidas' }, E.retidas ? blocoRetidas() : h('div', { class: 'bloco vazio' }, h('span', { class: 'carregando' }))) : null;
  if (comImpressora && (!E.retidas || Date.now() - (E.retidasEm || 0) > 3000)) carregarRetidas();
  if (temArq) blocoFin = h('div', { class: 'secao' }, etapa(4, tituloFinalidade()), h('div', { class: 'bloco' }, campoFinalidade(st, () => erroImp.classList.add('oculto'))));
  moldura('Imprimir', null, h('div', null,
    faixaLicenca(),
    blocoConferencias(),
    caixaRetidas,
    comImpressora ? h('div', { class: 'divisor' }, 'ou envie um arquivo daqui') : null,
    etapa(1, st.lote ? 'Arquivos' : 'Arquivo'), blocoArquivo,
    st.upload && og && !st.enviando ? blocoMontagem(st, remontar) : null,
    temArq ? h('div', { class: 'secao' }, etapa(2, 'Em qual impressora?'), escolhas) : null,
    temArq ? h('div', { class: 'secao' }, etapa(3, 'Como imprimir'),
      h('div', { class: 'bloco' },
        campoOrientacao,
        st.orientando ? h('p', { class: 'dica' }, h('span', { class: 'carregando' }), ' Aplicando a orientação às fotos…') : null,
        h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' } }, h('strong', null, 'Cópias'), passo),
        multiPagina ? h('div', { style: { marginTop: '16px' } }, segs, blocoIntervalo) : null,
        st.lote ? h('p', { class: 'dica' }, 'Cada arquivo sai inteiro, com as mesmas cópias, e começa numa folha nova. Para escolher páginas, imprima o arquivo sozinho.') : null,
        ehBanner ? null : h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Frente e verso'), h('div', { class: 'dica', style: { marginTop: '0' } }, 'Gasta menos papel. A cota conta cada lado impresso.')), fv),
        campoTam,
        prova ? prova.el : null)) : null,
    blocoFin,
    temArq ? h('div', { class: 'secao' }, conta, erroImp, confImp.el, btnPedir, btnAumento, btnImprimir) : null));
  atualizarConta();

  // arquivos do "Compartilhar" do app Android entram como se tivessem sido escolhidos aqui
  if (E.paraEnviar && E.paraEnviar.length && !st.enviando) {
    const recebidos = E.paraEnviar; E.paraEnviar = null;
    enviarArquivos(recebidos, !!(st.upload || st.lote));
  }

  async function enviarArquivos(lista, juntar) {
    const arqs = [...lista];
    const soFotos = arqs.every((a) => /\.(jpe?g|png)$/i.test(a.name));
    // várias fotos de uma vez viram uma montagem; documentos (ou fotos junto com documentos) viram uma lista
    const montarFotos = !juntar && soFotos && arqs.length > 1;
    const antes = juntar ? (st.lote ? [...st.lote] : st.upload ? [st.upload] : st.origem ? [st.origem.upload] : []) : [];
    const antesOriginais = juntar ? (st.lote ? [...(st.loteOriginais || st.lote)] : st.origem ? [st.origem.upload] : []) : [];
    const orientadosAntes = juntar ? { ...(st.loteOrientados || {}) } : {};
    if (juntar && !st.lote && st.origem && st.origem.foto && st.upload && st.upload.montagem) {
      orientadosAntes[st.origem.upload.id] = st.upload.id;
    }
    const max = montarFotos ? 40 : (E.eu.max_lote || 20);
    if (antes.length + arqs.length > max) { avisar(montarFotos ? 'Escolha até 40 fotos de cada vez.' : `Escolha até ${max} arquivos de cada vez.`, true); return; }
    if (arqs.some((a) => a.size > 60 * 1024 * 1024)) { avisar('Arquivo grande demais (máximo 60 MB).', true); return; }
    const aceitas = new Set(E.eu.extensoes || []);
    const fora = aceitas.size ? arqs.filter((a) => !aceitas.has('.' + (a.name.split('.').pop() || '').toLowerCase())) : [];
    if (fora.length === arqs.length) { avisar(`"${fora[0].name}" não dá para enviar por aqui. Use PDF, foto, Word, Excel ou PowerPoint, ou salve como PDF.`, true); return; }
    st.upload = null; st.origem = null; st.lote = null; st.loteOriginais = null; st.loteOrientados = {}; st.montagem = null; st.montando = false; st.falhasEnvio = null;
    st.mont = { tipo: 'fotos', por_folha: 1, vezes: 1, cortar: false, folhas: 4, pdf_por_folha: 1 };
    st.modo = 'todas'; st.intervalo = '';
    const ups = [], falhas = fora.map((a) => `"${a.name}" (tipo de arquivo não aceito).`);
    for (const [i, a] of arqs.filter((x) => !fora.includes(x)).entries()) {
      st.enviando = arqs.length > 1 ? `${a.name} (${i + 1} de ${arqs.length - fora.length})` : a.name;
      if (location.hash.startsWith('#imprimir')) telaImprimir();
      try { ups.push(await api('/api/upload', a, { headers: { 'X-Nome-Arquivo': encodeURIComponent(a.name), 'X-Orientacao-Papel': st.orientacaoPapel || 'auto' } })); }
      catch (e) {
        if (montarFotos) { avisar(e.message, true); ups.length = 0; break; }
        falhas.push(e.message.startsWith('"') ? e.message : `"${a.name}": ${e.message}`);
      }
    }
    try {
      if (montarFotos && ups.length) {
        st.origem = { ids: ups.map((u) => u.id), foto: true, paginas: ups[0].paginas, nome: `${ups.length} fotos`, upload: ups[0], qtd: ups.length, renderizador: ups[0].renderizador !== false };
        st.enviando = 'Montando as folhas…'; if (location.hash.startsWith('#imprimir')) telaImprimir();
        const r = await api('/api/montar', { modo: 'fotos', uploads: st.origem.ids, por_folha: 1, vezes: 1, orientacao: st.orientacaoPapel || 'auto' });
        st.upload = r.upload; st.montagem = r.montagem;
        st.loteOriginais = null; st.loteOrientados = {};
      } else if (!montarFotos) {
        const todos = [...antes, ...ups];
        if (todos.length === 1) {
          const u = todos[0];
          st.upload = u;
          st.origem = { ids: [u.id], foto: !!u.foto, paginas: u.paginas, nome: u.nome, upload: u, qtd: 1, renderizador: u.renderizador !== false };
          st.loteOriginais = null; st.loteOrientados = {};
        } else if (todos.length > 1) {
          st.lote = todos;
          st.loteOriginais = [...antesOriginais, ...ups];
          st.loteOrientados = orientadosAntes;
        }
      }
    } catch (e) { avisar(e.message, true); st.upload = null; st.origem = null; st.lote = null; st.loteOriginais = null; st.loteOrientados = {}; }
    if (falhas.length) {
      st.falhasEnvio = falhas;
      if (!st.upload && !st.lote && falhas.length === 1) { avisar(falhas[0], true); }
    }
    st.enviando = false;
    if (location.hash.startsWith('#imprimir')) telaImprimir();
  }
}

/* ---------------------------------------------------------------- tamanho na folha (escala) */

const ESCALA_MIN = 25, ESCALA_MAX = 200, ESCALA_PASSO = 1, ESCALA_OUTRO_INICIAL = 100;

// A preferência "tamanho próximo ao original" começa em Outro tamanho, 100%.
function escalaInicial() { return E.eu && E.eu.prefs && E.eu.prefs.tamanho_original ? String(ESCALA_OUTRO_INICIAL) : 'ajustar'; }
function textoEscala(e, plano) {
  if (e !== 'ajustar') return `${e}% do original`;
  const pcts = plano && plano.paginas ? plano.paginas.map((p) => p.pct) : [];
  if (!pcts.length) return 'Ajustar à folha';
  const mn = Math.min(...pcts), mx = Math.max(...pcts);
  return `Ajustar à folha (${mn === mx ? fmtPct(mn) : `${fmtPct(mn)} a ${fmtPct(mx)}`})`;
}
const fmtPct = (v) => `${String(Math.round(v * 10) / 10).replace('.', ',')}%`;
const fmtMm = (v) => `${String(Math.round(v * 10) / 10).replace('.', ',')} mm`;

// a folha da impressora com a área que ela alcança (tracejado) e a página no lugar e no tamanho do plano
function folhaComPagina(conteudo, plano, numero) {
  const [W, H] = plano.papel_mm;
  const m = plano.margens;
  const p = plano.paginas && plano.paginas[numero - 1];
  const papel = h('div', { class: 'papel-plano', style: { aspectRatio: `${W} / ${H}` } },
    h('span', { class: 'papel-area', 'aria-hidden': 'true', style: { left: `${(m.esq / W) * 100}%`, right: `${(m.dir / W) * 100}%`, top: `${(m.topo / H) * 100}%`, bottom: `${(m.baixo / H) * 100}%` } }));
  if (!p) { papel.append(conteudo); return papel; }
  const cx = p.x + p.largura / 2, cy = p.y + p.altura / 2;
  const [lw, lh] = p.giro ? [p.altura, p.largura] : [p.largura, p.altura];  // antes de girar
  conteudo.classList.add('papel-pagina');
  Object.assign(conteudo.style, {
    left: `${((cx - lw / 2) / W) * 100}%`, top: `${((cy - lh / 2) / H) * 100}%`,
    width: `${(lw / W) * 100}%`, height: `${(lh / H) * 100}%`,
    transform: p.giro ? 'rotate(-90deg)' : '',
  });
  papel.append(conteudo);
  if (p.corta) papel.classList.add('corta');
  return papel;
}

// prévia sem plano (lista de arquivos): só a página, como antes
function papelEscala(img, e) {
  if (!e || e === 'ajustar') return img;
  return h('div', { class: 'papel-escala', style: { '--esc': String(Number(e) / 100), '--dy': '0%' } }, img);
}

function campoEscala(st, { pagina, lote }) {
  let tipo = st.escala === 'ajustar' || !st.escala ? 'ajustar' : 'outro';
  if (st.escalaOutro == null) st.escalaOutro = tipo === 'outro' ? Number(st.escala) : ESCALA_OUTRO_INICIAL;
  const esquema = () => h('div', { class: 'tf-pagina tf-esquema', 'aria-hidden': 'true' }, h('i'), h('i'), h('i'), h('i'), h('i'), h('i'));
  const desenhoPagina = () => {
    if (!pagina) return esquema();
    const im = h('img', { class: 'tf-pagina', src: pagina, alt: '', decoding: 'async' });
    im.onerror = () => im.replaceWith(esquema());
    return im;
  };
  const caixa = h('div', { class: 'tf-folha', role: 'img', 'aria-label': 'Como a página fica na folha' });
  const saida = h('output', { class: 'num' });
  const faixa = h('input', { type: 'range', min: ESCALA_MIN, max: ESCALA_MAX, step: ESCALA_PASSO, 'aria-label': 'Tamanho na folha, em porcentagem do original' });
  const mudar = (v) => { st.escalaOutro = Math.max(ESCALA_MIN, Math.min(ESCALA_MAX, Math.round(v / ESCALA_PASSO) * ESCALA_PASSO)); aplicar(); };
  faixa.oninput = () => mudar(Number(faixa.value));
  const outro = h('div', { class: 'tf-outro' },
    h('div', { class: 'passo pequeno' },
      h('button', { type: 'button', 'aria-label': `Diminuir ${ESCALA_PASSO}%`, onclick: () => mudar(st.escalaOutro - ESCALA_PASSO) }, '−'), saida,
      h('button', { type: 'button', 'aria-label': `Aumentar ${ESCALA_PASSO}%`, onclick: () => mudar(st.escalaOutro + ESCALA_PASSO) }, '+')),
    faixa);
  const dica = h('p', { class: 'dica tf-dica', 'aria-live': 'polite' });
  const legenda = h('p', { class: 'tf-legenda' });
  const opcoes = [['ajustar', 'Ajustar à folha'], ['outro', 'Outro tamanho']];
  const segs = h('div', { class: 'segmentos compactos' }, opcoes.map(([v, r]) => h('button', {
    type: 'button', 'data-tam': v, onclick: () => { tipo = v; aplicar(); },
  }, r)));

  function desenhar() {
    const pl = st.plano && st.plano.chave === chave() ? st.plano : null;
    if (!pl) {
      caixa.replaceChildren(h('div', { class: 'papel-plano', style: { aspectRatio: '210 / 297' } }, desenhoPagina()));
      dica.textContent = lote ? (tipo === 'ajustar' ? 'Cada documento sai no maior tamanho que cabe na área que a impressora alcança.' : `Os documentos saem em ${st.escalaOutro}% do original.`) : 'Calculando como fica na folha…';
      if (lote && tipo !== 'ajustar') dica.textContent += ' Fotos saem como sempre.';
      legenda.replaceChildren();
      return;
    }
    caixa.replaceChildren(folhaComPagina(desenhoPagina(), pl, 1));
    const pags = pl.paginas || [];
    const cortam = pags.map((p, i) => (p.corta ? i + 1 : 0)).filter(Boolean);
    const pcts = pags.map((p) => p.pct);
    const mn = pcts.length ? Math.min(...pcts) : 100, mx = pcts.length ? Math.max(...pcts) : 100;
    if (!pags.length) {
      dica.textContent = tipo === 'ajustar' ? 'Este arquivo sai com o ajuste automático da impressora.' : `Sai em ${st.escalaOutro}% do original.`;
    } else if (tipo === 'ajustar') {
      dica.textContent = mn === mx
        ? (mx === 100 ? 'Sai em 100%, o tamanho original: tudo já cabe na área que a impressora alcança.'
          : mx > 100 ? `A página é menor que o papel: aumenta para ${fmtPct(mx)} e enche a área que a impressora alcança.`
            : `Sai em ${fmtPct(mx)}: o maior tamanho em que nada passa da área que a impressora alcança.`)
        : `As páginas saem entre ${fmtPct(mn)} e ${fmtPct(mx)}: cada uma no maior tamanho que cabe na área que a impressora alcança.`;
      if (!pl.tinta && mx < 100) dica.textContent += ' (Sem o Poppler no computador do sistema, a página inteira conta como conteúdo.)';
    } else if (cortam.length) {
      const lista = cortam.length === pags.length ? (pags.length === 1 ? 'a página' : 'todas as páginas')
        : `${cortam.length === 1 ? 'a página' : 'as páginas'} ${cortam.slice(0, 6).join(', ')}${cortam.length > 6 ? '…' : ''}`;
      dica.textContent = `Em ${st.escalaOutro}%, ${lista} ${cortam.length === 1 ? 'passa' : 'passam'} da área que a impressora alcança: o que fica fora do tracejado não sai. Ajustar à folha faz caber tudo.`;
    } else {
      dica.textContent = st.escalaOutro === 100 ? 'Sai em 100%, o tamanho original, e tudo cabe na área que a impressora alcança.'
        : st.escalaOutro < 100 ? `Sai em ${st.escalaOutro}%: sobra mais margem branca em volta.`
          : `Sai em ${st.escalaOutro}%, e tudo cabe na área que a impressora alcança.`;
    }
    const m = pl.margens;
    const iguais = m.topo === m.baixo && m.esq === m.dir && m.topo === m.esq;
    legenda.replaceChildren(h('span', { class: 'tf-tracejado', 'aria-hidden': 'true' }),
      `Até onde esta impressora alcança: ${iguais ? `${fmtMm(m.topo)} da beirada` : `${fmtMm(m.topo)} em cima, ${fmtMm(m.baixo)} embaixo, ${fmtMm(m.esq)} e ${fmtMm(m.dir)} dos lados`}${pl.origem_margens === 'padrao' ? ' (estimado; a gestão pode medir com a página de calibração)' : ''}.`);
  }

  const chave = () => (st.upload ? `${st.upload.id}|${st.impressora_id}|${st.escala}` : '');
  let espera = null;
  async function planejar() {
    if (lote || !st.upload || !st.impressora_id) { desenhar(); return; }
    const k = chave();
    if (st.plano && st.plano.chave === k) { desenhar(); return; }
    desenhar();
    clearTimeout(espera);
    espera = setTimeout(async () => {
      try {
        const r = await api('/api/tamanho/plano', { upload_id: st.upload.id, impressora_id: st.impressora_id, escala: st.escala });
        r.chave = k; st.plano = r;
      } catch (e) { st.plano = { chave: k, papel_mm: [210, 297], margens: { topo: 4.2, baixo: 4.2, esq: 4.2, dir: 4.2 }, paginas: null, origem_margens: 'padrao' }; }
      if (chave() === k && caixa.isConnected) desenhar();
    }, tipo === 'outro' ? 250 : 0);
  }

  function aplicar() {
    st.escalaModo = tipo;
    st.escala = tipo === 'ajustar' ? 'ajustar' : String(st.escalaOutro);
    segs.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.tam === tipo)));
    outro.classList.toggle('oculto', tipo !== 'outro');
    saida.textContent = `${st.escalaOutro}%`; faixa.value = String(st.escalaOutro);
    planejar();
  }
  aplicar();
  const el = h('div', { class: 'tamanho-folha' },
    h('strong', null, 'Tamanho na folha'),
    segs,
    h('div', { class: 'tf-corpo' }, caixa,
      h('div', { class: 'tf-lado' }, outro, dica, legenda)));
  el.replanejar = planejar;
  return el;
}

/* ---------------------------------------------------------------- montagem: fotos por folha, banner, páginas por folha */

const GRADE_FOTOS = { 1: [1, 1], 2: [1, 2], 4: [2, 2], 6: [2, 3], 9: [3, 3] };
const GRADE_BANNER = { 2: [2, 1], 4: [2, 2], 6: [3, 2], 9: [3, 3], 12: [4, 3], 16: [4, 4] };
const GRADE_PAGINAS = { 1: [1, 1, false], 2: [2, 1, true], 4: [2, 2, false] };

// desenho pequeno da folha (ou do banner) com a grade de fotos ou páginas
function iconeGrade(cols, lins, deitada, banner) {
  return h('span', {
    class: 'grade-ico' + (banner ? ' banner' : '') + (deitada ? ' deitada' : ''), 'aria-hidden': 'true',
    style: { gridTemplateColumns: `repeat(${cols}, 1fr)`, gridTemplateRows: `repeat(${lins}, 1fr)` },
  }, Array.from({ length: cols * lins }, () => h('i')));
}

function blocoMontagem(st, refazer) {
  const og = st.origem, m = st.mont;
  if (!og || (!og.foto && !(og.paginas > 1))) return null;
  const opcao = (ativo, rotulo, ico, aoEscolher, desligada) => h('button', {
    type: 'button', class: 'opcao-mont', 'aria-pressed': String(ativo), disabled: !!desligada,
    onclick: () => { if (!ativo) aoEscolher(); },
  }, ico, h('span', null, rotulo));
  const interruptor = (titulo, dica, valor, aoMudar) => {
    const cb = h('input', { type: 'checkbox', checked: valor });
    cb.onchange = () => aoMudar(cb.checked);
    return h('label', { class: 'interruptor' }, h('span', null, h('strong', null, titulo), h('div', { class: 'dica', style: { marginTop: '0' } }, dica)), cb);
  };
  if (og.foto) {
    const tipos = og.qtd === 1 ? h('div', { class: 'segmentos' }, [['fotos', 'Fotos na folha'], ['banner', 'Banner']].map(([v, r]) => h('button', {
      type: 'button', 'aria-pressed': String(m.tipo === v), onclick: () => { if (m.tipo !== v) { m.tipo = v; refazer(true); } },
    }, r))) : null;
    if (m.tipo === 'banner' && og.qtd === 1) {
      const info = st.montagem && st.montagem.modo === 'banner' ? st.montagem : null;
      return h('div', { class: 'bloco montagem' }, tipos,
        h('span', { class: 'rotulo-campo', style: { marginTop: '14px' } }, 'Em quantas folhas?'),
        h('div', { class: 'opcoes-mont' }, [2, 4, 6, 9, 12, 16].map((f) => opcao(m.folhas === f, `${f} folhas`, iconeGrade(...GRADE_BANNER[f], false, true), () => { m.folhas = f; refazer(true); }))),
        interruptor('Preencher todas as folhas', 'Corta as sobras da imagem para não ficar borda branca no banner.', m.cortar, (v) => { m.cortar = v; refazer(true); }),
        h('p', { class: 'dica' }, info ? `O banner fica com cerca de ${info.largura_cm} × ${info.altura_cm} cm. ` : '',
          'Cada folha sai com marcas de corte e a posição (linha e coluna) escrita na borda: corte nas marcas e junte as folhas.'));
    }
    const saida = h('output', { class: 'num' }, m.vezes);
    const mudar = (d) => { const v = Math.max(1, Math.min(60, m.vezes + d)); if (v === m.vezes) return; m.vezes = v; saida.textContent = v; refazer(); };
    return h('div', { class: 'bloco montagem' }, tipos,
      h('span', { class: 'rotulo-campo', style: { marginTop: tipos ? '14px' : '0' } }, og.qtd > 1 ? `Como colocar as ${og.qtd} fotos` : 'Tamanho na folha'),
      h('div', { class: 'opcoes-mont' }, [[1, 'Folha inteira'], [2, '2 por folha'], [4, '4 por folha'], [6, '6 por folha'], [9, '9 por folha']].map(([pf, rot]) => opcao(m.por_folha === pf, rot, iconeGrade(...GRADE_FOTOS[pf]), () => { m.por_folha = pf; refazer(true); }))),
      h('div', { class: 'linha-vezes' }, h('strong', null, og.qtd > 1 ? 'Vezes cada foto' : 'Quantas vezes a foto'),
        h('div', { class: 'passo' }, h('button', { type: 'button', 'aria-label': 'Uma vez a menos', onclick: () => mudar(-1) }, '−'), saida,
          h('button', { type: 'button', 'aria-label': 'Uma vez a mais', onclick: () => mudar(1) }, '+'))),
      interruptor('Preencher o espaço', 'Corta as bordas da foto para não sobrar espaço em branco.', m.cortar, (v) => { m.cortar = v; refazer(true); }),
      m.por_folha > 1 ? h('p', { class: 'dica' }, 'A foto gira sozinha quando fica bem maior assim. Entre as fotos sai um tracejado para recortar.') : null);
  }
  return h('div', { class: 'bloco montagem' },
    h('span', { class: 'rotulo-campo' }, 'Páginas por folha'),
    h('div', { class: 'opcoes-mont tres' }, [[1, '1 por folha'], [2, '2 por folha'], [4, '4 por folha']].map(([pf, rot]) => opcao(m.pdf_por_folha === pf, rot, iconeGrade(...GRADE_PAGINAS[pf]), () => { m.pdf_por_folha = pf; refazer(true); }, pf > 1 && !og.renderizador))),
    h('p', { class: 'dica' }, !og.renderizador ? 'Para 2 ou 4 por folha, instale o Poppler ou o Ghostscript no computador do sistema (veja o LEIA-ME).'
      : m.pdf_por_folha > 1 ? 'As páginas ficam menores, lado a lado. A cota conta as folhas que saem.' : 'Junte 2 ou 4 páginas em cada folha para gastar menos papel.'),
    og.paginas === 1 ? h('p', { class: 'dica' }, 'É uma foto? Quem imprime pela impressora do celular manda a foto já como página pronta. Para várias fotos por folha ou banner, envie a foto aqui, em Escolher arquivos.') : null);
}

/* ---------------------------------------------------------------- finalidade, prova e conferência antes de imprimir */

// troca o conteúdo ignorando vazios (replaceChildren escreveria "null" na tela)
function encher(el, ...itens) { el.replaceChildren(...itens.flat(Infinity).filter((x) => x != null && x !== false)); return el; }

function paginasIntervalo(txt, total) {
  const todas = () => Array.from({ length: total }, (_, i) => i + 1);
  txt = (txt || '').replace(/\s/g, '').replace(/;/g, ',');
  if (!txt) return todas();
  const s = new Set();
  for (const parte of txt.split(',')) {
    const m = parte.match(/^(\d+)(?:-(\d+))?$/); if (!m) continue;
    let a = +m[1], b = +(m[2] || m[1]); if (a > b) [a, b] = [b, a];
    for (let i = Math.max(1, a); i <= Math.min(total, b); i++) s.add(i);
  }
  return s.size ? [...s].sort((x, y) => x - y) : todas();
}

function textoIntervalo(lista) {
  const partes = []; let ini = lista[0], ant = lista[0];
  for (const p of lista.slice(1).concat([null])) {
    if (p === ant + 1) { ant = p; continue; }
    partes.push(ini === ant ? String(ini) : `${ini} a ${ant}`); ini = ant = p;
  }
  return partes.join(', ');
}

// mesma divisão que o servidor faz: a prova sai agora, o resto espera a conferência
function planoProva(pags, copias, fv, prova) {
  if (prova === 'folha') {
    const k = fv && pags.length >= 2 ? 2 : 1;
    if (pags.length <= k && copias === 1) return null;
    return { prova: k, resto: (pags.length - k) + pags.length * (copias - 1) };
  }
  if (prova === 'copia') return copias > 1 ? { prova: pags.length, resto: pags.length * (copias - 1) } : null;
  return null;
}

function nomeFinalidade(id) { const f = E.eu.controle.finalidades.find((x) => x.id === id); return f ? f.nome : ''; }
function previaAtiva() { const c = E.eu.controle; return c.previa === 'obrigatoria' || (c.previa === 'opcional' && E.eu.prefs.previa); }
function provaObrigatoria(total) { const c = E.eu.controle; return c.prova === 'acima' && total > 1 && total >= c.prova_minimo; }
// Cota negativa: quantas páginas passam da cota e se a gestão deixa imprimir assim (com justificativa)
function alemDaCota(s, usar) {
  const falta = usar - Math.max(s ? s.restante : 0, 0);
  const neg = E.eu.negativo || { resta: 0 };
  return { falta: Math.max(0, falta), pode: falta > 0 && neg.resta >= falta, desconta: !!neg.desconta };
}

function pedirTexto({ titulo, texto, rotulo, placeholder, botao, minimo = 5 }) {
  return new Promise((resolver) => {
    let feito = false;
    folha((f, fechar) => {
      const campo = h('textarea', { rows: '3', maxlength: '500', placeholder: placeholder || '' });
      const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '10px', marginBottom: '0' } });
      const ok = h('button', { class: 'btn' }, botao);
      ok.onclick = () => {
        const v = campo.value.trim();
        if (v.length < minimo) { erro.textContent = 'Escreva um pouco mais: fica registrado com a impressão.'; erro.classList.remove('oculto'); campo.focus(); return; }
        feito = true; fechar(); resolver(v);
      };
      f.append(h('h2', null, titulo), h('p', { class: 'mudo', style: { marginTop: '6px' } }, texto),
        h('label', { class: 'campo' }, h('span', null, rotulo), campo), erro,
        h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: () => { fechar(); } }, 'Voltar'), ok));
      focarDepois(campo);
    }, () => { if (!feito) resolver(null); });
  });
}

// Imprime; se a cota não der e a gestão permitir passar, pede a justificativa e tenta de novo
async function apiImprimir(caminho, corpo) {
  try { return await api(caminho, corpo); } catch (e) {
    if (e.codigo !== 'pode_negativo') throw e;
    const just = await pedirTexto({
      titulo: 'Imprimir além da cota?', texto: e.message, rotulo: 'Justificativa (a gestão vê)',
      placeholder: L('exemplo_alem'), botao: `Imprimir ${pag(e.dados.falta)} além`,
    });
    if (!just) throw new ErroApi('Impressão cancelada. Nada foi descontado.', 0, 'cancelado');
    return api(caminho, { ...corpo, alem: just });
  }
}

// Ações da gestão: se passar da cota do setor e quem está acima deixou, pede a justificativa e tenta de novo
async function apiGestao(caminho, corpo, campo = 'justificativa') {
  try { return await api(caminho, corpo); } catch (e) {
    if (e.codigo !== 'justificar_setor') throw e;
    const just = await pedirTexto({
      titulo: 'Passar da cota do setor?', texto: e.message, rotulo: 'Justificativa (a TI vê)',
      placeholder: 'Ex.: setor novo, campanha de vacinação', botao: 'Passar da cota',
    });
    if (!just) throw new ErroApi('Nada foi mudado.', 0, 'cancelado');
    return api(caminho, { ...corpo, [campo]: just });
  }
}

function folhaAumento({ impressora_id, paginas }) {
  folha((f, fechar) => {
    const st = { impressora_id: impressora_id || (E.eu.saldos[0] || {}).impressora_id };
    const qtd = h('input', { type: 'number', inputmode: 'numeric', min: '1', value: String(paginas || 10) });
    const just = h('textarea', { rows: '3', maxlength: '500', placeholder: L('exemplo_aumento') });
    const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '10px', marginBottom: '0' } });
    const btn = h('button', { class: 'btn' }, 'Pedir aumento');
    btn.onclick = async () => {
      botaoCarregando(btn); erro.classList.add('oculto');
      try {
        await api('/api/aumento/pedir', { impressora_id: st.impressora_id, paginas: Number(qtd.value || 0), justificativa: just.value });
        fechar(); avisar('Pedido enviado à gestão. A resposta aparece no Início.'); atualizarEu(true);
      } catch (e) { botaoPronto(btn); erro.textContent = e.message; erro.classList.remove('oculto'); }
    };
    f.append(h('h2', null, 'Pedir aumento de cota'),
      h('p', { class: 'mudo', style: { marginTop: '6px' } }, 'A gestão vê o pedido com a sua justificativa e decide. Se aprovar, as páginas entram na sua cota deste mês.'),
      E.eu.saldos.length > 1 ? h('div', { class: 'campo' }, h('span', null, 'Em qual impressora?'), escolhaImpressora(st, () => {})) : null,
      h('label', { class: 'campo' }, h('span', null, 'Quantas páginas a mais?'), qtd),
      h('label', { class: 'campo' }, h('span', null, 'Para que você precisa?'), just), erro,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar'), btn));
  });
}

function faixasAumento() {
  return (E.eu.aumentos || []).slice(0, 2).map((a) => {
    const txt = a.status === 'pendente' ? `Seu pedido de ${pag(a.paginas)} a mais na ${curto(a.impressora)} está com a gestão.`
      : a.status === 'aprovado' ? `Aumento aprovado: ${pag(a.aprovadas)} a mais na ${curto(a.impressora)}.${a.decisao ? ' ' + a.decisao : ''}`
        : a.status === 'recusado' ? `Pedido de aumento na ${curto(a.impressora)} não aprovado: ${a.decisao}` : null;
    if (!txt) return null;
    return h('div', { class: 'faixa ' + (a.status === 'recusado' ? 'erro' : a.status === 'aprovado' ? 'ok' : 'info') }, txt,
      a.status === 'pendente' ? h('button', { class: 'btn-texto pequeno', style: { marginLeft: '8px' }, onclick: async () => { await api('/api/aumento/cancelar', { id: a.id }); atualizarEu(true); } }, 'Cancelar') : null);
  });
}

function provaInicial() { return E.eu.prefs.prova_sempre && E.eu.controle.prova !== 'desligada' ? 'folha' : ''; }

function extensaoDe(nome) { const e = String(nome).split('.'); return e.length > 1 ? e.pop().toUpperCase().slice(0, 4) : 'DOC'; }
// tipos que o app aceita; os tipos MIME ajudam o seletor de arquivos do celular a mostrar planilhas e apresentações
const TIPOS_MIME = ['application/pdf', 'image/jpeg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.oasis.opendocument.text',
  'application/vnd.oasis.opendocument.spreadsheet', 'application/vnd.oasis.opendocument.presentation', 'application/rtf', 'text/rtf'];
function aceitarArquivos() { return [...((E.eu && E.eu.extensoes) || ['.pdf', '.jpg', '.jpeg', '.png']), ...TIPOS_MIME].join(','); }

// mesma regra do servidor para vários arquivos: a prova escolhida vale para cada um,
// e quem passa do limite da prova obrigatória sai só com a 1ª folha
function planoLote(itens, prova) {
  let agora = 0, resto = 0, arquivos = 0;
  for (const it of itens) {
    const total = it.pags.length * it.copias;
    let pl = prova ? planoProva(it.pags, it.copias, it.fv, prova) : null;
    if (!pl && provaObrigatoria(total) && total > 2) pl = planoProva(it.pags, it.copias, it.fv, 'folha');
    if (pl) { agora += pl.prova; resto += pl.resto; arquivos++; } else agora += total;
  }
  return arquivos ? { prova: agora, resto, arquivos } : null;
}

function campoProvaLote(st, info, aoMudar) {
  const caixa = h('div', { class: 'campo prova-campo' });
  function desenhar() {
    const c = E.eu.controle;
    const itens = info();
    if (c.prova === 'desligada' || !itens.length) { st.prova = ''; encher(caixa); caixa.classList.add('oculto'); return; }
    caixa.classList.remove('oculto');
    const copias = Math.max(...itens.map((it) => it.copias));
    const opcoes = [['', 'Imprimir tudo'], ['folha', 'Só a 1ª folha de cada']];
    if (copias > 1) opcoes.push(['copia', 'Só 1 cópia de cada']);
    if (st.prova === 'copia' && copias <= 1) st.prova = '';
    const segs = h('div', { class: 'segmentos compactos' }, opcoes.map(([v, r]) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(st.prova === v), disabled: v !== '' && !itens.some((it) => planoProva(it.pags, it.copias, it.fv, v)) }, r);
      b.onclick = () => { st.prova = v; desenhar(); if (aoMudar) aoMudar(); };
      return b;
    }));
    const plano = planoLote(itens, st.prova);
    const obrig = c.prova === 'acima' ? itens.filter((it) => provaObrigatoria(it.pags.length * it.copias) && it.pags.length * it.copias > 2).length : 0;
    const dica = plano
      ? `Agora sai ${pag(plano.prova)}. O resto (${pag(plano.resto)}) espera você conferir ${plano.arquivos === 1 ? 'a prova' : `as provas dos ${plano.arquivos} arquivos`}.`
      : 'Para conferir lados e orientação antes de gastar a cota toda, imprima só a 1ª folha de cada arquivo.';
    encher(caixa, h('span', { class: 'rotulo-campo' }, 'Conferir antes?'), segs, h('div', { class: 'dica' }, dica),
      obrig && !st.prova ? h('div', { class: 'dica' }, `${Lc('o')} pede uma prova a partir de ${pag(c.prova_minimo)}: ${obrig === 1 ? '1 arquivo sai' : `${obrig} arquivos saem`} só com a 1ª folha até você conferir.`) : null);
  }
  desenhar();
  return { el: caixa, atualizar: desenhar };
}

function arrumarTexto(t) {
  t = String(t || '').replace(/\s+/g, ' ').trim().slice(0, 120).trim();
  return t ? t[0].toLocaleUpperCase('pt-BR') + t.slice(1).toLocaleLowerCase('pt-BR') : '';
}
function tituloFinalidade() { return E.eu.controle.forma === 'livre' ? 'O que é?' : 'Para que é?'; }
function textoFinalidade(fin, desc) {
  const d = (desc || '').trim();
  return fin === 'livre' ? d : nomeFinalidade(fin) + (d ? `: ${d}` : '');
}

/* "O que é?" em campo livre (2.6.0): a pessoa escreve em poucas palavras; os últimos textos dela viram atalhos */
function campoFinalidadeLivre(st, aoMudar) {
  const c = E.eu.controle;
  if (st.finalidade !== 'pessoal') st.finalidade = 'livre';
  const mudou = () => { if (aoMudar) aoMudar(); };
  const campo = h('input', { type: 'text', maxlength: '120', value: st.descricao || '', placeholder: L('exemplo_desc'), autocapitalize: 'sentences', enterkeyhint: 'done' });
  const rot = h('span');
  const dicaPessoal = h('div', { class: 'dica oculto' });
  campo.oninput = () => { st.descricao = campo.value; mudou(); };
  campo.onchange = () => { campo.value = st.descricao = arrumarTexto(campo.value); mudou(); };
  const recentes = (c.recentes || []).length ? h('div', { class: 'fin-recentes', role: 'group', 'aria-label': 'Usados antes' },
    c.recentes.map((t) => h('button', { type: 'button', onclick: () => { campo.value = st.descricao = t; mudou(); } }, t))) : null;
  const pessoal = h('input', { type: 'checkbox', checked: st.finalidade === 'pessoal' });
  function atualizar() {
    const ehPessoal = st.finalidade === 'pessoal';
    rot.textContent = ehPessoal ? 'Escreva o que é (opcional)' : 'Escreva o que é';
    dicaPessoal.classList.toggle('oculto', !ehPessoal);
    dicaPessoal.textContent = c.limite_pessoal == null ? 'Conta na sua cota normal e aparece como pessoal para a gestão.'
      : `Até ${pag(c.limite_pessoal)} pessoais por mês. Você já usou ${n(c.pessoal_usado)}.`;
  }
  pessoal.onchange = () => { st.finalidade = pessoal.checked ? 'pessoal' : 'livre'; atualizar(); mudou(); };
  atualizar();
  return h('div', { class: 'finalidade livre' },
    h('label', { class: 'campo' }, rot, campo),
    recentes,
    c.limite_pessoal === 0 ? null : h('label', { class: 'interruptor', style: { marginTop: '10px' } },
      h('span', null, h('strong', null, 'É documento pessoal'), h('div', { class: 'dica', style: { marginTop: '0' } }, 'Uso particular, fora do trabalho.')), pessoal),
    dicaPessoal,
    h('div', { class: 'dica' }, 'A gestão vê, para cada impressão, quem imprimiu, o nome do arquivo e o que era.'));
}

function campoFinalidade(st, aoMudar) {
  const c = E.eu.controle;
  if (c.forma === 'livre') return campoFinalidadeLivre(st, aoMudar);
  const desc = h('input', { type: 'text', maxlength: '200', value: st.descricao || '', placeholder: L('exemplo_desc') });
  const rotDesc = h('span');
  const dicaPessoal = h('div', { class: 'dica oculto' });
  const opcoes = h('div', { class: 'fin-opcoes', role: 'group', 'aria-label': 'Para que é' }, c.finalidades.map((f) => {
    const b = h('button', { type: 'button', 'aria-pressed': String(st.finalidade === f.id) }, h('strong', null, f.nome), h('span', null, f.dica));
    b.onclick = () => { st.finalidade = f.id; opcoes.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); atualizar(); if (aoMudar) aoMudar(); };
    return b;
  }));
  desc.oninput = () => { st.descricao = desc.value; if (aoMudar) aoMudar(); };
  function atualizar() {
    const precisa = st.finalidade === 'outro' || c.descricao === 'sempre';
    rotDesc.textContent = precisa ? 'Do que se trata?' : 'Do que se trata? (opcional)';
    dicaPessoal.classList.toggle('oculto', st.finalidade !== 'pessoal');
    dicaPessoal.textContent = c.limite_pessoal === 0 ? `${Lc('o')} não libera a impressão de documentos pessoais.`
      : c.limite_pessoal == null ? 'Conta na sua cota normal e aparece como pessoal para a gestão.'
        : `Até ${pag(c.limite_pessoal)} pessoais por mês. Você já usou ${n(c.pessoal_usado)}.`;
  }
  atualizar();
  return h('div', { class: 'finalidade' }, opcoes, h('label', { class: 'campo' }, rotDesc, desc), dicaPessoal,
    h('div', { class: 'dica' }, 'A gestão vê, para cada impressão, quem imprimiu, o nome do arquivo e para que era.'));
}

function problemaFinalidade(st, total, pede) {
  if (!pede) return null;
  const c = E.eu.controle;
  if (c.forma === 'livre' && st.finalidade !== 'pessoal') return arrumarTexto(st.descricao).length < 3 ? 'Escreva o que é esta impressão, em poucas palavras.' : null;
  if (!st.finalidade) return 'Escolha para que é esta impressão.';
  if (!(st.descricao || '').trim() && (st.finalidade === 'outro' || c.descricao === 'sempre')) return 'Escreva em poucas palavras do que se trata.';
  if (st.finalidade === 'pessoal' && c.limite_pessoal != null) {
    if (c.limite_pessoal === 0) return `${Lc('o')} não libera a impressão de documentos pessoais.`;
    if (c.pessoal_usado + total > c.limite_pessoal) return `Documentos pessoais: até ${pag(c.limite_pessoal)} por mês. Você já usou ${n(c.pessoal_usado)} e esta impressão tem ${n(total)}.`;
  }
  return null;
}

function campoProva(st, info, aoMudar) {
  const caixa = h('div', { class: 'campo prova-campo' });
  function desenhar() {
    const c = E.eu.controle;
    const { pags, copias, fv } = info();
    const total = pags.length * copias;
    if (c.prova === 'desligada' || total <= 1) { st.prova = ''; encher(caixa, ); caixa.classList.add('oculto'); return; }
    caixa.classList.remove('oculto');
    const obrig = provaObrigatoria(total);
    const opcoes = [['', 'Imprimir tudo'], ['folha', fv && pags.length >= 2 ? 'Só a 1ª folha' : 'Só a 1ª página']];
    if (copias > 1) opcoes.push(['copia', 'Só 1 cópia']);
    if (st.prova && !planoProva(pags, copias, fv, st.prova)) st.prova = '';
    if (obrig && !st.prova) st.prova = 'folha';
    const segs = h('div', { class: 'segmentos compactos' }, opcoes.map(([v, r]) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(st.prova === v), disabled: (v === '' && obrig) || (v !== '' && !planoProva(pags, copias, fv, v)) }, r);
      b.onclick = () => { st.prova = v; desenhar(); if (aoMudar) aoMudar(); };
      return b;
    }));
    const plano = planoProva(pags, copias, fv, st.prova);
    const dica = plano
      ? `Sai ${pag(plano.prova)} para você conferir. O resto (${pag(plano.resto)}) só sai depois que você disser que ficou certo.`
      : 'Para conferir lados, orientação e páginas antes de gastar a cota toda, imprima uma prova.';
    encher(caixa, h('span', { class: 'rotulo-campo' }, 'Conferir antes?'), segs, h('div', { class: 'dica' }, dica),
      obrig ? h('div', { class: 'dica' }, `${Lc('o')} pede uma prova a partir de ${pag(c.prova_minimo)}.`) : null);
  }
  desenhar();
  return { el: caixa, atualizar: desenhar };
}

// Janela de conferência: prévia das folhas como vão sair, lados, orientação, cópias e total.
function folhaConfirmar(o) {
  const obrig = E.eu.controle.previa === 'obrigatoria';
  const q = `origem=${o.origem}&id=${encodeURIComponent(o.id)}`;
  const provaAtual = () => (typeof o.prova === 'function' ? o.prova() : o.prova);
  folha((f, fechar) => {
    const st = { fv: o.fv, orient: { retrato: 0, paisagem: 0, vistas: 0 }, marcado: {} };
    const area = h('div', { class: 'previa-area' }, h('div', { class: 'bloco vazio' }, h('span', { class: 'carregando' }), ' Preparando a prévia…'));
    const resumo = h('div', { class: 'conf-resumo' });
    const checks = h('div', { class: 'conf-checks' });
    const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '12px', marginBottom: '0' } });
    const btn = h('button', { class: 'btn' });
    let info = null;

    const urlPag = (p) => `/api/previa/pagina?${q}&p=${p}`;
    function img(p) {
      const im = h('img', { src: urlPag(p), alt: `Página ${p}`, loading: 'lazy', decoding: 'async' });
      im.onload = () => {
        st.orient.vistas++;
        if (im.naturalWidth > im.naturalHeight * 1.05) { st.orient.paisagem++; im.classList.add('deitada'); } else st.orient.retrato++;
        desenharResumo();
      };
      im.onerror = () => im.replaceWith(h('div', { class: 'sem-img' }, 'Sem prévia'));
      return im;
    }
    function desenharPrevia() {
      st.orient = { retrato: 0, paisagem: 0, vistas: 0 };
      if (info.erro) { encher(area, h('div', { class: 'faixa erro' }, info.erro)); desenharResumo(); return; }
      if (!info.imagens) {
        encher(area, 
          h('iframe', { class: 'previa-pdf', src: `/api/previa/pdf?${q}#page=${o.pags[0]}`, title: `Prévia de ${o.nome}` }),
          h('p', { class: 'dica' }, 'Se o arquivo não aparecer acima, ', h('a', { href: `/api/previa/pdf?${q}`, target: '_blank', rel: 'noopener' }, 'abra em outra aba'), ' e confira antes de imprimir.'));
        desenharResumo(); return;
      }
      if (o.banner && o.banner.posicoes) {
        const bn = o.banner;
        const grade = h('div', { class: 'banner-previa', style: { gridTemplateColumns: `repeat(${bn.cols}, 1fr)`, aspectRatio: `${bn.cols * (bn.deitadas ? 297 : 210)} / ${bn.lins * (bn.deitadas ? 210 : 297)}` } });
        bn.posicoes.forEach(([i, j], k) => { const im = img(k + 1); im.style.gridRow = String(i + 1); im.style.gridColumn = String(j + 1); grade.append(im); });
        encher(area, grade, h('p', { class: 'dica' }, `Assim fica o banner montado: ${bn.cols} ${bn.cols === 1 ? 'coluna' : 'colunas'} × ${bn.lins} ${bn.lins === 1 ? 'linha' : 'linhas'} de folhas, cerca de ${bn.largura_cm} × ${bn.altura_cm} cm. Cada folha sai com a posição escrita na borda.`));
        desenharResumo(); return;
      }
      const porFolha = st.fv ? 2 : 1;
      const grupos = [];
      for (let i = 0; i < o.pags.length; i += porFolha) grupos.push(o.pags.slice(i, i + porFolha));
      const max = 8;
      encher(area, 
        h('div', { class: 'folhas-previa' + (st.fv ? ' duplas' : '') }, grupos.slice(0, max).map((g, i) => h('figure', { class: 'folha-previa' },
          h('div', { class: 'lados' }, g.map((p, j) => h('div', { class: 'lado' }, o.plano && o.plano.papel_mm ? folhaComPagina(img(p), o.plano, p) : papelEscala(img(p), o.escala), st.fv ? h('span', null, j ? 'verso' : 'frente') : null))),
          h('figcaption', null, `Folha ${i + 1}: ${g.length === 2 ? `págs. ${g[0]} e ${g[1]}` : `pág. ${g[0]}`}`)))),
        grupos.length > max ? h('p', { class: 'dica' }, `E mais ${grupos.length - max} ${grupos.length - max === 1 ? 'folha' : 'folhas'} com as outras páginas.`) : null,
        o.copias > 1 ? h('p', { class: 'dica' }, `Isto é uma cópia. Vão sair ${n(o.copias)} iguais.`) : null);
      desenharResumo();
    }
    function textoOrientacao() {
      const { retrato, paisagem, vistas } = st.orient;
      if (!info || !info.imagens) return 'Confira no arquivo';
      if (!vistas) return 'Carregando…';
      if (!paisagem) return 'Em pé (retrato)';
      if (!retrato) return 'Deitada (paisagem)';
      return `Misturada: ${n(retrato)} em pé e ${n(paisagem)} ${paisagem === 1 ? 'deitada' : 'deitadas'}`;
    }
    function desenharResumo() {
      const sel = o.pags.length, total = sel * o.copias;
      const folhas = (st.fv ? Math.ceil(sel / 2) : sel) * o.copias;
      const plano = planoProva(o.pags, o.copias, st.fv, provaAtual());
      const linha = (rot, ...val) => h('div', { class: 'linha' }, h('span', { class: 'rot' }, rot), h('span', { class: 'val' }, ...val));
      const mudar = sel > 1 && !o.banner ? h('button', {
        type: 'button', class: 'btn-texto pequeno',
        onclick: () => { st.fv = !st.fv; st.marcado.lados = false; o.mudarLados(st.fv); desenharPrevia(); desenharChecks(); },
      }, st.fv ? 'Mudar para só frente' : 'Mudar para frente e verso') : null;
      encher(resumo, 
        linha('Arquivo', o.nome),
        linha('Páginas', sel === o.paginasDoc ? `todas (${n(sel)})` : `${n(sel)} de ${n(o.paginasDoc)}: ${textoIntervalo(o.pags)}`),
        h('div', { class: 'linha lados-linha' }, h('span', { class: 'rot' }, 'Lados'),
          h('span', { class: 'val' }, h('strong', null, st.fv ? 'Frente e verso' : 'Só frente'),
            h('span', { class: 'mudo pequeno' }, st.fv ? ' (2 páginas em cada folha)' : ' (cada página numa folha)'), mudar ? h('br') : null, mudar)),
        linha('Orientação', textoOrientacao()),
        o.escala != null ? linha('Tamanho', textoEscala(o.escala, o.plano)) : null,
        linha('Cópias', n(o.copias)),
        linha('Impressora', o.impressora),
        o.finalidade ? linha(o.finalidade === 'livre' ? 'O que é' : 'Para quê', textoFinalidade(o.finalidade, o.descricao)) : null,
        h('div', { class: 'linha total' }, h('span', { class: 'rot' }, 'Vai usar'), h('span', { class: 'val' }, `${pag(total)} da cota, ${n(folhas)} ${folhas === 1 ? 'folha' : 'folhas'} de papel`)),
        plano ? h('p', { class: 'conf-prova' }, `Primeiro sai só a prova (${pag(plano.prova)}). O resto (${pag(plano.resto)}) espera você conferir.`) : null);
      btn.textContent = plano ? `Imprimir a prova (${pag(plano.prova)})` : `Imprimir ${pag(total)}`;
      atualizarBotao();
    }
    function desenharChecks() {
      if (!obrig) { encher(checks, ); return; }
      const item = (chave, texto) => {
        const c = h('input', { type: 'checkbox', checked: !!st.marcado[chave] });
        c.onchange = () => { st.marcado[chave] = c.checked; atualizarBotao(); };
        return h('label', { class: 'conf-check' }, c, h('span', null, texto));
      };
      const lista = [['paginas', 'As páginas são essas'], ['lados', st.fv ? 'Frente e verso está certo' : 'Só frente está certo'], ['orientacao', 'A orientação está certa']];
      if (o.copias > 1) lista.push(['copias', `São ${n(o.copias)} cópias mesmo`]);
      st.precisa = lista.map(([k]) => k);
      encher(checks, h('p', { class: 'rotulo-campo' }, 'Antes de imprimir, confira e marque:'), lista.map(([k, t]) => item(k, t)));
      atualizarBotao();
    }
    function atualizarBotao() { btn.disabled = obrig && (st.precisa || []).some((k) => !st.marcado[k]); }
    btn.onclick = async () => {
      botaoCarregando(btn, 'Enviando para a impressora…'); erro.classList.add('oculto');
      try { await o.enviar(); fechar(); }
      catch (e) { botaoPronto(btn); desenharResumo(); erro.textContent = e.message; erro.classList.remove('oculto'); }
    };
    f.append(h('h2', null, 'Confira antes de imprimir'),
      h('p', { class: 'mudo pequeno', style: { marginTop: '4px' } }, 'É assim que as folhas vão sair. Se algo estiver errado, volte e ajuste.'),
      area, resumo, checks, erro,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar e ajustar'), btn));
    desenharChecks(); desenharResumo();
    api(`/api/previa?${q}`).then((r) => { info = r; }).catch((e) => { info = { imagens: false, erro: e.message }; }).finally(desenharPrevia);
  });
}

// Conferência de vários arquivos de uma vez (lista do app ou "Liberar todas"): cada arquivo com as primeiras folhas.
function folhaConfirmarLote(o) {
  const obrig = E.eu.controle.previa === 'obrigatoria';
  const provaAtual = () => (typeof o.prova === 'function' ? o.prova() : o.prova);
  const q = (it) => `origem=${it.origem}&id=${encodeURIComponent(it.id)}`;
  folha((f, fechar) => {
    const st = { orient: { retrato: 0, paisagem: 0, vistas: 0 }, marcado: {} };
    const area = h('div', { class: 'previa-area' }, h('div', { class: 'bloco vazio' }, h('span', { class: 'carregando' }), ' Preparando a prévia…'));
    const resumo = h('div', { class: 'conf-resumo' });
    const checks = h('div', { class: 'conf-checks' });
    const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '12px', marginBottom: '0' } });
    const btn = h('button', { class: 'btn' });
    let info = null;
    const ladosDe = () => new Set(o.itens.map((it) => !!it.fv));
    function img(it, p) {
      const im = h('img', { src: `/api/previa/pagina?${q(it)}&p=${p}`, alt: `${it.nome}, página ${p}`, loading: 'lazy', decoding: 'async' });
      im.onload = () => {
        st.orient.vistas++;
        if (im.naturalWidth > im.naturalHeight * 1.05) { st.orient.paisagem++; im.classList.add('deitada'); } else st.orient.retrato++;
        desenharResumo();
      };
      im.onerror = () => im.replaceWith(h('div', { class: 'sem-img' }, 'Sem prévia'));
      return im;
    }
    function desenharPrevia() {
      st.orient = { retrato: 0, paisagem: 0, vistas: 0 };
      if (!info.imagens) {
        encher(area, info.erro ? h('div', { class: 'faixa erro' }, info.erro) : null,
          h('ul', { class: 'lote-links' }, o.itens.map((it) => h('li', null, h('a', { href: `/api/previa/pdf?${q(it)}`, target: '_blank', rel: 'noopener' }, it.nome), ` (${pag(it.pags.length)})`))),
          h('p', { class: 'dica' }, 'Abra cada arquivo e confira antes de imprimir.'));
        desenharResumo(); return;
      }
      const max = 3, misturado = ladosDe().size > 1;
      encher(area, o.itens.map((it) => {
        const porFolha = it.fv ? 2 : 1;
        const grupos = [];
        for (let i = 0; i < it.pags.length; i += porFolha) grupos.push(it.pags.slice(i, i + porFolha));
        const extra = [pag(it.pags.length)];
        if (it.copias > 1) extra.push(`${n(it.copias)} cópias`);
        if (misturado) extra.push(it.fv ? 'frente e verso' : 'só frente');
        return h('section', { class: 'lote-previa' },
          h('h3', null, h('span', { class: 'nome-arq' }, it.nome), h('span', { class: 'mudo pequeno' }, extra.join(', '))),
          h('div', { class: 'folhas-previa' + (it.fv ? ' duplas' : '') }, grupos.slice(0, max).map((g, i) => h('figure', { class: 'folha-previa' },
            h('div', { class: 'lados' }, g.map((p, j) => h('div', { class: 'lado' }, papelEscala(img(it, p), it.foto ? '' : o.escala), it.fv ? h('span', null, j ? 'verso' : 'frente') : null))),
            h('figcaption', null, `Folha ${i + 1}`)))),
          grupos.length > max ? h('p', { class: 'dica' }, `E mais ${grupos.length - max} ${grupos.length - max === 1 ? 'folha' : 'folhas'} deste arquivo.`) : null);
      }));
      desenharResumo();
    }
    function textoOrientacao() {
      const { retrato, paisagem, vistas } = st.orient;
      if (!info || !info.imagens) return 'Confira nos arquivos';
      if (!vistas) return 'Carregando…';
      if (!paisagem) return 'Em pé (retrato)';
      if (!retrato) return 'Deitada (paisagem)';
      return `Misturada: ${n(retrato)} em pé e ${n(paisagem)} ${paisagem === 1 ? 'deitada' : 'deitadas'}`;
    }
    function desenharResumo() {
      const pags = o.itens.reduce((a, it) => a + it.pags.length, 0);
      const total = o.itens.reduce((a, it) => a + it.pags.length * it.copias, 0);
      const folhas = o.itens.reduce((a, it) => a + (it.fv ? Math.ceil(it.pags.length / 2) : it.pags.length) * it.copias, 0);
      const plano = planoLote(o.itens, provaAtual());
      const lad = ladosDe(), fvTodos = [...lad][0];
      const copias = new Set(o.itens.map((it) => it.copias));
      const linha = (rot, ...val) => h('div', { class: 'linha' }, h('span', { class: 'rot' }, rot), h('span', { class: 'val' }, ...val));
      const mudar = o.mudarLados && lad.size === 1 && o.itens.some((it) => it.pags.length > 1) ? h('button', {
        type: 'button', class: 'btn-texto pequeno',
        onclick: () => { const v = !fvTodos; o.itens.forEach((it) => { it.fv = v; }); st.marcado.lados = false; o.mudarLados(v); desenharPrevia(); desenharChecks(); },
      }, fvTodos ? 'Mudar para só frente' : 'Mudar para frente e verso') : null;
      encher(resumo,
        linha('Arquivos', `${n(o.itens.length)} arquivos, ${pag(pags)} ao todo`),
        h('div', { class: 'linha lados-linha' }, h('span', { class: 'rot' }, 'Lados'),
          h('span', { class: 'val' }, lad.size === 1
            ? [h('strong', null, fvTodos ? 'Frente e verso' : 'Só frente'), h('span', { class: 'mudo pequeno' }, fvTodos ? ' (2 páginas em cada folha)' : ' (cada página numa folha)')]
            : h('strong', null, 'Cada arquivo do seu jeito (veja acima)'), mudar ? h('br') : null, mudar)),
        linha('Orientação', textoOrientacao()),
        o.escala ? linha('Tamanho', `${textoEscala(o.escala)}${o.itens.some((it) => it.foto) ? ' (as fotos saem como sempre)' : ''}`) : null,
        linha('Cópias', copias.size === 1 ? `${n(o.itens[0].copias)} de cada arquivo` : 'Cada arquivo com as suas (veja acima)'),
        linha('Impressora', o.impressora),
        o.finalidade ? linha(o.finalidade === 'livre' ? 'O que é' : 'Para quê', textoFinalidade(o.finalidade, o.descricao)) : null,
        h('div', { class: 'linha total' }, h('span', { class: 'rot' }, 'Vai usar'), h('span', { class: 'val' }, `${pag(total)} da cota, ${n(folhas)} ${folhas === 1 ? 'folha' : 'folhas'} de papel`)),
        plano ? h('p', { class: 'conf-prova' }, `Agora sai ${pag(plano.prova)}. O resto (${pag(plano.resto)}) espera você conferir ${plano.arquivos === 1 ? 'a prova' : `as provas de ${plano.arquivos} arquivos`}.`) : null);
      btn.textContent = plano ? `Imprimir ${pag(plano.prova)} agora` : `Imprimir ${pag(total)}`;
      atualizarBotao();
    }
    function desenharChecks() {
      if (!obrig) { encher(checks); return; }
      const item = (chave, texto) => {
        const c = h('input', { type: 'checkbox', checked: !!st.marcado[chave] });
        c.onchange = () => { st.marcado[chave] = c.checked; atualizarBotao(); };
        return h('label', { class: 'conf-check' }, c, h('span', null, texto));
      };
      const lad = ladosDe(), copias = new Set(o.itens.map((it) => it.copias));
      const lista = [['arquivos', `Os ${o.itens.length} arquivos são esses`],
        ['lados', lad.size > 1 ? 'Os lados de cada arquivo estão certos' : [...lad][0] ? 'Frente e verso está certo' : 'Só frente está certo'],
        ['orientacao', 'A orientação está certa']];
      if (o.itens.some((it) => it.copias > 1)) lista.push(['copias', copias.size === 1 ? `São ${n(o.itens[0].copias)} cópias de cada mesmo` : 'As cópias de cada arquivo estão certas']);
      st.precisa = lista.map(([k]) => k);
      encher(checks, h('p', { class: 'rotulo-campo' }, 'Antes de imprimir, confira e marque:'), lista.map(([k, t]) => item(k, t)));
      atualizarBotao();
    }
    function atualizarBotao() { btn.disabled = obrig && (st.precisa || []).some((k) => !st.marcado[k]); }
    btn.onclick = async () => {
      botaoCarregando(btn, 'Enviando para a impressora…'); erro.classList.add('oculto');
      try { await o.enviar(); fechar(); }
      catch (e) { if (!f.isConnected) return; botaoPronto(btn); desenharResumo(); erro.textContent = e.message; erro.classList.remove('oculto'); }
    };
    f.append(h('h2', null, 'Confira antes de imprimir'),
      h('p', { class: 'mudo pequeno', style: { marginTop: '4px' } }, 'É assim que as folhas vão sair. Cada arquivo começa numa folha nova. Se algo estiver errado, volte e ajuste.'),
      area, resumo, checks, erro,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar e ajustar'), btn));
    desenharChecks(); desenharResumo();
    api(`/api/previa?${q(o.itens[0])}`).then((r) => { info = r; }).catch((e) => { info = { imagens: false, erro: e.message }; }).finally(desenharPrevia);
  });
}

function cartaoConferencia(c) {
  const btnSim = h('button', { class: 'btn largo' }, 'Saiu certo: imprimir o resto');
  const btnAjustar = h('button', { class: 'btn claro pequeno' }, 'Ajustar');
  const btnCancelar = h('button', { class: 'btn claro pequeno' }, 'Cancelar o resto');
  const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '12px', marginBottom: '0' } });
  btnSim.onclick = async () => {
    botaoCarregando(btnSim, 'Enviando o resto…'); erro.classList.add('oculto');
    try {
      const r = await api('/api/conferencia/continuar', { id: c.id });
      E.ultimoResultado = r; E.imp = null;
      await atualizarEu();
      if (location.hash.startsWith('#imprimir')) telaImprimir(); else location.hash = '#imprimir';
    } catch (e) { botaoPronto(btnSim); erro.textContent = e.message; erro.classList.remove('oculto'); if (/não está mais esperando/.test(e.message)) atualizarEu(true); }
  };
  btnAjustar.onclick = async () => {
    try {
      const r = await api('/api/conferencia/ajustar', { id: c.id });
      E.ultimoResultado = null;
      E.imp = { upload: r.upload, impressora_id: r.impressora_id, copias: 1, modo: 'todas', intervalo: '', frente_verso: c.frente_verso, enviando: false, finalidade: r.finalidade, descricao: r.descricao, prova: provaInicial() };
      await atualizarEu();
      avisar('Ajuste páginas, lados e cópias e imprima de novo.');
      if (location.hash.startsWith('#imprimir')) telaImprimir(); else location.hash = '#imprimir';
    } catch (e) { avisar(e.message, true); atualizarEu(true); }
  };
  btnCancelar.onclick = async () => {
    if (!(await confirmar('Cancelar o resto?', `O resto de "${c.nome}" não será impresso e o arquivo é apagado. A prova já saiu e continua contada.`, 'Cancelar o resto', true))) return;
    try { await api('/api/conferencia/cancelar', { id: c.id }); avisar('Resto cancelado.'); E.ultimoResultado = null; await atualizarEu(true); if (location.hash.startsWith('#imprimir')) telaImprimir(); }
    catch (e) { avisar(e.message, true); }
  };
  return h('section', { class: 'bloco conferencia', style: { '--cor': c.cor || 'var(--tinta)' } },
    h('strong', { class: 'conf-titulo' }, 'Confira a prova na impressora'),
    h('p', { class: 'mudo pequeno', style: { marginTop: '4px' } },
      `"${c.nome}": saiu ${c.prova === 'copia' ? '1 cópia' : (c.prova_total === 2 ? 'a 1ª folha (frente e verso)' : 'a 1ª página')} na ${c.impressora || 'impressora'}. `,
      `Veja se os lados, a orientação e as páginas estão certos. O resto (${pag(c.resto_total)}) espera até ${hora(c.expira_em)}. `,
      'Se saiu errado, toque em Ajustar: o arquivo volta para você mudar lados, páginas ou cópias.'),
    btnSim, erro, h('div', { class: 'linha-botoes', style: { marginTop: '8px' } }, btnAjustar, btnCancelar));
}

function blocoConferencias() {
  const lista = E.eu.conferencias || [];
  return lista.length ? h('div', { class: 'conferencias' }, lista.map(cartaoConferencia)) : null;
}

/* ---------------------------------------------------------------- impressões aguardando liberação */

async function carregarRetidas() {
  try {
    const r = await api('/api/retidas');
    E.retidas = r.retidas; E.horasFila = r.horas; E.retidasEm = Date.now();
  } catch (e) { return; }
  const caixa = document.getElementById('retidas');
  if (caixa) caixa.replaceChildren(blocoRetidas());
}

function blocoRetidas() {
  const lista = E.retidas || [];
  if (!lista.length) {
    return h('div', { class: 'bloco como-imprimir' },
      h('strong', null, 'Imprima de qualquer programa'),
      h('p', { class: 'mudo pequeno', style: { marginTop: '4px' } }, E.eu && E.eu.so_conectado
        ? 'Deixe o app aberto neste aparelho e, em qualquer programa, escolha a impressora "Folha a Folha" e imprima como sempre. O documento aparece aqui, só para você, para escolher a impressora e liberar.'
        : 'No computador ou no celular, escolha a impressora "Folha a Folha" e imprima como sempre. O documento aparece aqui para você escolher a impressora e liberar.'),
      h('button', { class: 'btn-texto pequeno', onclick: () => folhaComoInstalar() }, 'Como adicionar a impressora Folha a Folha'));
  }
  const todas = lista.length > 1 ? h('div', { class: 'bloco liberar-todas' },
    h('div', null, h('strong', null, `Liberar as ${lista.length} de uma vez`),
      h('p', { class: 'mudo pequeno' }, 'Mesma impressora e mesma finalidade. Cada uma sai com as cópias e os lados do cartão.')),
    h('button', { class: 'btn', onclick: () => folhaLiberarTodas(lista.slice(0, E.eu.max_lote || 20)) }, 'Liberar todas')) : null;
  return h('div', null,
    h('h2', { class: 'titulo-secao' }, lista.length === 1 ? 'Aguardando você' : `Aguardando você (${lista.length})`),
    todas,
    lista.map(cartaoRetida),
    h('p', { class: 'dica' }, `O que não for liberado em ${E.horasFila || 4} horas é apagado sem gastar páginas.`));
}

function textoRetida(r) {
  const partes = [r.paginas_sel !== r.paginas ? `${pag(r.paginas_sel)} de ${n(r.paginas)} (${r.intervalo})` : pag(r.paginas)];
  partes.push(r.frente_verso ? 'pediu frente e verso' : 'só frente');
  partes.push(`chegou ${rotuloDia(r.criado_em).toLowerCase()} às ${hora(r.criado_em)}`);
  return partes.join(', ');
}

function cartaoRetida(r) {
  const st = { impressora_id: r.impressora_sugerida, copias: r.copias || 1, frente_verso: !!r.frente_verso, finalidade: '', descricao: '', prova: provaInicial() };
  (E.retidaSt || (E.retidaSt = {}))[r.id] = st;  // "Liberar todas" usa as cópias e os lados de cada cartão
  const pags = r.tipo === 'imagem' ? [1] : paginasIntervalo(r.intervalo, r.paginas);
  const saida = h('output', { class: 'num' }, st.copias);
  const mudar = (d) => { st.copias = Math.max(1, Math.min(E.eu.max_copias, st.copias + d)); saida.textContent = st.copias; atualizar(); };
  const passo = h('div', { class: 'passo' },
    h('button', { type: 'button', 'aria-label': 'Menos uma cópia', onclick: () => mudar(-1) }, '−'), saida,
    h('button', { type: 'button', 'aria-label': 'Mais uma cópia', onclick: () => mudar(1) }, '+'));
  const fv = h('input', { type: 'checkbox', checked: st.frente_verso });
  fv.onchange = () => { st.frente_verso = fv.checked; atualizar(); };
  const escolha = escolhaImpressora(st, () => atualizar());
  const prova = campoProva(st, () => ({ pags, copias: st.copias, fv: st.frente_verso }), () => atualizar());
  const fin = h('div', { class: 'retida-fin' }, h('div', { class: 'retida-rotulo' }, tituloFinalidade()), campoFinalidade(st, () => erro.classList.add('oculto')));
  const resumo = h('p', { class: 'retida-conta', 'aria-live': 'polite' });
  const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '12px', marginBottom: '0' } });
  const btn = h('button', { class: 'btn largo', style: { marginTop: '12px' } }, 'Imprimir');
  const conf = confirmaImpressora(st, () => atualizar());
  const btnPedir = h('button', { class: 'btn claro pequeno oculto' }, 'Pedir páginas');
  const btnAjustar = h('button', { class: 'btn claro pequeno' }, 'Mais opções');
  const btnDescartar = h('button', { class: 'btn claro pequeno' }, 'Descartar');
  const saldoEscolhido = () => E.eu.saldos.find((x) => x.impressora_id === st.impressora_id);

  function atualizar() {
    const s = saldoEscolhido();
    fin.classList.toggle('oculto', !(s && s.pede_finalidade));
    prova.atualizar();
    if (!s) { resumo.textContent = 'Escolha uma impressora.'; btn.disabled = true; return; }
    const usar = r.paginas_sel * st.copias;
    const sobra = s.restante - usar;
    const alem = alemDaCota(s, usar);
    const custo = s.custo_pagina > 0 ? ` (${reais(usar * s.custo_pagina)})` : '';
    resumo.className = 'retida-conta' + (sobra < 0 && !alem.pode ? ' falta' : '');
    resumo.textContent = alem.pode ? `Vai usar ${pag(usar)}${custo}: ${pag(alem.falta)} além da cota, com justificativa.`
      : sobra < 0
        ? `Vai usar ${pag(usar)}${custo}. ${-sobra === 1 ? 'Falta' : 'Faltam'} ${pag(-sobra)} na ${curto(s.nome)}.`
        : `Vai usar ${pag(usar)}${custo}, ${st.frente_verso ? 'frente e verso' : 'só frente'}. Você fica com ${n(sobra)} na ${curto(s.nome)}.`;
    conf.atualizar();
    btn.disabled = (sobra < 0 && !alem.pode) || !conf.ok();
    const plano = planoProva(pags, st.copias, st.frente_verso, st.prova);
    btn.textContent = sobra < 0 && !alem.pode ? 'Páginas insuficientes' : previaAtiva() ? 'Conferir e imprimir' : alem.pode ? 'Imprimir além da cota' : plano ? `Imprimir a prova (${pag(plano.prova)})` : `Imprimir ${pag(usar)}`;
    btnPedir.classList.toggle('oculto', sobra >= 0);
    btnPedir.onclick = () => folhaPedir({ impressora_id: st.impressora_id, paginas: -sobra });
  }

  async function tratarErro(e) {
    erro.textContent = e.message; erro.classList.remove('oculto');
    if (e.codigo === 'sem_cota' || e.codigo === 'pessoal') { await atualizarEu(); atualizar(); erro.textContent = e.message; erro.classList.remove('oculto'); }
    else if (/não está mais aguardando/.test(e.message)) { document.querySelectorAll('.veu').forEach((v) => v.remove()); avisar(e.message, true); carregarRetidas(); }
  }

  btn.onclick = async () => {
    const s = saldoEscolhido(); if (!s || !conf.ok()) return;
    const pede = !!s.pede_finalidade;
    const prob = problemaFinalidade(st, r.paginas_sel * st.copias, pede);
    if (prob) { erro.textContent = prob; erro.classList.remove('oculto'); fin.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
    erro.classList.add('oculto');
    const enviar = async () => {
      const res = await apiImprimir('/api/retidas/liberar', { id: r.id, impressora_id: st.impressora_id, copias: st.copias, frente_verso: st.frente_verso, finalidade: pede ? st.finalidade : '', descricao: st.descricao, prova: st.prova });
      E.ultimoResultado = res; E.retidas = null;
      await atualizarEu();
      if (location.hash.startsWith('#imprimir')) telaImprimir();
    };
    if (previaAtiva()) {
      folhaConfirmar({
        origem: 'retida', id: r.id, nome: r.nome, tipo: r.tipo, paginasDoc: r.paginas, pags, copias: st.copias, fv: st.frente_verso,
        prova: () => st.prova, impressora: s.nome, finalidade: pede ? st.finalidade : '', descricao: st.descricao,
        mudarLados: (v) => { st.frente_verso = v; fv.checked = v; atualizar(); },
        enviar: async () => { try { await enviar(); } catch (e) { tratarErro(e); throw e; } },
      });
      return;
    }
    botaoCarregando(btn, 'Enviando para a impressora…');
    try { await enviar(); } catch (e) { botaoPronto(btn); atualizar(); tratarErro(e); }
  };
  btnAjustar.onclick = async () => {
    try {
      const a = await api('/api/retidas/ajustar', { id: r.id });
      E.imp = { upload: a.upload, impressora_id: st.impressora_id, copias: a.copias, modo: a.intervalo ? 'algumas' : 'todas', intervalo: a.intervalo || '', frente_verso: a.frente_verso, enviando: false, finalidade: st.finalidade, descricao: st.descricao, prova: st.prova };
      E.retidas = null; await atualizarEu(); telaImprimir();
      const alvo = document.querySelector('.arquivo-escolhido'); if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) { avisar(e.message, true); carregarRetidas(); }
  };
  btnDescartar.onclick = async () => {
    const ok = await confirmar('Descartar esta impressão?', `"${r.nome}" sai da fila sem imprimir. Nenhuma página é descontada.`, 'Descartar', true);
    if (!ok) return;
    try { await api('/api/retidas/descartar', { id: r.id }); avisar('Impressão descartada.'); await atualizarEu(); carregarRetidas(); }
    catch (e) { avisar(e.message, true); }
  };
  atualizar();
  return h('section', { class: 'bloco retida' },
    h('div', { class: 'retida-topo' },
      h('div', { class: 'icone-doc' }, r.tipo === 'imagem' ? 'IMG' : 'PDF'),
      h('div', { style: { flex: '1', minWidth: '0' } }, h('div', { class: 'nome-arq' }, r.nome), h('div', { class: 'mudo pequeno' }, textoRetida(r)))),
    h('div', { class: 'retida-copias' }, h('strong', null, 'Cópias'), passo),
    pags.length > 1 || r.tipo !== 'imagem' ? h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Frente e verso'),
      h('div', { class: 'dica', style: { marginTop: '0' } }, r.frente_verso ? 'Veio marcado do computador. Desligue se quiser só frente.' : 'Gasta menos papel. A cota conta cada lado impresso.')), fv) : null,
    prova.el,
    h('div', { class: 'retida-rotulo' }, 'Em qual impressora?'),
    escolha, fin, resumo, conf.el, erro, btn,
    h('div', { class: 'linha-botoes', style: { marginTop: '8px' } }, btnPedir, r.tipo === 'pdf' ? btnAjustar : null, btnDescartar));
}

function folhaLiberarTodas(lista) {
  const est = E.retidaSt || {};
  const itens = lista.map((r) => {
    const c = est[r.id] || {};
    return { r, origem: 'retida', id: r.id, nome: r.nome, paginas: r.paginas, pags: r.tipo === 'imagem' ? [1] : paginasIntervalo(r.intervalo, r.paginas),
      copias: c.copias || r.copias || 1, fv: c.frente_verso != null ? !!c.frente_verso : !!r.frente_verso };
  });
  const primeiro = est[lista[0].id] || {};
  const st = { impressora_id: primeiro.impressora_id || lista[0].impressora_sugerida, finalidade: primeiro.finalidade || '', descricao: primeiro.descricao || '', prova: provaInicial() };
  folha((f, fechar) => {
    const resumo = h('p', { class: 'retida-conta', 'aria-live': 'polite' });
    const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '12px', marginBottom: '0' } });
    const btn = h('button', { class: 'btn' }, 'Imprimir');
    const escolha = escolhaImpressora(st, () => atualizar());
    const conf = confirmaImpressora(st, () => atualizar());
    const prova = campoProvaLote(st, () => itens, () => atualizar());
    const fin = h('div', { class: 'retida-fin' }, h('div', { class: 'retida-rotulo' }, tituloFinalidade()), campoFinalidade(st, () => erro.classList.add('oculto')));
    const saldo = () => E.eu.saldos.find((x) => x.impressora_id === st.impressora_id);
    const total = itens.reduce((a, it) => a + it.pags.length * it.copias, 0);
    function atualizar() {
      const s = saldo();
      fin.classList.toggle('oculto', !(s && s.pede_finalidade));
      prova.atualizar();
      if (!s) { resumo.textContent = 'Escolha uma impressora.'; btn.disabled = true; return; }
      const sobra = s.restante - total;
      const alem = alemDaCota(s, total);
      const custo = s.custo_pagina > 0 ? ` (${reais(total * s.custo_pagina)})` : '';
      resumo.className = 'retida-conta' + (sobra < 0 && !alem.pode ? ' falta' : '');
      resumo.textContent = alem.pode ? `Vai usar ${pag(total)}${custo}: ${pag(alem.falta)} além da cota, com justificativa.`
        : sobra < 0
          ? `Vai usar ${pag(total)}${custo}. ${-sobra === 1 ? 'Falta' : 'Faltam'} ${pag(-sobra)} na ${curto(s.nome)}.`
          : `Vai usar ${pag(total)}${custo}. Você fica com ${n(sobra)} na ${curto(s.nome)}.`;
      conf.atualizar();
      btn.disabled = (sobra < 0 && !alem.pode) || !conf.ok();
      const plano = planoLote(itens, st.prova);
      btn.textContent = sobra < 0 && !alem.pode ? 'Páginas insuficientes' : previaAtiva() ? 'Conferir e imprimir' : alem.pode ? 'Imprimir além da cota' : plano ? `Imprimir ${pag(plano.prova)} agora` : `Imprimir ${pag(total)}`;
    }
    async function tratar(e) {
      if (e.codigo === 'lote_parcial' || /não está mais aguardando/.test(e.message)) {
        document.querySelectorAll('.veu').forEach((v) => v.remove());
        avisar(e.message, true); E.retidas = null; await atualizarEu(); carregarRetidas();
        return;
      }
      erro.textContent = e.message; erro.classList.remove('oculto');
      if (e.codigo === 'sem_cota' || e.codigo === 'pessoal') { await atualizarEu(); atualizar(); }
    }
    btn.onclick = async () => {
      const s = saldo(); if (!s || !conf.ok()) return;
      const pede = !!s.pede_finalidade;
      const prob = problemaFinalidade(st, total, pede);
      if (prob) { erro.textContent = prob; erro.classList.remove('oculto'); fin.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
      erro.classList.add('oculto');
      const enviar = async () => {
        const res = await apiImprimir('/api/retidas/liberar-todas', {
          itens: itens.map((it) => ({ id: it.id, copias: it.copias, frente_verso: it.fv })), impressora_id: st.impressora_id,
          finalidade: pede ? st.finalidade : '', descricao: st.descricao, prova: st.prova,
        });
        E.ultimoResultado = res; E.retidas = null;
        fechar();
        await atualizarEu();
        if (location.hash.startsWith('#imprimir')) telaImprimir(); else location.hash = '#imprimir';
      };
      if (previaAtiva()) {
        folhaConfirmarLote({ itens, prova: () => st.prova, impressora: s.nome, finalidade: pede ? st.finalidade : '', descricao: st.descricao,
          enviar: async () => { try { await enviar(); } catch (e) { tratar(e); throw e; } } });
        return;
      }
      botaoCarregando(btn, 'Enviando para a impressora…');
      try { await enviar(); } catch (e) { botaoPronto(btn); atualizar(); tratar(e); }
    };
    f.append(h('h2', null, `Liberar ${lista.length} impressões`),
      h('ul', { class: 'lote-lista compacta' }, itens.map((it) => h('li', null,
        h('div', { class: 'icone-doc' }, it.r.tipo === 'imagem' ? 'IMG' : 'PDF'),
        h('div', { class: 'lote-nome' }, h('div', { class: 'nome-arq' }, it.nome),
          h('div', { class: 'mudo pequeno' }, [pag(it.pags.length), it.copias > 1 ? `${n(it.copias)} cópias` : null, it.fv ? 'frente e verso' : 'só frente'].filter(Boolean).join(', ')))))),
      h('div', { class: 'retida-rotulo' }, 'Em qual impressora?'), escolha, prova.el, fin, resumo, conf.el, erro,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar'), btn));
    atualizar();
  });
}

function campoEndereco(rotulo, valor) {
  const copiar = h('button', { type: 'button', class: 'btn claro pequeno' }, 'Copiar');
  copiar.onclick = () => copiarTexto(valor);
  return h('div', { class: 'endereco' }, h('div', { class: 'rot' }, rotulo),
    h('div', { class: 'valor' }, h('code', null, valor), copiar));
}

function folhaComoInstalar(v) {
  const base = E.eu.impressora_virtual || `${location.origin}/ipp/print`;
  const filas = v ? v.filas : [{ nome: 'Folha a Folha', windows: base, linux: base.replace(/^http:/, 'ipp:') }];
  const ip = v ? v.ip : base.replace(/^https?:\/\//, '').split(/[:/]/)[0];
  const androidIp = v ? v.porta_631 : true;
  folha((f, fechar) => f.append(
    h('h2', null, 'Adicionar a impressora Folha a Folha'),
    h('p', { class: 'mudo' }, `Faça uma vez em cada aparelho. O aparelho precisa estar no Wi-Fi ou na rede ${L('do')}.`),
    filas.map((q) => h('div', { class: 'bloco', style: { marginTop: '12px' } },
      filas.length > 1 ? h('strong', null, q.nome) : null,
      campoEndereco('Windows', q.windows), campoEndereco('Linux', q.linux))),
    h('div', { class: 'passos-so' },
      h('h3', null, 'Windows 10 e 11'),
      h('ol', null,
        h('li', null, 'Abra Configurações, Dispositivos (ou Bluetooth e dispositivos), Impressoras e scanners.'),
        h('li', null, 'Clique em Adicionar. Se "Folha a Folha" aparecer na lista, clique nela e pronto.'),
        h('li', null, 'Se não aparecer: "A impressora que eu quero não está na lista", "Selecionar uma impressora compartilhada pelo nome" e cole o endereço do Windows.'),
        h('li', null, 'Se pedir um driver, escolha o fabricante Microsoft e o modelo "Microsoft IPP Class Driver".')),
      h('h3', null, 'Linux (Ubuntu, Mint e outros)'),
      h('ol', null,
        h('li', null, 'Abra Configurações, Impressoras, Adicionar. "Folha a Folha" aparece sozinha.'),
        h('li', null, 'Ou, no terminal: ', h('code', null, `sudo lpadmin -p Folha_a_Folha -E -v ${filas[0].linux} -m everywhere`))),
      h('h3', null, 'Android'),
      h('ol', null,
        h('li', null, 'Abra Configurações, Dispositivos conectados (ou Conexões), Impressão, Serviço de impressão padrão, e deixe ligado.'),
        h('li', null, `"Folha a Folha" aparece sozinha quando o celular está no Wi-Fi ${L('do')}.`),
        androidIp ? h('li', null, `Se não aparecer, toque em Adicionar impressora e informe o IP ${ip}.`) : null),
      h('h3', null, 'iPhone e iPad'),
      h('p', { class: 'pequeno' }, 'Ainda não aparecem como impressora. Salve o documento em PDF e envie pela tela Imprimir deste app.'),
      h('h3', null, 'Depois de instalar'),
      h('p', { class: 'pequeno' }, 'Imprima normalmente escolhendo "Folha a Folha". Nada sai no papel até você abrir este app, escolher a impressora e tocar em Imprimir.')),
    h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Fechar'))));
}

function telaResultado() {
  const r = E.ultimoResultado;
  if (r.lote) {
    const ids = new Set((r.conferencias || []).map((c) => c.id));
    const pendentes = (E.eu.conferencias || []).filter((x) => ids.has(x.id));
    const qtd = r.arquivos.length;
    moldura('Imprimir', null, h('div', null,
      h('div', { class: 'faixa ok' }, r.teste ? 'Registrado em modo teste.' : `${qtd} ${qtd === 1 ? 'arquivo foi' : 'arquivos foram'} para a impressora!`),
      h('div', { class: 'bloco' },
        h('ul', { class: 'lote-feitos' }, r.arquivos.map((a) => h('li', null, h('span', { class: 'nome-arq' }, a.nome),
          h('span', { class: 'mudo pequeno' }, a.prova ? `só a prova, ${pag(a.total)}` : pag(a.total))))),
        h('p', { style: { marginTop: '12px' } }, r.teste
          ? `A ${r.impressora} está em modo teste: nada saiu no papel, mas ${pag(r.total)} foram descontadas para você conferir o funcionamento.`
          : `${pag(r.total)} foram para a ${r.impressora}. Pode buscar as folhas.`),
        r.acompanhando ? h('p', { class: 'mudo pequeno', style: { marginTop: '8px' } }, 'Se alguma página não sair (impressora desligada, sem papel, trabalho cancelado), ela volta sozinha para a sua cota.') : null,
        r.custo > 0 ? h('p', { style: { marginTop: '8px' } }, `Custo: ${reais(r.custo)}.`) : null,
        h('p', { style: { marginTop: '12px', fontSize: '18px', fontWeight: '800' } }, `Você ainda tem ${pag(Math.max(0, r.restante))} nesta impressora.`)),
      pendentes.length ? h('div', { class: 'conferencias', style: { marginTop: '16px' } },
        h('h2', { class: 'titulo-secao' }, pendentes.length === 1 ? 'Confira a prova' : `Confira as ${pendentes.length} provas`), pendentes.map(cartaoConferencia)) : null,
      h('div', { class: 'acao-principal' },
        h('button', { class: 'btn largo', onclick: () => { E.ultimoResultado = null; telaImprimir(); } },
          E.eu.retidas ? (E.eu.retidas === 1 ? 'Ver a outra impressão aguardando' : `Ver as outras ${E.eu.retidas} aguardando`) : 'Imprimir outros arquivos'),
        h('a', { class: 'btn claro largo', href: '#inicio', style: { marginTop: '10px' }, onclick: () => { E.ultimoResultado = null; } }, 'Voltar ao início'))));
    return;
  }
  if (r.conferencia) {
    const c = (E.eu.conferencias || []).find((x) => x.id === r.conferencia.id) || r.conferencia;
    moldura('Imprimir', null, h('div', null,
      h('div', { class: 'faixa ok' }, r.teste ? 'Prova registrada em modo teste.' : 'A prova foi para a impressora!'),
      h('p', { class: 'mudo', style: { margin: '4px 0 12px' } }, r.teste
        ? `A ${r.impressora} está em modo teste: nada saiu no papel. Use os botões abaixo para seguir o caminho de uma prova de verdade.`
        : `Vá até a ${r.impressora}, pegue a folha e confira. ${pag(r.total)} já foram descontadas; o resto só sai quando você mandar.`),
      (E.eu.conferencias || []).some((x) => x.id === c.id) ? cartaoConferencia(c) : h('div', { class: 'bloco vazio' }, 'Esta prova já foi resolvida.'),
      h('div', { class: 'acao-principal' },
        h('a', { class: 'btn claro largo', href: '#inicio', onclick: () => { E.ultimoResultado = null; } }, 'Voltar ao início'))));
    return;
  }
  moldura('Imprimir', null, h('div', null,
    h('div', { class: 'faixa ok' }, r.teste ? 'Registrado em modo teste.' : r.resto ? 'O resto foi para a impressora!' : 'Enviado para a impressora!'),
    h('div', { class: 'bloco' },
      h('p', null, r.teste
        ? `A ${r.impressora} está em modo teste: nada saiu no papel, mas ${pag(r.total)} foram descontadas para você conferir o funcionamento.`
        : `${pag(r.total)} foram para a ${r.impressora}. Pode buscar as folhas.`),
      r.acompanhando ? h('p', { class: 'mudo pequeno', style: { marginTop: '8px' } }, 'Se alguma página não sair (impressora desligada, sem papel, trabalho cancelado), ela volta sozinha para a sua cota.') : null,
      r.custo > 0 ? h('p', { style: { marginTop: '8px' } }, `Custo desta impressão: ${reais(r.custo)}.`) : null,
      h('p', { style: { marginTop: '12px', fontSize: '18px', fontWeight: '800' } }, `Você ainda tem ${pag(Math.max(0, r.restante))} nesta impressora.`)),
    h('div', { class: 'acao-principal' },
      h('button', { class: 'btn largo', onclick: () => { E.ultimoResultado = null; telaImprimir(); } },
        E.eu.retidas ? (E.eu.retidas === 1 ? 'Ver a outra impressão aguardando' : `Ver as outras ${E.eu.retidas} aguardando`) : 'Imprimir outro arquivo'),
      h('a', { class: 'btn claro largo', href: '#inicio', style: { marginTop: '10px' }, onclick: () => { E.ultimoResultado = null; } }, 'Voltar ao início'))));
}

/* ================================================================ pedir e passar páginas */

async function carregarColegas() {
  try { E.colegas = (await api('/api/colegas')).colegas; } catch (e) { E.colegas = E.colegas || []; }
  return E.colegas;
}

/* "Vai para a impressora certa?" Com mais de uma impressora, só deixa imprimir depois de marcar;
   trocou de impressora, precisa marcar de novo. */
function confirmaImpressora(st, aoMudar) {
  const ligado = () => E.eu.controle.confirmar_impressora !== false && E.eu.saldos.length > 1;
  const c = h('input', { type: 'checkbox' });
  const texto = h('span');
  const el = h('label', { class: 'conf-check conf-impressora' }, c, texto);
  c.onchange = () => { st.impConfirmada = c.checked ? st.impressora_id : null; atualizar(); if (aoMudar) aoMudar(); };
  function atualizar() {
    el.classList.toggle('oculto', !ligado());
    if (st.impConfirmada !== st.impressora_id) st.impConfirmada = null;
    c.checked = !!st.impConfirmada;
    el.classList.toggle('pendente', !c.checked);
    const s = E.eu.saldos.find((x) => x.impressora_id === st.impressora_id);
    el.style.setProperty('--cor', s ? s.cor : 'var(--tinta)');
    texto.replaceChildren(...(s ? ['Conferi: é para sair na ', h('strong', null, s.nome), s.teste ? ' (em modo teste)' : '', '.'] : ['Escolha a impressora acima.']));
  }
  atualizar();
  return { el, atualizar, ok: () => !ligado() || (!!st.impressora_id && st.impConfirmada === st.impressora_id) };
}

function escolhaImpressora(st, aoMudar, mostrar = 'meu') {
  const caixa = h('div', { class: 'escolha' });
  function desenhar() {
    caixa.replaceChildren(...E.eu.saldos.map((s) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(s.impressora_id === st.impressora_id), style: { '--cor': s.cor } },
        h('span', { class: 'marca' }), h('span', { class: 'nome' }, curto(s.nome)),
        mostrar === 'meu' ? h('span', { class: 'qtd num' }, `você tem ${n(Math.max(0, s.restante))}`) : null);
      b.onclick = () => { st.impressora_id = s.impressora_id; desenhar(); aoMudar && aoMudar(); };
      return b;
    }));
  }
  desenhar();
  return caixa;
}

async function folhaPedir({ conversa, impressora_id, paginas }) {
  if (E.eu.trocas.modo === 'reserva') return folhaPedirReserva({ impressora_id, paginas });
  const colegas = conversa ? null : await carregarColegas();
  const st = { impressora_id: impressora_id || (E.eu.saldos[0] || {}).impressora_id, destino: conversa || 'mural' };
  folha((f, fechar) => {
    const qtd = h('input', { type: 'number', inputmode: 'numeric', min: '1', value: paginas || '', autofocus: !paginas, placeholder: 'Quantas páginas?' });
    const texto = h('textarea', { placeholder: 'Conte para que é (opcional)', maxlength: '500' });
    let destinoSel = null;
    const montarDestino = () => {
      if (!colegas) return;
      const atual = destinoSel ? destinoSel.value : st.destino;
      const ordenadas = [...colegas].sort((a, b) => sobra(b) - sobra(a));
      destinoSel.replaceChildren(
        h('option', { value: 'mural' }, 'Mural da equipe (qualquer colega pode atender)'),
        ordenadas.map((c) => h('option', { value: `u:${c.id}` }, `${c.nome}, tem ${n(Math.max(0, sobra(c)))} sobrando`)));
      destinoSel.value = atual;
    };
    function sobra(c) { const s = c.saldos.find((x) => x.impressora_id === st.impressora_id); return s ? s.restante : 0; }
    const limite = h('p', { class: 'dica' });
    const mostrarLimite = () => { const l = limiteTroca(st.impressora_id); limite.textContent = l ? `Este mês você ainda pode receber ${pag(l.receber)} desta impressora de colegas.` : ''; };
    mostrarLimite();
    if (colegas) { destinoSel = h('select'); destinoSel.onchange = () => { st.destino = destinoSel.value; }; montarDestino(); }
    const btn = h('button', { class: 'btn' }, 'Enviar pedido');
    btn.onclick = async () => {
      botaoCarregando(btn);
      try {
        await api('/api/pedir', { conversa: st.destino, impressora_id: st.impressora_id, paginas: qtd.value, texto: texto.value });
        fechar(); avisar(st.destino === 'mural' ? 'Pedido publicado no mural.' : 'Pedido enviado.');
        if (location.hash === '#conversa/' + encodeURIComponent(st.destino)) recarregarChat(true);
        else if (!conversa) location.hash = '#conversa/' + encodeURIComponent(st.destino);
      } catch (e) { avisar(e.message, true); botaoPronto(btn); }
    };
    f.append(h('h2', null, 'Pedir páginas'),
      colegas ? h('label', { class: 'campo' }, h('span', null, 'Para quem?'), destinoSel) : null,
      h('div', { class: 'campo' }, h('span', { class: 'mudo pequeno', style: { fontWeight: '700', display: 'block', marginBottom: '6px' } }, 'De qual impressora?'), escolhaImpressora(st, () => { montarDestino(); mostrarLimite(); }, 'nenhum')),
      h('label', { class: 'campo' }, h('span', null, 'Quantas páginas?'), qtd, limite),
      h('label', { class: 'campo' }, h('span', null, 'Mensagem'), texto),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
  });
}

function folhaPassar(conversa, nomeColega) {
  const st = { impressora_id: (E.eu.saldos.find((s) => s.restante > 0) || E.eu.saldos[0] || {}).impressora_id };
  folha((f, fechar) => {
    const qtd = h('input', { type: 'number', inputmode: 'numeric', min: '1', autofocus: true, placeholder: 'Quantas páginas?' });
    const texto = h('textarea', { placeholder: 'Mensagem (opcional)', maxlength: '500' });
    const resumo = h('p', { class: 'dica' });
    const atualiza = () => {
      const s = E.eu.saldos.find((x) => x.impressora_id === st.impressora_id);
      const v = Number(qtd.value || 0);
      const l = limiteTroca(st.impressora_id);
      let txt = s ? (v > s.restante ? `Você só tem ${pag(Math.max(0, s.restante))} nesta impressora.` : v > 0 ? `Você ficará com ${pag(s.restante - v)}.` : '') : '';
      if (l) txt = (txt ? txt + ' ' : '') + (v > l.doar ? `O limite deste mês é ${pag(l.max_doar)}, e você ainda pode passar ${pag(l.doar)}.` : `Este mês você ainda pode passar ${pag(l.doar)} desta impressora.`);
      resumo.textContent = txt;
    };
    qtd.oninput = atualiza;
    const btn = h('button', { class: 'btn' }, 'Passar páginas');
    btn.onclick = async () => {
      botaoCarregando(btn);
      try {
        await api('/api/doar', { conversa, impressora_id: st.impressora_id, paginas: qtd.value, texto: texto.value });
        fechar(); avisar(`${nomeColega} recebeu ${pag(Number(qtd.value))}.`);
        await atualizarEu(); recarregarChat(true);
      } catch (e) { avisar(e.message, true); botaoPronto(btn); }
    };
    f.append(h('h2', null, `Passar páginas para ${nomeColega}`),
      h('div', { class: 'campo' }, h('span', { class: 'mudo pequeno', style: { fontWeight: '700', display: 'block', marginBottom: '6px' } }, 'De qual impressora?'), escolhaImpressora(st, atualiza)),
      h('label', { class: 'campo' }, h('span', null, 'Quantas páginas?'), qtd, resumo),
      h('label', { class: 'campo' }, h('span', null, 'Mensagem'), texto),
      h('p', { class: 'aviso-troca' }, E.eu.trocas.aviso),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
    atualiza();
  });
}

function limiteTroca(iid) {
  const t = E.eu.trocas;
  return t && t.modo === 'limite' ? t.limites[String(iid)] || null : null;
}

function folhaPedirReserva({ impressora_id, paginas }) {
  const st = { impressora_id: impressora_id || (E.eu.saldos[0] || {}).impressora_id };
  const auto = E.eu.trocas.reserva_auto;
  folha((f, fechar) => {
    const qtd = h('input', { type: 'number', inputmode: 'numeric', min: '1', value: paginas || '', autofocus: !paginas, placeholder: 'Quantas páginas?' });
    const motivo = h('textarea', { placeholder: 'Para que é? A gestão vê.', maxlength: '500' });
    const btn = h('button', { class: 'btn' }, 'Pedir à reserva');
    btn.onclick = async () => {
      botaoCarregando(btn);
      try {
        const r = await api('/api/pedir', { conversa: 'reserva', impressora_id: st.impressora_id, paginas: qtd.value, texto: motivo.value });
        fechar();
        avisar(r.liberado ? `Pronto! Você recebeu ${pag(Number(qtd.value))} da reserva.` : 'Pedido enviado à gestão.');
        await atualizarEu(true);
        if (location.hash.startsWith('#conversas')) telaConversas();
      } catch (e) { avisar(e.message, true); botaoPronto(btn); }
    };
    f.append(h('h2', null, `Pedir à reserva ${L('do')}`),
      h('p', { class: 'mudo' }, auto > 0 ? `Até ${pag(auto)} por mês, em cada impressora, saem na hora. Acima disso, a gestão decide.` : 'A gestão decide cada pedido.'),
      h('div', { class: 'campo' }, h('span', { class: 'mudo pequeno', style: { fontWeight: '700', display: 'block', marginBottom: '6px' } }, 'De qual impressora?'), escolhaImpressora(st, () => {}, 'nenhum')),
      h('label', { class: 'campo' }, h('span', null, 'Quantas páginas?'), qtd),
      h('label', { class: 'campo' }, h('span', null, 'Motivo'), motivo),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
  });
}

function folhaDevolver() {
  const st = { impressora_id: (E.eu.saldos.find((s) => s.restante > 0) || E.eu.saldos[0] || {}).impressora_id };
  folha((f, fechar) => {
    const qtd = h('input', { type: 'number', inputmode: 'numeric', min: '1', autofocus: true, placeholder: 'Quantas páginas?' });
    const resumo = h('p', { class: 'dica' });
    const atualiza = () => {
      const s = E.eu.saldos.find((x) => x.impressora_id === st.impressora_id);
      const v = Number(qtd.value || 0);
      resumo.textContent = !s ? '' : v > s.restante ? `Você só tem ${pag(Math.max(0, s.restante))} nesta impressora.` : `Você tem ${pag(Math.max(0, s.restante))}.${v > 0 ? ` Ficará com ${pag(s.restante - v)}.` : ''}`;
    };
    qtd.oninput = atualiza;
    const btn = h('button', { class: 'btn' }, `Devolver ${L('ao')}`);
    btn.onclick = async () => {
      botaoCarregando(btn);
      try {
        await api('/api/devolver', { impressora_id: st.impressora_id, paginas: qtd.value });
        fechar(); avisar(`Pronto! ${pag(Number(qtd.value))} voltaram para ${L('o')}.`);
        await atualizarEu(true);
        if (location.hash.startsWith('#conversas')) telaConversas();
      } catch (e) { avisar(e.message, true); botaoPronto(btn); }
    };
    f.append(h('h2', null, `Devolver páginas ${L('ao')}`),
      h('p', { class: 'mudo' }, `As páginas que você não vai usar voltam para a reserva ${L('do')}. O que ninguém usar vira economia. Não dá para desfazer.`),
      h('div', { class: 'campo' }, h('span', { class: 'mudo pequeno', style: { fontWeight: '700', display: 'block', marginBottom: '6px' } }, 'De qual impressora?'), escolhaImpressora(st, atualiza)),
      h('label', { class: 'campo' }, h('span', null, 'Quantas páginas?'), qtd, resumo),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
    atualiza();
  });
}

function blocoTrocasPessoa(reserva) {
  const t = E.eu.trocas;
  const status = { pendente: ['Aguardando a gestão', 'alerta'], aceito: ['Liberado', 'ok'], recusado: ['Não liberado', 'esgotado'], cancelado: ['Cancelado', 'teste'], expirado: ['Expirou', 'teste'] };
  if (t.modo === 'reserva') {
    return h('div', { class: 'bloco trocas-prof' },
      h('strong', null, `Aqui ${L('no')}, as páginas circulam pela reserva`),
      h('p', { class: 'mudo pequeno' }, `Quem tem sobra devolve ${L('ao')}. Quem precisa pede à reserva.`),
      h('div', { class: 'linha-botoes', style: { marginTop: '12px' } },
        h('button', { class: 'btn pequeno', onclick: () => folhaPedirReserva({}) }, 'Pedir à reserva'),
        h('button', { class: 'btn claro pequeno', onclick: folhaDevolver }, 'Devolver sobras')),
      reserva && reserva.pedidos.length ? h('div', { class: 'lista', style: { marginTop: '14px' } }, reserva.pedidos.map((p) => {
        const [rot, cl] = status[p.status] || [p.status, 'teste'];
        return h('div', { class: 'item', style: { '--cor': p.cor } },
          h('span', { class: 'avatar', style: { fontSize: '13px' } }, n(p.paginas)),
          h('span', { class: 'meio' }, h('strong', null, `${pag(p.paginas)} da ${curto(p.impressora_nome)}`),
            h('span', { class: 'previa' }, `${diaCurto(p.criado_em)}${p.motivo ? ', ' + p.motivo : ''}`),
            h('div', { style: { marginTop: '6px' } }, h('span', { class: 'selo ' + cl }, rot))));
      })) : null);
  }
  const linhas = [];
  if (t.modo === 'limite') {
    E.eu.saldos.forEach((s) => {
      const l = t.limites[String(s.impressora_id)];
      if (l && (l.max_doar || l.max_receber)) linhas.push(h('div', { class: 'sobra' }, `${curto(s.nome)}: pode passar mais ${n(l.doar)} e receber mais ${n(l.receber)} este mês`));
    });
  }
  return h('div', { class: 'bloco trocas-prof' },
    h('strong', null, `Sobrou página? Devolva ${L('ao')}`),
    h('p', { class: 'mudo pequeno' }, `O que volta para a reserva e ninguém usa vira economia para ${L('o')}.`),
    linhas.length ? h('div', { style: { marginTop: '8px' } }, linhas) : null,
    h('div', { class: 'linha-botoes', style: { marginTop: '12px' } }, h('button', { class: 'btn claro pequeno', onclick: folhaDevolver }, 'Devolver sobras')));
}

/* ================================================================ conversas */

async function telaConversas() {
  moldura('Conversas', 'Combine com colegas e troque páginas', h('div', { class: 'bloco vazio' }, h('span', { class: 'carregando' })));
  let conv, colegas, reserva = null;
  try { [conv, colegas, reserva] = await Promise.all([api('/api/conversas'), carregarColegas(), E.eu.trocas.modo === 'reserva' ? api('/api/reserva') : null]); }
  catch (e) { avisar(e.message, true); return; }
  if (!location.hash.startsWith('#conversas')) return;
  const porId = Object.fromEntries(colegas.map((c) => [c.id, c]));
  const nomesImp = Object.fromEntries(E.eu.saldos.map((s) => [s.impressora_id, curto(s.nome)]));
  const lista = conv.conversas.slice();
  const mural = lista.shift();
  lista.sort((a, b) => ((b.ultima && b.ultima.id) || 0) - ((a.ultima && a.ultima.id) || 0) || a.nome.localeCompare(b.nome));
  const previa = (c) => {
    if (c.bloqueado) return 'Pessoa bloqueada';
    const u = c.ultima; if (!u) return c.chave === 'mural' ? 'Recados e pedidos para toda a equipe' : 'Nenhuma mensagem ainda';
    const quem = u.de_id === E.eu.usuario.id ? 'Você: ' : (c.chave === 'mural' ? `${u.de_nome}: ` : '');
    if (u.tipo === 'pedido') return `${quem}pedido de páginas`;
    if (u.tipo === 'doacao') return `${quem}páginas passadas`;
    return quem + (u.texto || '');
  };
  const item = (c) => {
    const col = c.usuario_id && !c.bloqueado ? porId[c.usuario_id] : null;
    const sobras = col ? col.saldos.filter((s) => s.restante > 0 && nomesImp[s.impressora_id]) : [];
    return h('a', { href: '#conversa/' + encodeURIComponent(c.chave) },
      h('span', { class: 'avatar' + (c.chave === 'mural' ? ' mural' : '') }, c.chave === 'mural' ? icone('conversas') : iniciais(c.nome)),
      h('span', { class: 'meio' }, h('strong', null, c.nome), h('span', { class: 'previa' }, previa(c)),
        col ? h('div', { class: 'sobra' }, sobras.length ? ['Tem sobrando: ', sobras.map((s, i) => [i ? ', ' : '', h('b', null, n(s.restante)), ` ${nomesImp[s.impressora_id]}`])] : 'Sem páginas sobrando') : null),
      c.nao_lidas ? h('span', { class: 'contador' }, c.nao_lidas) : null);
  };
  moldura('Conversas', E.eu.trocas.modo === 'reserva' ? 'Recados para a equipe e páginas da reserva' : 'Combine com colegas e troque páginas', h('div', null,
    blocoTrocasPessoa(reserva),
    h('div', { class: 'lista' }, item(mural)),
    h('div', { class: 'secao' }, h('h2', null, 'Colegas'),
      lista.length ? h('div', { class: 'lista' }, lista.map(item)) : h('div', { class: 'bloco vazio' }, 'Ainda não há outras pessoas cadastradas.'))));
  const ic = $app.querySelector('.avatar.mural svg'); if (ic) ic.style.cssText = 'width:22px;height:22px';
}

function telaConversa(chave) {
  E.chat = { chave, assinatura: '', nome: '' };
  const ehMural = chave === 'mural';
  const entrada = h('input', { type: 'text', placeholder: 'Escreva uma mensagem', maxlength: '1000', enterkeyhint: 'send', 'aria-label': 'Mensagem' });
  const form = h('form', {
    onsubmit: async (e) => {
      e.preventDefault(); const texto = entrada.value.trim(); if (!texto) return;
      entrada.value = '';
      try { await api('/api/mensagens', { conversa: chave, texto }); recarregarChat(true, true); }
      catch (err) { entrada.value = texto; avisar(err.message, true); }
    },
  }, entrada, h('button', { class: 'enviar', 'aria-label': 'Enviar' }, icone('enviar')));
  const compositor = h('div', { class: 'compositor' }, h('div', { class: 'dentro' },
    h('div', { class: 'acoes' },
      h('button', { type: 'button', onclick: () => folhaPedir({ conversa: chave }) }, 'Pedir páginas'),
      ehMural || E.eu.trocas.modo === 'reserva' ? null : h('button', { type: 'button', onclick: () => folhaPassar(chave, E.chat.nome || 'colega') }, 'Passar páginas'),
      ehMural ? null : h('button', { type: 'button', class: 'bloquear-colega', onclick: () => bloquearPessoa(Number(chave.slice(2)), E.chat.nome || 'esta pessoa', () => recarregarChat(true)) }, 'Bloquear')),
    form));
  moldura(ehMural ? 'Mural da equipe' : '…', ehMural ? 'Toda a equipe vê estas mensagens' : null,
    h('div', { class: 'chat', id: 'chat' }, h('div', { class: 'vazio' }, h('span', { class: 'carregando' }))),
    { voltar: '#conversas', compositor });
  recarregarChat(true, true);
  timerChat = setInterval(() => { if (!document.hidden) recarregarChat(false); }, 4000);
}

async function recarregarChat(forcar, rolarFim) {
  const chave = E.chat.chave; const caixa = document.getElementById('chat');
  if (!caixa || !chave) return;
  let r;
  try { r = await api('/api/mensagens?conversa=' + encodeURIComponent(chave)); } catch (e) { if (forcar) avisar(e.message, true); return; }
  if (E.chat.chave !== chave || !document.getElementById('chat')) return;
  if (r.nome && chave !== 'mural' && E.chat.nome !== r.nome) {
    E.chat.nome = r.nome; const t = document.querySelector('.topo h1'); if (t) t.textContent = r.nome;
  }
  const comp = document.querySelector('.compositor'); if (comp) comp.style.display = r.bloqueado ? 'none' : '';
  if (r.bloqueado) {
    caixa.replaceChildren(h('div', { class: 'vazio' }, h('p', null, `Você bloqueou ${r.nome || 'esta pessoa'}.`),
      h('button', { class: 'btn claro', style: { marginTop: '12px' }, onclick: async () => { try { await api('/api/colega/bloquear', { usuario_id: Number(chave.slice(2)), bloquear: false }); atualizarEu(true); recarregarChat(true); } catch (e) { avisar(e.message, true); } } }, 'Desbloquear')));
    E.chat.assinatura = ''; return;
  }
  const assinatura = JSON.stringify(r.mensagens);
  if (!forcar && assinatura === E.chat.assinatura) return;
  E.chat.assinatura = assinatura;
  const pertoDoFim = window.innerHeight + window.scrollY >= document.body.scrollHeight - 160;
  const itens = []; let dia = '';
  for (const m of r.mensagens) {
    const d = rotuloDia(m.criado_em);
    if (d !== dia) { dia = d; itens.push(h('div', { class: 'data-chat' }, d)); }
    itens.push(desenharMensagem(m, chave === 'mural'));
  }
  if (!itens.length) itens.push(h('div', { class: 'vazio' }, chave === 'mural'
    ? 'Nenhum recado ainda. Use o mural para pedir páginas a qualquer colega.'
    : 'Nenhuma mensagem ainda. Escreva, peça ou passe páginas.'));
  caixa.replaceChildren(...itens);
  if (rolarFim || pertoDoFim || forcar) window.scrollTo(0, document.body.scrollHeight);
  if (forcar) atualizarEu();
}

function desenharMensagem(m, ehMural) {
  const me = E.eu.usuario.id;
  if (m.tipo === 'sistema') return h('div', { class: 'msg-sistema' }, m.texto);
  if (m.tipo === 'pedido' && m.pedido) {
    const p = m.pedido;
    const quem = p.solicitante_id === me ? 'Você pediu' : `${p.solicitante_nome} pediu`;
    const status = {
      aceito: h('span', { class: 'selo ok' }, `Atendido por ${p.respondido_por === me ? 'você' : p.respondido_por_nome}`),
      recusado: h('span', { class: 'selo esgotado' }, 'Não atendido'),
      cancelado: h('span', { class: 'selo teste' }, 'Cancelado'),
      expirado: h('span', { class: 'selo teste' }, 'Expirou com o fim do mês'),
    }[p.status] || h('span', { class: 'selo alerta' }, 'Aguardando');
    const botoes = [];
    if (p.pode_responder) {
      const sim = h('button', { class: 'btn pequeno cor' }, `Passar ${n(p.paginas)}`);
      sim.onclick = () => responderPedido(p, true, sim);
      botoes.push(sim);
      if (p.destinatario_id) {
        const nao = h('button', { class: 'btn claro pequeno' }, 'Não posso atender');
        nao.onclick = () => responderPedido(p, false, nao);
        botoes.push(nao);
      } else if (p.dispensado) {
        botoes.push(h('span', { class: 'dica', style: { alignSelf: 'center' } }, 'Fora da sua tela inicial.'));
      } else {
        const dispensar = h('button', { class: 'btn claro pequeno' }, 'Dispensar da minha tela inicial');
        dispensar.onclick = async () => {
          if (!(await confirmar('Dispensar este pedido?', 'O pedido continuará no mural para os demais colegas; apenas deixará de aparecer nas suas pendências.', 'Dispensar'))) return;
          botaoCarregando(dispensar);
          try { await api('/api/pedido/dispensar', { id: p.id }); avisar('Pedido dispensado das suas pendências.'); await atualizarEu(true); recarregarChat(true); }
          catch (e) { avisar(e.message, true); botaoPronto(dispensar); }
        };
        botoes.push(dispensar);
      }
    }
    if (p.pode_cancelar) {
      const c = h('button', { class: 'btn claro pequeno' }, 'Cancelar pedido');
      c.onclick = async () => { botaoCarregando(c); try { await api('/api/pedido/cancelar', { id: p.id }); recarregarChat(true); atualizarEu(true); } catch (e) { avisar(e.message, true); botaoPronto(c); } };
      botoes.push(c);
    }
    return h('div', { class: 'cartao-folhas' + (m.minha ? ' minha' : ''), style: { '--cor': p.cor } },
      h('div', { class: 'tit' }, quem, ehMural && p.solicitante_id !== me ? ' à equipe' : '', ' ', status),
      h('div', { class: 'qtd' }, n(p.paginas), ' ', h('small', null, `${p.paginas === 1 ? 'página' : 'páginas'} da ${curto(p.impressora_nome)}`)),
      m.texto ? h('div', { class: 'texto' }, m.texto) : null,
      h('div', { class: 'hora mudo pequeno' }, hora(m.criado_em), m.minha ? null : botaoMaisMensagem(m, m.de_id, m.de_nome)),
      botoes.length ? h('div', { class: 'linha-botoes' }, botoes) : null);
  }
  if (m.tipo === 'doacao' && m.doacao) {
    const d = m.doacao;
    let tit;
    if (d.tipo === 'ajuste') tit = d.de_id ? `A gestão tirou páginas de ${d.de_id === me ? 'você' : d.de_nome}` : `A gestão liberou páginas para ${d.para_id === me ? 'você' : d.para_nome}`;
    else if (d.tipo === 'reserva') tit = `A gestão liberou da reserva para ${d.para_id === me ? 'você' : d.para_nome}`;
    else if (d.tipo === 'aumento') tit = `A gestão aprovou aumento de cota para ${d.para_id === me ? 'você' : d.para_nome}`;
    else if (d.tipo === 'devolucao') tit = `${d.de_id === me ? 'Você' : d.de_nome} devolveu ${L('ao')}`;
    else tit = `${d.de_id === me ? 'Você' : d.de_nome} passou para ${d.para_id === me ? 'você' : d.para_nome}`;
    return h('div', { class: 'cartao-folhas' + (m.minha ? ' minha' : ''), style: { '--cor': d.cor } },
      h('div', { class: 'tit' }, tit),
      h('div', { class: 'qtd' }, (d.tipo === 'ajuste' && d.de_id ? '−' : '+') + n(d.paginas), ' ', h('small', null, `${d.paginas === 1 ? 'página' : 'páginas'} da ${curto(d.impressora_nome)}`)),
      (m.texto || d.obs) && !/^Pedido #/.test(d.obs || '') ? h('div', { class: 'texto' }, m.texto || d.obs) : null,
      h('div', { class: 'hora mudo pequeno' }, hora(m.criado_em)));
  }
  return h('div', { class: 'msg' + (m.minha ? ' minha' : '') },
    ehMural && !m.minha ? h('div', { class: 'autor' }, m.de_nome) : null,
    m.texto, h('div', { class: 'hora' }, hora(m.criado_em), m.minha ? null : botaoMaisMensagem(m, m.de_id, m.de_nome)));
}

/* ================================================================ histórico */

async function telaHistorico() {
  const mes = E.historicoMes || E.eu.mes;
  const sel = h('select', { 'aria-label': 'Mês', value: mes }, ultimosMeses(E.eu.mes, 12).map((m) => h('option', { value: m }, mesTitulo(m))));
  sel.value = mes;
  sel.onchange = () => { E.historicoMes = sel.value; telaHistorico(); };
  const corpo = h('div', null, sel, h('div', { class: 'bloco vazio', style: { marginTop: '12px' } }, h('span', { class: 'carregando' })));
  moldura('Histórico', 'Suas impressões e trocas de páginas', corpo);
  let r; try { r = await api('/api/trabalhos?mes=' + mes); } catch (e) { avisar(e.message, true); return; }
  if (!location.hash.startsWith('#historico')) return;
  const rotStatus = ROT_STATUS;
  corpo.replaceChildren(sel, resumoMes(r.trabalhos),
    h('div', { class: 'secao' }, h('h2', null, 'Impressões'),
      r.trabalhos.length ? h('div', { class: 'lista' }, r.trabalhos.map((t) => {
        const [cl, rot] = rotStatus[t.status] || ['teste', t.status];
        return h('div', { class: 'item', style: { '--cor': t.cor } },
          h('span', { class: 'avatar', style: { background: 'var(--cor)', color: '#fff', fontSize: '13px' } }, n(t.total)),
          h('span', { class: 'meio' }, h('strong', { style: { wordBreak: 'break-word' } }, t.arquivo),
            h('span', { class: 'previa' }, `${diaCurto(t.criado_em)}, ${hora(t.criado_em)}, ${curto(t.impressora_nome)}`),
            h('div', { class: 'sobra' }, `${pag(t.paginas_sel)} × ${t.copias} ${t.copias === 1 ? 'cópia' : 'cópias'}${t.frente_verso ? ', frente e verso' : ''}${t.custo > 0 ? `, ${reais(t.custo)}` : ''}${t.etapa === 'prova' ? ', prova' : t.etapa === 'resto' ? ', resto depois da prova' : ''}`),
            t.finalidade ? h('div', { class: 'sobra' }, textoFinalidade(t.finalidade, t.descricao)) : null,
            t.erro && t.status === 'erro' ? h('div', { class: 'sobra', style: { color: 'var(--perigo)' } }, t.erro) : null,
            t.erro && t.status === 'impresso' ? h('div', { class: 'sobra' }, t.erro) : null,
            t.status === 'na_fila' ? h('div', { class: 'sobra' }, `${t.fila_motivo || 'Na fila da impressora'}.`) : null,
            t.status === 'na_fila' ? h('button', { class: 'btn-texto pequeno', onclick: (e) => cancelarFila(t, e.currentTarget) }, 'Cancelar impressão') : null),
          h('span', { class: 'selo ' + cl }, rot));
      })) : h('div', { class: 'bloco vazio' }, 'Nenhuma impressão neste mês.')),
    h('div', { class: 'secao' }, h('h2', null, 'Páginas recebidas e passadas'),
      r.movimentos.length ? h('div', { class: 'lista' }, r.movimentos.map((m) => {
        const txt = m.tipo === 'ajuste'
          ? (m.entrada ? 'A gestão liberou' : 'A gestão tirou')
          : m.tipo === 'devolucao' ? `Devolveu ${L('ao')}`
            : m.tipo === 'aumento' ? 'Aumento de cota aprovado'
            : m.tipo === 'desconto' ? 'Desconto: passou da cota no mês anterior'
            : m.tipo === 'reserva' ? `Recebeu da reserva ${L('do')}`
              : (m.entrada ? `Recebeu de ${m.de_nome}` : `Passou para ${m.para_nome}`);
        return h('div', { class: 'item', style: { '--cor': m.cor } },
          h('span', { class: 'avatar', style: { color: m.entrada ? 'var(--ok)' : 'var(--perigo)', fontSize: '13px' } }, (m.entrada ? '+' : '−') + n(m.paginas)),
          h('span', { class: 'meio' }, h('strong', null, txt), h('span', { class: 'previa' }, `${diaCurto(m.criado_em)}, ${curto(m.impressora_nome)}`)));
      })) : h('div', { class: 'bloco vazio' }, 'Nenhuma troca neste mês.')));
}

function resumoMes(trabalhos) {
  const contam = trabalhos.filter((t) => ['impresso', 'teste', 'enviando', 'na_fila'].includes(t.status));
  if (!contam.length) return h('div');
  const paginas = contam.reduce((a, t) => a + t.total, 0);
  const custo = contam.reduce((a, t) => a + (t.custo || 0), 0);
  return h('div', { class: 'bloco', style: { marginTop: '12px' } }, h('div', { class: 'numeros', style: { marginTop: '0' } },
    h('div', null, h('b', null, n(paginas)), 'páginas impressas'),
    custo > 0 ? h('div', null, h('b', null, reais(custo)), 'custo das suas impressões') : null));
}

/* ================================================================ moderação: bloquear, denunciar, excluir a conta (2.5.0) */

const MOTIVOS = [['ofensa', 'Ofensa ou xingamento'], ['assedio', 'Assédio ou ameaça'], ['conteudo_improprio', 'Conteúdo impróprio'], ['spam', 'Propaganda ou spam'], ['outro', 'Outro motivo']];

async function bloquearPessoa(id, nome, depois) {
  if (!(await confirmar(`Bloquear ${nome}?`, 'Você deixa de ver as mensagens e os pedidos dessa pessoa, e ela não consegue escrever para você. Dá para desbloquear no menu do seu nome, em Pessoas bloqueadas.', 'Bloquear', true))) return;
  try { await api('/api/colega/bloquear', { usuario_id: id, bloquear: true }); avisar(`${nome} foi bloqueada.`); await atualizarEu(true); if (depois) depois(); }
  catch (e) { avisar(e.message, true); }
}

function folhaDenunciar(m) {
  folha((f, fechar) => {
    const motivo = h('select', { 'aria-label': 'Motivo da denúncia' }, MOTIVOS.map(([v, t]) => h('option', { value: v }, t)));
    const texto = h('input', { type: 'text', maxlength: '300', placeholder: 'Quer explicar? (opcional)', 'aria-label': 'Explicação' });
    const btn = h('button', { class: 'btn perigo' }, 'Enviar denúncia');
    btn.onclick = async () => {
      botaoCarregando(btn);
      try { await api('/api/denunciar', { mensagem_id: m.id, motivo: motivo.value, texto: texto.value }); fechar(); avisar('Denúncia enviada à gestão.'); }
      catch (e) { botaoPronto(btn); avisar(e.message, true); }
    };
    f.append(h('h2', null, 'Denunciar mensagem'),
      h('p', { class: 'mudo', style: { marginTop: '8px' } }, `A gestão vai ler a mensagem de ${m.de_nome || 'colega'} e decidir o que fazer. Só a gestão vê a denúncia.`),
      h('label', { class: 'campo' }, h('span', null, 'Motivo'), motivo), h('label', { class: 'campo' }, h('span', null, 'Detalhe'), texto),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar'), btn));
  });
}

function folhaOpcoesMensagem(m, autorId, autorNome) {
  folha((f, fechar) => f.append(
    h('h2', null, 'Opções da mensagem'),
    h('p', { class: 'mudo', style: { marginTop: '8px' } }, `De ${autorNome}.`),
    h('div', { class: 'linha-botoes', style: { marginTop: '14px', flexDirection: 'column' } },
      h('button', { class: 'btn claro largo', onclick: () => { fechar(); folhaDenunciar(m); } }, 'Denunciar esta mensagem'),
      h('button', { class: 'btn claro largo', onclick: () => { fechar(); bloquearPessoa(autorId, autorNome, () => recarregarChat(true)); } }, `Bloquear ${autorNome}`)),
    h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Fechar'))));
}

function botaoMaisMensagem(m, autorId, autorNome) {
  return h('button', { type: 'button', class: 'msg-mais', 'aria-label': `Mais opções: denunciar ou bloquear ${autorNome}`, onclick: () => folhaOpcoesMensagem(m, autorId, autorNome) }, '⋯');
}

async function folhaBloqueados() {
  let lista = [];
  try { lista = (await api('/api/bloqueios')).bloqueados; } catch (e) { avisar(e.message, true); return; }
  folha((f, fechar) => f.append(
    h('h2', null, 'Pessoas bloqueadas'),
    lista.length ? h('div', { class: 'lista', style: { marginTop: '12px' } }, lista.map((u) => h('div', { class: 'item' },
      h('span', { class: 'avatar' }, iniciais(u.nome)), h('span', { class: 'meio' }, h('strong', null, u.nome)),
      h('button', { class: 'btn claro pequeno', onclick: async (e) => { botaoCarregando(e.currentTarget); try { await api('/api/colega/bloquear', { usuario_id: u.id, bloquear: false }); fechar(); avisar(`${u.nome} foi desbloqueada.`); atualizarEu(true); } catch (x) { avisar(x.message, true); } } }, 'Desbloquear'))))
      : h('p', { class: 'mudo', style: { marginTop: '8px' } }, 'Você não bloqueou ninguém.'),
    h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Fechar'))));
}

function folhaExcluirConta() {
  folha((f, fechar) => {
    const pedido = E.eu.exclusao_pedida;
    if (pedido) {
      f.append(h('h2', null, 'Exclusão da conta pedida'),
        h('p', { class: 'mudo', style: { marginTop: '8px' } }, `Você pediu em ${diaCurto(pedido)}. A gestão ${L('do')} vai apagar seus dados pessoais. Até lá, você continua com acesso.`),
        h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Fechar'),
          h('button', { class: 'btn', onclick: async (e) => { botaoCarregando(e.currentTarget); try { await api('/api/excluir-conta/cancelar', {}); fechar(); await atualizarEu(true); avisar('Pedido cancelado.'); } catch (x) { avisar(x.message, true); } } }, 'Cancelar o pedido')));
      return;
    }
    const senha = h('input', { type: 'password', autocomplete: 'current-password', 'aria-label': 'Sua senha' });
    const erro = h('div', { class: 'faixa erro oculto' });
    const btn = h('button', { class: 'btn perigo' }, 'Pedir exclusão da conta');
    btn.onclick = async () => {
      erro.classList.add('oculto'); botaoCarregando(btn);
      try { await api('/api/excluir-conta/pedir', { senha: senha.value }); fechar(); await atualizarEu(true); avisar('Pedido enviado à gestão.'); }
      catch (e) { botaoPronto(btn); erro.textContent = e.message; erro.classList.remove('oculto'); }
    };
    f.append(h('h2', null, 'Excluir minha conta'),
      h('p', { class: 'mudo', style: { marginTop: '8px' } }, `O pedido vai para a gestão ${L('do')}, que é quem cuida dos seus dados. Ela apaga seu nome, usuário, senha, mensagens e arquivos. Os números de impressão ficam nos relatórios, sem o seu nome (aparece "Pessoa removida").`),
      h('label', { class: 'campo' }, h('span', null, 'Digite sua senha para confirmar'), senha), erro,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar'), btn));
  });
}

function dirModeracao(painel, r) {
  const den = (r && r.denuncias) || [], exc = (r && r.exclusoes) || [];
  const acao = async (b, rota, corpo, ok) => { botaoCarregando(b); try { await api(rota, corpo); avisar(ok); await atualizarEu(true); recarregarDirecao(); } catch (e) { botaoPronto(b); avisar(e.message, true); } };
  const motivoTxt = (m) => { const [k, ...resto] = String(m || 'outro').split(': '); return (MOTIVOS.find(([v]) => v === k) || [0, k])[1] + (resto.length ? ` — ${resto.join(': ')}` : ''); };
  return h('div', null,
    h('div', { class: 'secao', style: { marginTop: '0' } }, h('h2', null, den.length ? `Denúncias (${den.length})` : 'Denúncias'),
      den.length ? den.map((d) => {
        const apagar = h('button', { class: 'btn pequeno' }, 'Apagar a mensagem');
        apagar.onclick = () => acao(apagar, '/api/admin/denuncias/resolver', { id: d.id, acao: 'apagar_mensagem' }, 'Mensagem apagada.');
        const desat = h('button', { class: 'btn claro pequeno' }, 'Desativar a pessoa');
        desat.onclick = async () => { if (await confirmar(`Desativar ${d.alvo_nome}?`, 'A pessoa perde o acesso agora. Dá para reativar em Equipe.', 'Desativar', true)) acao(desat, '/api/admin/denuncias/resolver', { id: d.id, acao: 'desativar' }, 'Pessoa desativada.'); };
        const ign = h('button', { class: 'btn claro pequeno' }, 'Ignorar');
        ign.onclick = () => acao(ign, '/api/admin/denuncias/resolver', { id: d.id, acao: 'ignorar' }, 'Denúncia encerrada.');
        return h('div', { class: 'bloco' },
          h('strong', null, `${d.denunciante_nome || 'Alguém'} denunciou ${d.alvo_nome || 'uma pessoa'}`),
          h('p', { class: 'mudo pequeno' }, `${motivoTxt(d.motivo)} · ${diaCurto(d.criado_em)}${d.conversa === 'mural' ? ' · no mural' : d.conversa ? ' · em conversa direta' : ''}`),
          d.trecho ? h('p', { class: 'aumento-just' }, `“${d.trecho}”`) : null,
          h('div', { class: 'linha-botoes', style: { marginTop: '10px' } }, d.mensagem_id ? apagar : null, d.alvo_ativo ? desat : null, ign));
      }) : h('div', { class: 'bloco vazio' }, 'Nenhuma denúncia esperando.')),
    E.eu.usuario.admin ? h('div', { class: 'secao' }, h('h2', null, exc.length ? `Pedidos para excluir a conta (${exc.length})` : 'Pedidos para excluir a conta'),
      h('p', { class: 'mudo pequeno' }, 'Quem pede abre a conta para ser apagada. Ao atender, o nome vira "Pessoa removida" e mensagens, senha e arquivos são apagados. Os números ficam nos relatórios.'),
      exc.length ? exc.map((u) => {
        const sim = h('button', { class: 'btn perigo pequeno' }, 'Apagar os dados');
        sim.onclick = async () => { if (await confirmar(`Apagar os dados de ${u.nome}?`, 'Não dá para desfazer.', 'Apagar', true)) acao(sim, '/api/admin/exclusoes/atender', { id: u.id }, 'Dados apagados.'); };
        const nao = h('button', { class: 'btn claro pequeno' }, 'Recusar');
        nao.onclick = () => acao(nao, '/api/admin/exclusoes/recusar', { id: u.id }, 'Pedido recusado.');
        return h('div', { class: 'bloco' }, h('strong', null, u.nome), h('p', { class: 'mudo pequeno' }, `Usuário ${u.login} · pediu em ${diaCurto(u.pedido_em)}`), h('div', { class: 'linha-botoes', style: { marginTop: '10px' } }, sim, nao));
      }) : h('div', { class: 'bloco vazio' }, 'Nenhum pedido.')) : null);
}

/* ================================================================ gestão */

const CORES = ['#0E7C7B', '#6B4FBB', '#C2410C', '#1D4ED8', '#B4235A', '#4D7C0F'];

function subsGestao() {
  if (!E.eu.usuario.admin) return [['resumo', 'Resumo do mês'], ['relatorios', 'Relatórios'], ['equipe', 'Equipe'], ['moderacao', 'Denúncias'], ['regras', 'Regras do setor']];
  const central = E.eu.instalacao === 'central';
  return [['resumo', 'Resumo do mês'], ...(central ? [['setores', 'Setores']] : []), ['relatorios', 'Relatórios'], ['equipe', 'Equipe'], ['moderacao', 'Denúncias'], ['trocas', 'Trocas'], ['impressoras', 'Impressoras'], ['ajustes', 'Ajustes']];
}

async function telaDirecao(sub) {
  if (sub === 'registros') sub = 'relatorios';
  const subs = subsGestao();
  if (!subs.some(([id]) => id === sub)) sub = 'resumo';
  const nav = h('nav', { class: 'sub-abas', 'aria-label': 'Partes da Gestão' }, subs.map(([id, nome]) => h('a', { href: '#gestao/' + id, 'aria-current': sub === id ? 'page' : null }, nome)));
  const corpo = h('div', null, h('div', { class: 'bloco vazio' }, h('span', { class: 'carregando' })));
  moldura('Gestão', E.eu.usuario.admin ? E.eu.escola : E.eu.usuario.setor, h('div', null, nav, corpo));
  mostrarAbaAtiva(nav);
  const mes = E.direcao.mes || E.eu.mes;
  try {
    const pedidos = [api('/api/admin/painel?mes=' + mes)];
    if (sub === 'impressoras') pedidos.push(api('/api/admin/sistema'));
    if (sub === 'relatorios') pedidos.push(api(`/api/admin/relatorio?mes=${mes}&${consultaRelatorio()}`));
    if (sub === 'ajustes') pedidos.push(api('/api/admin/licenca'));
    if (sub === 'trocas') pedidos.push(api('/api/admin/trocas?mes=' + mes));
    if (sub === 'resumo') pedidos.push(api('/api/admin/aumentos'));
    if (sub === 'moderacao') pedidos.push(api('/api/admin/denuncias'));
    if (sub === 'setores') pedidos.push(api('/api/admin/setores?mes=' + mes));
    const [painel, extra] = await Promise.all(pedidos);
    E.direcao.dados = painel;
    let naRota = (location.hash.split('/')[1] || 'resumo').replace('registros', 'relatorios');
    if (!subs.some(([id]) => id === naRota)) naRota = 'resumo';
    if (!/^#(gestao|direcao)/.test(location.hash) || naRota !== sub) return;
    const fn = { resumo: (pp, a) => h('div', null, blocoAumentos(a), dirResumo(pp)), equipe: dirEquipe, trocas: dirTrocas, impressoras: dirImpressoras, relatorios: dirRelatorios, ajustes: dirAjustes, setores: dirSetores, regras: dirRegras, moderacao: dirModeracao }[sub] || dirResumo;
    corpo.replaceChildren(fn(painel, extra));
    corpo.querySelectorAll('select[data-valor]').forEach((s) => { s.value = s.dataset.valor; });
    if (E.direcao.irParaEntrada && sub === 'resumo') {  // veio do botão do cartaz, na aba Equipe
      E.direcao.irParaEntrada = false;
      const alvo = document.getElementById('entrada-equipe'); if (alvo) alvo.scrollIntoView({ block: 'start' });
    }
  } catch (e) { corpo.replaceChildren(h('div', { class: 'faixa erro' }, e.message)); }
}
function recarregarDirecao() { telaDirecao(location.hash.split('/')[1] || 'resumo'); }
function filtrosQuery() { return new URLSearchParams(E.direcao.filtros || {}).toString(); }

// Período do relatório (2.7.0): um mês, os últimos dias, o ano ou datas à escolha. As datas saem do relógio do aparelho.
const PERIODOS = [['mes', 'Um mês'], ['7', 'Últimos 7 dias'], ['30', 'Últimos 30 dias'], ['90', 'Últimos 90 dias'], ['ano', 'Este ano'], ['perso', 'Datas à escolha']];
function dataIso(d) { const z = (v) => String(v).padStart(2, '0'); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`; }
function dataBr(iso) { return `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}`; }
function periodoDatas() {
  const pe = E.direcao.periodo;
  if (!pe || pe.tipo === 'mes') return null;
  const hoje = new Date();
  if (pe.tipo === 'ano') return { de: `${hoje.getFullYear()}-01-01`, ate: dataIso(hoje) };
  if (pe.tipo === 'perso') return pe.de && pe.ate ? { de: pe.de, ate: pe.ate } : null;
  const ini = new Date(hoje);
  ini.setDate(ini.getDate() - (Number(pe.tipo) - 1));
  return { de: dataIso(ini), ate: dataIso(hoje) };
}
function consultaRelatorio() {
  const d = periodoDatas();
  return [d ? `de=${d.de}&ate=${d.ate}` : '', filtrosQuery()].filter(Boolean).join('&');
}

function seletorMes(p) {
  const s = h('select', { 'aria-label': 'Mês', 'data-valor': p.mes }, p.meses.map((m) => h('option', { value: m }, mesTitulo(m))));
  s.onchange = () => { E.direcao.mes = s.value; recarregarDirecao(); };
  return s;
}

function blocoAumentos(r) {
  const lista = (r && r.aumentos) || [];
  if (!lista.length) return null;
  const pend = lista.filter((a) => a.status === 'pendente');
  const feitos = lista.filter((a) => a.status !== 'pendente').slice(0, 8);
  const cartao = (a) => {
    const qtd = h('input', { type: 'number', inputmode: 'numeric', min: '1', max: String(a.paginas), value: String(a.paginas), 'aria-label': 'Páginas aprovadas' });
    const decisao = h('input', { type: 'text', maxlength: '300', placeholder: 'Observação (a pessoa lê)', 'aria-label': 'Observação para a pessoa; obrigatória para não aprovar' });
    const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '8px', marginBottom: '0' } });
    const sim = h('button', { class: 'btn pequeno' }, 'Aprovar');
    const nao = h('button', { class: 'btn claro pequeno' }, 'Não aprovar');
    const responder = async (aprovar, b) => {
      erro.classList.add('oculto');
      if (!aprovar && decisao.value.trim().length < 3) { erro.textContent = 'Escreva o motivo para não aprovar. A pessoa vai ler.'; erro.classList.remove('oculto'); decisao.focus(); return; }
      botaoCarregando(b);
      try {
        await apiGestao('/api/admin/aumento/responder', { id: a.id, aprovar, paginas: Number(qtd.value || a.paginas), decisao: decisao.value }, 'justificativa_setor');
        avisar(aprovar ? 'Aumento aprovado.' : 'Pedido respondido.'); recarregarDirecao();
      } catch (e) { botaoPronto(b); if (e.codigo !== 'cancelado') { erro.textContent = e.message; erro.classList.remove('oculto'); } }
    };
    sim.onclick = () => responder(true, sim); nao.onclick = () => responder(false, nao);
    const sobra = a.setor_sobra == null ? '' : a.setor_sobra >= 0 ? ` Sobram ${pag(a.setor_sobra)} na cota de ${a.setor}.` : ` ${a.setor} já passou da cota em ${pag(-a.setor_sobra)}.`;
    return h('div', { class: 'bloco aumento' },
      h('strong', null, `${a.pessoa} pede ${pag(a.paginas)} a mais na ${curto(a.impressora)}`),
      h('p', { class: 'aumento-just' }, `“${a.justificativa}”`),
      h('p', { class: 'mudo pequeno' }, `${diaCurto(a.criado_em)}. ${a.restante < 0 ? `Já está ${pag(-a.restante)} além da cota.` : `Tem ${pag(a.restante)} agora.`}${sobra}`),
      h('div', { class: 'aumento-acoes' }, h('label', { class: 'aumento-qtd' }, h('span', null, 'Aprovar'), qtd, h('span', null, 'páginas')), decisao),
      erro, h('div', { class: 'linha-botoes', style: { marginTop: '10px' } }, sim, nao));
  };
  return h('div', { class: 'secao' }, h('h2', null, pend.length ? `Pedidos de aumento de cota (${pend.length})` : 'Pedidos de aumento de cota'),
    pend.length ? pend.map(cartao) : h('div', { class: 'bloco vazio' }, 'Nenhum pedido esperando.'),
    feitos.length ? h('details', { class: 'bloco' }, h('summary', null, 'Respondidos'), h('ul', { class: 'lista-simples' }, feitos.map((a) => h('li', null,
      h('strong', null, `${a.pessoa}: ${a.status === 'aprovado' ? `aprovado ${pag(a.aprovadas)} de ${n(a.paginas)}` : 'não aprovado'}`),
      h('span', { class: 'mudo pequeno' }, ` · “${a.justificativa}”${a.decisao ? ` · ${a.decisao}` : ''}${a.respondido_nome ? ` · por ${a.respondido_nome}` : ''}`))))) : null);
}

function camposRegras(pol, opcoes = {}) {
  // aumento de cota e cota negativa: o mesmo bloco nos ajustes gerais, nas regras do setor e na ficha do setor
  const st = { aumento: !!pol.aumento, negativo: Number(pol.negativo || 0), desconta: pol.negativo_desconta !== false };
  const aumento = h('input', { type: 'checkbox', checked: st.aumento });
  const neg = h('input', { type: 'number', inputmode: 'numeric', min: '0', value: String(st.negativo), disabled: opcoes.semNegativo || false });
  const desconta = h('input', { type: 'checkbox', checked: st.desconta });
  const el = h('div', null,
    h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Aceitar pedidos de aumento de cota'), h('span', { class: 'dica' }, 'A pessoa pede com justificativa; o gestor aprova (no todo ou em parte) ou não, com o motivo. Fica registrado.')), aumento),
    h('label', { class: 'campo' }, h('span', null, 'Cota negativa: páginas além da cota, por pessoa, por mês'), neg,
      h('div', { class: 'dica' }, opcoes.semNegativo ? opcoes.semNegativo : '0 = não deixa passar da cota. Com um número, a pessoa pode imprimir até esse tanto além, escrevendo a justificativa na hora.')),
    h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'O que passar sai da cota do mês seguinte'), h('span', { class: 'dica' }, 'Desligado, só fica registrado nos relatórios, sem desconto.')), desconta));
  return { el, valor: () => ({ aumento: aumento.checked, negativo: Number(neg.value || 0), negativo_desconta: desconta.checked }) };
}

function dirRegras(p) {
  const meu = setorDe(p, E.eu.usuario.setor_id);
  if (!meu) return h('div', { class: 'bloco vazio' }, 'Setor não encontrado.');
  const pol = meu.politica;
  const campos = camposRegras(pol, { semNegativo: pol.pode_negativo ? null : 'A TI não permite cota negativa neste setor.' });
  const btn = h('button', { class: 'btn largo', style: { marginTop: '16px' } }, 'Salvar as regras do setor');
  btn.onclick = async () => {
    botaoCarregando(btn);
    try { await api('/api/admin/setor/politica', { setor_id: meu.id, politica: campos.valor() }); avisar('Regras salvas.'); botaoPronto(btn); atualizarEu(true); }
    catch (e) { avisar(e.message, true); botaoPronto(btn); }
  };
  return h('div', null,
    h('div', { class: 'bloco' }, h('h3', { style: { marginTop: '0' } }, meu.caminho),
      meu.cota != null ? h('p', null, `Cota do setor: ${pag(meu.cota)} por mês. Já entregues: ${pag(meu.distribuido)}.`) : null,
      h('ul', { class: 'lista-simples' },
        h('li', null, pol.cadastro === 'ti' ? 'Quem cadastra as pessoas: a TI.' : 'Quem cadastra as pessoas: você, em Equipe.'),
        h('li', null, pol.exceder ? 'Você pode passar da cota do setor, escrevendo a justificativa (a TI vê).' : 'A soma das cotas não pode passar da cota do setor. Para mais, peça à TI.'))),
    h('div', { class: 'secao' }, h('h2', null, 'Aumento de cota e cota negativa'), h('div', { class: 'bloco' }, campos.el, btn)));
}

function dirSetores(p, r) {
  const todos = r.setores;
  const filhos = (id) => todos.filter((x) => x.pai_id === id);
  const raiz = todos.find((x) => x.id === 1);
  const agora_ = Date.now();
  const cartao = (sx, nivel) => {
    const dias = sx.ultimo_contato ? Math.floor((agora_ - new Date(sx.ultimo_contato.replace(' ', 'T')).getTime()) / 864e5) : null;
    const base = Math.max(sx.cota || 0, sx.distribuido.total, sx.usado, 1);
    const selos = [];
    if (sx.remoto) selos.push(h('span', { class: 'selo' }, 'Aparelho próprio'));
    if (sx.remoto && !sx.aderido) selos.push(h('span', { class: 'selo alerta' }, sx.codigo_ativo ? 'Código gerado' : 'Aparelho não ligado'));
    if (sx.remoto && sx.aderido && dias != null && dias >= 2) selos.push(h('span', { class: 'selo alerta' }, `Sem contato há ${dias} dias`));
    if (!sx.ativo) selos.push(h('span', { class: 'selo esgotado' }, 'Desativado'));
    const entregue = sx.remoto && sx.remoto_resumo && sx.remoto_resumo.distribuido != null ? sx.remoto_resumo.distribuido : sx.distribuido.total;
    if (sx.cota != null && entregue > sx.cota) selos.push(h('span', { class: 'selo esgotado' }, 'Acima da cota'));
    else if (sx.cota != null && sx.usado - (sx.excedente || 0) > sx.cota) selos.push(h('span', { class: 'selo esgotado', title: 'O relatório mostra mais páginas do que a cota e a cota negativa explicam. Confira as exceções e o aparelho.' }, 'Usou mais que a cota'));
    const quem = sx.remoto ? (sx.remoto_resumo && sx.remoto_resumo.pessoas != null ? `${n(sx.remoto_resumo.pessoas)} pessoas no aparelho` : 'Pessoas no aparelho da unidade')
      : `${n(sx.pessoas)} ${sx.pessoas === 1 ? 'pessoa' : 'pessoas'}`;
    return h('div', { class: 'bloco setor', style: { marginLeft: `${Math.min(nivel, 4) * 14}px` } },
      h('div', { class: 'setor-topo' }, h('strong', null, sx.nome), ...selos),
      h('div', { class: 'setor-numeros' },
        h('span', null, sx.cota == null ? 'Sem cota própria' : `Cota ${n(sx.cota)}/mês`),
        h('span', null, `Entregues ${n(entregue)}`),
        h('span', null, `Usadas no mês ${n(sx.usado)}`),
        sx.excedente ? h('span', { class: 'alem-txt' }, `${n(sx.excedente)} além da cota`) : null),
      sx.cota != null ? h('div', { class: 'barra-trilho setor-barra', 'aria-hidden': 'true' }, h('span', { class: 'barra-cheia', style: { width: `${Math.min(100, (100 * sx.usado) / base)}%` } })) : null,
      h('p', { class: 'mudo pequeno' }, [quem, sx.gestores.length ? `gestor: ${sx.gestores.join(', ')}` : (sx.id === 1 || sx.remoto ? null : 'sem gestor'),
        sx.remoto && sx.ultimo_contato ? `último contato ${diaCurto(sx.ultimo_contato)} ${hora(sx.ultimo_contato)}` : null].filter(Boolean).join(' · ')),
      sx.id === 1 ? null : h('div', { class: 'linha-botoes' },
        h('button', { class: 'btn claro pequeno', onclick: () => folhaSetor(sx, r) }, 'Editar'),
        sx.remoto ? h('button', { class: 'btn claro pequeno', title: 'Código de adesão, para ligar o aparelho pela rede', onclick: () => gerarCodigo(sx) }, 'Código') : null,
        sx.remoto ? h('button', { class: 'btn claro pequeno', title: 'Arquivo de adesão, para levar no pendrive', onclick: () => baixarArquivoAdesao(sx) }, 'Pendrive') : null));
  };
  const arvore = [];
  const andar = (sx, nivel) => { arvore.push(cartao(sx, nivel)); filhos(sx.id).forEach((f) => andar(f, nivel + 1)); };
  if (raiz) andar(raiz, 0);
  const entrada = h('input', { type: 'file', accept: '.json,application/json', class: 'oculto', id: 'rel-unidade' });
  entrada.onchange = async () => {
    const arq = entrada.files[0]; if (!arq) return;
    try { const r2 = await api('/api/admin/setor/relatorio', { relatorio: await arq.text() }); avisar(`Relatório de ${r2.unidade} carregado.`); recarregarDirecao(); }
    catch (e) { avisar(e.message, true); }
  };
  return h('div', null,
    seletorMes(p),
    h('div', { class: 'linha-botoes', style: { margin: '12px 0' } },
      h('button', { class: 'btn', onclick: () => folhaSetor(null, r) }, 'Novo setor ou unidade'),
      h('label', { class: 'btn claro', for: 'rel-unidade' }, 'Carregar relatório de unidade', entrada)),
    h('p', { class: 'dica' }, 'Cada setor só entrega o que recebeu: a soma das cotas dos setores de dentro e das pessoas não passa da cota do setor, a não ser que você deixe passar com justificativa. Unidade com aparelho próprio imprime sozinha, mesmo sem internet.'),
    arvore,
    blocoExcecoes(r.excecoes));
}

function blocoExcecoes(lista) {
  if (!lista || !lista.length) return null;
  return h('div', { class: 'secao' }, h('h2', null, 'Exceções do mês, com justificativa'),
    h('div', { class: 'lista' }, lista.map((x) => h('div', { class: 'item excecao' },
      h('span', { class: 'meio' },
        h('span', { class: 'selo ' + (x.tipo === 'aumento_recusado' ? 'esgotado' : 'alerta') }, x.rotulo),
        h('strong', null, [x.pessoa, E.eu.instalacao === 'central' ? x.setor : null].filter(Boolean).join(' · ') + (x.paginas ? ` · ${pag(x.paginas)}` : '')),
        h('span', { class: 'previa', style: { whiteSpace: 'normal' } }, x.justificativa ? `“${x.justificativa}”` : ''),
        h('div', { class: 'sobra' }, [`${diaCurto(x.criado_em)} ${hora(x.criado_em)}`, x.impressora, x.decisao, x.por_nome && x.tipo !== 'negativo' ? `por ${x.por_nome}` : null].filter(Boolean).join(' · ')))))));
}

async function gerarCodigo(sx) {
  try {
    const r = await api('/api/admin/setor/adesao', { id: sx.id });
    folha((f, fechar) => f.append(h('h2', null, `Código de ${sx.nome}`),
      h('p', { class: 'codigo-adesao' }, r.codigo),
      h('p', { class: 'mudo' }, `Vale por 7 dias e uma vez só. No aparelho da unidade, na primeira configuração, escolha "Unidade de uma central", informe o endereço da central${r.endereco ? ` (${r.endereco})` : ''} e este código.`),
      h('div', { class: 'rodape' }, h('button', { class: 'btn', onclick: fechar }, 'Pronto'))));
    recarregarDirecao();
  } catch (e) { avisar(e.message, true); }
}

async function baixarArquivoAdesao(sx) {
  const ok = await confirmar(`Arquivo de adesão de ${sx.nome}`,
    'Serve para ligar o aparelho da unidade sem internet (leve no pendrive) e para levar as mudanças até ele. O arquivo traz a chave da unidade: guarde como uma senha. Ao gerar um arquivo novo, o aparelho que estava ligado com a chave antiga precisa receber este arquivo.', 'Baixar arquivo');
  if (!ok) return;
  location.href = `/api/admin/setor/arquivo?id=${sx.id}`;
}

function folhaSetor(sx, r) {
  const todos = r.setores;
  const dentro = sx ? new Set((function sub(id) { const ids = [id]; todos.filter((x) => x.pai_id === id).forEach((f) => ids.push(...sub(f.id))); return ids; })(sx.id)) : new Set();
  folha((f, fechar) => {
    const pol = sx ? sx.politica : { cadastro: 'gestor', exceder: false, pode_negativo: false, aumento: true, negativo: 0, negativo_desconta: true };
    const nome = h('input', { type: 'text', value: sx ? sx.nome : '', maxlength: '80', autofocus: true, placeholder: 'Ex.: Financeiro, Filial Centro, Secretaria de Saúde' });
    const pais = todos.filter((x) => !x.remoto && x.ativo && !dentro.has(x.id));
    const pai = h('select', { 'aria-label': 'Dentro de' }, pais.map((x) => h('option', { value: String(x.id) }, x.caminho)));
    pai.value = String(sx ? sx.pai_id : 1);
    const cota = h('input', { type: 'number', inputmode: 'numeric', min: '0', value: String(sx ? sx.cota || 0 : 0) });
    const temFilhos = sx && todos.some((x) => x.pai_id === sx.id && x.ativo);
    const remoto = h('input', { type: 'checkbox', checked: sx ? sx.remoto : false, disabled: !!temFilhos });
    const ativo = h('input', { type: 'checkbox', checked: sx ? sx.ativo : true });
    let cadastro = pol.cadastro;
    const segCad = h('div', { class: 'segmentos' }, [['gestor', 'O gestor do setor'], ['ti', 'A TI']].map(([v, t]) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(cadastro === v) }, t);
      b.onclick = () => { cadastro = v; segCad.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); };
      return b;
    }));
    const exceder = h('input', { type: 'checkbox', checked: !!pol.exceder });
    const podeNeg = h('input', { type: 'checkbox', checked: !!pol.pode_negativo });
    const regras = camposRegras(pol);
    const caixaRegras = h('div', { class: remoto.checked ? 'oculto' : '' }, h('h3', { style: { marginTop: '22px' } }, 'Regras para as pessoas do setor'), regras.el,
      h('p', { class: 'dica' }, 'O gestor do setor também pode mudar estas regras, dentro do que você permitir acima.'));
    remoto.onchange = () => caixaRegras.classList.toggle('oculto', remoto.checked);
    const btn = h('button', { class: 'btn' }, sx ? 'Salvar' : 'Criar');
    btn.onclick = async () => {
      botaoCarregando(btn);
      const politica = { cadastro, exceder: exceder.checked, pode_negativo: podeNeg.checked, ...(remoto.checked ? {} : regras.valor()) };
      if (!podeNeg.checked) politica.negativo = 0;
      try {
        await apiGestao('/api/admin/setor', { id: sx ? sx.id : null, nome: nome.value, pai_id: Number(pai.value), cota: Number(cota.value || 0), remoto: remoto.checked, ativo: ativo.checked, politica });
        fechar(); avisar(sx ? 'Setor salvo.' : 'Setor criado.'); recarregarDirecao();
      } catch (e) { if (e.codigo !== 'cancelado') avisar(e.message, true); botaoPronto(btn); }
    };
    f.append(h('h2', null, sx ? sx.nome : 'Novo setor ou unidade'),
      h('label', { class: 'campo' }, h('span', null, 'Nome'), nome),
      h('label', { class: 'campo' }, h('span', null, 'Fica dentro de'), pai),
      h('label', { class: 'campo' }, h('span', null, 'Cota do setor: páginas por mês'), cota,
        h('div', { class: 'dica' }, 'Soma de tudo o que o setor entrega: pessoas e setores de dentro, em todas as impressoras.')),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Unidade com aparelho próprio'),
        h('span', { class: 'dica' }, temFilhos ? 'Só um setor sem subdivisões pode ter aparelho próprio.' : 'Filial, escola ou posto com a própria caixinha ou computador, ligada a esta central pela rede ou por pendrive. As pessoas de lá imprimem pelo aparelho de lá.')), remoto),
      h('div', { class: 'campo' }, h('span', { class: 'mudo pequeno', style: { fontWeight: '700', display: 'block', marginBottom: '6px' } }, 'Quem cadastra as pessoas'), segCad),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'O gestor pode passar da cota do setor'), h('span', { class: 'dica' }, 'Sempre com justificativa, que você vê em Exceções.')), exceder),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Pode ter cota negativa'), h('span', { class: 'dica' }, 'Deixa o gestor do setor permitir que as pessoas imprimam além da cota, com justificativa.')), podeNeg),
      caixaRegras,
      sx ? h('label', { class: 'interruptor' }, h('strong', null, 'Setor ativo'), ativo) : null,
      sx && sx.remoto && sx.aderido ? h('button', { class: 'btn claro largo', style: { marginTop: '12px', color: 'var(--perigo)' }, onclick: async () => {
        if (!(await confirmar(`Desligar o aparelho de ${sx.nome}?`, 'Ele para de receber as cotas da central. Para ligar de novo, gere um código ou um arquivo de adesão.', 'Desligar', true))) return;
        try { await api('/api/admin/setor/desligar', { id: sx.id }); fechar(); avisar('Aparelho desligado da central.'); recarregarDirecao(); } catch (e) { avisar(e.message, true); }
      } }, 'Desligar o aparelho da central') : null,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
  });
}

function dirResumo(p) {
  const imps = p.impressoras.filter((i) => i.ativa);
  const ativos = p.usuarios.filter((u) => u.ativo);
  return h('div', null,
    seletorMes(p),
    imps.map((i) => {
      const total = i.cota_total;
      const base = Math.max(total, i.distribuido, i.usado) || 1;
      const avisos = [];
      if (total && i.distribuido > total) avisos.push(h('div', { class: 'faixa erro', style: { marginTop: '12px', marginBottom: '0' } }, `Foram distribuídas ${pag(i.distribuido)}, mas a cota do grupo é ${n(total)}. Reduza as cotas na aba Equipe.`));
      else if (total && i.reserva > 0) avisos.push(h('p', { class: 'dica', style: { marginTop: '10px' } }, `${pag(i.reserva)} ainda sem dona. Dá para liberar a alguém pela aba Equipe.`));
      if (!i.sistema) avisos.push(h('p', { class: 'dica' }, 'Em modo teste: não imprime de verdade. Ligue-a a uma impressora do computador na aba Impressoras.'));
      if (i.custo_pagina > 0) avisos.push(h('p', { class: 'dica' }, `${precoPagina(i.custo_pagina)} por página${total ? `. A cota do grupo vale ${reais(total * i.custo_pagina)} por mês` : ''}.`));
      else avisos.push(h('p', { class: 'dica' }, 'Informe o custo por página na aba Impressoras para ver os valores em reais.'));
      avisos.push(blocoConferencia(i));
      avisos.push(tabelaMeses(i));
      return h('section', { class: 'bloco', style: { '--cor': i.cor, marginTop: '12px', borderLeft: '6px solid var(--cor)' } },
        h('h2', { style: { fontSize: '17px' } }, i.nome),
        h('div', { class: 'numeros' },
          h('div', null, h('b', null, total ? n(total) : 'Livre'), 'cota do grupo'),
          h('div', null, h('b', null, n(i.distribuido)), 'distribuídas'),
          h('div', null, h('b', null, n(i.usado)), 'impressas'),
          total ? h('div', null, h('b', null, n(total - i.usado)), 'restam no grupo') : null,
          i.custo_pagina > 0 ? h('div', null, h('b', null, reais(i.gasto)), 'gasto no mês') : null),
        h('div', { class: 'barra', role: 'img', 'aria-label': `${n(i.usado)} impressas de ${n(total || i.distribuido)}` },
          h('i', { style: { width: `${(i.usado / base) * 100}%`, background: 'var(--cor)' } }),
          h('i', { style: { width: `${(Math.max(0, i.distribuido - i.usado) / base) * 100}%`, background: 'var(--cor)', opacity: '.3' } })),
        h('div', { class: 'legenda' }, h('span', { style: { '--c': i.cor } }, 'impressas'), h('span', { style: { '--c': i.cor + '4D' } }, 'distribuídas e ainda não usadas')),
        avisos);
    }),
    h('div', { class: 'secao' }, h('h2', null, 'Quanto cada pessoa ainda tem'),
      h('div', { class: 'bloco' }, h('div', { class: 'rolar' }, h('table', { class: 'tabela' },
        h('thead', null, h('tr', null, h('th', null, 'Pessoa'), imps.map((i) => h('th', { class: 'n' }, curto(i.nome))))),
        h('tbody', null, ativos.map((u) => h('tr', null, h('td', null, u.nome),
          imps.map((i) => {
            const s = u.saldos[i.id];
            const frac = s.cota > 0 ? Math.max(0, Math.min(1, s.restante / s.cota)) : 0;
            return h('td', { class: 'n', style: { '--cor': i.cor } }, `${n(s.restante)} de ${n(s.cota)}`,
              h('div', { class: 'mini-barra' }, h('i', { style: { width: `${frac * 100}%` } })),
              i.custo_pagina > 0 && s.gasto > 0 ? h('div', { class: 'dica', style: { marginTop: '4px' } }, `gastou ${reais(s.gasto)}`) : null);
          })))))))),
    h('div', { class: 'secao' },
      h('a', { class: 'btn claro largo', href: '/api/admin/relatorio.csv?mes=' + p.mes, download: '' }, 'Baixar planilha do mês'),
      h('p', { class: 'dica', style: { textAlign: 'center' } }, 'Abre no Excel ou no LibreOffice Calc.')),
    h('div', { class: 'secao', id: 'entrada-equipe' }, h('h2', null, 'Endereço para os celulares'),
      h('div', { class: 'bloco' },
        p.endereco.length ? null : h('p', { role: 'status' }, h('strong', null, 'Este computador não está numa rede agora.'),
          ' Por isso não há endereço para os celulares. Confira o Wi-Fi ou o cabo de rede dele e abra esta aba de novo: o endereço aparece sozinho.'),
        p.endereco.map((e) => h('div', { class: 'endereco' }, e)),
        qrDoEndereco(p.endereco[0]),
        acoesCartaz(p),
        p.endereco.length ? h('p', { class: 'dica' }, `Com o celular no Wi-Fi ${L('do')}, abra este endereço no navegador. Dica: use "Adicionar à tela de início" para virar um ícone.`) : null,
        p.endereco.length ? h('p', { class: 'dica' }, 'No app Folha a Folha do Android, toque em "Ler QR code" e aponte a câmera para o quadrado acima: o app acha o servidor sozinho.') : null)));
}

// copia um texto (sem HTTPS o navegador não deixa usar a área de transferência nova: usa o jeito antigo)
async function copiarTexto(valor, feito = 'Endereço copiado.') {
  try { await navigator.clipboard.writeText(valor); avisar(feito); return; } catch (e) { /* sem HTTPS */ }
  const t = h('textarea', { style: { position: 'fixed', opacity: '0' } }); t.value = valor; document.body.append(t); t.select();
  try { document.execCommand('copy'); avisar(feito); } catch (e) { avisar('Segure o dedo no endereço para copiar.'); }
  t.remove();
}

// Cartaz com o QR code (2.6.0): imprimir sem contar na cota, baixar em PDF e copiar o endereço
function acoesCartaz(p) {
  const endereco = p.endereco[0];
  if (!endereco) return null;
  const reais = p.impressoras.filter((i) => i.ativa && i.sistema);
  const imprimir = E.eu.usuario.admin ? h('button', { type: 'button', class: 'btn largo', onclick: () => folhaImprimirCartaz(reais) }, 'Imprimir cartaz') : null;
  return h('div', { class: 'acoes-cartaz' },
    imprimir,
    h('a', { class: 'btn claro largo', href: '/api/admin/cartaz.pdf', download: 'cartaz-folha-a-folha.pdf' }, 'Baixar cartaz (PDF)'),
    h('button', { type: 'button', class: 'btn claro largo', onclick: () => copiarTexto(endereco) }, 'Copiar endereço'),
    h('p', { class: 'dica' }, 'O cartaz é uma folha com o nome do lugar, este QR code, o endereço e os passos para entrar. Imprimir o cartaz não conta na cota de ninguém.'));
}

function folhaImprimirCartaz(reais) {
  if (!reais.length) { avisar('Nenhuma impressora está ligada a uma impressora do computador. Baixe o cartaz em PDF.', true); return; }
  folha((f, fechar) => {
    const sel = h('select', { 'aria-label': 'Impressora' }, reais.map((i) => h('option', { value: i.id }, i.nome)));
    const erro = h('div', { class: 'faixa erro oculto', role: 'alert', style: { marginTop: '12px', marginBottom: '0' } });
    const btn = h('button', { class: 'btn' }, 'Imprimir');
    btn.onclick = async () => {
      botaoCarregando(btn, 'Enviando…'); erro.classList.add('oculto');
      try {
        const r = await api('/api/admin/cartaz/imprimir', { impressora_id: Number(sel.value), copias: 1 });
        fechar(); avisar(`Cartaz enviado para ${r.impressora}.`);
      } catch (e) { erro.textContent = e.message; erro.classList.remove('oculto'); botaoPronto(btn); }
    };
    f.append(h('h2', null, 'Imprimir o cartaz'),
      h('p', { class: 'mudo', style: { marginTop: '8px' } }, 'Sai uma folha com o QR code, o endereço e os passos para a equipe entrar. Não conta na cota de ninguém.'),
      h('label', { class: 'campo', style: { marginTop: '14px' } }, h('span', null, 'Em qual impressora?'), sel),
      erro,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar'), btn));
  });
}

// Imprimir o relatório (2.7.0): sai no papel da impressora escolhida e não conta na cota de ninguém
function folhaImprimirRelatorio(reais, consulta, r) {
  if (!reais.length) { avisar('Nenhuma impressora está ligada a uma impressora do computador. Baixe o relatório em PDF.', true); return; }
  folha((f, fechar) => {
    const sel = h('select', { 'aria-label': 'Impressora' }, reais.map((i) => h('option', { value: i.id }, i.nome)));
    const erro = h('div', { class: 'faixa erro oculto', role: 'alert', style: { marginTop: '12px', marginBottom: '0' } });
    const btn = h('button', { class: 'btn' }, 'Imprimir');
    btn.onclick = async () => {
      botaoCarregando(btn, 'Enviando…'); erro.classList.add('oculto');
      try {
        const q = `mes=${r.mes}${consulta ? '&' + consulta : ''}`;
        const x = await api(`/api/admin/relatorio/imprimir?${q}`, { impressora_id: Number(sel.value), copias: 1 });
        fechar(); avisar(`Relatório enviado para ${x.impressora}.`);
      } catch (e) { erro.textContent = e.message; erro.classList.remove('oculto'); botaoPronto(btn); }
    };
    f.append(h('h2', null, 'Imprimir o relatório'),
      h('p', { class: 'mudo', style: { marginTop: '8px' } }, `Sai o relatório de ${r.periodo ? r.periodo.rotulo : mesTitulo(r.mes)}, com os filtros que estão na tela. Não conta na cota de ninguém.`),
      h('label', { class: 'campo', style: { marginTop: '14px' } }, h('span', null, 'Em qual impressora?'), sel),
      erro,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Voltar'), btn));
  });
}

// a aba aberta fica à vista na faixa que rola de lado, e a faixa mostra quando há mais abas para um lado (2.6.0)
function mostrarAbaAtiva(nav) {
  const marcar = () => {
    nav.classList.toggle('mais-esq', nav.scrollLeft > 4);
    nav.classList.toggle('mais-dir', nav.scrollLeft + nav.clientWidth < nav.scrollWidth - 4);
  };
  const centrar = () => {
    const aberta = nav.querySelector('[aria-current="page"]');
    if (aberta) nav.scrollLeft = Math.max(0, aberta.offsetLeft - (nav.clientWidth - aberta.offsetWidth) / 2);
    marcar();
  };
  nav.addEventListener('scroll', marcar, { passive: true });
  centrar();
  // a largura muda com a Gestão aberta (janela, zoom, celular girado): a aba aberta volta para a vista (2.6.1)
  if (window.ResizeObserver) new ResizeObserver(centrar).observe(nav);
}

// QR code do endereço (primeiro da lista), gerado aqui mesmo por qr.js, sem biblioteca e sem internet
function qrDoEndereco(endereco) {
  const svg = endereco && typeof window.qrSvg === 'function' ? window.qrSvg(endereco, `QR code do endereço ${endereco}`) : '';
  if (!svg) return null;
  const caixa = h('div', { class: 'qr-endereco' });
  caixa.innerHTML = svg;  // o texto vem de qrSvg, que só escreve números e um nome sem < > & "
  return caixa;
}

function blocoConferencia(i) {
  const c = i.conferencia;
  const titulo = h('h3', { style: { fontSize: '15px', fontWeight: '800', marginBottom: '4px' } }, 'Conferência com o contador');
  if (!c) {
    return h('div', { style: { marginTop: '14px' } }, titulo,
      h('p', { class: 'dica', style: { marginTop: '0' } }, 'Para saber quanto foi impresso fora do sistema, leia ou anote o contador da impressora na aba Impressoras.'));
  }
  if (c.leituras < 2) {
    return h('div', { style: { marginTop: '14px' } }, titulo,
      h('p', { class: 'dica', style: { marginTop: '0' } }, `Primeira leitura em ${diaCurto(c.de)}, às ${hora(c.de)}. A partir da próxima, aparece aqui quanto foi impresso fora do sistema.`));
  }
  if (c.zerou) {
    return h('div', { style: { marginTop: '14px' } }, titulo,
      h('p', { class: 'dica', style: { marginTop: '0', color: 'var(--perigo)' } }, 'O contador diminuiu entre as leituras. Confira se a impressora foi trocada ou se alguma leitura foi anotada errada.'));
  }
  const fora = Math.max(c.fora, 0);
  const pct = c.contador > 0 ? Math.round((100 * fora) / c.contador) : 0;
  return h('div', { style: { marginTop: '14px' } }, titulo,
    h('div', { class: 'numeros', style: { marginTop: '4px' } },
      h('div', null, h('b', null, n(c.contador)), 'no contador da impressora'),
      h('div', null, h('b', null, n(c.sistema)), 'pelo sistema'),
      h('div', { style: { color: fora > 0 ? 'var(--perigo)' : null } }, h('b', { style: { color: 'inherit' } }, n(fora)), fora > 0 ? `fora do sistema (${pct}%)` : 'fora do sistema')),
    h('p', { class: 'dica' }, `De ${diaCurto(c.de)}, ${hora(c.de)}, a ${diaCurto(c.ate)}, ${hora(c.ate)}.`,
      c.valor_fora > 0 ? ` As páginas fora do sistema custaram ${reais(c.valor_fora)}.` : '',
      ' O contador inclui cópias feitas no vidro e relatórios da própria impressora.'),
    c.fora < 0 ? h('p', { class: 'dica' }, 'O sistema registrou mais páginas que o contador. Isso acontece quando uma impressão enviada falha na impressora.') : null);
}

async function lerContador(i, btn, forcar = false) {
  if (btn) botaoCarregando(btn, 'Lendo…');
  try {
    const r = await api('/api/admin/contador/ler', { impressora_id: i.id, forcar });
    avisar(`Contador: ${n(r.valor)} páginas${r.modelo ? `, ${r.modelo}` : ''}.`);
    recarregarDirecao();
  } catch (e) {
    if (btn) botaoPronto(btn);
    if (e.codigo === 'contador_menor') {
      if (await confirmar('Contador menor que o anterior', e.message, 'Registrar mesmo assim')) lerContador(i, null, true);
      return;
    }
    avisar(e.message, true);
  }
}

function folhaAnotar(i) {
  folha((f, fechar) => {
    const valor = h('input', { type: 'number', inputmode: 'numeric', min: '0', autofocus: true, placeholder: 'Ex.: 152340' });
    const btn = h('button', { class: 'btn' }, 'Registrar leitura');
    const enviar = async (forcar) => {
      botaoCarregando(btn);
      try {
        await api('/api/admin/contador/anotar', { impressora_id: i.id, valor: valor.value, forcar });
        fechar(); avisar('Leitura registrada.'); recarregarDirecao();
      } catch (e) {
        botaoPronto(btn);
        if (e.codigo === 'contador_menor') {
          if (await confirmar('Contador menor que o anterior', e.message, 'Registrar mesmo assim')) enviar(true);
          return;
        }
        avisar(e.message, true);
      }
    };
    btn.onclick = () => enviar(false);
    f.append(h('h2', null, `Anotar contador: ${curto(i.nome)}`),
      h('p', { class: 'mudo', style: { marginTop: '6px' } }, 'O total de páginas aparece no painel da impressora, no menu de informações ou de contadores, ou na página de configuração que ela imprime. Anote no primeiro e no último dia de cada mês.'),
      h('label', { class: 'campo' }, h('span', null, 'Total de páginas no contador'), valor),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
  });
}

function tabelaMeses(i) {
  const meses = i.meses || [];
  if (!(i.custo_pagina > 0) || !meses.length) return null;
  const temBase = i.base_mensal > 0;
  const corEconomia = (v) => (v > 0 ? 'var(--ok)' : v < 0 ? 'var(--perigo)' : null);
  const textoEconomia = (m) => {
    if (m.economia != null) return reais(m.economia);
    if (!m.fechado) return 'em andamento';
    return 'mês de início';
  };
  return h('div', { style: { marginTop: '14px' } },
    h('h3', { style: { fontSize: '15px', fontWeight: '800', marginBottom: '4px' } }, 'Mês a mês'),
    h('div', { class: 'rolar' }, h('table', { class: 'tabela' },
      h('thead', null, h('tr', null, h('th', null, 'Mês'), h('th', { class: 'n' }, 'Páginas'), h('th', { class: 'n' }, 'Gasto'),
        temBase ? h('th', { class: 'n' }, 'Economia') : null)),
      h('tbody', null, meses.map((m) => h('tr', null,
        h('td', null, mesCurto(m.mes)),
        h('td', { class: 'n' }, n(m.paginas)),
        h('td', { class: 'n' }, reais(m.gasto)),
        temBase ? h('td', { class: 'n', style: { color: corEconomia(m.economia), fontWeight: m.economia != null ? '800' : null } }, textoEconomia(m)) : null))))),
    h('p', { class: 'dica' }, temBase
      ? `Economia comparada à média de antes do sistema: ${pag(i.base_mensal)} por mês, ou ${reais(i.base_mensal * i.custo_pagina)}.`
      : 'Para ver a economia, informe na aba Impressoras quantas páginas eram impressas por mês antes do sistema.'));
}

function setorDe(p, sid) { return (p.setores || []).find((x) => x.id === (sid || 1)); }
function nomeSetorCurto(p, sid) { const x = setorDe(p, sid); return x ? x.nome : ''; }

function dirEquipe(p) {
  const imps = p.impressoras.filter((i) => i.ativa);
  const central = p.instalacao === 'central';
  const pelaTi = p.central && p.central.pela_ti;
  const linha = (u) => {
    const st_ = setorDe(p, u.setor_id);
    const remoto = st_ && st_.remoto;
    const prev = remoto
      ? (st_.impressoras_remotas.length ? st_.impressoras_remotas.map((i) => `${curto(i.nome)}: ${n(u.cotas_remotas[i.ref] || 0)}/mês`).join(', ') : 'Cotas na unidade')
      : imps.map((i) => `${curto(i.nome)}: ${n(u.saldos[i.id].base)}/mês`).join(', ');
    return h('button', { onclick: () => (u.anonimizado ? avisar('Os dados desta pessoa foram apagados.') : folhaPessoa(u, p)), style: { opacity: u.ativo ? '1' : '.55' } },
      h('span', { class: 'avatar' }, iniciais(u.nome)),
      h('span', { class: 'meio' },
        h('strong', null, u.nome, u.papel === 'admin' ? h('span', { class: 'selo teste' }, central ? 'TI' : 'Gestor') : u.papel === 'gestor' ? h('span', { class: 'selo teste' }, 'Gestor do setor') : null,
          u.ref_central ? h('span', { class: 'selo' }, 'Pela TI') : null,
          u.trocar_senha && u.ativo && !remoto ? h('span', { class: 'selo alerta' }, 'Ainda não criou a senha') : null,
          u.ativo ? null : h('span', { class: 'selo esgotado' }, u.anonimizado ? 'Dados apagados' : 'Acesso desativado')),
        u.login && !u.anonimizado ? h('div', { class: 'sobra' }, `Usuário: ${u.login}`) : null,
        central ? h('div', { class: 'sobra' }, (st_ ? st_.caminho : '') + (remoto ? ' (unidade com aparelho)' : '')) : null,
        h('span', { class: 'previa', style: { whiteSpace: 'normal' } }, prev),
        remoto ? null : h('div', { class: 'sobra' }, 'Restam agora: ', imps.map((i, k) => [k ? ', ' : '', h('b', null, n(u.saldos[i.id].restante)), ` ${curto(i.nome)}`]))));
  };
  const pend = p.pendentes || [];
  const espera = pend.length ? h('div', { class: 'secao espera-aprovacao', style: { marginTop: '0', marginBottom: '20px' } },
    h('h2', null, `Esperando aprovação (${pend.length})`),
    h('p', { class: 'mudo pequeno' }, 'Pediram o cadastro na tela de entrada. Ainda não entram nem têm cota. Aprove e defina as cotas, ou recuse.'),
    h('div', { class: 'lista' }, pend.map((u) => h('div', { class: 'item item-espera' },
      h('span', { class: 'avatar' }, iniciais(u.nome)),
      h('span', { class: 'meio' }, h('strong', null, u.nome),
        h('div', { class: 'sobra' }, `Usuário: ${u.login}`),
        u.obs ? h('div', { class: 'sobra' }, u.obs) : null,
        h('div', { class: 'sobra' }, `Pediu ${rotuloDia(u.criado_em).toLowerCase() === 'hoje' ? 'hoje' : rotuloDia(u.criado_em) === 'Ontem' ? 'ontem' : 'em ' + rotuloDia(u.criado_em)}, às ${hora(u.criado_em)}`),
        h('div', { class: 'linha-botoes', style: { marginTop: '8px' } },
          h('button', { class: 'btn pequeno', onclick: () => folhaPessoa(u, p, { aprovar: true }) }, 'Aprovar'),
          h('button', {
            class: 'btn claro pequeno',
            onclick: async (e) => {
              if (!(await confirmar(`Recusar o cadastro de ${u.nome}?`, 'O pedido é apagado. Se for engano, a pessoa pode pedir de novo.', 'Recusar', true))) return;
              botaoCarregando(e.currentTarget);
              try { await api('/api/admin/cadastro/recusar', { id: u.id }); avisar('Cadastro recusado.'); await atualizarEu(true); recarregarDirecao(); } catch (x) { avisar(x.message, true); }
            },
          }, 'Recusar'))))))) : null;
  return h('div', null,
    espera,
    pelaTi ? h('div', { class: 'faixa info' }, 'Nesta unidade, quem cadastra as pessoas é a TI, pela central. As mudanças chegam na sincronização.')
      : h('button', { class: 'btn largo', onclick: () => folhaPessoa(null, p) }, 'Adicionar pessoa'),
    h('button', { class: 'btn claro largo', style: { marginTop: '8px' }, onclick: () => { E.direcao.irParaEntrada = true; location.hash = '#gestao/resumo'; } }, 'Cartaz com QR code para a equipe entrar'),
    h('div', { class: 'lista', style: { marginTop: '16px' } }, p.usuarios.map(linha)));
}

/* Depois de cadastrar ou dar senha nova: o que entregar para a pessoa. */
function folhaEntregar(nome, login, senha, troca, endereco) {
  folha((f, fechar) => {
    f.append(h('h2', null, `Entregue para ${String(nome).split(' ')[0]}`),
      h('div', { class: 'bloco entrega' },
        h('p', { style: { margin: '0' } }, 'Endereço do app'), h('p', { class: 'login-grande' }, endereco || location.origin),
        h('p', { style: { margin: '12px 0 0' } }, 'Usuário'), h('p', { class: 'login-grande' }, login),
        senha ? [h('p', { style: { margin: '12px 0 0' } }, troca ? 'Senha provisória' : 'Senha'), h('p', { class: 'login-grande' }, senha)] : null),
      h('p', { class: 'mudo pequeno' }, troca ? 'No primeiro acesso, o app pede para a pessoa criar a senha dela. Depois disso, nem você sabe a senha.' : 'Entregue em particular. A senha não aparece de novo.'),
      h('div', { class: 'rodape' }, h('button', { class: 'btn', onclick: fechar }, 'Pronto')));
  });
}

function folhaPessoa(u, p, opcoes = {}) {
  const aprovando = !!opcoes.aprovar;
  const imps = p.impressoras.filter((i) => i.ativa);
  const central = p.instalacao === 'central';
  const ti = E.eu.usuario.admin;
  folha((f, fechar) => {
    const st = { setor_id: u ? u.setor_id : (ti ? 1 : E.eu.usuario.setor_id), papel: u ? u.papel : 'prof' };
    const nome = h('input', { type: 'text', value: u ? u.nome : '', autofocus: !u, placeholder: 'Nome' });
    const login = h('input', { type: 'text', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false', maxlength: '40', value: u ? u.login || '' : '', placeholder: 'Ex.: ana.silva' });
    let loginMexido = !!u;
    login.oninput = () => { loginMexido = true; };
    nome.oninput = () => { if (!loginMexido) login.value = sugerirLogin(nome.value); };
    const pin = h('input', { type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', maxlength: '128', placeholder: u ? 'Deixe vazio para manter a senha' : `Pelo menos ${SENHA_MIN} caracteres` });
    const pedirTroca = h('input', { type: 'checkbox', checked: true });
    const papeis = !central ? [['prof', 'Usuário'], ['admin', 'Gestor']]
      : ti ? [['prof', 'Usuário'], ['gestor', 'Gestor do setor'], ['admin', 'TI (gestor geral)']] : null;
    const segs = papeis ? h('div', { class: 'segmentos' }, papeis.map(([v, r]) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(st.papel === v) }, r);
      b.onclick = () => { st.papel = v; segs.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); };
      return b;
    })) : null;
    const ativo = h('input', { type: 'checkbox', checked: aprovando ? true : u ? !!u.ativo : true });
    const nomesPc = h('input', { type: 'text', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false', value: u ? u.nomes_computador || '' : '', placeholder: 'Ex.: ana.silva' });
    const cotas = {}; const remotas = {};
    const caixaCotas = h('div');
    const caixaPc = h('div');
    function desenharCotas() {
      const sx = setorDe(p, st.setor_id);
      const remoto = sx && sx.remoto;
      for (const k of Object.keys(cotas)) delete cotas[k];
      for (const k of Object.keys(remotas)) delete remotas[k];
      let grade;
      if (remoto) {
        grade = sx.impressoras_remotas.length ? h('div', { class: 'cotas-grade' }, sx.impressoras_remotas.map((i) => {
          remotas[i.ref] = h('input', { type: 'number', inputmode: 'numeric', min: '0', value: u ? (u.cotas_remotas[i.ref] || 0) : 0, 'aria-label': `Cota mensal na ${i.nome}` });
          return [h('span', { class: 'rotulo' }, h('i'), curto(i.nome)), remotas[i.ref]];
        })) : h('p', { class: 'dica' }, 'As impressoras desta unidade aparecem aqui depois que o aparelho dela sincronizar com a central.');
      } else {
        grade = h('div', { class: 'cotas-grade' }, imps.map((i) => {
          cotas[i.id] = h('input', { type: 'number', inputmode: 'numeric', min: '0', value: u ? u.saldos[i.id].base : 0, 'aria-label': `Cota mensal na ${i.nome}` });
          return [h('span', { class: 'rotulo', style: { '--cor': i.cor } }, h('i'), curto(i.nome)), cotas[i.id]];
        }));
      }
      const limite = sx && sx.cota != null ? h('div', { class: 'dica' }, `Cota de ${sx.nome}: ${pag(sx.cota)} por mês; já entregues ${pag(sx.distribuido)}. A soma não pode passar${sx.politica.exceder ? ' sem justificativa' : ''}.`) : null;
      encher(caixaCotas, h('span', { class: 'mudo pequeno', style: { fontWeight: '700' } }, remoto ? `Páginas por mês nas impressoras de ${sx.nome}` : 'Páginas por mês em cada impressora'), grade, limite,
        remoto ? null : h('div', { class: 'dica' }, 'Vale todo mês. Para dar ou tirar páginas só neste mês, use o botão abaixo.'));
      encher(caixaPc, remoto ? null : h('label', { class: 'campo' }, h('span', null, 'Nome de usuário no computador (opcional)'), nomesPc,
        h('div', { class: 'dica' }, `Para quem imprime de um computador ${L('do')} com login próprio. Com o nome aqui, as impressões desse login aparecem para a pessoa liberar em qualquer aparelho. Separe vários nomes com vírgula.`)));
    }
    const setores = (p.setores || []).filter((x) => x.ativo || (u && x.id === u.setor_id));
    const selSetor = central && setores.length > 1 ? h('select', { 'aria-label': 'Setor', 'data-valor': String(st.setor_id) }, setores.map((x) => h('option', { value: String(x.id) }, x.caminho + (x.remoto ? ' (aparelho próprio)' : '')))) : null;
    if (selSetor) { selSetor.value = String(st.setor_id); selSetor.onchange = () => { st.setor_id = Number(selSetor.value); desenharCotas(); }; }
    desenharCotas();
    const btn = h('button', { class: 'btn' }, aprovando ? 'Aprovar' : u ? 'Salvar' : 'Cadastrar');
    btn.onclick = async () => {
      botaoCarregando(btn);
      try {
        const r = await apiGestao('/api/admin/usuario', {
          id: u ? u.id : null, nome: nome.value, usuario: login.value, senha: pin.value || null, trocar_senha: pedirTroca.checked, papel: st.papel, ativo: ativo.checked, nomes_computador: nomesPc.value, aprovar: aprovando,
          setor_id: st.setor_id,
          cotas: Object.fromEntries(Object.entries(cotas).map(([k, el]) => [k, el.value || 0])),
          cotas_remotas: Object.fromEntries(Object.entries(remotas).map(([k, el]) => [k, el.value || 0])),
        });
        fechar(); recarregarDirecao();
        if (aprovando) { avisar(`Cadastro aprovado. ${nome.value.split(' ')[0]} já pode entrar com o usuário ${r.login}.`); atualizarEu(true); }
        else if (!u || pin.value) folhaEntregar(nome.value, r.login, pin.value, pedirTroca.checked, (p.endereco || [])[0]); else avisar('Dados salvos.');
      } catch (e) { if (e.codigo !== 'cancelado') avisar(e.message, true); botaoPronto(btn); }
    };
    const remotoAgora = () => { const sx = setorDe(p, st.setor_id); return sx && sx.remoto; };
    f.append(h('h2', null, aprovando ? `Aprovar o cadastro de ${u.nome.split(' ')[0]}` : u ? u.nome : 'Nova pessoa na equipe'),
      aprovando ? h('div', { class: 'faixa info' }, u.obs ? `Ela escreveu: "${u.obs}". ` : '', 'Confira o nome e o usuário, escolha o tipo de acesso e defina as páginas por mês em cada impressora.') : null,
      h('label', { class: 'campo' }, h('span', null, 'Nome'), nome),
      h('label', { class: 'campo' }, h('span', null, 'Usuário (para entrar)'), login, h('div', { class: 'dica' }, 'Letras, números e ponto, sem espaços. Cada pessoa tem o seu.')),
      (u && u.ref_central) || aprovando ? null : h('label', { class: 'campo' }, h('span', null, u ? 'Nova senha provisória' : 'Senha provisória'), pin,
        h('div', { class: 'dica' }, u ? 'Preencha só se a pessoa esqueceu a senha. A senha antiga deixa de valer.' : 'Você entrega para a pessoa junto com o usuário.')),
      (u && u.ref_central) || aprovando ? null : h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Pedir para a pessoa criar a senha dela no primeiro acesso'),
        h('div', { class: 'dica', style: { marginTop: '0' } }, 'Recomendado. Assim só ela sabe a senha.')), pedirTroca),
      selSetor ? h('label', { class: 'campo' }, h('span', null, 'Setor'), selSetor) : null,
      segs ? h('div', { class: 'campo' }, h('span', { class: 'mudo pequeno', style: { fontWeight: '700', display: 'block', marginBottom: '6px' } }, 'Tipo de acesso'), segs,
        central ? h('div', { class: 'dica' }, 'O gestor do setor cuida das pessoas e das cotas do setor dele (e dos setores de dentro). Numa unidade com aparelho próprio, ele é o gestor do aparelho.') : null) : null,
      h('div', { class: 'campo' }, caixaCotas),
      caixaPc,
      aprovando ? null : h('label', { class: 'interruptor' }, h('strong', null, 'Pode usar o sistema'), ativo),
      u && u.ativo && !remotoAgora() ? h('button', { class: 'btn claro largo', style: { marginTop: '16px' }, onclick: () => { fechar(); folhaAjuste(u, imps); } }, 'Liberar ou tirar páginas deste mês') : null,
      u && !aprovando && !remotoAgora() ? h('button', { class: 'btn claro largo', style: { marginTop: '10px' }, onclick: () => { fechar(); E.direcao.filtros = { pessoa: String(u.id) }; location.hash = '#gestao/relatorios'; } }, 'Ver tudo o que imprimiu') : null,
      u && !u.ativo && !u.anonimizado && !aprovando ? h('button', {
        class: 'btn claro largo', style: { marginTop: '16px', color: 'var(--perigo)' },
        onclick: async () => {
          fechar();
          const ok = await confirmar(`Apagar os dados pessoais de ${u.nome}?`, 'O nome vira "Pessoa removida", as mensagens da pessoa são apagadas e os nomes de arquivos somem do histórico. Os números de páginas continuam nos relatórios. Não dá para desfazer.', 'Apagar dados', true);
          if (!ok) return;
          try { await api('/api/admin/anonimizar', { id: u.id }); avisar('Dados pessoais apagados.'); recarregarDirecao(); } catch (e) { avisar(e.message, true); }
        },
      }, 'Apagar dados pessoais') : null,
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
  });
}

function folhaAjuste(u, imps) {
  folha((f, fechar) => {
    const st = { impressora_id: imps[0] && imps[0].id };
    let sinal = 1;
    const escolha = h('div', { class: 'escolha' });
    const desenhar = () => escolha.replaceChildren(...imps.map((i) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(i.id === st.impressora_id), style: { '--cor': i.cor } },
        h('span', { class: 'marca' }), h('span', { class: 'nome' }, curto(i.nome)), h('span', { class: 'qtd' }, `tem ${n(u.saldos[i.id].restante)}`));
      b.onclick = () => { st.impressora_id = i.id; desenhar(); };
      return b;
    }));
    desenhar();
    const segs = h('div', { class: 'segmentos' }, [[1, 'Liberar páginas'], [-1, 'Tirar páginas']].map(([v, r]) => {
      const b = h('button', { type: 'button', 'aria-pressed': String(sinal === v) }, r);
      b.onclick = () => { sinal = v; segs.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); };
      return b;
    }));
    const qtd = h('input', { type: 'number', inputmode: 'numeric', min: '1', placeholder: 'Quantas páginas?' });
    const obs = h('input', { type: 'text', placeholder: 'Ex.: projeto da horta' });
    const btn = h('button', { class: 'btn' }, 'Confirmar');
    btn.onclick = async () => {
      botaoCarregando(btn);
      try { await apiGestao('/api/admin/ajuste', { usuario_id: u.id, impressora_id: st.impressora_id, paginas: sinal * Number(qtd.value || 0), obs: obs.value }); fechar(); avisar('Ajuste feito.'); recarregarDirecao(); atualizarEu(); }
      catch (e) { if (e.codigo !== 'cancelado') avisar(e.message, true); botaoPronto(btn); }
    };
    f.append(h('h2', null, `Ajustar páginas de ${u.nome}`), h('p', { class: 'mudo' }, 'Vale só para este mês. A pessoa recebe um aviso nas conversas.'),
      h('div', { class: 'campo' }, segs), h('div', { class: 'campo' }, escolha),
      h('label', { class: 'campo' }, h('span', null, 'Quantidade'), qtd),
      h('label', { class: 'campo' }, h('span', null, 'Motivo (opcional)'), obs),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
  });
}

function dirImpressoras(p, sis) {
  const ponto = (ok) => h('span', { class: 'ponto', style: { background: ok ? 'var(--ok)' : 'var(--perigo)' } });
  const ativos = p.usuarios.filter((u) => u.ativo).length;
  return h('div', null,
    p.impressoras.map((i) => h('section', { class: 'bloco', style: { '--cor': i.cor, borderLeft: '6px solid var(--cor)', marginTop: '12px', opacity: i.ativa ? '1' : '.55' } },
      h('h2', { style: { fontSize: '17px' } }, i.nome, i.ativa ? null : h('span', { class: 'selo esgotado' }, 'Desativada')),
      h('p', { class: 'mudo pequeno', style: { marginTop: '4px' } }, i.sistema ? `Imprime em: ${i.sistema}` : 'Modo teste: não imprime de verdade'),
      h('p', { class: 'mudo pequeno' }, i.cota_total ? `Cota do grupo: ${pag(i.cota_total)} por mês` : 'Sem cota de grupo definida'),
      h('p', { class: 'mudo pequeno' }, i.custo_pagina > 0 ? `Custo por página: ${precoPagina(i.custo_pagina)}` : 'Custo por página não informado'),
      h('p', { class: 'mudo pequeno' }, i.ultima_leitura
        ? `Contador: ${n(i.ultima_leitura.valor)} páginas, lido em ${diaCurto(i.ultima_leitura.criado_em)} às ${hora(i.ultima_leitura.criado_em)} (${i.ultima_leitura.origem})`
        : (i.endereco_ip ? `Contador ainda não lido (IP ${i.endereco_ip})` : 'Contador sem leitura. Informe o IP em Editar, ou anote à mão.')),
      h('div', { class: 'linha-botoes', style: { marginTop: '12px' } },
        h('button', { class: 'btn claro pequeno', onclick: () => folhaImpressora(i, sis) }, 'Editar'),
        i.ativa && i.endereco_ip ? h('button', { class: 'btn claro pequeno', onclick: (e) => lerContador(i, e.currentTarget) }, 'Ler contador') : null,
        i.ativa ? h('button', { class: 'btn claro pequeno', onclick: () => folhaAnotar(i) }, 'Anotar contador') : null,
        i.cota_total && i.ativa ? h('button', {
          class: 'btn claro pequeno',
          onclick: async () => {
            const cada = Math.floor(i.cota_total / Math.max(1, ativos));
            const ok = await confirmar('Dividir igualmente?', `${pag(i.cota_total)} divididas entre ${ativos} pessoas ativas: cada uma fica com ${n(cada)} por mês${i.cota_total - cada * ativos ? ` e sobram ${n(i.cota_total - cada * ativos)} sem dona` : ''}. As cotas atuais desta impressora serão substituídas.`, 'Dividir');
            if (!ok) return;
            try { await api('/api/admin/dividir', { impressora_id: i.id }); avisar('Cotas divididas.'); recarregarDirecao(); atualizarEu(); }
            catch (e) { avisar(e.message, true); }
          },
        }, 'Dividir igualmente') : null))),
    h('button', { class: 'btn claro largo', style: { marginTop: '12px' }, onclick: () => folhaImpressora(null, sis) }, 'Adicionar impressora'),
    blocoEstilo(sis),
    sis.virtual.modo === 'impressora' ? blocoVirtual(p, sis) : null,
    sis.virtual.modo === 'impressora' ? blocoAguardando(sis) : null,
    h('div', { class: 'secao' }, h('h2', null, 'Este computador'),
      h('div', { class: 'bloco' },
        h('div', { class: 'status-ferramenta' }, ponto(true), h('div', null, h('strong', null, `Sistema: ${sis.sistema}`))),
        h('div', { class: 'status-ferramenta' }, ponto(sis.impressoras.length), h('div', null,
          h('strong', null, sis.impressoras.length ? 'Impressoras encontradas' : 'Nenhuma impressora encontrada'),
          h('div', { class: 'dica', style: { marginTop: '0' } }, sis.impressoras.length ? sis.impressoras.join(', ') : 'Instale as impressoras neste computador primeiro.'))),
        sis.windows ? h('div', { class: 'status-ferramenta' }, ponto(sis.sumatra), h('div', null,
          h('strong', null, sis.sumatra ? 'SumatraPDF encontrado' : 'SumatraPDF não encontrado'),
          h('div', { class: 'dica', style: { marginTop: '0' } }, sis.sumatra || 'Necessário para imprimir no Windows. Veja o LEIA-ME.'))) : h('div', { class: 'status-ferramenta' }, ponto(sis.lp), h('div', null,
          h('strong', null, sis.lp ? 'Sistema de impressão (CUPS) pronto' : 'CUPS não encontrado'),
          sis.lp ? null : h('div', { class: 'dica', style: { marginTop: '0' } }, 'Instale com: sudo apt install cups'))),
        h('div', { class: 'status-ferramenta' }, ponto(sis.soffice), h('div', null,
          h('strong', null, sis.soffice ? 'LibreOffice encontrado' : 'LibreOffice não encontrado'),
          h('div', { class: 'dica', style: { marginTop: '0' } }, sis.soffice ? 'Arquivos do Word, Excel e PowerPoint são convertidos automaticamente.' : 'Opcional. Sem ele, a equipe envia PDF ou foto.'))),
        h('div', { class: 'status-ferramenta' }, ponto(sis.previa), h('div', null,
          h('strong', null, sis.previa ? 'Miniaturas da prévia prontas' : 'Miniaturas da prévia: programa não encontrado'),
          h('div', { class: 'dica', style: { marginTop: '0' } }, sis.previa || 'Sem ele, a prévia abre o PDF no leitor do navegador (no celular, em outra aba). Veja no LEIA-ME como instalar o Poppler ou o Ghostscript.'))))));
}

function blocoEstilo(sis) {
  const atual = sis.virtual.modo;
  const st = { modo: atual };
  const btn = h('button', { class: 'btn claro largo', style: { marginTop: '12px' }, disabled: true }, 'Trocar o estilo');
  btn.onclick = async () => {
    const texto = st.modo === 'impressora'
      ? 'A impressora Folha a Folha passa a aparecer na rede. Depois, instale-a nos computadores e celulares.'
      : 'A impressora Folha a Folha some da rede e o que estiver aguardando liberação deixa de aparecer. O envio pelo app continua.';
    if (!(await confirmar(`Usar o estilo "${ESTILOS[st.modo][0].toLowerCase()}"?`, texto, 'Trocar'))) return;
    botaoCarregando(btn);
    try { await api('/api/admin/config', { modo: st.modo }); avisar('Estilo trocado.'); await atualizarEu(); setTimeout(recarregarDirecao, 1200); }
    catch (e) { avisar(e.message, true); botaoPronto(btn); }
  };
  return h('div', { class: 'secao' }, h('h2', null, 'Estilo de instalação'),
    h('div', { class: 'bloco' },
      h('p', { class: 'mudo pequeno', style: { marginBottom: '12px' } }, `Hoje: ${ESTILOS[atual][0].toLowerCase()}.`),
      escolhaEstilo(st, (id) => { btn.disabled = id === atual; }),
      btn));
}

function blocoVirtual(p, sis) {
  const v = sis.virtual;
  const ponto = (ok) => h('span', { class: 'ponto', style: { background: ok ? 'var(--ok)' : 'var(--alerta-texto)' } });
  const textoAnuncio = !v.anunciar ? ['Anúncio no Wi-Fi desligado', 'Os aparelhos só acham a Folha a Folha pelo endereço.']
    : v.anuncio ? ['Anunciada no Wi-Fi', 'Computadores e celulares na mesma rede encontram a Folha a Folha sozinhos.']
      : ['Não foi possível anunciar no Wi-Fi', 'Outro programa pode estar usando o anúncio de rede. Adicione os aparelhos pelo endereço.'];
  const filas = h('input', { type: 'checkbox', checked: p.config.filas_por_impressora === '1' });
  const anunciar = h('input', { type: 'checkbox', checked: v.anunciar });
  const soConectado = h('input', { type: 'checkbox', checked: v.so_conectado });
  const horas = h('input', { type: 'number', inputmode: 'numeric', min: '1', max: '72', value: v.horas_fila });
  const btn = h('button', { class: 'btn claro largo', style: { marginTop: '16px' } }, 'Salvar');
  btn.onclick = async () => {
    botaoCarregando(btn);
    try {
      await api('/api/admin/config', { filas_por_impressora: filas.checked, anunciar_rede: anunciar.checked, ipp_so_conectado: soConectado.checked, horas_fila: horas.value });
      avisar('Ajustes da impressora Folha a Folha salvos.');
      setTimeout(recarregarDirecao, 1500);
    } catch (e) { avisar(e.message, true); botaoPronto(btn); }
  };
  return h('div', { class: 'secao' }, h('h2', null, 'Impressora Folha a Folha'),
    h('div', { class: 'bloco' },
      h('p', { class: 'mudo pequeno' }, v.so_conectado
        ? 'É a impressora que a equipe instala no computador e no celular. A pessoa abre o app e entra, imprime de qualquer programa e libera no app. Só aí a cota é descontada.'
        : 'É a impressora que a equipe instala no computador e no celular. O documento fica aguardando até a pessoa abrir o app, escolher a impressora de verdade e liberar. Só aí a cota é descontada.'),
      v.filas.map((q) => h('div', { style: { marginTop: '14px' } }, h('strong', null, q.nome), campoEndereco('Windows', q.windows), campoEndereco('Linux', q.linux))),
      h('div', { class: 'status-ferramenta', style: { marginTop: '14px' } }, ponto(v.anuncio && v.anunciar), h('div', null, h('strong', null, textoAnuncio[0]), h('div', { class: 'dica', style: { marginTop: '0' } }, textoAnuncio[1]))),
      h('div', { class: 'status-ferramenta' }, ponto(v.porta_631), h('div', null,
        h('strong', null, v.porta_631 ? `Porta das impressoras aberta (IP ${v.ip})` : 'Porta das impressoras (631) ocupada'),
        h('div', { class: 'dica', style: { marginTop: '0' } }, v.porta_631 ? 'No Android, também dá para adicionar só pelo IP.' : 'Normal no Linux com CUPS. O Android acha a Folha a Folha pelo anúncio no Wi-Fi.'))),
      h('button', { class: 'btn claro largo', style: { marginTop: '12px' }, onclick: () => folhaComoInstalar(v) }, 'Passo a passo para cada aparelho')),
    !sis.windows ? h('div', { class: 'bloco' },
      h('strong', null, 'Só pela Folha a Folha neste computador'),
      h('p', { class: 'mudo pequeno', style: { marginTop: '4px' } }, 'A impressora de verdade continua instalada aqui, porque é por ela que o app imprime. Para os programas deste computador não imprimirem direto nela, rode uma vez no Terminal:'),
      campoEndereco('Terminal', `sudo sh ${sis.pasta}/ferramentas/so-pela-folha-a-folha.sh`),
      h('p', { class: 'dica' }, 'O Folha a Folha passa a rodar sozinho, como serviço, e a impressora de verdade só aceita trabalhos dele. A Folha a Folha vira a impressora padrão. Nos outros computadores e nos celulares, tire a impressora de verdade e feche-a na rede (veja o LEIA-ME, "Como fechar a impressora").')) : null,
    h('div', { class: 'bloco' },
      h('label', { class: 'interruptor', style: { marginTop: '0' } }, h('span', null, h('strong', null, 'Só aceitar de quem está com o app aberto'),
        h('div', { class: 'dica', style: { marginTop: '0' } }, 'A impressora recusa o documento se, naquele computador ou celular, ninguém estiver com o app aberto e desbloqueado. O que chega vai só para quem estava conectado (ou para quem tem aquele login do computador na ficha). Recomendado em computadores compartilhados.')), soConectado),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Uma Folha a Folha para cada impressora'), h('div', { class: 'dica', style: { marginTop: '0' } }, 'Além da geral, cria uma fila com o nome de cada impressora, como "Folha a Folha - Recepção". Já chega sugerindo a impressora certa.')), filas),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Anunciar no Wi-Fi'), h('div', { class: 'dica', style: { marginTop: '0' } }, `Desligue se a rede ${L('do')} for compartilhada com outros prédios ou empresas.`)), anunciar),
      h('label', { class: 'campo' }, h('span', null, 'Horas para liberar antes de apagar'), horas, h('div', { class: 'dica' }, 'Entre 1 e 72. O que passar do prazo é apagado sem gastar páginas.')),
      btn));
}

function blocoAguardando(sis) {
  const lista = sis.aguardando || [];
  return h('div', { class: 'secao' }, h('h2', null, `Aguardando liberação (${lista.length})`),
    lista.length ? h('div', { class: 'lista' }, lista.map((r) => h('div', { class: 'item' },
      h('span', { class: 'avatar', style: { fontSize: '13px' } }, n(r.paginas * r.copias)),
      h('span', { class: 'meio' }, h('strong', null, r.nome),
        h('span', { class: 'previa' }, `${r.usuario_so ? r.usuario_so + ', ' : ''}aparelho ${r.ip}`),
        h('div', { class: 'sobra' }, `${rotuloDia(r.criado_em)}, ${hora(r.criado_em)}, ${n(r.paginas)} × ${r.copias}`)),
      h('button', {
        class: 'btn claro pequeno',
        onclick: async () => {
          if (!(await confirmar('Descartar esta impressão?', `"${r.nome}" sai da fila sem imprimir.`, 'Descartar', true))) return;
          try { await api('/api/retidas/descartar', { id: r.id }); avisar('Descartada.'); recarregarDirecao(); } catch (e) { avisar(e.message, true); }
        },
      }, 'Descartar')))) : h('div', { class: 'bloco vazio' }, 'Nenhuma impressão aguardando.'));
}

function folhaImpressora(i, sis) {
  folha((f, fechar) => {
    const nome = h('input', { type: 'text', value: i ? i.nome : '', placeholder: 'Ex.: Impressora da recepção', autofocus: !i });
    const opcoes = [...sis.impressoras]; if (i && i.sistema && !opcoes.includes(i.sistema)) opcoes.unshift(i.sistema);
    const sistema = h('select', null, h('option', { value: '' }, 'Modo teste (não imprime de verdade)'), opcoes.map((o) => h('option', { value: o }, o)));
    sistema.value = i ? i.sistema : '';
    const total = h('input', { type: 'number', inputmode: 'numeric', min: '0', value: i ? i.cota_total : 0 });
    const custo = h('input', { type: 'text', inputmode: 'decimal', placeholder: 'Ex.: 0,37', value: i && i.custo_pagina ? String(i.custo_pagina).replace('.', ',') : '' });
    const baseM = h('input', { type: 'number', inputmode: 'numeric', min: '0', placeholder: 'Ex.: 4000', value: i && i.base_mensal ? i.base_mensal : '' });
    const ip = h('input', { type: 'text', autocapitalize: 'off', spellcheck: 'false', placeholder: 'Ex.: 192.168.0.50', value: i ? i.endereco_ip || '' : '' });
    const comunidade = h('input', { type: 'text', autocapitalize: 'off', spellcheck: 'false', value: i ? i.snmp_comunidade || 'public' : 'public' });
    const conferir = h('input', { type: 'checkbox', checked: i ? i.conferir_contador !== 0 : true });
    let cor = i ? i.cor : CORES[0];
    const cores = h('div', { style: { display: 'flex', gap: '10px', flexWrap: 'wrap' } });
    const desenharCores = () => cores.replaceChildren(...CORES.map((c) => h('button', {
      type: 'button', 'aria-label': `Cor ${c}`, 'aria-pressed': String(c === cor), onclick: () => { cor = c; desenharCores(); },
      style: { width: '40px', height: '40px', borderRadius: '10px', border: c === cor ? '3px solid var(--tinta)' : '0', background: c },
    })));
    desenharCores();
    const ativa = h('input', { type: 'checkbox', checked: i ? !!i.ativa : true });
    const pedeFin = h('input', { type: 'checkbox', checked: i ? !!i.pede_finalidade : true });
    const porImpressora = (E.direcao.dados && E.direcao.dados.config.finalidade) === 'escolhidas';
    // papel e área de impressão (para o Tamanho na folha sair exato nesta impressora)
    const papel = h('select', { 'aria-label': 'Papel' }, h('option', { value: '' }, 'O que a impressora usa'));
    papel.value = i && i.papel ? i.papel : '';
    const temManual = !!(i && i.margem_topo != null && i.margem_baixo != null && i.margem_esq != null && i.margem_dir != null);
    const manual = h('input', { type: 'checkbox', checked: temManual });
    const campoMm = (rotulo, chave) => {
      const inp = h('input', { type: 'number', inputmode: 'decimal', min: '0', max: '30', step: '0.1', value: i && i['margem_' + chave] != null ? i['margem_' + chave] : '4.2', 'data-lado': chave });
      return h('label', { class: 'campo' }, h('span', null, rotulo + ' (mm)'), inp);
    };
    const margensCampos = h('div', { class: 'margens-campos' + (temManual ? '' : ' oculto') }, campoMm('Em cima', 'topo'), campoMm('Embaixo', 'baixo'), campoMm('Esquerda', 'esq'), campoMm('Direita', 'dir'));
    manual.onchange = () => margensCampos.classList.toggle('oculto', !manual.checked);
    const infoArea = h('div', { class: 'dica' }, 'Quanto da beirada do papel esta impressora não alcança. O Tamanho na folha usa isto para nada ficar de fora.');
    const btnCalibrar = h('button', { class: 'btn claro', type: 'button' }, 'Imprimir página de calibração');
    btnCalibrar.disabled = !(i && i.sistema);
    btnCalibrar.onclick = async () => {
      botaoCarregando(btnCalibrar);
      try { await api('/api/admin/impressora/calibrar', { id: i.id }); avisar('Página de calibração enviada. Em cada borda, anote o menor número cujo traço saiu inteiro.'); }
      catch (e) { avisar(e.message, true); }
      botaoPronto(btnCalibrar);
    };
    if (i) {
      api(`/api/admin/impressora/area?id=${i.id}`).then((r) => {
        (r.papeis || []).forEach((p) => papel.append(h('option', { value: p.id }, p.nome)));
        papel.value = i.papel || '';
        const inf = r.informada, m = inf.margens;
        const nomePapel = (r.papeis.find((p) => p.id === inf.papel) || {}).nome || `${Math.round(inf.papel_mm[0])} × ${Math.round(inf.papel_mm[1])} mm`;
        papel.options[0].textContent = `O que a impressora usa (${nomePapel})`;
        const fonte = inf.origem_margens === 'cups' ? 'informado pela impressora ao CUPS' : inf.origem_margens === 'ppd' ? 'lido do driver da impressora' : 'estimado: a impressora não informa';
        infoArea.textContent = `Sem medir: ${fmtMm(m.topo)} em cima, ${fmtMm(m.baixo)} embaixo, ${fmtMm(m.esq)} à esquerda e ${fmtMm(m.dir)} à direita (${fonte}). Para ficar exato, imprima a página de calibração, ligue "Medir à mão" e anote o que saiu.`;
        if (!temManual) margensCampos.querySelectorAll('input').forEach((inp) => { inp.value = String(m[inp.dataset.lado]); });
      }).catch(() => {});
    } else {
      ['A4', 'Carta', 'Oficio', 'Legal', 'A5', 'A3'].forEach((p) => papel.append(h('option', { value: p }, p === 'Oficio' ? 'Ofício' : p)));
    }
    const btn = h('button', { class: 'btn' }, 'Salvar');
    btn.onclick = async () => {
      botaoCarregando(btn);
      const margens = manual.checked ? Object.fromEntries([...margensCampos.querySelectorAll('input')].map((inp) => [inp.dataset.lado, inp.value])) : null;
      try { await api('/api/admin/impressora', { id: i ? i.id : null, nome: nome.value, sistema: sistema.value, cota_total: total.value || 0, cor, ativa: ativa.checked, custo_pagina: custo.value, base_mensal: baseM.value || 0, endereco_ip: ip.value, snmp_comunidade: comunidade.value, conferir_contador: conferir.checked, pede_finalidade: porImpressora ? pedeFin.checked : null, papel: papel.value, margens }); fechar(); avisar('Impressora salva.'); recarregarDirecao(); atualizarEu(); if (E.imp) E.imp.plano = null; }
      catch (e) { avisar(e.message, true); botaoPronto(btn); }
    };
    f.append(h('h2', null, i ? 'Editar impressora' : 'Nova impressora'),
      h('label', { class: 'campo' }, h('span', null, 'Nome que a equipe vê'), nome),
      h('label', { class: 'campo' }, h('span', null, 'Impressora deste computador'), sistema,
        h('div', { class: 'dica' }, 'Comece em modo teste para conferir as cotas sem gastar papel.')),
      h('label', { class: 'campo' }, h('span', null, 'Cota mensal do grupo (páginas)'), total,
        h('div', { class: 'dica' }, 'Use 0 se não houver limite total. Em impressora alugada, coloque a franquia do contrato.')),
      h('label', { class: 'campo' }, h('span', null, 'Custo por página (R$)'), custo,
        h('div', { class: 'dica' }, 'Em impressora alugada, use o valor por página do contrato. Em impressora própria, some papel e toner. Se o contrato cobra uma franquia mínima, a economia real só existe nas páginas acima dela.')),
      h('label', { class: 'campo' }, h('span', null, 'Páginas por mês antes do sistema'), baseM,
        h('div', { class: 'dica' }, 'Opcional. É a média mensal de antes, pelo contador da impressora ou pela fatura. Serve para mostrar a economia mês a mês.')),
      h('label', { class: 'campo' }, h('span', null, 'Endereço IP da impressora (opcional)'), ip,
        h('div', { class: 'dica' }, 'Com o IP, o sistema lê o contador de páginas sozinho, de hora em hora, e mostra quanto foi impresso por fora. Se a impressora está ligada por cabo USB, deixe vazio e anote o contador à mão.')),
      h('label', { class: 'campo' }, h('span', null, 'Comunidade SNMP'), comunidade,
        h('div', { class: 'dica' }, 'Quase sempre é "public". Só mude se a TI tiver trocado.')),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Descontar só o que a impressora contar'),
        h('div', { class: 'dica', style: { marginTop: '0' } }, (sis.acompanha
          ? 'Com o IP preenchido, cada impressão espera a anterior terminar nesta impressora, e o sistema lê o contador antes e depois. Se enroscar papel e cancelarem no meio, desconta só o que saiu. Começa a valer depois da primeira impressão completa, quando o contador se mostra certo.'
          : 'Funciona quando o sistema está num computador com Linux. Neste computador, as páginas são descontadas quando a impressão vai para a impressora; se algo não sair, devolva em Relatórios.'))), conferir),
      h('div', { class: 'bloco', style: { marginTop: '12px' } },
        h('h3', { style: { marginTop: '0' } }, 'Papel e área de impressão'),
        h('label', { class: 'campo' }, h('span', null, 'Papel'), papel),
        infoArea,
        h('label', { class: 'interruptor', style: { marginTop: '10px' } }, h('span', null, h('strong', null, 'Medir à mão'),
          h('div', { class: 'dica', style: { marginTop: '0' } }, 'Use o que saiu na página de calibração: em cada borda, o menor número cujo traço saiu inteiro.')), manual),
        margensCampos,
        h('div', { style: { marginTop: '10px' } }, btnCalibrar,
          h('div', { class: 'dica' }, i && i.sistema ? 'Sai uma folha com réguas nas quatro bordas, em tamanho real. Não conta na cota de ninguém.' : 'Salve a impressora ligada a uma impressora do computador para poder calibrar.'))),
      h('div', { class: 'campo' }, h('span', { class: 'mudo pequeno', style: { fontWeight: '700', display: 'block', marginBottom: '6px' } }, 'Cor'), cores),
      porImpressora ? h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Perguntar para que é cada impressão'), h('div', { class: 'dica', style: { marginTop: '0' } }, 'Vale só nesta impressora (escolhido em Ajustes, Controle de impressão).')), pedeFin) : null,
      h('label', { class: 'interruptor' }, h('strong', null, 'Ativa'), ativa),
      h('div', { class: 'rodape' }, h('button', { class: 'btn claro', onclick: fechar }, 'Cancelar'), btn));
  });
}

const ROT_STATUS = { impresso: ['ok', 'Impresso'], teste: ['teste', 'Modo teste'], erro: ['esgotado', 'Não imprimiu'], estornado: ['alerta', 'Páginas devolvidas'], enviando: ['alerta', 'Enviando'], na_fila: ['alerta', 'Na fila'] };

function dirRelatorios(p, r) {
  const fl = E.direcao.filtros || (E.direcao.filtros = {});
  const pe = E.direcao.periodo || (E.direcao.periodo = { tipo: 'mes' });
  const aplicar = (chave, valor) => { E.direcao.verMais = 20; if (valor === '' || valor == null) delete fl[chave]; else fl[chave] = String(valor); recarregarDirecao(); };
  const sel = (rotulo, chave, opcoes) => {
    const s = h('select', { 'aria-label': rotulo, 'data-valor': fl[chave] || '' }, h('option', { value: '' }, rotulo), opcoes.map(([v, t]) => h('option', { value: String(v) }, t)));
    s.onchange = () => aplicar(chave, s.value);
    return s;
  };
  const busca = h('input', { type: 'search', enterkeyhint: 'search', placeholder: 'Buscar no nome do arquivo ou na descrição', value: fl.busca || '', 'aria-label': 'Buscar' });
  busca.onkeydown = (e) => { if (e.key === 'Enter') aplicar('busca', busca.value.trim()); };
  busca.onchange = () => { if ((fl.busca || '') !== busca.value.trim()) aplicar('busca', busca.value.trim()); };
  const temFiltro = Object.keys(fl).length > 0;
  const t = r.totais;
  const quando = r.periodo ? 'período' : 'mês';

  // período: o primeiro controle da tela
  const selPeriodo = h('select', { 'aria-label': 'Período do relatório', 'data-valor': pe.tipo }, PERIODOS.map(([v, tx]) => h('option', { value: v }, tx)));
  selPeriodo.onchange = () => {
    pe.tipo = selPeriodo.value; E.direcao.verMais = 20;
    if (pe.tipo === 'perso' && !(pe.de && pe.ate)) { const hoje = new Date(); pe.de = dataIso(new Date(hoje.getFullYear(), hoje.getMonth(), 1)); pe.ate = dataIso(hoje); }
    recarregarDirecao();
  };
  let camposDatas = null;
  if (pe.tipo === 'perso') {
    const hojeIso = dataIso(new Date());
    const de = h('input', { type: 'date', value: pe.de || '', max: hojeIso, 'aria-label': 'Do dia' });
    const ate = h('input', { type: 'date', value: pe.ate || '', max: hojeIso, 'aria-label': 'Até o dia' });
    const ver = h('button', { type: 'button', class: 'btn claro' }, 'Ver este período');
    ver.onclick = () => {
      if (!de.value || !ate.value) { avisar('Escolha o dia de início e o dia de fim.', true); return; }
      if (de.value > ate.value) { avisar('O dia de início vem depois do dia de fim.', true); return; }
      if ((new Date(ate.value) - new Date(de.value)) / 86400000 > 731) { avisar('O período pode ter no máximo 2 anos.', true); return; }
      pe.de = de.value; pe.ate = ate.value; E.direcao.verMais = 20; recarregarDirecao();
    };
    camposDatas = h('div', { class: 'datas-periodo' },
      h('label', { class: 'campo' }, h('span', null, 'Do dia'), de),
      h('label', { class: 'campo' }, h('span', null, 'Até o dia'), ate), ver);
  }
  const periodoBloco = h('div', { class: 'periodo-bloco' },
    h('label', { class: 'campo', style: { marginTop: '0' } }, h('span', null, 'Período'), selPeriodo),
    pe.tipo === 'mes' ? h('label', { class: 'campo', style: { marginTop: '0' } }, h('span', null, 'Mês'), seletorMes(p)) : null,
    camposDatas,
    h('p', { class: 'dica', style: { margin: '0' } }, `Mostrando ${r.periodo ? r.periodo.rotulo : mesTitulo(r.mes)}.`));

  // filtros: recolhidos num botão, com uma etiqueta para cada um que está ligado
  const rotuloFiltro = (c, v) => c === 'pessoa' ? ((r.opcoes.pessoas.find((u) => String(u.id) === v) || {}).nome || 'Pessoa')
    : c === 'impressora' ? ((r.opcoes.impressoras.find((i) => String(i.id) === v) || {}).nome || 'Impressora')
    : c === 'finalidade' ? (v === 'nenhuma' ? 'Finalidade não informada' : ((r.opcoes.finalidades.find((f) => f.id === v) || {}).nome || v))
    : c === 'busca' ? `Busca: “${v}”` : v;
  const etiquetas = temFiltro ? h('div', { class: 'etiquetas', role: 'group', 'aria-label': 'Filtros ligados' }, Object.entries(fl).map(([c, v]) => h('button', {
    type: 'button', class: 'etiqueta', 'aria-label': `Tirar o filtro ${rotuloFiltro(c, v)}`, onclick: () => aplicar(c, ''),
  }, rotuloFiltro(c, v), h('span', { 'aria-hidden': 'true' }, ' ×')))) : null;
  const maisFiltros = h('details', { class: 'mais-filtros', open: E.direcao.filtrosAbertos || false },
    h('summary', null, temFiltro ? `Filtros (${Object.keys(fl).length === 1 ? '1 ligado' : Object.keys(fl).length + ' ligados'})` : 'Filtros: pessoa, impressora, finalidade, busca'),
    h('div', { class: 'filtros' },
      sel('Todas as pessoas', 'pessoa', r.opcoes.pessoas.map((u) => [u.id, u.nome + (u.ativo ? '' : ' (saiu)')])),
      sel('Todas as impressoras', 'impressora', r.opcoes.impressoras.map((i) => [i.id, i.nome])),
      sel('Todas as finalidades', 'finalidade', [...r.opcoes.finalidades.map((f) => [f.id, f.nome]), ['nenhuma', 'Não informada']]),
      busca,
      temFiltro ? h('button', { class: 'btn-texto pequeno', onclick: () => { E.direcao.filtros = {}; E.direcao.verMais = 20; recarregarDirecao(); } }, 'Limpar filtros') : null));
  maisFiltros.addEventListener('toggle', () => { E.direcao.filtrosAbertos = maisFiltros.open; });
  const filtros = h('div', { class: 'filtros-relatorio' }, periodoBloco, etiquetas, maisFiltros);

  const numeros = h('div', { class: 'bloco' }, h('div', { class: 'numeros', style: { marginTop: '0' } },
    h('div', null, h('b', null, n(t.paginas)), 'páginas impressas'),
    h('div', null, h('b', null, n(t.impressoes)), t.impressoes === 1 ? 'impressão' : 'impressões'),
    h('div', null, h('b', null, n(t.pessoas)), t.pessoas === 1 ? 'pessoa imprimiu' : 'pessoas imprimiram'),
    t.custo > 0 ? h('div', null, h('b', null, reais(t.custo)), 'custo') : null,
    t.provas ? h('div', null, h('b', null, n(t.provas)), t.provas === 1 ? 'prova antes de imprimir' : 'provas antes de imprimir') : null),
    t.erros ? h('p', { class: 'dica' }, `${n(t.erros)} ${t.erros === 1 ? 'impressão não saiu' : 'impressões não saíram'} por erro da impressora (não contam na cota).`) : null);

  // levar o relatório: planilha, PDF e papel, logo abaixo dos números
  const consulta = consultaRelatorio();
  const csv = `/api/admin/relatorio.csv?mes=${r.mes}${consulta ? '&' + consulta : ''}`;
  const pdfUrl = `/api/admin/relatorio.pdf?mes=${r.mes}${consulta ? '&' + consulta : ''}`;
  const reaisImp = (p.impressoras || []).filter((i) => i.ativa && i.sistema);
  const levar = h('div', { class: 'secao' }, h('h2', null, 'Levar o relatório'),
    h('div', { class: 'acoes-relatorio' },
      E.eu.usuario.admin ? h('button', { type: 'button', class: 'btn largo', onclick: () => folhaImprimirRelatorio(reaisImp, consulta, r) }, 'Imprimir relatório') : null,
      h('a', { class: 'btn claro largo', href: pdfUrl, download: '' }, 'Baixar relatório (PDF)'),
      h('a', { class: 'btn claro largo', href: csv, download: '' }, temFiltro ? `Baixar planilha ${r.periodo ? 'do período' : 'do mês'} com estes filtros` : `Baixar planilha ${r.periodo ? 'do período' : 'do mês'}`)),
    h('p', { class: 'dica' }, 'O relatório em PDF leva os números, para que foi impresso, quem imprimiu e os pontos de atenção, sem nomes de arquivos. Imprimir o relatório não conta na cota de ninguém. A planilha traz tudo, com a lista de impressões.'));

  // para que foi impresso: barras de uma cor só, com o número escrito ao lado
  const maxF = Math.max(1, ...r.por_finalidade.map((f) => f.paginas));
  const barras = r.por_finalidade.length ? h('div', { class: 'bloco barras' }, r.por_finalidade.map((f) => {
    const pct = t.paginas ? Math.round((100 * f.paginas) / t.paginas) : 0;
    return h('button', {
      type: 'button', class: 'barra-linha', 'aria-pressed': String(f.texto ? fl.busca === f.texto : fl.finalidade === f.finalidade),
      title: `${f.nome}: ${pag(f.paginas)} em ${n(f.impressoes)} ${f.impressoes === 1 ? 'impressão' : 'impressões'}${f.custo > 0 ? `, ${reais(f.custo)}` : ''}. Toque para filtrar.`,
      onclick: () => (f.texto ? aplicar('busca', fl.busca === f.texto ? '' : f.texto) : aplicar('finalidade', fl.finalidade === f.finalidade ? '' : f.finalidade)),
    }, h('span', { class: 'barra-rot' }, f.nome),
      h('span', { class: 'barra-trilho', 'aria-hidden': 'true' }, h('span', { class: 'barra-cheia', style: { width: `${Math.max(1.5, (100 * f.paginas) / maxF)}%` } })),
      h('span', { class: 'barra-val num' }, `${n(f.paginas)}`, h('small', null, ` ${pct}%`)));
  })) : h('div', { class: 'bloco vazio' }, 'Nada impresso com estes filtros.');

  const atencao = r.atencao.length ? h('div', { class: 'lista atencao' }, r.atencao.map((a) => h('button', {
    type: 'button', class: 'item', onclick: () => aplicar('pessoa', a.usuario_id),
  }, h('span', { class: 'selo alerta atencao-selo' }, a.tipo === 'grande' ? 'Grande' : a.tipo === 'repetido' ? 'Repetida' : 'Acima da média'),
    h('span', { class: 'meio' }, h('span', { style: { whiteSpace: 'normal' } }, a.texto))))) : h('div', { class: 'bloco vazio' }, `Nada fora do comum neste ${quando}.`);

  const pessoas = r.por_pessoa.length ? h('div', { class: 'lista' }, r.por_pessoa.map((u) => {
    const partes = Object.entries(u.por_finalidade).sort((a, b) => b[1] - a[1]).slice(0, 3)
      .map(([k, v]) => `${k === 'nenhuma' ? 'não informada' : k === 'livre' ? 'texto livre' : nomeFinalidade(k).toLowerCase()} ${n(v)}`);
    return h('button', { type: 'button', class: 'item', onclick: () => aplicar('pessoa', fl.pessoa === String(u.id) ? '' : u.id) },
      h('span', { class: 'avatar' }, iniciais(u.nome)),
      h('span', { class: 'meio' }, h('strong', null, u.nome),
        h('span', { class: 'previa', style: { whiteSpace: 'normal' } }, `${n(u.impressoes)} ${u.impressoes === 1 ? 'impressão' : 'impressões'}${u.provas ? `, ${n(u.provas)} com prova` : ''}`),
        h('div', { class: 'sobra' }, partes.join(' · '))),
      h('span', { class: 'num-direita' }, h('b', null, n(u.paginas)), h('span', null, u.custo > 0 ? reais(u.custo) : 'páginas')));
  })) : h('div', { class: 'bloco vazio' }, 'Ninguém imprimiu com estes filtros.');

  const lim = E.direcao.verMais || 20;
  const mostrados = r.trabalhos.slice(0, lim);
  const lista = r.trabalhos.length ? h('div', { class: 'lista', 'aria-label': 'Impressões' }, mostrados.map((tr) => {
    const [cl, rot] = ROT_STATUS[tr.status] || ['teste', tr.status];
    const pode = tr.status === 'impresso' || tr.status === 'teste';
    return h('div', { class: 'item', style: { '--cor': tr.cor, alignItems: 'flex-start' } },
      h('span', { class: 'avatar', style: { background: 'var(--cor)', color: '#fff', fontSize: '13px' } }, n(tr.total)),
      h('span', { class: 'meio' }, h('strong', null, tr.usuario_nome),
        h('span', { class: 'previa', style: { whiteSpace: 'normal', wordBreak: 'break-word' } }, tr.arquivo),
        tr.finalidade_nome ? h('div', { class: 'fin-linha' }, h('span', { class: 'selo fin' }, tr.finalidade_nome), tr.descricao && tr.finalidade !== 'livre' ? h('span', null, tr.descricao) : null)
          : h('div', { class: 'sobra' }, 'Finalidade não informada'),
        h('div', { class: 'sobra' }, `${diaCurto(tr.criado_em)}, ${hora(tr.criado_em)}, ${curto(tr.impressora_nome)}, ${n(tr.paginas_sel)} × ${tr.copias}${tr.frente_verso ? ', frente e verso' : ''}${tr.custo > 0 ? `, ${reais(tr.custo)}` : ''}${tr.etapa === 'prova' ? ', prova' : tr.etapa === 'resto' ? ', resto depois da prova' : ''}`),
        tr.erro ? h('div', { class: 'sobra' }, tr.erro) : null,
        tr.status === 'na_fila' ? h('div', { class: 'sobra' }, `${tr.fila_motivo || 'Na fila da impressora'}.`) : null,
        tr.status === 'na_fila' ? h('button', { class: 'btn-texto pequeno', onclick: (e) => cancelarFila({ id: tr.id, arquivo: tr.arquivo }, e.currentTarget) }, 'Cancelar impressão') : null,
        tr.excedente ? h('div', { class: 'sobra alem-txt' }, `${pag(tr.excedente)} além da cota: “${tr.justificativa}”`) : null,
        pode ? h('button', {
          class: 'btn-texto pequeno',
          onclick: async () => {
            if (!(await confirmar(`Devolver ${pag(tr.total)} para ${tr.usuario_nome}?`, 'Use quando a impressão saiu com defeito ou o papel enroscou.', 'Devolver'))) return;
            try { await api('/api/admin/estornar', { id: tr.id }); avisar('Páginas devolvidas.'); recarregarDirecao(); atualizarEu(); } catch (e) { avisar(e.message, true); }
          },
        }, 'Devolver páginas') : null),
      h('span', { class: 'selo ' + cl }, rot));
  })) : h('div', { class: 'bloco vazio' }, 'Nenhuma impressão com estes filtros.');

  const verMais = r.trabalhos.length > lim
    ? h('button', { type: 'button', class: 'btn claro largo', style: { marginTop: '12px' }, onclick: () => { E.direcao.verMais = lim + 20; recarregarDirecao(); } }, `Ver mais impressões (faltam ${n(r.trabalhos.length - lim)})`) : null;
  return h('div', null, filtros, numeros, levar,
    h('div', { class: 'secao' }, h('h2', null, 'Para que foi impresso'), barras),
    h('div', { class: 'secao' }, h('h2', null, 'Pontos de atenção'),
      h('p', { class: 'dica', style: { margin: '-4px 0 10px' } }, `Impressões a partir de ${pag(r.alerta_grande)}, o mesmo arquivo 3 vezes ou mais, e quem imprimiu o dobro da média. Servem para conversar, não provam uso errado.`),
      atencao),
    h('div', { class: 'secao' }, h('h2', null, 'Quem imprimiu'), pessoas),
    blocoExcecoes(r.excecoes),
    h('div', { class: 'secao' }, h('h2', null, r.total_lista > mostrados.length ? `Impressões (mostrando ${n(mostrados.length)} de ${n(r.total_lista)})` : `Impressões (${n(mostrados.length)})`), lista, verMais,
      r.total_lista > r.trabalhos.length && !verMais ? h('p', { class: 'dica' }, 'A tela mostra até 500 impressões. A planilha traz todas.') : null),
    h('div', { class: 'secao' }, h('h2', null, `Trocas e ajustes (${r.movimentos.length})`),
      r.movimentos.length ? h('div', { class: 'lista' }, r.movimentos.map((m) => h('div', { class: 'item', style: { '--cor': m.cor } },
        h('span', { class: 'avatar', style: { fontSize: '13px' } }, n(m.paginas)),
        h('span', { class: 'meio' },
          h('strong', null, m.tipo === 'ajuste' ? (m.de_id ? `Gestão tirou de ${m.de_nome}` : `Gestão liberou para ${m.para_nome}`)
            : m.tipo === 'devolucao' ? `${m.de_nome} devolveu ${L('ao')}`
            : m.tipo === 'aumento' ? `Aumento de cota para ${m.para_nome}`
            : m.tipo === 'desconto' ? `Desconto de ${m.de_nome} (cota negativa do mês anterior)`
              : m.tipo === 'reserva' ? `Reserva liberou para ${m.para_nome}${m.criado_por ? '' : ' (na hora)'}`
                : `${m.de_nome} passou para ${m.para_nome}`),
          h('span', { class: 'previa' }, `${diaCurto(m.criado_em)}, ${curto(m.impressora_nome)}${m.obs ? ', ' + m.obs : ''}`))))) : h('div', { class: 'bloco vazio' }, `Nenhuma troca neste ${quando}.`)));
}

const MODOS_TROCA = {
  livre: ['Livre entre colegas', 'Qualquer pessoa passa páginas para qualquer colega, sem limite.'],
  limite: ['Com limite', 'Cada pessoa passa e recebe de colegas até uma parte da própria cota por mês.'],
  reserva: ['Pela reserva', 'Ninguém passa para ninguém. Quem tem sobra devolve para a reserva comum; quem precisa pede à reserva.'],
};

function dirTrocas(p, t) {
  const st = { modo: t.modo };
  const doar = h('input', { type: 'number', inputmode: 'numeric', min: '0', max: '100', value: t.config.limite_doar_pct });
  const receber = h('input', { type: 'number', inputmode: 'numeric', min: '0', max: '500', value: t.config.limite_receber_pct });
  const auto = h('input', { type: 'number', inputmode: 'numeric', min: '0', value: t.config.reserva_auto });
  const campoLimite = h('div', { class: 'lado-a-lado' },
    h('label', { class: 'campo' }, h('span', null, 'Pode passar até (% da cota)'), doar),
    h('label', { class: 'campo' }, h('span', null, 'Pode receber até (% da cota)'), receber));
  const campoAuto = h('label', { class: 'campo' }, h('span', null, 'Páginas que saem na hora, por pessoa e por mês'), auto,
    h('div', { class: 'dica' }, 'Acima disso, o pedido espera a sua decisão aqui. Use 0 para decidir todos.'));
  const mostrar = () => { campoLimite.hidden = st.modo !== 'limite'; campoAuto.hidden = st.modo !== 'reserva'; };
  const escolha = h('div', { class: 'estilos', role: 'radiogroup' });
  const desenhar = () => escolha.replaceChildren(...Object.entries(MODOS_TROCA).map(([id, [nome, texto]]) => h('button', {
    type: 'button', role: 'radio', 'aria-checked': st.modo === id ? 'true' : 'false', class: 'estilo' + (st.modo === id ? ' marcado' : ''),
    onclick: () => { st.modo = id; desenhar(); mostrar(); },
  }, h('span', { class: 'estilo-nome' }, nome), h('span', { class: 'estilo-texto' }, texto))));
  desenhar(); mostrar();
  const salvar = h('button', { class: 'btn claro largo', style: { marginTop: '16px' } }, 'Salvar');
  salvar.onclick = async () => {
    botaoCarregando(salvar);
    try {
      await api('/api/admin/config', { modo_trocas: st.modo, limite_doar_pct: doar.value, limite_receber_pct: receber.value, reserva_auto: auto.value });
      avisar('Regras de troca salvas.'); await atualizarEu(); recarregarDirecao();
    } catch (e) { avisar(e.message, true); botaoPronto(salvar); }
  };

  const pendentes = t.pendentes.length ? h('div', { class: 'secao' }, h('h2', null, `Pedidos à reserva (${t.pendentes.length})`),
    h('div', { class: 'lista' }, t.pendentes.map((q) => {
      const sim = h('button', { class: 'btn pequeno' }, 'Liberar');
      const nao = h('button', { class: 'btn claro pequeno' }, 'Recusar');
      const responder = async (aceitar, b) => {
        botaoCarregando(b);
        try { await api('/api/admin/reserva/responder', { id: q.id, aceitar }); avisar(aceitar ? `${q.solicitante_nome} recebeu ${pag(q.paginas)}.` : 'Pedido recusado.'); recarregarDirecao(); }
        catch (e) { avisar(e.message, true); botaoPronto(b); }
      };
      sim.onclick = () => responder(true, sim); nao.onclick = () => responder(false, nao);
      return h('div', { class: 'item', style: { '--cor': q.cor } },
        h('span', { class: 'avatar', style: { fontSize: '13px' } }, n(q.paginas)),
        h('span', { class: 'meio' }, h('strong', null, `${q.solicitante_nome}: ${pag(q.paginas)} da ${curto(q.impressora_nome)}`),
          h('span', { class: 'previa' }, `${diaCurto(q.criado_em)}, ${hora(q.criado_em)}${q.motivo ? ', ' + q.motivo : ''}`),
          h('div', { class: 'linha-botoes', style: { marginTop: '8px' } }, sim, nao)));
    }))) : null;

  const pessoa = (x) => h('div', { class: 'item' }, h('span', { class: 'avatar', style: { fontSize: '13px' } }, n(x.paginas)),
    h('span', { class: 'meio' }, h('strong', null, x.nome), h('span', { class: 'previa' }, `${pag(x.paginas)} em ${x.vezes} ${x.vezes === 1 ? 'troca' : 'trocas'}`)));
  return h('div', null,
    seletorMes(p),
    pendentes,
    h('div', { class: 'secao' }, h('h2', null, 'Este mês'),
      h('div', { class: 'bloco' },
        h('div', { class: 'trocas-numeros' },
          h('div', null, h('b', { class: 'num' }, n(t.total.paginas)), h('span', null, `páginas trocadas entre colegas, em ${t.total.trocas} ${t.total.trocas === 1 ? 'troca' : 'trocas'}`)),
          h('div', null, h('b', { class: 'num' }, n(t.total.devolvidas)), h('span', null, `devolvidas ${L('ao')}`)),
          h('div', null, h('b', { class: 'num' }, n(t.total.da_reserva)), h('span', null, 'liberadas da reserva'))),
        t.reservas.some((r) => r.reserva !== null) ? h('p', { class: 'dica', style: { marginTop: '12px' } },
          'Na reserva agora: ' + t.reservas.filter((r) => r.reserva !== null).map((r) => `${pag(Math.max(0, r.reserva))} da ${curto(r.nome)}`).join(', ') + '.') : null)),
    h('div', { class: 'secao' }, h('h2', null, 'Quem mais passou'),
      t.doadores.length ? h('div', { class: 'lista' }, t.doadores.map(pessoa)) : h('div', { class: 'bloco vazio' }, 'Nenhuma troca neste mês.')),
    h('div', { class: 'secao' }, h('h2', null, 'Quem mais recebeu'),
      t.recebedores.length ? h('div', { class: 'lista' }, t.recebedores.map(pessoa)) : h('div', { class: 'bloco vazio' }, 'Nenhuma troca neste mês.')),
    h('div', { class: 'secao' }, h('h2', null, 'Trocas que se repetem'),
      h('p', { class: 'dica', style: { marginTop: '0', marginBottom: '10px' } }, 'A mesma dupla trocando 3 vezes ou mais no mês, ou em 3 meses seguidos. Não quer dizer que haja algo errado, mas vale uma conversa.'),
      t.pares.length ? h('div', { class: 'lista' }, t.pares.map((x) => h('div', { class: 'item' },
        h('span', { class: 'avatar', style: { fontSize: '13px' } }, n(x.paginas)),
        h('span', { class: 'meio' }, h('strong', null, `${x.de} → ${x.para}`),
          h('span', { class: 'previa' }, `${x.vezes} ${x.vezes === 1 ? 'troca' : 'trocas'} no mês${x.meses >= 3 ? ', há 3 meses seguidos' : ''}`))))) : h('div', { class: 'bloco vazio' }, 'Nenhuma troca repetida.')),
    h('div', { class: 'secao' }, h('h2', null, 'Como as páginas circulam'),
      h('div', { class: 'bloco' }, escolha, campoLimite, campoAuto,
        h('p', { class: 'aviso-troca' }, `Na hora de passar páginas, todos veem: "${t.aviso}"`),
        salvar)));
}

function blocoLicenca(lic) {
  const nomes = { ativa: ['Ativa', 'ok'], vencendo: ['Vencendo', 'alerta'], carencia: ['Vencida, em carência', 'alerta'], bloqueada: ['Parada', 'esgotado'], avaliacao: ['Avaliação', 'teste'], avaliacao_fim: ['Avaliação terminando', 'alerta'] };
  const [rotulo, tipo] = nomes[lic.estado] || [lic.estado, 'teste'];
  const campo = h('textarea', { rows: '4', spellcheck: 'false', autocapitalize: 'off', placeholder: 'FAF1.…', 'aria-label': 'Chave de ativação', class: 'campo-chave' });
  const erro = h('div', { class: 'faixa erro oculto', style: { marginTop: '12px', marginBottom: '0' } });
  const btn = h('button', { class: 'btn largo', style: { marginTop: '12px' } }, lic.com_chave ? 'Trocar pela nova chave' : 'Ativar');
  btn.onclick = async () => {
    erro.classList.add('oculto'); botaoCarregando(btn, 'Conferindo…');
    try {
      const r = await api('/api/admin/licenca', { chave: campo.value });
      avisar(r.estado === 'bloqueada' ? 'Chave salva, mas ela já venceu.' : 'Licença ativada.', r.estado === 'bloqueada');
      await atualizarEu(); recarregarDirecao();
    } catch (e) { botaoPronto(btn); erro.textContent = e.message; erro.classList.remove('oculto'); }
  };
  const br = (iso) => iso.split('-').reverse().join('/');
  const linha = (k, v) => h('div', null, h('dt', null, k), h('dd', null, v));
  return h('div', { class: 'secao' }, h('h2', null, 'Licença e ativação'),
    h('div', { class: 'bloco licenca-cartao' },
      h('div', { class: 'licenca-topo' }, h('strong', null, lic.com_chave ? lic.cliente : 'Sem chave de ativação'), h('span', { class: 'selo ' + tipo }, rotulo)),
      h('p', { style: { marginTop: '8px' } }, lic.mensagem),
      lic.com_chave
        ? h('dl', { class: 'licenca-dados' }, linha('Plano', lic.plano), linha('Unidades', String(lic.unidades)), linha('Validade', `${br(lic.inicio)} a ${br(lic.fim)}`), linha('Nº da licença', lic.id))
        : h('p', { class: 'dica' }, `Sem chave, o Folha a Folha funciona ${lic.avaliacao_dias} dias a partir da instalação. Depois disso, a impressão para até a chave ser inserida. Nada é apagado.`),
      lic.erro_chave ? h('div', { class: 'faixa erro', style: { marginTop: '12px', marginBottom: '0' } }, `A chave guardada não confere: ${lic.erro_chave}`) : null),
    h('div', { class: 'bloco' },
      h('label', { class: 'campo', style: { marginTop: '0' } }, h('span', null, lic.com_chave ? 'Nova chave (renovação)' : 'Chave de ativação'), campo,
        h('div', { class: 'dica' }, `O desenvolvedor envia a chave por e-mail depois da compra. Copie e cole inteira, começando por FAF1. Depois do vencimento, a impressão continua por ${lic.carencia_dias} dias.`)),
      erro, btn,
      lic.site ? h('p', { style: { marginTop: '12px', textAlign: 'center' } }, h('a', { href: lic.site, target: '_blank', rel: 'noopener' }, 'Comprar ou renovar no site')) : null));
}

function opcoesRadio(nome, atual, opcoes, aoMudar) {
  return h('div', { class: 'opcoes-radio', role: 'radiogroup' }, opcoes.map(([v, t, d]) => {
    const r = h('input', { type: 'radio', name: nome, value: v, checked: atual === v });
    r.onchange = () => aoMudar(v);
    return h('label', { class: 'opcao-radio' }, r, h('span', null, h('strong', null, t), d ? h('span', { class: 'dica', style: { display: 'block', marginTop: '2px' } }, d) : null));
  }));
}

function blocoControle(p) {
  const c = p.config;
  const st = { forma: c.finalidade_forma === 'livre' ? 'livre' : 'lista', finalidade: c.finalidade, descricao: c.descricao, previa: c.previa, prova: c.prova, marcadas: {} };
  p.impressoras.forEach((i) => { st.marcadas[i.id] = !!i.pede_finalidade; });
  const marcadas = h('div', { class: 'marcadas' + (st.finalidade === 'escolhidas' ? '' : ' oculto') }, p.impressoras.filter((i) => i.ativa).map((i) => {
    const cb = h('input', { type: 'checkbox', checked: st.marcadas[i.id] });
    cb.onchange = () => { st.marcadas[i.id] = cb.checked; };
    return h('label', { class: 'interruptor', style: { '--cor': i.cor } }, h('strong', null, i.nome), cb);
  }));
  const limite = h('input', { type: 'number', inputmode: 'numeric', min: '0', value: c.limite_pessoal, placeholder: 'Sem limite próprio' });
  const minimo = h('input', { type: 'number', inputmode: 'numeric', min: '2', value: c.prova_minimo });
  const campoMinimo = h('label', { class: 'campo' + (st.prova === 'acima' ? '' : ' oculto') }, h('span', null, 'Prova obrigatória a partir de quantas páginas'), minimo);
  const grande = h('input', { type: 'number', inputmode: 'numeric', min: '1', value: c.alerta_grande });
  const confImpr = h('input', { type: 'checkbox', checked: c.confirmar_impressora !== '0' });
  // lista de finalidades: a gestão troca nomes, acrescenta e tira; "Documento pessoal" e "Outro" ficam sempre
  const fins = p.finalidades;
  const stF = { lista: fins.lista.map((f) => ({ id: f.id, nome: f.nome, dica: f.dica })), mudou: false, sugestoes: false };
  const caixaFins = h('div', { class: 'lista-fins' });
  function desenharFins(focarUltima) {
    encher(caixaFins,
      stF.lista.map((f, i) => {
        const nome = h('input', { type: 'text', value: f.nome, maxlength: '40', placeholder: 'Nome (ex.: Material de vendas)', 'aria-label': `Finalidade ${i + 1}: nome` });
        const dica = h('input', { type: 'text', value: f.dica, maxlength: '80', placeholder: 'Exemplos (opcional)', 'aria-label': `Finalidade ${i + 1}: exemplos` });
        nome.oninput = () => { f.nome = nome.value; stF.mudou = true; stF.sugestoes = false; };
        dica.oninput = () => { f.dica = dica.value; stF.mudou = true; stF.sugestoes = false; };
        return h('div', { class: 'fin-linha' }, h('div', { class: 'fin-campos' }, nome, dica),
          stF.lista.length > 1 ? h('button', { type: 'button', class: 'btn-icone', 'aria-label': `Tirar ${f.nome || 'esta finalidade'}`, title: 'Tirar', onclick: () => { stF.lista.splice(i, 1); stF.mudou = true; stF.sugestoes = false; desenharFins(); } }, '×') : null);
      }),
      fins.fixas.map((f) => h('div', { class: 'fin-linha fixa' }, h('div', { class: 'fin-campos' }, h('strong', null, f.nome),
        h('span', { class: 'dica' }, f.id === 'pessoal' ? 'Sempre aparece. Tem o limite de páginas logo abaixo.' : 'Sempre aparece. Pede para escrever do que se trata.')))),
      h('div', { class: 'linha-botoes', style: { marginTop: '10px' } },
        stF.lista.length < fins.maximo ? h('button', { type: 'button', class: 'btn claro pequeno', onclick: () => { stF.lista.push({ id: '', nome: '', dica: '' }); stF.mudou = true; stF.sugestoes = false; desenharFins(true); } }, '+ Nova finalidade') : null,
        h('button', { type: 'button', class: 'btn-texto pequeno', onclick: () => { stF.lista = (fins.sugeridas[p.local.tipo] || []).map((f) => ({ id: '', nome: f.nome, dica: f.dica })); stF.mudou = true; stF.sugestoes = true; desenharFins(); } }, 'Voltar às sugestões')));
    if (focarUltima) { const campos = caixaFins.querySelectorAll('.fin-linha:not(.fixa) input'); if (campos.length) campos[campos.length - 2].focus(); }
  }
  desenharFins();
  const btn = h('button', { class: 'btn largo', style: { marginTop: '16px' } }, 'Salvar o controle de impressão');
  btn.onclick = async () => {
    botaoCarregando(btn);
    const corpo = { finalidade_forma: st.forma, finalidade: st.finalidade, descricao: st.descricao, previa: st.previa, prova: st.prova, prova_minimo: minimo.value || 20, limite_pessoal: limite.value.trim(), alerta_grande: grande.value || 50, pede_finalidade: st.marcadas, confirmar_impressora: confImpr.checked ? '1' : '0' };
    if (stF.mudou) corpo.finalidades = stF.sugestoes ? 'sugestoes' : stF.lista.filter((f) => f.nome.trim() || f.dica.trim());
    try {
      await api('/api/admin/config', corpo);
      avisar('Controle de impressão salvo.'); botaoPronto(btn); stF.mudou = false; atualizarEu(true);
    } catch (e) { avisar(e.message, true); botaoPronto(btn); }
  };
  const sub = (t) => h('h3', { class: 'sub-controle' }, t);
  const soLista = [];  // o que só vale quando a pessoa escolhe numa lista de finalidades
  const daLista = (el) => { soLista.push(el); el.classList.toggle('oculto', st.forma !== 'lista'); return el; };
  return h('div', { class: 'secao' }, h('h2', null, 'Controle de impressão'),
    h('div', { class: 'bloco controle' },
      sub('Como perguntar o que é cada impressão'),
      opcoesRadio('forma', st.forma, [
        ['livre', 'Campo livre', 'A pessoa escreve o que é, em poucas palavras. O app põe a primeira letra maiúscula e junta os textos iguais nos relatórios.'],
        ['lista', 'Lista de finalidades', 'A pessoa escolhe uma das finalidades que você define mais abaixo.']], (v) => { st.forma = v; soLista.forEach((x) => x.classList.toggle('oculto', v !== 'lista')); }),
      sub('Onde perguntar'),
      opcoesRadio('finalidade', st.finalidade, [
        ['todas', 'Em todas as impressoras', 'A pergunta aparece em toda impressão.'],
        ['escolhidas', 'Só nas impressoras que eu marcar', 'Bom para começar o teste numa impressora.'],
        ['desligada', 'Não perguntar']], (v) => { st.finalidade = v; marcadas.classList.toggle('oculto', v !== 'escolhidas'); }),
      marcadas,
      daLista(sub('Finalidades')),
      daLista(caixaFins),
      daLista(sub('Descrição')),
      daLista(opcoesRadio('descricao', st.descricao, [['outro', 'Só quando escolherem "Outro"'], ['sempre', 'Sempre', `${L('exemplo_desc')}.`]], (v) => { st.descricao = v; })),
      h('label', { class: 'campo' }, h('span', null, 'Documentos pessoais: páginas por pessoa por mês'), limite,
        h('div', { class: 'dica' }, 'Use 0 para não permitir. Deixe vazio para não ter limite próprio (conta só na cota).')),
      sub('Prévia antes de imprimir'),
      opcoesRadio('previa', st.previa, [
        ['obrigatoria', 'Obrigatória', 'Mostra as folhas como vão sair e pede para marcar: páginas, lados, orientação e cópias.'],
        ['opcional', 'A pessoa escolhe', 'Vem ligada; cada um pode desligar em Minha conta.'],
        ['desligada', 'Desligada']], (v) => { st.previa = v; }),
      sub('Impressora certa'),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'Pedir para confirmar a impressora antes de imprimir'),
        h('div', { class: 'dica', style: { marginTop: '0' } }, 'Quem tem cota em mais de uma impressora marca "é para sair na impressora X" antes de imprimir. Ao trocar de impressora, marca de novo.')), confImpr),
      sub('Impressão de prova'),
      opcoesRadio('prova', st.prova, [
        ['opcional', 'A pessoa escolhe', 'Pode imprimir só a 1ª folha ou 1 cópia, conferir e depois mandar o resto.'],
        ['acima', 'Obrigatória para impressões grandes'],
        ['desligada', 'Desligada']], (v) => { st.prova = v; campoMinimo.classList.toggle('oculto', v !== 'acima'); }),
      campoMinimo,
      sub('Relatórios'),
      h('label', { class: 'campo' }, h('span', null, 'Destacar impressões a partir de quantas páginas'), grande),
      btn));
}

function blocoRegrasGerais(p) {
  const pol = p.politica || {};
  const unidade = p.instalacao === 'unidade';
  const campos = camposRegras(pol, { semNegativo: unidade && !pol.pode_negativo ? 'A TI não permite cota negativa nesta unidade.' : null });
  const btn = h('button', { class: 'btn largo', style: { marginTop: '16px' } }, 'Salvar aumento e cota negativa');
  btn.onclick = async () => {
    botaoCarregando(btn);
    const v = campos.valor();
    try {
      await api('/api/admin/config', { aumento: v.aumento ? '1' : '0', negativo: String(v.negativo), negativo_desconta: v.negativo_desconta ? '1' : '0' });
      avisar('Regras salvas.'); botaoPronto(btn); atualizarEu(true);
    } catch (e) { avisar(e.message, true); botaoPronto(btn); }
  };
  return h('div', { class: 'secao' }, h('h2', null, 'Aumento de cota e cota negativa'),
    h('p', { class: 'dica', style: { margin: '-4px 0 10px' } }, p.instalacao === 'central' ? 'Valem para quem está direto na central. Cada setor tem as suas, na ficha do setor.' : 'Cada exceção fica registrada com a justificativa, em Relatórios.'),
    h('div', { class: 'bloco' }, campos.el, btn));
}

function blocoCentralUnidade(c) {
  const url = h('input', { type: 'text', value: c.url || '', placeholder: 'Ex.: http://10.0.0.5:8080', autocapitalize: 'off', spellcheck: 'false' });
  const salvarUrl = h('button', { class: 'btn claro pequeno' }, 'Salvar endereço');
  salvarUrl.onclick = async () => { try { await api('/api/admin/central/endereco', { url: url.value }); avisar('Endereço salvo.'); recarregarDirecao(); } catch (e) { avisar(e.message, true); } };
  const sinc = h('button', { class: 'btn' }, 'Sincronizar agora');
  sinc.onclick = async () => {
    botaoCarregando(sinc);
    try { const r = await api('/api/admin/central/sincronizar', {}); avisar(r.ok ? 'Sincronizado com a central.' : r.erro, !r.ok); await atualizarEu(true); recarregarDirecao(); }
    catch (e) { avisar(e.message, true); botaoPronto(sinc); }
  };
  const entrada = h('input', { type: 'file', accept: '.json,application/json', class: 'oculto', id: 'arq-central' });
  entrada.onchange = async () => {
    const arq = entrada.files[0]; if (!arq) return;
    try { await api('/api/admin/central/arquivo', { arquivo: await arq.text() }); avisar('Arquivo da central carregado.'); await atualizarEu(true); recarregarDirecao(); }
    catch (e) { avisar(e.message, true); }
  };
  const pol = c.politica || {};
  return h('div', { class: 'secao' }, h('h2', null, 'Central da TI'),
    c.erro ? h('div', { class: 'faixa erro' }, c.erro) : null,
    !c.pacote_ok ? h('div', { class: 'faixa erro' }, 'O pacote da central não confere (pode ter sido alterado). Sincronize ou carregue o arquivo da central: até lá, não dá para aumentar cotas.') : null,
    h('div', { class: 'bloco' },
      h('p', { style: { marginTop: '0' } }, h('strong', null, c.caminho || 'Unidade'), ` · ligada a ${c.central || 'uma central'}`),
      h('ul', { class: 'lista-simples' },
        h('li', null, `Cota da unidade: ${pag(c.cota || 0)} por mês. Já entregues às pessoas: ${pag(c.distribuido)}.`),
        h('li', null, c.pela_ti ? 'Quem cadastra as pessoas: a TI, pela central.' : 'Quem cadastra as pessoas: o gestor da unidade.'),
        h('li', null, pol.exceder ? 'Pode passar da cota da unidade, com justificativa (a TI vê).' : 'A soma das cotas não pode passar da cota da unidade.'),
        h('li', null, pol.pode_negativo ? 'A TI permite cota negativa (você decide o limite, abaixo).' : 'A TI não permite cota negativa.'),
        h('li', null, c.ultimo ? `Última sincronização: ${diaCurto(c.ultimo)} ${hora(c.ultimo)}.` : 'Ainda não sincronizou.')),
      h('div', { class: 'botoes-coluna' }, c.url ? sinc : null,
        h('label', { class: 'btn claro', for: 'arq-central' }, 'Carregar arquivo da central', entrada),
        h('a', { class: 'btn claro', href: '/api/admin/central/relatorio' }, 'Baixar relatório para a central')),
      h('p', { class: 'dica' }, 'Sem internet: leve o relatório no pendrive para a TI e traga de lá o arquivo da central. A impressão continua funcionando com as últimas cotas recebidas.'),
      h('label', { class: 'campo' }, h('span', null, 'Endereço da central'), url), salvarUrl));
}

function dirAjustes(p, lic) {
  const c = p.config;
  const stLocal = { tipo: p.local.tipo };
  const escola = h('input', { type: 'text', value: c.escola, maxlength: '120', placeholder: p.local.exemplo, disabled: p.instalacao === 'unidade', title: p.instalacao === 'unidade' ? 'O nome vem da central' : null });
  const rotNome = h('span', null, p.local.rotulo);
  const tiposLocal = h('div', { class: 'segmentos tipos-local', role: 'group', 'aria-label': 'Onde é usado' }, [['empresa', 'Empresa'], ['escola', 'Escola'], ['outro', 'Outra organização']].map(([v, t]) => {
    const b = h('button', { type: 'button', 'aria-pressed': String(stLocal.tipo === v) }, t);
    b.onclick = () => {
      stLocal.tipo = v; tiposLocal.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
      const l = p.locais[v]; rotNome.textContent = l.rotulo; escola.placeholder = l.exemplo;
    };
    return b;
  }));
  const aviso = h('input', { type: 'number', inputmode: 'numeric', min: '10', max: '100', value: c.aviso_pct });
  const maxc = h('input', { type: 'number', inputmode: 'numeric', min: '1', value: c.max_copias });
  const bloqueio = h('input', { type: 'number', inputmode: 'numeric', min: '0', max: '480', value: c.bloqueio_minutos });
  const cadAberto = h('input', { type: 'checkbox', checked: c.cadastro_aberto !== '0' });
  const sumatra = h('input', { type: 'text', value: c.sumatra, placeholder: 'Automático' });
  const soffice = h('input', { type: 'text', value: c.soffice, placeholder: 'Automático' });
  const empresa = h('input', { type: 'text', value: c.empresa_nome, placeholder: 'Razão social' });
  const cnpj = h('input', { type: 'text', inputmode: 'numeric', value: c.empresa_cnpj, placeholder: '00.000.000/0000-00' });
  const contatoPriv = h('input', { type: 'text', value: c.contato_privacidade, placeholder: 'E-mail de privacidade da empresa' });
  const contatoEscola = h('input', { type: 'text', value: c.contato_escola, placeholder: 'E-mail ou telefone da gestão' });
  const reter = h('input', { type: 'number', inputmode: 'numeric', min: '1', max: '120', value: c.reter_mensagens_meses });
  const site = h('input', { type: 'url', value: c.site_empresa, placeholder: 'https://…' });
  const filtroLigado = h('input', { type: 'checkbox', checked: c.filtro_ligado !== '0' });
  const filtroExtras = h('input', { type: 'text', value: c.filtro_extras || '', placeholder: 'palavras separadas por vírgula', maxlength: '1000' });
  const filtroLiberadas = h('input', { type: 'text', value: c.filtro_liberadas || '', placeholder: 'palavras da lista que podem passar', maxlength: '1000' });
  const termosUrl = h('input', { type: 'url', value: c.termos_url || '', placeholder: 'https://… (termos de uso completos)' });
  const btn = h('button', { class: 'btn largo', style: { marginTop: '20px' } }, 'Salvar ajustes');
  btn.onclick = async () => {
    botaoCarregando(btn);
    try { await api('/api/admin/config', { tipo_local: stLocal.tipo, escola: escola.value, aviso_pct: aviso.value, max_copias: maxc.value, bloqueio_minutos: bloqueio.value || 0, cadastro_aberto: cadAberto.checked ? '1' : '0', sumatra: sumatra.value, soffice: soffice.value, empresa_nome: empresa.value, empresa_cnpj: cnpj.value, contato_privacidade: contatoPriv.value, contato_escola: contatoEscola.value, reter_mensagens_meses: reter.value, site_empresa: site.value, filtro_ligado: filtroLigado.checked ? '1' : '0', filtro_extras: filtroExtras.value, filtro_liberadas: filtroLiberadas.value, termos_url: termosUrl.value }); avisar('Ajustes salvos.'); E.eu.bloqueio_minutos = Number(bloqueio.value || 0); botaoPronto(btn); const mudouTipo = stLocal.tipo !== p.local.tipo; await atualizarEu(true); if (mudouTipo) recarregarDirecao(); else { const sub = document.querySelector('.topo .sub'); if (sub) sub.textContent = E.eu.escola; } }
    catch (e) { avisar(e.message, true); botaoPronto(btn); }
  };
  return h('div', null,
    p.central ? blocoCentralUnidade(p.central) : null,
    lic ? blocoLicenca(lic) : null,
    blocoControle(p),
    blocoRegrasGerais(p),
    h('div', { class: 'secao' }, h('h2', null, 'Geral'), h('div', { class: 'bloco' },
      h('div', { class: 'campo', style: { marginTop: '0' } }, h('span', null, 'Onde o Folha a Folha é usado'), tiposLocal,
        h('div', { class: 'dica' }, 'Muda as palavras das telas e, se você não trocou a lista, as finalidades sugeridas. As regras são as mesmas.')),
      h('label', { class: 'campo' }, rotNome, escola),
      h('label', { class: 'campo' }, h('span', null, 'Avisar quando a pessoa já usou (%)'), aviso, h('div', { class: 'dica' }, 'A pilha fica amarela a partir deste ponto.')),
      h('label', { class: 'campo' }, h('span', null, 'Máximo de cópias por impressão'), maxc),
      h('label', { class: 'interruptor' }, h('span', null, h('strong', null, 'As pessoas podem pedir o cadastro na tela de entrada'),
        h('div', { class: 'dica', style: { marginTop: '0' } }, 'Aparece "Criar meu cadastro". Quem pede entra na lista "Esperando aprovação", em Equipe, sem cota e sem acesso, até você aprovar.')), cadAberto),
      h('label', { class: 'campo' }, h('span', null, 'Bloquear a tela depois de quantos minutos sem uso'), bloqueio,
        h('div', { class: 'dica' }, 'Para continuar, a pessoa digita a senha de novo. Protege a cota de quem esquece o app aberto num computador compartilhado. Com o app bloqueado, a impressora Folha a Folha também não aceita impressões daquele aparelho. Use 0 para nunca bloquear.')),
      h('label', { class: 'campo' }, h('span', null, 'Caminho do SumatraPDF (só Windows)'), sumatra, h('div', { class: 'dica' }, 'Deixe vazio para procurar sozinho, inclusive na pasta "ferramentas".')),
      h('label', { class: 'campo' }, h('span', null, 'Caminho do LibreOffice'), soffice))),
    h('div', { class: 'secao' }, h('h2', null, 'Privacidade (LGPD)'),
      h('div', { class: 'bloco' },
        h('label', { class: 'campo', style: { marginTop: '0' } }, h('span', null, 'Empresa que mantém o sistema'), empresa),
        h('label', { class: 'campo' }, h('span', null, 'CNPJ da empresa'), cnpj),
        h('label', { class: 'campo' }, h('span', null, 'Site da empresa'), site),
        h('label', { class: 'campo' }, h('span', null, 'Contato de privacidade da empresa'), contatoPriv),
        h('label', { class: 'campo' }, h('span', null, 'Contato da gestão para pedidos sobre dados'), contatoEscola),
        h('label', { class: 'campo' }, h('span', null, 'Apagar mensagens com mais de quantos meses'), reter),
        h('p', { class: 'dica' }, 'Esses dados aparecem no aviso de privacidade que cada pessoa vê no primeiro acesso.'),
        h('label', { class: 'interruptor', style: { marginTop: '14px' } }, h('span', null, h('strong', null, 'Filtro de palavras ofensivas'), h('div', { class: 'dica', style: { marginTop: '0' } }, 'Nas mensagens e nos pedidos, as palavras ofensivas viram asteriscos.')), filtroLigado),
        h('label', { class: 'campo' }, h('span', null, 'Palavras a mais no filtro'), filtroExtras),
        h('label', { class: 'campo' }, h('span', null, 'Palavras liberadas'), filtroLiberadas),
        h('label', { class: 'campo' }, h('span', null, 'Endereço dos termos de uso'), termosUrl)),
      btn),
    h('div', { class: 'secao' }, h('h2', null, 'Depois dos testes'),
      h('div', { class: 'bloco' },
        h('p', null, 'Apaga todas as impressões feitas em modo teste, devolvendo essas páginas às pessoas.'),
        h('button', {
          class: 'btn claro largo', style: { marginTop: '12px' },
          onclick: async () => {
            if (!(await confirmar('Apagar impressões de teste?', 'Isso não afeta impressões reais.', 'Apagar', true))) return;
            try { const r = await api('/api/admin/apagar-testes', {}); avisar(`${r.apagados} registros de teste apagados.`); atualizarEu(); }
            catch (e) { avisar(e.message, true); }
          },
        }, 'Apagar impressões de teste'))));
}

iniciar();
