/* QR code em JavaScript puro, sem biblioteca de fora.
   Modo de bytes (UTF-8), correção de erro M, versões 1 a 10 (até 213 bytes: sobra para um endereço de rede).
   Uso: window.qrSvg('http://192.168.1.91:8080') devolve o texto de um <svg> pronto, preto sobre branco, com a borda
   branca obrigatória. Devolve '' se o texto não couber. window.qrMatriz(texto) devolve a grade (true = escuro). */
(function () {
  'use strict';

  const ECC_POR_BLOCO = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26];  // por versão, nível M
  const BLOCOS = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];
  const VERSAO_MAX = 10;

  function modulosDeDados(v) {
    let r = (16 * v + 128) * v + 64;
    if (v >= 2) {
      const n = Math.floor(v / 7) + 2;
      r -= (25 * n - 10) * n - 55;
      if (v >= 7) r -= 36;
    }
    return r;
  }
  const palavrasDeDados = (v) => Math.floor(modulosDeDados(v) / 8) - ECC_POR_BLOCO[v] * BLOCOS[v];

  // ---- Reed-Solomon no campo de 256 elementos
  function gfMul(x, y) {
    let z = 0;
    for (let i = 7; i >= 0; i--) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      z ^= ((y >>> i) & 1) * x;
    }
    return z;
  }
  function divisorRS(grau) {
    const r = new Array(grau).fill(0);
    r[grau - 1] = 1;
    let raiz = 1;
    for (let i = 0; i < grau; i++) {
      for (let j = 0; j < r.length; j++) {
        r[j] = gfMul(r[j], raiz);
        if (j + 1 < r.length) r[j] ^= r[j + 1];
      }
      raiz = gfMul(raiz, 0x02);
    }
    return r;
  }
  function restoRS(dados, divisor) {
    const r = new Array(divisor.length).fill(0);
    for (const b of dados) {
      const f = b ^ r.shift();
      r.push(0);
      divisor.forEach((c, i) => { r[i] ^= gfMul(c, f); });
    }
    return r;
  }

  function utf8(texto) {
    return Array.from(new TextEncoder().encode(texto));
  }

  // ---- dados + correção de erro, já intercalados
  function palavrasFinais(bytes, v) {
    const capacidade = palavrasDeDados(v) * 8;
    const bits = [];
    const poe = (valor, n) => { for (let i = n - 1; i >= 0; i--) bits.push((valor >>> i) & 1); };
    poe(0x4, 4);
    poe(bytes.length, v <= 9 ? 8 : 16);
    bytes.forEach((b) => poe(b, 8));
    poe(0, Math.min(4, capacidade - bits.length));
    poe(0, (8 - (bits.length % 8)) % 8);
    for (let pad = 0xEC; bits.length < capacidade; pad ^= 0xEC ^ 0x11) poe(pad, 8);
    const dados = [];
    for (let i = 0; i < bits.length; i += 8) {
      let b = 0;
      for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j];
      dados.push(b);
    }
    const n = BLOCOS[v], ecc = ECC_POR_BLOCO[v];
    const bruto = Math.floor(modulosDeDados(v) / 8);
    const curtos = n - (bruto % n), tamCurto = Math.floor(bruto / n);
    const div = divisorRS(ecc);
    const blocos = [];
    for (let i = 0, k = 0; i < n; i++) {
      const dat = dados.slice(k, k + tamCurto - ecc + (i < curtos ? 0 : 1));
      k += dat.length;
      const e = restoRS(dat, div);
      if (i < curtos) dat.push(0);
      blocos.push(dat.concat(e));
    }
    const saida = [];
    for (let i = 0; i < blocos[0].length; i++) {
      blocos.forEach((bl, j) => { if (i !== tamCurto - ecc || j >= curtos) saida.push(bl[i]); });
    }
    return saida;
  }

  // ---- a grade
  function montar(v, palavras, mascaraFixa) {
    const tam = v * 4 + 17;
    const m = Array.from({ length: tam }, () => new Array(tam).fill(false));
    const fn = Array.from({ length: tam }, () => new Array(tam).fill(false));
    const poe = (x, y, escuro) => { m[y][x] = escuro; fn[y][x] = true; };
    const dentro = (x, y) => x >= 0 && x < tam && y >= 0 && y < tam;

    for (let i = 0; i < tam; i++) { poe(6, i, i % 2 === 0); poe(i, 6, i % 2 === 0); }
    [[3, 3], [tam - 4, 3], [3, tam - 4]].forEach(([cx, cy]) => {
      for (let dy = -4; dy <= 4; dy++) {
        for (let dx = -4; dx <= 4; dx++) {
          const d = Math.max(Math.abs(dx), Math.abs(dy));
          if (dentro(cx + dx, cy + dy)) poe(cx + dx, cy + dy, d !== 2 && d !== 4);
        }
      }
    });
    if (v > 1) {
      const n = Math.floor(v / 7) + 2;
      const passo = Math.ceil((v * 4 + 4) / (n * 2 - 2)) * 2;
      const pos = [6];
      for (let p = tam - 7; pos.length < n; p -= passo) pos.splice(1, 0, p);
      pos.forEach((cx, i) => pos.forEach((cy, j) => {
        if ((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0)) return;
        for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) poe(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
      }));
    }
    function formato(mascara) {
      const dados = (0 << 3) | mascara;  // nível M = 00
      let r = dados;
      for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537);
      const bits = ((dados << 10) | r) ^ 0x5412;
      const b = (i) => ((bits >>> i) & 1) !== 0;
      for (let i = 0; i <= 5; i++) poe(8, i, b(i));
      poe(8, 7, b(6)); poe(8, 8, b(7)); poe(7, 8, b(8));
      for (let i = 9; i < 15; i++) poe(14 - i, 8, b(i));
      for (let i = 0; i < 8; i++) poe(tam - 1 - i, 8, b(i));
      for (let i = 8; i < 15; i++) poe(8, tam - 15 + i, b(i));
      poe(8, tam - 8, true);
    }
    formato(0);
    if (v >= 7) {
      let r = v;
      for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1F25);
      const bits = (v << 12) | r;
      for (let i = 0; i < 18; i++) {
        const b = ((bits >>> i) & 1) !== 0, a = tam - 11 + (i % 3), c = Math.floor(i / 3);
        poe(a, c, b); poe(c, a, b);
      }
    }
    // dados em zigue-zague
    let i = 0;
    for (let dir = tam - 1; dir >= 1; dir -= 2) {
      if (dir === 6) dir = 5;
      for (let vert = 0; vert < tam; vert++) {
        for (let j = 0; j < 2; j++) {
          const x = dir - j, sobe = ((dir + 1) & 2) === 0, y = sobe ? tam - 1 - vert : vert;
          if (!fn[y][x] && i < palavras.length * 8) {
            m[y][x] = ((palavras[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0;
            i++;
          }
        }
      }
    }
    const aplicar = (mascara) => {
      for (let y = 0; y < tam; y++) {
        for (let x = 0; x < tam; x++) {
          let inverte;
          switch (mascara) {
            case 0: inverte = (x + y) % 2 === 0; break;
            case 1: inverte = y % 2 === 0; break;
            case 2: inverte = x % 3 === 0; break;
            case 3: inverte = (x + y) % 3 === 0; break;
            case 4: inverte = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
            case 5: inverte = ((x * y) % 2) + ((x * y) % 3) === 0; break;
            case 6: inverte = (((x * y) % 2) + ((x * y) % 3)) % 2 === 0; break;
            default: inverte = (((x + y) % 2) + ((x * y) % 3)) % 2 === 0;
          }
          if (!fn[y][x] && inverte) m[y][x] = !m[y][x];
        }
      }
    };
    let melhor = mascaraFixa, menor = Infinity;
    if (mascaraFixa === undefined) {
      for (let k = 0; k < 8; k++) {
        aplicar(k); formato(k);
        const p = penalidade(m);
        if (p < menor) { menor = p; melhor = k; }
        aplicar(k);
      }
    }
    aplicar(melhor); formato(melhor);
    return m;
  }

  function penalidade(m) {
    const tam = m.length;
    let total = 0;
    const linhas = [];
    for (let y = 0; y < tam; y++) linhas.push(m[y]);
    for (let x = 0; x < tam; x++) linhas.push(m.map((l) => l[x]));
    linhas.forEach((l) => {
      let corrida = 1;
      for (let i = 1; i <= tam; i++) {
        if (i < tam && l[i] === l[i - 1]) corrida++;
        else { if (corrida >= 5) total += 3 + (corrida - 5); corrida = 1; }
      }
      const s = l.map((c) => (c ? 1 : 0)).join('');
      for (let i = 0; i + 7 <= tam; i++) {
        if (s.substr(i, 7) !== '1011101') continue;
        const antes = s.substring(Math.max(0, i - 4), i), depois = s.substring(i + 7, i + 11);
        if ((i - 4 < 0 || antes === '0000')) total += 40;
        if ((i + 11 > tam || depois === '0000')) total += 40;
      }
    });
    for (let y = 0; y < tam - 1; y++) {
      for (let x = 0; x < tam - 1; x++) {
        const c = m[y][x];
        if (c === m[y][x + 1] && c === m[y + 1][x] && c === m[y + 1][x + 1]) total += 3;
      }
    }
    const escuros = m.reduce((a, l) => a + l.filter(Boolean).length, 0);
    total += (Math.ceil(Math.abs(escuros * 20 - tam * tam * 10) / (tam * tam)) - 1) * 10;
    return total;
  }

  /* Grade do QR (true = módulo escuro) ou null se o texto não couber. `mascara` (0 a 7) só serve para testes. */
  function qrMatriz(texto, mascara) {
    const bytes = utf8(String(texto));
    for (let v = 1; v <= VERSAO_MAX; v++) {
      const bitsPrecisos = 4 + (v <= 9 ? 8 : 16) + bytes.length * 8;
      if (bitsPrecisos <= palavrasDeDados(v) * 8) return montar(v, palavrasFinais(bytes, v), mascara);
    }
    return null;
  }

  function qrSvg(texto, descricao) {
    const m = qrMatriz(texto);
    if (!m) return '';
    const borda = 4, tam = m.length + borda * 2;
    let d = '';
    m.forEach((linha, y) => {
      for (let x = 0; x < linha.length;) {
        if (!linha[x]) { x++; continue; }
        let fim = x;
        while (fim < linha.length && linha[fim]) fim++;
        d += `M${x + borda} ${y + borda}h${fim - x}v1h${x - fim}z`;
        x = fim;
      }
    });
    const nome = String(descricao || 'QR code').replace(/[<>&"]/g, '');
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${tam} ${tam}" shape-rendering="crispEdges" role="img" aria-label="${nome}">`
      + `<rect width="${tam}" height="${tam}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
  }

  const api = { qrMatriz, qrSvg };
  if (typeof window !== 'undefined') { window.qrMatriz = qrMatriz; window.qrSvg = qrSvg; }
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
