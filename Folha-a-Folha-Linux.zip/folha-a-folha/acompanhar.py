"""Acompanha cada impressão no servidor de impressão do Linux (CUPS) até ela sair da fila.

Com isso o Folha a Folha só desconta de vez o que foi impresso: trabalho cancelado ou com erro
devolve as páginas, e quem está esperando vê o motivo (sem papel, impressora desligada...).
Conversa com o CUPS pelo mesmo IPP que as impressoras usam. Só biblioteca padrão.

Com o IP da impressora, também lê o contador de páginas da máquina antes e depois de cada
trabalho (veja contador.py) e desconta só o que ela contou.
"""
import getpass
import http.client
import io
import os
import random
import re
import shutil
import socket
import subprocess
import time

import contador
import ipp

WINDOWS = os.name == "nt"
ENDERECO = os.environ.get("CI_CUPS", "localhost:631")
SOQUETES = ("/run/cups/cups.sock", "/var/run/cups/cups.sock")

OID_ESTADO_IMPRESSORA = "1.3.6.1.2.1.25.3.5.1.1.1"  # hrPrinterStatus: 3 parada, 4 imprimindo, 5 aquecendo
OID_ERROS_IMPRESSORA = "1.3.6.1.2.1.25.3.5.1.2.1"   # hrPrinterDetectedErrorState: um bit por problema
OID_UNIDADE = "1.3.6.1.2.1.43.10.2.1.3.1.1"          # prtMarkerCounterUnit: 7 lados impressos, 8 folhas
UNIDADE_FOLHAS = 8

FINAIS = (ipp.JOB_CANCELADO, ipp.JOB_ABORTADO, ipp.JOB_CONCLUIDO)
PARADO = 6

# motivos que o CUPS e a impressora informam, do mais específico para o mais geral
MOTIVOS = [
    ("media-jam", "papel enroscado"),
    ("media-empty", "sem papel"), ("media-needed", "sem papel"),
    ("input-tray-missing", "bandeja de papel fora do lugar"),
    ("door-open", "tampa aberta"), ("cover-open", "tampa aberta"), ("interlock-open", "tampa aberta"),
    ("toner-empty", "sem toner"), ("marker-supply-empty", "sem toner ou tinta"),
    ("output-area-full", "bandeja de saída cheia"),
    ("paused", "a fila desta impressora está pausada no computador"),
    ("printer-stopped", "a fila desta impressora está pausada no computador"),
    ("offline", "a impressora não responde (desligada ou fora da rede?)"),
    ("connecting-to-device", "o computador está tentando falar com a impressora (desligada ou fora da rede?)"),
    ("timed-out", "a impressora não responde"),
    ("job-hold-until-specified", "retida no servidor de impressão"),
    ("job-held-for-authentication", "o servidor de impressão pede senha"),
]


class SemCups(Exception):
    pass


def usuario():
    try:
        return getpass.getuser()
    except Exception:
        return "folha-a-folha"


# ---------------------------------------------------------------- conversa com o CUPS

class _ConexaoUnix(http.client.HTTPConnection):
    def __init__(self, caminho, timeout):
        super().__init__("localhost", timeout=timeout)
        self.caminho = caminho

    def connect(self):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(self.timeout)
        s.connect(self.caminho)
        self.sock = s


def _conexoes(timeout):
    host, _, porta = ENDERECO.rpartition(":")
    saida = [lambda: http.client.HTTPConnection(host or "localhost", int(porta or 631), timeout=timeout)]
    if not WINDOWS and hasattr(socket, "AF_UNIX") and "CI_CUPS" not in os.environ:
        for s in SOQUETES:
            if os.path.exists(s):
                saida.append(lambda s=s: _ConexaoUnix(s, timeout))
    return saida


def pedir(operacao, atributos, timeout=4):
    """Manda um pedido IPP ao CUPS e devolve a resposta lida (o código fica em .operacao)."""
    r = ipp.Resposta(operacao, random.randint(1, 0x7FFFFFFF), (2, 0))
    for nome, tag, valores in atributos:
        r.add(nome, tag, valores)
    r.add("requesting-user-name", ipp.T_NOME, [usuario()])
    corpo = r.bytes()
    ultimo = "sem resposta"
    for fazer in _conexoes(timeout):
        try:
            c = fazer()
            c.request("POST", "/", body=corpo, headers={"Content-Type": "application/ipp"})
            resp = c.getresponse()
            dados = resp.read()
            servidor = resp.getheader("Server") or ""
            c.close()
        except (OSError, http.client.HTTPException) as e:
            ultimo = str(e)
            continue
        # na porta 631 pode estar o próprio Folha a Folha (num computador sem CUPS); o CUPS se apresenta
        # como "CUPS/2.x", ou não se apresenta, se a TI escondeu a versão
        if "CUPS" not in servidor.upper() and any(x in servidor.upper() for x in ("FOLHAAFOLHA", "BASEHTTP", "PYTHON")):
            ultimo = "o que responde não é o CUPS"
            continue
        if resp.status != 200:
            ultimo = f"HTTP {resp.status}"
            continue
        try:
            return ipp.ler_requisicao(io.BytesIO(dados))
        except ipp.ErroIPP as e:
            ultimo = str(e)
    raise SemCups(ultimo)


def _attr(resp, nome):
    for _, attrs in resp.grupos:
        if nome in attrs:
            return attrs[nome][1]
    return None


_DISP = {"t": 0.0, "v": False}


def disponivel():
    """O CUPS deste computador responde? (Guardado por 30 segundos.)"""
    if WINDOWS:
        return False
    if time.time() - _DISP["t"] < 30:
        return _DISP["v"]
    try:
        pedir(ipp.GET_JOBS, [("printer-uri", ipp.T_URI, ["ipp://localhost/"]), ("limit", ipp.T_INTEIRO, [1]),
                             ("requested-attributes", ipp.T_PALAVRA, ["job-id"])], timeout=2)
        v = True
    except SemCups:
        v = False
    _DISP.update(t=time.time(), v=v)
    return v


def id_do_trabalho(saida, impressora):
    """Número do trabalho no CUPS, tirado da resposta do lp ("request id is HP-12 (1 file(s))", em qualquer idioma)."""
    m = re.search(re.escape(impressora) + r"-(\d+)\b", saida or "")
    if not m:
        m = re.search(r"\S-(\d+)\s*\(", saida or "")
    return m.group(1) if m else ""


def estado(job):
    """Situação do trabalho no CUPS: {estado, motivos, mensagem, impressoes} ou None se o CUPS não o conhece.
    Lança SemCups se o CUPS não responder."""
    r = pedir(ipp.GET_JOB_ATTRIBUTES, [
        ("job-uri", ipp.T_URI, [f"ipp://localhost/jobs/{int(job)}"]),
        ("requested-attributes", ipp.T_PALAVRA, ["job-state", "job-state-reasons", "job-printer-state-message",
                                                  "job-printer-state-reasons", "job-impressions-completed"])])
    if r.operacao == ipp.ERRO_NAO_ENCONTRADO:
        return None
    if r.operacao >= 0x0400:
        raise SemCups(f"o CUPS recusou a consulta ({r.operacao:#06x})")
    st = (_attr(r, "job-state") or [0])[0]
    motivos = [m for m in (_attr(r, "job-state-reasons") or []) + (_attr(r, "job-printer-state-reasons") or [])
               if isinstance(m, str)]
    msg = (_attr(r, "job-printer-state-message") or [""])[0]
    imp = (_attr(r, "job-impressions-completed") or [None])[0]
    return {"estado": st, "motivos": motivos, "mensagem": msg if isinstance(msg, str) else "",
            "impressoes": imp if isinstance(imp, int) and imp >= 0 else None}


def motivo(st):
    for chave, texto in MOTIVOS:
        if any(chave in m for m in st.get("motivos") or []):
            return texto
    return ""


def texto_estado(st):
    """Frase curta para quem está esperando a impressão."""
    m = motivo(st)
    e = st["estado"]
    if e == ipp.JOB_PROCESSANDO:
        base = "Imprimindo"
    elif e == PARADO:
        base = "Parada na impressora"
    elif e == ipp.JOB_RETIDO:
        base = "Retida no servidor de impressão"
    else:
        base = "Na fila da impressora"
    if m and not (e == ipp.JOB_RETIDO and "retida" in m):
        return f"{base}: {m}"
    return base


def _comando(cmd):
    if not shutil.which(cmd[0]):
        return False
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=30)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0


def liberar(job):
    """Solta um trabalho mandado retido (lp -H hold)."""
    return _comando(["lp", "-i", str(int(job)), "-H", "resume"])


def liberar_ultimo(impressora):
    """Se não deu para saber o número do trabalho que acabou de ser mandado retido, solta o mais novo retido
    desta impressora, para ele não ficar parado para sempre."""
    try:
        r = pedir(ipp.GET_JOBS, [("printer-uri", ipp.T_URI, [f"ipp://localhost/printers/{impressora}"]),
                                 ("which-jobs", ipp.T_PALAVRA, ["not-completed"]), ("my-jobs", ipp.T_BOOL, [True]),
                                 ("requested-attributes", ipp.T_PALAVRA, ["job-id", "job-state"])])
    except SemCups:
        return False
    retidos = [g["job-id"][1][0] for tag, g in r.grupos if tag == ipp.G_TRABALHO and "job-id" in g
               and (g.get("job-state") or (0, [0]))[1][0] == ipp.JOB_RETIDO]
    return liberar(max(retidos)) if retidos else False


def cancelar(job):
    return _comando(["cancel", str(int(job))])


# ---------------------------------------------------------------- contador da impressora

def ler_valor(endereco, comunidade):
    """Só o número do contador, rápido (para acompanhar um trabalho). Lança ErroContador."""
    return contador.ler_valor(endereco, comunidade or "public", timeout=1.5, tentativas=1)


# hrPrinterDetectedErrorState (RFC 3805): só os problemas que param a impressão (pouco papel ou toner não param)
ERROS_QUE_PARAM = [(0, 0x40, "sem papel"), (0, 0x10, "sem toner"), (0, 0x08, "tampa aberta"), (0, 0x04, "papel enroscado"),
                   (0, 0x02, "impressora fora de linha"), (1, 0x80, "bandeja de papel fora do lugar"),
                   (1, 0x40, "bandeja de saída fora do lugar"), (1, 0x20, "cartucho fora do lugar"),
                   (1, 0x08, "bandeja de saída cheia"), (1, 0x04, "bandeja de papel vazia")]


def estado_impressora(endereco, comunidade):
    """(situação, problemas): situação 3 em repouso, 4 imprimindo, 5 aquecendo, None se ela não informa;
    problemas é a lista do que a está impedindo de imprimir (papel enroscado, sem papel...)."""
    com = comunidade or "public"
    try:
        _, v = contador.consultar(endereco, OID_ESTADO_IMPRESSORA, com, timeout=1.0, tentativas=1)
    except contador.ErroContador:
        return None, []
    situacao = v if isinstance(v, int) else None
    problemas = []
    try:
        _, bits = contador.consultar(endereco, OID_ERROS_IMPRESSORA, com, timeout=1.0, tentativas=1, cru=True)
    except contador.ErroContador:
        bits = b""
    if isinstance(bits, bytes):
        for byte, mascara, texto in ERROS_QUE_PARAM:
            if len(bits) > byte and bits[byte] & mascara and texto not in problemas:
                problemas.append(texto)
    return situacao, problemas


def unidade(endereco, comunidade):
    try:
        _, v = contador.consultar(endereco, OID_UNIDADE, comunidade or "public", timeout=1.0, tentativas=1)
    except contador.ErroContador:
        return None
    return v if isinstance(v, int) else None


def esperado(total, paginas_sel, copias, frente_verso, unid):
    """Quanto o contador deve andar para a impressão inteira. Contador em folhas conta meia folha por lado."""
    if unid == UNIDADE_FOLHAS and frente_verso:
        return max(1, copias * ((paginas_sel + 1) // 2))
    return max(1, total)


def paginas_pelo_contador(delta, total, esp):
    """Converte o que o contador andou em páginas da impressão (nunca mais que o pedido)."""
    if delta <= 0:
        return 0
    if delta >= esp:
        return total
    return min(total, max(1, round(delta * total / esp)))
