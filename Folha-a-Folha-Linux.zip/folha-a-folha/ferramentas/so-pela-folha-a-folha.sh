#!/bin/sh
# Folha a Folha: faz o computador do sistema (Linux com CUPS) imprimir SÓ pela Folha a Folha.
#
#   sudo sh ferramentas/so-pela-folha-a-folha.sh             aplica
#   sudo sh ferramentas/so-pela-folha-a-folha.sh --so-ligar  só liga como serviço (passos 1 e 2), sem fechar
#                                                            as impressoras: bom para o estilo navegador, para
#                                                            a central da TI e antes da primeira configuração
#   sudo sh ferramentas/so-pela-folha-a-folha.sh --desfazer  libera as impressoras de novo
#
# O que faz:
#   1. Cria o usuário de sistema "folhaafolha" e copia o programa (com a pasta dados) para /opt/folha-a-folha.
#   2. Liga o Folha a Folha como serviço desse usuário, sozinho quando o computador liga.
#   3. As impressoras de verdade passam a aceitar trabalhos só desse usuário. Qualquer outro programa
#      que tentar imprimir direto nelas recebe "não autorizado".
#   4. Instala a impressora "Folha a Folha" neste computador e a deixa como padrão.
set -eu

USUARIO="${FOLHA_USUARIO:-folhaafolha}"
DESTINO="${FOLHA_DESTINO:-/opt/folha-a-folha}"
PORTA="${FOLHA_PORTA:-8080}"
FILA="Folha_a_Folha"
UNIDADE="${FOLHA_UNIDADE:-/etc/systemd/system/folha-a-folha.service}"
ORIGEM="$(cd "$(dirname "$0")/.." && pwd)"

falhar() { echo; echo "PAROU: $*"; exit 1; }
porta_aberta() { python3 -c "import socket,sys; s=socket.socket(); s.settimeout(1); sys.exit(0 if s.connect_ex(('127.0.0.1', $PORTA)) == 0 else 1)"; }
impressoras_reais() { lpstat -e 2>/dev/null | grep -viE '^folha.?a.?folha' || true; }
endereco_rede() { hostname -I 2>/dev/null | awk '{print $1}'; }
SO_LIGAR=0
[ "${1:-}" = "--so-ligar" ] && SO_LIGAR=1

[ "$(id -u)" -eq 0 ] || falhar "rode com sudo:  sudo sh $0"
command -v lpadmin >/dev/null 2>&1 || falhar "o CUPS não está instalado. Rode: sudo apt install cups"
command -v python3 >/dev/null 2>&1 || falhar "o Python 3 não está instalado. Rode: sudo apt install python3"

if [ "${1:-}" = "--desfazer" ]; then
  for p in $(impressoras_reais); do
    lpadmin -p "$p" -u allow:all
    echo "Liberada para qualquer programa: $p"
  done
  echo
  echo "Pronto. As impressoras voltam a aceitar impressão direta."
  echo "O Folha a Folha continua ligado. Para desligar o serviço: sudo systemctl disable --now folha-a-folha"
  exit 0
fi

REAIS="$(impressoras_reais)"
[ -n "$REAIS" ] || [ "$SO_LIGAR" -eq 1 ] || falhar "nenhuma impressora de verdade instalada neste computador. Instale-a em Configurações, Impressoras, e rode de novo."

echo "== 1. Usuário do sistema e cópia do programa"
if ! id -u "$USUARIO" >/dev/null 2>&1; then
  useradd --system --home-dir "$DESTINO" --shell /usr/sbin/nologin "$USUARIO"
  echo "Criado o usuário $USUARIO."
fi
# Escanear: o serviço roda como "$USUARIO", que precisa dos grupos do scanner para usar scanner USB
for grupo in scanner lp; do
  if getent group "$grupo" >/dev/null 2>&1 && ! id -nG "$USUARIO" | tr ' ' '\n' | grep -qx "$grupo"; then
    usermod -aG "$grupo" "$USUARIO" && echo "O usuário $USUARIO entrou no grupo $grupo (para escanear)."
  fi
done
if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet folha-a-folha 2>/dev/null; then
  systemctl stop folha-a-folha
fi
if porta_aberta; then
  falhar "o Folha a Folha está aberto em outra janela. Feche-a (Ctrl + C) e rode este comando de novo."
fi
if [ "$ORIGEM" != "$DESTINO" ]; then
  mkdir -p "$DESTINO"
  if [ -f "$DESTINO/dados/controle.db" ]; then
    # já instalado: atualiza só o programa e mantém os dados que estão em uso
    (cd "$ORIGEM" && tar --exclude=./dados --exclude=./__pycache__ -cf - .) | (cd "$DESTINO" && tar -xf -)
    echo "Programa atualizado em $DESTINO. Os dados de lá foram mantidos."
  else
    cp -a "$ORIGEM"/. "$DESTINO"/
    echo "Programa e dados copiados de $ORIGEM para $DESTINO."
  fi
fi
rm -rf "$DESTINO/__pycache__"
chown -R "$USUARIO:$USUARIO" "$DESTINO"

echo "== 2. Serviço que liga sozinho"
cat > "$UNIDADE" <<EOF
[Unit]
Description=Folha a Folha
After=network-online.target cups.service avahi-daemon.service
Wants=network-online.target

[Service]
User=$USUARIO
WorkingDirectory=$DESTINO
ExecStart=/usr/bin/python3 servidor.py --porta $PORTA
Restart=always

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now folha-a-folha
i=0
until porta_aberta; do
  i=$((i + 1))
  [ $i -le 40 ] || falhar "o serviço não respondeu. Veja o motivo com: sudo journalctl -u folha-a-folha -n 30"
  sleep 0.5
done
echo "Folha a Folha ligado como serviço (usuário $USUARIO)."
IP="$(endereco_rede)"
if [ "$SO_LIGAR" -eq 1 ]; then
  cat <<EOF

PRONTO. O Folha a Folha liga sozinho junto com este computador.
- Nos outros computadores e celulares da rede, abra:  http://${IP:-ENDERECO-DESTE-COMPUTADOR}:$PORTA
- Neste computador:  http://localhost:$PORTA
- O programa agora fica em $DESTINO.
- Para ver se está rodando:  systemctl status folha-a-folha
- Para fechar as impressoras (estilo impressora), rode depois:  sudo sh $DESTINO/ferramentas/so-pela-folha-a-folha.sh
EOF
  exit 0
fi
MODO="$(python3 -c "import json,urllib.request; print(json.load(urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:$PORTA/api/inicio', timeout=5)).get('modo', ''))" 2>/dev/null || true)"
if [ "$MODO" != "impressora" ]; then
  falhar "o Folha a Folha não está no estilo \"como impressora\". Abra o app (http://localhost:$PORTA), configure ou vá em Gestão, Impressoras, Estilo de instalação, escolha \"Como impressora\" e rode este comando de novo."
fi

echo "== 3. Impressoras de verdade só aceitam o Folha a Folha"
for p in $REAIS; do
  lpadmin -p "$p" -u "allow:$USUARIO"
  lpadmin -p "$p" -o printer-is-shared=false
  echo "Fechada: $p"
done

echo "== 4. Impressora Folha a Folha neste computador"
if ! lpstat -v "$FILA" >/dev/null 2>&1; then
  lpadmin -p "$FILA" -E -v "ipp://localhost:$PORTA/ipp/print" -m everywhere -D "Folha a Folha" \
    || falhar "não deu para instalar a impressora Folha a Folha. Confira em Gestão, Impressoras se o estilo é \"como impressora\"."
fi
lpadmin -d "$FILA"
echo "Instalada e deixada como padrão: Folha a Folha"

cat <<EOF

PRONTO.
- Imprima de qualquer programa escolhendo "Folha a Folha" (já é a padrão) e libere no app.
- Se alguém escolher a impressora de verdade, o trabalho é recusado ("não autorizado").
- O app continua em http://localhost:$PORTA e, na rede, em http://${IP:-ENDERECO-DESTE-COMPUTADOR}:$PORTA
- O programa agora fica em $DESTINO. A janela do Terminal não é mais necessária.
- Para ver se o serviço está rodando:  systemctl status folha-a-folha
- Para desfazer:  sudo sh $DESTINO/ferramentas/so-pela-folha-a-folha.sh --desfazer
EOF
if [ "$ORIGEM" != "$DESTINO" ]; then
  echo "- Depois de conferir que está tudo certo, você pode apagar a cópia antiga em $ORIGEM (não apague $DESTINO)."
fi
