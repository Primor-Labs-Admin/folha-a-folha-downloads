"""Digitalização usando os controladores de scanner já instalados no computador.

Windows: WIA (Windows Image Acquisition), por meio de PowerShell + COM.
Linux/macOS: SANE, por meio do utilitário scanimage.

A descoberta é independente das filas de impressão: uma multifuncional pode continuar
aparecendo aqui mesmo quando sua impressora está oculta/desativada para impressão na rede.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

WINDOWS = os.name == "nt"
LIMITE_PAGINAS = 100
LIMITE_DPI = 1200


class ErroDigitalizacao(Exception):
    """Erro que pode ser mostrado com segurança na tela de digitalização."""


class Paginas(list):
    """Lista das páginas digitalizadas. `aviso` diz se o scanner parou antes do fim (papel atolado etc.)."""
    aviso = ""


# A procura de scanners (scanimage -L, WIA) pode levar de 5 a 30 s, sobretudo com scanners de rede.
# Guarda a última lista e as opções de cada scanner por alguns minutos: escolher as opções e digitalizar
# não repetem a procura inteira. "Atualizar lista" (listar) sempre procura de novo.
_CACHE_SEG = 300
_cache = {"lista": None, "quando": 0.0, "opcoes": {}}


def _lista_em_cache():
    if _cache["lista"] is not None and time.time() - _cache["quando"] < _CACHE_SEG:
        return _cache["lista"]
    return None


def _guardar_lista(lista):
    _cache["lista"], _cache["quando"] = lista, time.time()
    _cache["opcoes"] = {k: v for k, v in _cache["opcoes"].items() if any(d.get("id") == k for d in lista)}


def _sem_janela():
    return {"creationflags": 0x08000000} if WINDOWS else {}


def _rodar(cmd, timeout=30, env=None):
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, env=env, **_sem_janela()
        )
    except FileNotFoundError:
        raise ErroDigitalizacao("O recurso de digitalização nativo não foi encontrado neste computador.")
    except subprocess.TimeoutExpired:
        raise ErroDigitalizacao("O scanner demorou demais para responder. Confira se está ligado e conectado.")
    except OSError as exc:
        raise ErroDigitalizacao(f"Não foi possível iniciar o serviço de digitalização: {exc}")


def _script_powershell(roteiro, argumentos=(), timeout=40):
    """Executa um roteiro WIA em STA, necessário para os objetos COM de digitalização."""
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        raise ErroDigitalizacao("O Windows PowerShell não foi encontrado. Verifique a instalação do Windows.")
    with tempfile.NamedTemporaryFile("w", suffix=".ps1", encoding="utf-8-sig", delete=False) as f:
        f.write(roteiro)
        caminho = f.name
    try:
        r = _rodar([powershell, "-NoLogo", "-NoProfile", "-NonInteractive", "-STA",
                    "-ExecutionPolicy", "Bypass", "-File", caminho, *map(str, argumentos)], timeout)
        if r.returncode != 0:
            detalhe = (r.stderr or r.stdout or "").strip()
            raise ErroDigitalizacao(_mensagem_wia(detalhe))
        return r.stdout.strip()
    finally:
        try:
            os.unlink(caminho)
        except OSError:
            pass


def _mensagem_wia(detalhe):
    t = (detalhe or "").replace("\r", " ").replace("\n", " ").strip()
    if not t:
        return "O driver do scanner não concluiu a digitalização. Confira a conexão e o papel."
    baixo = t.lower()
    if "80210003" in baixo or "paper empty" in baixo or "papel" in baixo and ("vazio" in baixo or "acabou" in baixo):
        return "O alimentador está vazio. Coloque as folhas e tente novamente."
    if "80210002" in baixo or "paper jam" in baixo or "atol" in baixo:
        return "O scanner informou papel atolado. Retire o papel e tente novamente."
    if "80210006" in baixo or "device busy" in baixo:
        return "O scanner está ocupado. Feche o outro programa que está usando o dispositivo e tente novamente."
    if "cancel" in baixo:
        return "A digitalização foi cancelada pelo scanner."
    return ("O driver do scanner informou: " + t[-700:])[:760]


_WIA_LISTAR = r'''$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
try {
  $manager = New-Object -ComObject WIA.DeviceManager
  $lista = @()
  foreach ($d in $manager.DeviceInfos) {
    if ([int]$d.Type -ne 1) { continue }
    $nome = ''
    foreach ($p in $d.Properties) { if ($p.PropertyID -eq 7) { $nome = [string]$p.Value; break } }
    if (-not $nome) { $nome = 'Scanner WIA' }
    $id = [string]$d.DeviceID
    $origens = @(@{valor='auto'; nome='Padrão do driver'})
    $duplex = $false
    $conectado = $null
    $item = $null
    try {
      $conectado = $d.Connect()
      $capacidades = 0
      $valoresSelecao = @()
      foreach ($p in $conectado.Properties) {
        if ($p.PropertyID -eq 3086) { try { $capacidades = [int]$p.Value } catch { } }
        if ($p.PropertyID -eq 3088) {
          try { $valoresSelecao = @($p.SubTypeValues | ForEach-Object { [int]$_ }) } catch { }
        }
      }
      # WIA_DPS_DOCUMENT_HANDLING_CAPABILITIES: FEED=1, FLAT=2, DUP=4.
      # Se o driver omitir a propriedade de capacidades, consulta os valores permitidos
      # da propriedade de seleção do alimentador/mesa.
      $temFeed = (($capacidades -band 1) -ne 0) -or ($valoresSelecao -contains 1) -or ($valoresSelecao -contains 5) -or ($valoresSelecao -contains 9) -or ($valoresSelecao -contains 13) -or ($valoresSelecao -contains 33)
      $temFlat = (($capacidades -band 2) -ne 0) -or ($valoresSelecao -contains 2)
      $duplex = (($capacidades -band 4) -ne 0) -or ($valoresSelecao -contains 5) -or ($valoresSelecao -contains 13)
      if ($temFlat) { $origens += @{valor='flatbed'; nome='Mesa de vidro'} }
      if ($temFeed) { $origens += @{valor='adf'; nome='Alimentador (frente)'} }
      if ($temFeed -and $duplex) { $origens += @{valor='duplex'; nome='Alimentador (frente e verso)'} }
    } catch { }
    $dpis = @()
    $temDpi = $false
    $modos = @()
    $temBrilho = $false; $temContraste = $false
    $brilhoRange = $null; $contrasteRange = $null
    $tamanhos = @('auto')
    $formatos = @('bmp')
    try {
      $item = $conectado.Items.Item(1)
      foreach ($p in $item.Properties) {
        if ($p.PropertyID -eq 6146) {
          try {
            $intencoes = @($p.SubTypeValues | ForEach-Object { [int]$_ })
            if ($intencoes.Count -eq 0) { $intencoes = @([int]$p.Value) }
            if ($intencoes -contains 1) { $modos += 'Color' }
            if ($intencoes -contains 2) { $modos += 'Gray' }
            if ($intencoes -contains 4) { $modos += 'Lineart' }
          } catch { }
        }
        if ($p.PropertyID -eq 6154) {
          try {
            if ([int]$p.SubType -eq 1) {
              $temBrilho = $true
              $brilhoRange = @{min=[double]$p.SubTypeMin; max=[double]$p.SubTypeMax; padrao=[double]$p.Value; passo=[double]$p.SubTypeStep}
            }
          } catch { }
        }
        if ($p.PropertyID -eq 6155) {
          try {
            if ([int]$p.SubType -eq 1) {
              $temContraste = $true
              $contrasteRange = @{min=[double]$p.SubTypeMin; max=[double]$p.SubTypeMax; padrao=[double]$p.Value; passo=[double]$p.SubTypeStep}
            }
          } catch { }
        }
        if ($p.PropertyID -eq 3097) {
          try {
            foreach ($v in $p.SubTypeValues) {
              switch ([int]$v) { 0 { $tamanhos += 'A4' } 1 { $tamanhos += 'Letter' } 3 { $tamanhos += 'Legal' } 10 { $tamanhos += 'A3' } 11 { $tamanhos += 'A5' } }
            }
          } catch { }
        }
        if ($p.PropertyID -eq 6147) {
          try {
            $temDpi = $true
            if ([int]$p.SubType -eq 2) {
              $permitidos = @($p.SubTypeValues | ForEach-Object { [int]$_ })
              if ($permitidos.Count -gt 0) { $dpis = @($permitidos | Where-Object { $_ -ge 30 -and $_ -le 1200 } | Sort-Object -Unique) }
            } elseif ([int]$p.SubType -eq 1) {
              $min = [int]$p.SubTypeMin; $max = [int]$p.SubTypeMax; $passo = [int]$p.SubTypeStep
              if ($passo -lt 1) { $passo = 1 }
              $dpis = @(75,100,150,200,300,600,1200 | Where-Object { $_ -ge $min -and $_ -le $max -and (($_ - $min) % $passo) -eq 0 })
              if ($dpis.Count -eq 0 -and $max -ge $min) {
                $alvo = [Math]::Max($min, [Math]::Min($max, 300))
                $ajustado = $min + ([Math]::Round(($alvo - $min) / $passo) * $passo)
                $dpis = @([int][Math]::Max($min, [Math]::Min($max, $ajustado)))
              }
            }
          } catch { }
        }
        if ($p.PropertyID -eq 4106) {
          try {
            $formatos = @()
            foreach ($f in $p.SubTypeValues) {
              $g = ([guid]([string]$f)).ToString('B').ToLower()
              switch ($g) {
                '{b96b3cab-0728-11d3-9d7b-0000f81ef32e}' { $formatos += 'bmp' }
                '{b96b3cae-0728-11d3-9d7b-0000f81ef32e}' { $formatos += 'jpg' }
                '{b96b3caf-0728-11d3-9d7b-0000f81ef32e}' { $formatos += 'png' }
                '{b96b3cb1-0728-11d3-9d7b-0000f81ef32e}' { $formatos += 'tif' }
              }
            }
            if ($formatos.Count -eq 0) { $formatos = @('bmp') }
          } catch { }
        }
      }
    } catch { }
    if (-not $temDpi -or $dpis.Count -eq 0) { $dpis = @(0) }
    if ($modos.Count -eq 0) { $modos = @('Default') }
    if ($item) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($item) }
    if ($conectado) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($conectado) }
    $lista += @{id=$id; nome=$nome; fabricante='Driver WIA do Windows'; origens=$origens;
                modos=@($modos | Select-Object -Unique); dpi=@($dpis); max_dpi=($dpis | Measure-Object -Maximum).Maximum;
                formatos=@($formatos | Select-Object -Unique); duplex=$duplex; brilho=$temBrilho; contraste=$temContraste;
                brilho_range=$brilhoRange; contraste_range=$contrasteRange; tamanhos=@($tamanhos | Select-Object -Unique)}
  }
  ConvertTo-Json -InputObject @($lista) -Depth 5 -Compress
} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 2 }
'''

_WIA_CONVERTER_PNG = r'''param([string]$FilesJson)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$ErrorActionPreference = 'Stop'
try {
  Add-Type -AssemblyName System.Drawing
  $arquivos = @()
  foreach ($caminho in (ConvertFrom-Json -InputObject $FilesJson)) {
    $imagem = $null; $bitmap = $null
    try {
      $imagem = [System.Drawing.Image]::FromFile([string]$caminho)
      $bitmap = [System.Drawing.Bitmap]::new($imagem)
      $destino = [System.IO.Path]::ChangeExtension([string]$caminho, '.png')
      $bitmap.Save($destino, [System.Drawing.Imaging.ImageFormat]::Png)
      $arquivos += $destino
    } finally {
      if ($bitmap) { $bitmap.Dispose() }
      if ($imagem) { $imagem.Dispose() }
    }
  }
  ConvertTo-Json -InputObject @{arquivos=@($arquivos)} -Depth 3 -Compress
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 2
}
'''


_WIA_SCAN = r'''param(
  [string]$DeviceId,
  [string]$OutDir,
  [string]$Format,
  [int]$Dpi,
  [string]$Mode,
  [string]$Source,
  [string]$Paper,
  [int]$Brightness,
  [int]$Contrast,
  [int]$MaxPages
)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$ErrorActionPreference = 'Stop'
function Set-WiaProperty($object, [int]$propertyId, $value) {
  foreach ($p in $object.Properties) {
    if ([int]$p.PropertyID -eq $propertyId) {
      try { $p.Value = $value; return $true } catch { return $false }
    }
  }
  return $false
}
try {
  $manager = New-Object -ComObject WIA.DeviceManager
  $info = $null
  foreach ($d in $manager.DeviceInfos) { if ([string]$d.DeviceID -eq $DeviceId) { $info = $d; break } }
  if ($null -eq $info) { throw 'O scanner escolhido não está mais disponível.' }
  $device = $info.Connect()

  # Seleciona a origem com os sinalizadores que o próprio driver aceita.
  $handling = 0
  if ($Source -ne 'auto') {
    foreach ($p in $device.Properties) {
      if ([int]$p.PropertyID -eq 3088) {
        $permitidos = @()
        try { $permitidos = @($p.SubTypeValues | ForEach-Object { [int]$_ }) } catch { }
        $candidatos = switch ($Source) {
          'flatbed' { @(2) }
          'adf' { @(33,1) }
          'duplex' { @(13,5) }
        }
        $selecionado = $false
        foreach ($c in $candidatos) {
          if ($permitidos.Count -gt 0 -and $permitidos -notcontains $c) { continue }
          try { $p.Value = $c; $handling = $c; $selecionado = $true; break } catch { }
        }
        if (-not $selecionado) { throw 'O driver não aceita a origem de papel selecionada.' }
        break
      }
    }
    if ($handling -eq 0) { throw 'O driver não oferece a origem de papel selecionada.' }
  }

  $item = $device.Items.Item(1)
  if ($Dpi -gt 0) {
    [void](Set-WiaProperty $item 6147 $Dpi) # WIA_IPS_XRES
    [void](Set-WiaProperty $item 6148 $Dpi) # WIA_IPS_YRES
  }
  if ($Mode -ne 'Default') {
    $intent = switch ($Mode) { 'Color' { 1 } 'Gray' { 2 } default { 4 } }
    [void](Set-WiaProperty $item 6146 $intent) # WIA_IPS_CUR_INTENT
  }
  [void](Set-WiaProperty $item 6154 $Brightness) # WIA_IPS_BRIGHTNESS
  [void](Set-WiaProperty $item 6155 $Contrast) # WIA_IPS_CONTRAST
  if ($Source -eq 'adf' -or $Source -eq 'duplex') { [void](Set-WiaProperty $item 3096 $MaxPages) } # WIA_IPS_PAGES
  $page = switch ($Paper) { 'Letter' { 1 } 'Legal' { 3 } 'A4' { 0 } 'A3' { 10 } 'A5' { 11 } default { -1 } }
  if ($page -ge 0) { [void](Set-WiaProperty $item 3097 $page) }

  $formatIds = @{
    'bmp' = '{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}'
    'jpg' = '{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}'
    'png' = '{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}'
    'tif' = '{B96B3CB1-0728-11D3-9D7B-0000F81EF32E}'
  }
  $guid = $formatIds[$Format]
  if (-not $guid) { throw 'Formato de imagem não compatível com WIA.' }
  $arquivos = @()
  for ($i = 1; $i -le $MaxPages; $i++) {
    try {
      $imagem = $item.Transfer($guid)
      $destino = Join-Path $OutDir ('pagina-{0:D3}.{1}' -f $i, $Format)
      $imagem.SaveFile($destino)
      $arquivos += $destino
    } catch {
      $codigo = [long]$_.Exception.HResult
      $mensagem = [string]$_.Exception.Message
      # Apenas o código WIA_ERROR_PAPER_EMPTY encerra normalmente um lote.
      if ($i -gt 1 -and ($codigo -eq -2145320957 -or $mensagem -match 'paper empty|document feeder out of documents|no documents|sem papel|sem documentos')) { break }
      throw
    }
  }
  if ($arquivos.Count -eq 0) { throw 'O scanner não entregou nenhuma página. Verifique o papel e a origem.' }
  @{arquivos=@($arquivos); paginas=$arquivos.Count} | ConvertTo-Json -Depth 3 -Compress
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 2
} finally {
  if ($item) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($item) }
  if ($device) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($device) }
  if ($manager) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($manager) }
}
'''


def _normalizar_lista_json(txt):
    if not txt:
        return []
    try:
        dados = json.loads(txt)
    except (ValueError, TypeError):
        return []
    if isinstance(dados, dict):
        return [dados]
    return dados if isinstance(dados, list) else []


def _listar_windows():
    txt = _script_powershell(_WIA_LISTAR, timeout=45)
    return [d for d in _normalizar_lista_json(txt) if isinstance(d, dict) and d.get("id")]


def _scanimage():
    return shutil.which("scanimage")


def _listar_sane():
    prog = _scanimage()
    if not prog:
        return [], "O SANE não está instalado. No Linux, instale sane-utils e o backend do fabricante (ou sane-airscan para scanners de rede)."
    env = os.environ.copy()
    env.setdefault("LC_ALL", "C.UTF-8")
    r = _rodar([prog, "-L"], timeout=35, env=env)
    texto = (r.stdout or "") + "\n" + (r.stderr or "")
    encontrados = []
    for linha in texto.splitlines():
        m = re.search(r"device\s+['\"`](.*?)['\"`]\s+is\s+(.+)$", linha.strip(), re.I)
        if not m:
            continue
        dispositivo, descricao = m.group(1), m.group(2).strip()
        descricao = re.sub(r"^(?:a|an)\s+", "", descricao, flags=re.I)  # "is a CANON Canon PIXMA" vira "CANON Canon PIXMA"
        encontrados.append({
            "id": dispositivo,
            "nome": descricao,
            "fabricante": "SANE / driver instalado",
            "origens": [], "modos": ["Color", "Gray", "Lineart"],
            "dpi": [75, 100, 150, 200, 300, 600, 1200],
            "duplex": False, "brilho": False, "contraste": False,
            "tamanhos": ["auto", "A4", "A5", "Letter", "Legal", "A3"],
        })
    if not encontrados:
        aviso = "Nenhum scanner SANE foi encontrado. Confira o cabo, o Wi-Fi e se o driver de digitalização está instalado."
        if r.returncode and not texto.strip():
            aviso += " O comando scanimage não conseguiu consultar o serviço SANE."
        return [], aviso
    return encontrados, ""


def listar():
    """Lista scanners pelo serviço nativo, sem consultar a relação de impressoras."""
    if WINDOWS:
        try:
            dispositivos = _listar_windows()
            _guardar_lista(dispositivos)
            return {"disponivel": True, "plataforma": "Windows", "driver": "WIA",
                    "scanners": dispositivos, "aviso": "" if dispositivos else
                    "O Windows não encontrou scanners WIA. Instale o driver de digitalização do fabricante; impressoras instaladas sem componente WIA podem não aparecer."}
        except ErroDigitalizacao as exc:
            return {"disponivel": False, "plataforma": "Windows", "driver": "WIA", "scanners": [], "aviso": str(exc)}
    try:
        dispositivos, aviso = _listar_sane()
        _guardar_lista(dispositivos)
        return {"disponivel": bool(_scanimage()), "plataforma": "macOS" if sys.platform == "darwin" else "Linux",
                "driver": "SANE", "scanners": dispositivos, "aviso": aviso}
    except ErroDigitalizacao as exc:
        return {"disponivel": False, "plataforma": "Linux", "driver": "SANE", "scanners": [], "aviso": str(exc)}


def _tamanhos_sane(max_largura, max_altura):
    """Exibe somente papéis que cabem na área máxima anunciada pelo scanner (mm)."""
    if max_largura is None or max_altura is None:
        return ["auto"]
    a, b = max(max_largura, max_altura), min(max_largura, max_altura)
    tamanhos = ["auto"]
    # Tamanhos ISO e norte-americanos são avaliados em qualquer orientação.
    for nome, largura, altura in (
        ("A5", 148.0, 210.0), ("A4", 210.0, 297.0),
        ("Letter", 215.9, 279.4), ("Legal", 215.9, 355.6),
        ("A3", 297.0, 420.0),
    ):
        if b + 0.2 >= min(largura, altura) and a + 0.2 >= max(largura, altura):
            tamanhos.append(nome)
    return tamanhos


def _opcoes_sane(dispositivo):
    prog = _scanimage()
    env = os.environ.copy()
    env.setdefault("LC_ALL", "C.UTF-8")
    r = _rodar([prog, "-A", "-d", dispositivo], timeout=30, env=env)
    texto = (r.stdout or "") + "\n" + (r.stderr or "")
    if r.returncode != 0 and not re.search(r"^\s*--[a-zA-Z0-9_-]+", r.stdout or "", re.M):
        raise ErroDigitalizacao(_mensagem_sane(r.stderr or r.stdout, "Não deu para ler as opções deste scanner."))
    nomes = set()
    fontes = []
    modos = []
    adf_mode_values = []
    duplex_values = []
    sane_modes = {}
    dpis = []
    brilho_range = None
    contraste_range = None
    max_dpi = 1200
    max_largura = max_altura = None
    # o scanimage mostra a área de digitalização com os nomes curtos -l -t -x -y (tl-x, tl-y, br-x, br-y)
    curtos = {"l": "tl-x", "t": "tl-y", "x": "br-x", "y": "br-y"}
    for linha in texto.splitlines():
        m = re.match(r"\s*--([a-zA-Z0-9_-]+)(?:\s+(.*))?$", linha)
        c = None if m else re.match(r"\s*-([ltxy])\s+(\S.*)$", linha)
        if not m and not c:
            continue
        nome, especificacao = (m.group(1), (m.group(2) or "").strip()) if m else (curtos[c.group(1)], c.group(2).strip())
        nomes.add(nome)
        if nome == "source":
            op = re.sub(r"\s+\[[^\]]*\]\s*$", "", especificacao)
            fontes = [p.strip() for p in op.split("|") if p.strip()]
        elif nome == "mode":
            op = re.sub(r"\s+\[[^\]]*\]\s*$", "", especificacao)
            modos = [p.strip() for p in op.split("|") if p.strip()]
            for modo_driver in modos:
                baixo = modo_driver.casefold()
                if any(x in baixo for x in ("lineart", "line art", "black and white", "b&w", "halftone")):
                    sane_modes.setdefault("Lineart", modo_driver)
                elif any(x in baixo for x in ("gray", "grey", "grayscale", "greyscale", "monochrome")):
                    sane_modes.setdefault("Gray", modo_driver)
                elif any(x in baixo for x in ("color", "colour", "rgb")):
                    sane_modes.setdefault("Color", modo_driver)
        elif nome == "adf-mode":
            op = re.sub(r"\s+\[[^\]]*\]\s*$", "", especificacao)
            adf_mode_values = [p.strip() for p in op.split("|") if p.strip()]
        elif nome == "duplex":
            op = re.sub(r"\s+\[[^\]]*\]\s*$", "", especificacao)
            duplex_values = [p.strip() for p in op.split("|") if p.strip()]
        elif nome in ("brightness", "contrast"):
            faixa = re.search(r"(-?\d+(?:\.\d+)?)\s*\.\.\s*(-?\d+(?:\.\d+)?)", especificacao)
            if faixa:
                padrao_m = re.search(r"\[\s*(-?\d+(?:\.\d+)?)\s*\]\s*$", especificacao)
                passo_m = re.search(r"steps?\s+of\s+(\d+(?:\.\d+)?)", especificacao, re.I)
                intervalo = {"min": float(faixa.group(1)), "max": float(faixa.group(2)),
                             "padrao": float(padrao_m.group(1)) if padrao_m else 0.0,
                             "passo": float(passo_m.group(1)) if passo_m else 1.0}
                if nome == "brightness": brilho_range = intervalo
                else: contraste_range = intervalo
        elif nome in ("page-width", "br-x"):
            faixa_pagina = re.search(r"(-?\d+(?:\.\d+)?)\s*\.\.\s*(-?\d+(?:\.\d+)?)", especificacao)
            if faixa_pagina:
                max_largura = max(max_largura or 0, float(faixa_pagina.group(2)))
        elif nome in ("page-height", "br-y"):
            faixa_pagina = re.search(r"(-?\d+(?:\.\d+)?)\s*\.\.\s*(-?\d+(?:\.\d+)?)", especificacao)
            if faixa_pagina:
                max_altura = max(max_altura or 0, float(faixa_pagina.group(2)))
        elif nome == "resolution":
            spec = re.sub(r"\s+\[[^\]]*\]\s*$", "", especificacao).lower()
            faixa = re.search(r"(\d+)\s*\.\.\s*(\d+)", spec)
            if faixa:
                minimo, maximo = int(faixa.group(1)), int(faixa.group(2))
                passo_m = re.search(r"steps?\s+of\s+(\d+)", spec)
                passo = max(1, int(passo_m.group(1))) if passo_m else 1
                max_dpi = min(LIMITE_DPI, maximo)
                dpis = [x for x in (75,100,150,200,300,600,1200) if minimo <= x <= max_dpi and (x-minimo) % passo == 0]
                if not dpis and minimo <= max_dpi:
                    alvo = max(minimo, min(max_dpi, 300))
                    dpis = [minimo + round((alvo - minimo) / passo) * passo]
            else:
                valores = [int(x) for x in re.findall(r"\d+", spec)]
                dpis = sorted({x for x in valores if 30 <= x <= LIMITE_DPI})
                if dpis:
                    max_dpi = max(dpis)
    # A interface usa nomes estáveis; o nome exato da opção do driver fica separado.
    auto_fonte = next((s for s in fontes if s.casefold() in ("auto", "automatic", "automatic document feeder")), None)
    origens = [{"valor": "auto", "nome": "Detecção automática" if auto_fonte else "Padrão do driver"}]
    if any("flatbed" in s.lower() or "mesa" in s.lower() for s in fontes):
        origens.append({"valor": "flatbed", "nome": "Mesa de vidro"})
    if any(("adf" in s.lower() or "feeder" in s.lower() or "aliment" in s.lower()) and
           "duplex" not in s.lower() for s in fontes):
        origens.append({"valor": "adf", "nome": "Alimentador (frente)"})
    fonte_adf = any(("adf" in s.lower() or "feeder" in s.lower() or "aliment" in s.lower()) and "duplex" not in s.lower() for s in fontes)
    duplex_separado = any("duplex" in v.lower() for v in adf_mode_values) or any("yes" in v.lower() or "true" in v.lower() or "on" in v.lower() for v in duplex_values)
    tem_duplex = any("duplex" in s.lower() for s in fontes) or duplex_separado or "duplex" in nomes
    if tem_duplex:
        origens.append({"valor": "duplex", "nome": "Alimentador (frente e verso)"})
    return {
        "opcoes": sorted(nomes), "origens": origens, "sane_sources": fontes, "sane_auto_source": auto_fonte,
        "modos": (list(sane_modes) if sane_modes else (["Color", "Gray", "Lineart"] if "mode" in nomes else ["Default"])),
        "sane_modes": sane_modes, "formatos": ["jpg", "png", "tif"],
        "sane_adf_mode": next((v for v in adf_mode_values if "duplex" in v.lower()), None),
        "sane_duplex_option": "duplex" in nomes,
        "sane_duplex_value": next((v for v in duplex_values if v.lower() in ("yes", "true", "on", "1")), None),
        "dpi": (dpis if dpis else ([300] if "resolution" in nomes else [0])), "max_dpi": max_dpi, "duplex": tem_duplex,
        "brilho": brilho_range is not None, "contraste": contraste_range is not None,
        "brilho_range": brilho_range, "contraste_range": contraste_range,
        "tamanhos": _tamanhos_sane(max_largura, max_altura),
    }


def _achar(dispositivo_id):
    """O scanner na lista guardada; se não estiver lá (ou a lista for velha), procura de novo uma vez."""
    lista = _lista_em_cache()
    d = next((x for x in lista or [] if x.get("id") == dispositivo_id), None)
    if d is None:
        lista = _listar_windows() if WINDOWS else _listar_sane()[0]
        _guardar_lista(lista)
        d = next((x for x in lista if x.get("id") == dispositivo_id), None)
    if d is None:
        raise ErroDigitalizacao("O scanner escolhido não está mais disponível. Atualize a lista.")
    return d


def _opcoes_sane_guardadas(dispositivo_id, renovar=False):
    o = None if renovar else _cache["opcoes"].get(dispositivo_id)
    if o is None or time.time() - o[0] >= _CACHE_SEG:
        o = (time.time(), _opcoes_sane(dispositivo_id))
        _cache["opcoes"][dispositivo_id] = o
    return o[1]


def opcoes(dispositivo_id):
    """Retorna os recursos que o controlador desse scanner realmente publica."""
    d = _achar(dispositivo_id)
    if WINDOWS:
        # As propriedades WIA variam por driver. Os valores são tentados apenas quando
        # o controlador informa que aceita a propriedade; o scanner mantém seus padrões nos demais casos.
        return {k: d.get(k) for k in ("origens", "modos", "dpi", "max_dpi", "formatos", "duplex", "brilho", "contraste", "brilho_range", "contraste_range", "tamanhos")}
    return _opcoes_sane_guardadas(dispositivo_id, renovar=True)


def _mensagem_sane(detalhe, padrao):
    """Tradução das mensagens mais comuns do scanimage."""
    t = (detalhe or "").strip()
    baixo = t.lower()
    if "out of documents" in baixo or "paper empty" in baixo or "no documents" in baixo:
        return "O alimentador está vazio. Coloque as folhas e tente novamente."
    if "jammed" in baixo or "paper jam" in baixo:
        return "O scanner informou papel atolado. Retire o papel e tente novamente."
    if "cover open" in baixo:
        return "A tampa do scanner está aberta. Feche-a e tente novamente."
    if "device busy" in baixo:
        return "O scanner está sendo usado por outro programa. Feche esse programa e tente novamente."
    if "access denied" in baixo or "permission" in baixo:
        return "O usuário que executa o Folha a Folha não tem permissão para acessar o scanner."
    return (t or padrao)[-700:]


def _fonte_sane(opcoes_driver, origem, duplex):
    nomes = [str(x) for x in (opcoes_driver.get("sane_sources") or [])]
    if origem == "auto":
        return opcoes_driver.get("sane_auto_source")
    if origem == "flatbed":
        escolha = next((x for x in nomes if "flatbed" in x.lower() or "mesa" in x.lower()), None)
    elif origem == "duplex" or duplex:
        escolha = next((x for x in nomes if "duplex" in x.lower()), None)
        if not escolha and (opcoes_driver.get("sane_adf_mode") or opcoes_driver.get("sane_duplex_option")):
            escolha = next((x for x in nomes if "adf" in x.lower() or "feeder" in x.lower() or "aliment" in x.lower()), None)
            if not escolha and "source" not in (opcoes_driver.get("opcoes") or []):
                return None
        if not escolha:
            raise ErroDigitalizacao("Este driver não informa alimentador frente e verso. Escolha frente ou instale o backend completo do fabricante.")
    else:
        escolha = next((x for x in nomes if ("adf" in x.lower() or "feeder" in x.lower() or "aliment" in x.lower())
                        and "duplex" not in x.lower()), None)
    if not escolha:
        raise ErroDigitalizacao("O driver não oferece essa origem de papel. Atualize a lista e escolha uma origem compatível.")
    return escolha


def _mapear_ajuste(valor, faixa, padrao=0):
    """Converte um controle normalizado (-100..100) para o intervalo do driver."""
    if not faixa:
        return int(valor)
    minimo = float(faixa.get("min", -100))
    maximo = float(faixa.get("max", 100))
    centro = float(faixa.get("padrao", padrao))
    passo = abs(float(faixa.get("passo", 1) or 1))
    valor = max(-100, min(100, float(valor)))
    if valor < 0:
        real = centro + (centro - minimo) * (valor / 100.0)
    else:
        real = centro + (maximo - centro) * (valor / 100.0)
    if passo > 0:
        real = minimo + round((real - minimo) / passo) * passo
    real = max(minimo, min(maximo, real))
    return int(round(real))


def _validar_parametros(config):
    origem = str(config.get("origem") or "auto")
    if origem not in ("auto", "flatbed", "adf", "duplex"):
        raise ErroDigitalizacao("Escolha uma origem de digitalização válida.")
    modo = str(config.get("modo") or "Color")
    if modo not in ("Color", "Gray", "Lineart", "Default"):
        raise ErroDigitalizacao("Escolha um modo de cor válido.")
    try:
        valor_dpi = config.get("dpi", 300)
        dpi = int(300 if valor_dpi in (None, "") else valor_dpi)
    except (ValueError, TypeError):
        raise ErroDigitalizacao("Informe uma resolução válida.")
    if dpi != 0 and not 30 <= dpi <= LIMITE_DPI:
        raise ErroDigitalizacao("Escolha uma resolução entre 30 e 1.200 DPI.")
    formato = str(config.get("formato") or "pdf").lower()
    if formato not in ("pdf", "bmp", "jpg", "png", "tif"):
        raise ErroDigitalizacao("Escolha PDF, BMP, JPG, PNG ou TIFF.")
    papel = str(config.get("papel") or "auto")
    if papel not in ("auto", "A4", "A5", "Letter", "Legal", "A3"):
        raise ErroDigitalizacao("Escolha um tamanho de papel válido.")
    try:
        paginas = int(config.get("paginas") or 1)
    except (ValueError, TypeError):
        raise ErroDigitalizacao("Informe uma quantidade válida de páginas.")
    paginas = max(1, min(LIMITE_PAGINAS, paginas))
    try:
        brilho = max(-100, min(100, int(config.get("brilho") or 0)))
        contraste = max(-100, min(100, int(config.get("contraste") or 0)))
    except (ValueError, TypeError):
        raise ErroDigitalizacao("Brilho e contraste devem ser números entre -100 e 100.")
    return {"origem": origem, "modo": modo, "dpi": dpi, "formato": formato, "papel": papel,
            "paginas": paginas, "brilho": brilho, "contraste": contraste,
            "duplex": origem == "duplex" or bool(config.get("duplex"))}


def digitalizar(dispositivo_id, config, pasta_destino):
    """Digitaliza no próprio computador do Folha a Folha e devolve os caminhos das páginas."""
    c = _validar_parametros(config or {})
    pasta = Path(pasta_destino).resolve()
    pasta.mkdir(parents=True, exist_ok=True)
    extensao_fonte = "png" if c["formato"] == "pdf" else c["formato"]

    if WINDOWS:
        d = _achar(dispositivo_id)
        # Se a origem foi indicada manualmente, confirma se o driver WIA oferece esse recurso.
        if c["origem"] != "auto":
            fontes = [x.get("valor") for x in (d.get("origens") or [])]
            if c["origem"] not in fontes:
                raise ErroDigitalizacao("O driver WIA não publicou essa origem de papel para este scanner.")
        formatos_wia = [str(x).lower() for x in (d.get("formatos") or ["bmp"])]
        if c["formato"] == "pdf":
            extensao_fonte = next((f for f in ("png", "jpg", "tif", "bmp") if f in formatos_wia), "")
        elif c["formato"] in formatos_wia:
            extensao_fonte = c["formato"]
        else:
            extensao_fonte = ""
        if not extensao_fonte:
            raise ErroDigitalizacao("O driver deste scanner não oferece o formato escolhido. Selecione outro formato de saída.")
        dpis_wia = [int(x) for x in (d.get("dpi") or [])]
        if dpis_wia and c["dpi"] not in dpis_wia:
            raise ErroDigitalizacao("Esta resolução não é oferecida pelo driver do scanner. Atualize as opções e escolha um dos valores disponíveis.")
        modos_wia = d.get("modos") or ["Color", "Gray", "Lineart"]
        if c["modo"] != "Default" and c["modo"] not in modos_wia:
            raise ErroDigitalizacao("Este modo de cor não é oferecido pelo driver do scanner.")
        brilho_real = _mapear_ajuste(c["brilho"], d.get("brilho_range")) if d.get("brilho") else 0
        contraste_real = _mapear_ajuste(c["contraste"], d.get("contraste_range")) if d.get("contraste") else 0
        resultado = _script_powershell(
            _WIA_SCAN,
            [dispositivo_id, str(pasta), extensao_fonte, c["dpi"], c["modo"], c["origem"],
             c["papel"], brilho_real, contraste_real, c["paginas"] if c["origem"] in ("adf", "duplex") else 1],
            timeout=900,
        )
        dados = _normalizar_lista_json(resultado)
        if dados:
            dados = dados[0]
        else:
            try:
                dados = json.loads(resultado)
            except ValueError:
                raise ErroDigitalizacao("O driver WIA não devolveu o resultado da digitalização.")
        arquivos = [Path(x) for x in dados.get("arquivos", []) if Path(x).is_file() and Path(x).stat().st_size]
        if not arquivos:
            raise ErroDigitalizacao("O scanner não criou arquivos. Confira o driver e tente novamente.")
        # O montador PDF interno aceita JPG/PNG. Alguns drivers WIA oferecem somente
        # BMP ou TIFF; nesses casos, converte as páginas com o System.Drawing nativo.
        if c["formato"] == "pdf" and extensao_fonte not in ("jpg", "png"):
            convertido = _script_powershell(
                _WIA_CONVERTER_PNG, [json.dumps([str(p) for p in arquivos])], timeout=180
            )
            saidas_json = _normalizar_lista_json(convertido)
            saidas = saidas_json[0].get("arquivos", []) if saidas_json and isinstance(saidas_json[0], dict) else []
            pngs = [Path(x) for x in saidas if isinstance(x, str) and Path(x).is_file()]
            if len(pngs) != len(arquivos):
                raise ErroDigitalizacao("O Windows não conseguiu converter as imagens do scanner para PDF. Escolha outro formato ou atualize o driver WIA.")
            for original in arquivos:
                try:
                    original.unlink()
                except OSError:
                    pass
            arquivos = pngs
        return Paginas(arquivos)

    prog = _scanimage()
    if not prog:
        raise ErroDigitalizacao("O comando scanimage não está instalado. No Linux, instale sane-utils e o driver SANE do fabricante.")
    _achar(dispositivo_id)
    driver = _opcoes_sane_guardadas(dispositivo_id)
    # Confere que o controlador oferece os recursos selecionados.
    modos = driver.get("modos") or ["Color", "Gray", "Lineart"]
    modo_real = (driver.get("sane_modes") or {}).get(c["modo"])
    if not modo_real and "mode" in (driver.get("opcoes") or set()):
        modo_real = next((x for x in modos if x.casefold() == c["modo"].casefold()), None)
    if "mode" in (driver.get("opcoes") or set()) and not modo_real:
        raise ErroDigitalizacao("O driver não oferece esse modo de cor. Atualize a lista e escolha outro.")
    if "resolution" in (driver.get("opcoes") or set()) and driver.get("dpi") and c["dpi"] not in driver["dpi"]:
        raise ErroDigitalizacao("Esta resolução não é oferecida pelo driver do scanner. Atualize as opções e escolha um dos valores disponíveis.")
    fonte = _fonte_sane(driver, c["origem"], c["duplex"])

    formato_sane = {"jpg": "jpeg", "png": "png", "tif": "tiff"}.get(extensao_fonte)
    if not formato_sane:
        raise ErroDigitalizacao("O formato de imagem escolhido não é compatível com SANE.")
    cmd = [prog, "--device-name", dispositivo_id, "--format", formato_sane]
    if "resolution" in (driver.get("opcoes") or set()) and c["dpi"] > 0:
        cmd += ["--resolution", str(c["dpi"])]
    if modo_real and "mode" in (driver.get("opcoes") or set()):
        cmd += ["--mode", modo_real]
    nomes = driver.get("opcoes") or set()
    if fonte and "source" in nomes:
        cmd += ["--source", fonte]
    if c["origem"] == "duplex" and "duplex" not in str(fonte or "").lower():
        if driver.get("sane_adf_mode") and "adf-mode" in nomes:
            cmd += ["--adf-mode", driver["sane_adf_mode"]]
        elif driver.get("sane_duplex_option") and "duplex" in nomes:
            valor_duplex = driver.get("sane_duplex_value") or "yes"
            cmd += ["--duplex=" + valor_duplex]
    if c["brilho"] and driver.get("brilho_range"):
        cmd += ["--brightness", str(_mapear_ajuste(c["brilho"], driver["brilho_range"]))]
    if c["contraste"] and driver.get("contraste_range"):
        cmd += ["--contrast", str(_mapear_ajuste(c["contraste"], driver["contraste_range"]))]
    medidas = {"A4": (210, 297), "A5": (148, 210), "Letter": (215.9, 279.4), "Legal": (215.9, 355.6), "A3": (297, 420)}
    if c["papel"] in medidas:
        larg, alt = medidas[c["papel"]]
        # -x e -y são a largura e a altura da área (o scanimage converte para br-x e br-y)
        if "page-width" in nomes:
            cmd += ["--page-width", str(larg)]
        if "br-x" in nomes:
            cmd += ["-x", str(larg)]
        if "page-height" in nomes:
            cmd += ["--page-height", str(alt)]
        if "br-y" in nomes:
            cmd += ["-y", str(alt)]
    padrao = "pagina-%03d." + extensao_fonte
    if c["origem"] in ("adf", "duplex") or fonte and any(x in fonte.lower() for x in ("adf", "feeder", "aliment")):
        # --batch tem argumento opcional: o padrão precisa vir junto, com '='.
        cmd += ["--batch=" + str(pasta / padrao), "--batch-count", str(c["paginas"])]
    else:
        cmd += ["--output-file", str(pasta / ("pagina-001." + extensao_fonte))]

    env = os.environ.copy()
    env.setdefault("LC_ALL", "C.UTF-8")
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=900, env=env, **_sem_janela())
    except subprocess.TimeoutExpired:
        raise ErroDigitalizacao("A digitalização ultrapassou 15 minutos e foi interrompida.")
    except OSError as exc:
        raise ErroDigitalizacao(f"Não foi possível iniciar o scanner: {exc}")
    # só as páginas completas: o scanimage escreve em "pagina-003.png.part" e renomeia ao terminar a folha;
    # um ".part" que sobrou é a folha que não terminou (papel atolado, scanner desligado no meio)
    arquivos = sorted(p for p in pasta.glob("pagina-*." + extensao_fonte) if p.is_file() and p.stat().st_size)
    if not arquivos:
        raise ErroDigitalizacao(_mensagem_sane(r.stderr or r.stdout, "O scanner não produziu nenhuma página."))
    saida = Paginas(arquivos[:LIMITE_PAGINAS])
    # 0 = tudo certo; 7 = o alimentador esvaziou depois de entregar as folhas (fim normal do lote)
    if r.returncode not in (0, 7):
        saida.aviso = (f"O scanner parou depois de {len(saida)} página(s): "
                       + _mensagem_sane(r.stderr or r.stdout, "erro do driver."))
    return saida
