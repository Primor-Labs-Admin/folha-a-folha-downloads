# Servidor e tela web (Windows e Linux)

Código do Folha a Folha **2.4.10** ("compartilhar do celular"), a partir do zip `Folha-a-Folha-2.4.9-usabilidade.zip` mais a mudança de compartilhar arquivo do app Android.

- Não subir aqui a pasta `dados/`, `__pycache__`, chaves ou zips.
- Os testes automáticos ficam fora do repositório, no zip `Folha-a-Folha-testes-<versão>.zip`.
- A tela web (`web/`) vale para todos os apps. O app Android só abre essa tela (veja `../android/`).
- Para atualizar: trocar o conteúdo desta pasta pelo da versão nova, sem apagar este README.
