"""Protocolo IPP (Internet Printing Protocol), o idioma padrão das impressoras de rede.

Com ele, o Folha a Folha aparece como impressora no Windows, Linux, Android e outros
sistemas, sem instalar nada. Só biblioteca padrão. Referências: RFC 8010 (codificação)
e RFC 8011 (operações e atributos).
"""
import struct
import time

# operações
PRINT_JOB = 0x0002
VALIDATE_JOB = 0x0004
CREATE_JOB = 0x0005
SEND_DOCUMENT = 0x0006
CANCEL_JOB = 0x0008
GET_JOB_ATTRIBUTES = 0x0009
GET_JOBS = 0x000A
GET_PRINTER_ATTRIBUTES = 0x000B
CLOSE_JOB = 0x003B
IDENTIFY_PRINTER = 0x003C
OPERACOES = [PRINT_JOB, VALIDATE_JOB, CREATE_JOB, SEND_DOCUMENT, CANCEL_JOB, GET_JOB_ATTRIBUTES,
             GET_JOBS, GET_PRINTER_ATTRIBUTES, CLOSE_JOB, IDENTIFY_PRINTER]

# códigos de resposta
OK = 0x0000
OK_IGNORADOS = 0x0001
ERRO_PEDIDO = 0x0400
ERRO_NAO_POSSIVEL = 0x0404
ERRO_NAO_ENCONTRADO = 0x0406
ERRO_FORMATO = 0x040A
ERRO_CONTA = 0x049C  # client-error-account-info-needed: falta a pessoa entrar (o CUPS segura o trabalho em vez de parar a fila)
ERRO_INTERNO = 0x0500
ERRO_OPERACAO = 0x0501
ERRO_VERSAO = 0x0503

# grupos
G_OPERACAO, G_TRABALHO, G_FIM, G_IMPRESSORA, G_NAO_SUPORTADO = 0x01, 0x02, 0x03, 0x04, 0x05

# tipos de valor
T_NAO_SUPORTADO, T_DESCONHECIDO, T_SEM_VALOR = 0x10, 0x12, 0x13
T_INTEIRO, T_BOOL, T_ENUM = 0x21, 0x22, 0x23
T_OCTETOS, T_DATA, T_RESOLUCAO, T_FAIXA = 0x30, 0x31, 0x32, 0x33
T_COLECAO, T_TEXTO_LING, T_NOME_LING, T_FIM_COLECAO = 0x34, 0x35, 0x36, 0x37
T_TEXTO, T_NOME, T_PALAVRA, T_URI, T_ESQUEMA, T_CHARSET, T_IDIOMA, T_MIME, T_MEMBRO = (
    0x41, 0x42, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A)

# estados de trabalho
JOB_PENDENTE, JOB_RETIDO, JOB_PROCESSANDO, JOB_CANCELADO, JOB_ABORTADO, JOB_CONCLUIDO = 3, 4, 5, 7, 8, 9

TEXTOS = {T_TEXTO, T_NOME, T_PALAVRA, T_URI, T_ESQUEMA, T_CHARSET, T_IDIOMA, T_MIME, T_MEMBRO}


class ErroIPP(Exception):
    def __init__(self, msg, status=ERRO_PEDIDO):
        super().__init__(msg)
        self.status = status


# ================================================================ leitura

class _Leitor:
    def __init__(self, arquivo):
        self.f = arquivo

    def ler(self, n):
        b = self.f.read(n)
        if len(b) != n:
            raise ErroIPP("Pedido IPP incompleto.")
        return b


def _valor(tag, b):
    if tag in (T_INTEIRO, T_ENUM):
        return struct.unpack(">i", b)[0] if len(b) == 4 else 0
    if tag == T_BOOL:
        return bool(b[0]) if b else False
    if tag == T_FAIXA:
        return struct.unpack(">ii", b) if len(b) == 8 else (0, 0)
    if tag == T_RESOLUCAO:
        return struct.unpack(">iib", b) if len(b) == 9 else (0, 0, 3)
    if tag in TEXTOS:
        return b.decode("utf-8", "replace")
    if tag in (T_TEXTO_LING, T_NOME_LING):
        if len(b) >= 2:
            n = struct.unpack(">H", b[:2])[0]
            resto = b[2 + n:]
            if len(resto) >= 2:
                m = struct.unpack(">H", resto[:2])[0]
                return resto[2:2 + m].decode("utf-8", "replace")
        return ""
    if 0x10 <= tag <= 0x1F:
        return None
    return b


def _ler_colecao(leitor):
    """Lê os membros de uma coleção até o endCollection. Devolve dict."""
    membros, atual = {}, None
    while True:
        tag = leitor.ler(1)[0]
        n = struct.unpack(">H", leitor.ler(2))[0]
        leitor.ler(n)  # nome (sempre vazio dentro de coleções)
        m = struct.unpack(">H", leitor.ler(2))[0]
        b = leitor.ler(m)
        if tag == T_FIM_COLECAO:
            return membros
        if tag == T_MEMBRO:
            atual = b.decode("utf-8", "replace")
            membros[atual] = (None, [])
            continue
        valor = _ler_colecao(leitor) if tag == T_COLECAO else _valor(tag, b)
        if atual is not None:
            t, lista = membros[atual]
            membros[atual] = (t or tag, lista + [valor])


class Requisicao:
    def __init__(self, versao, operacao, request_id, grupos):
        self.versao, self.operacao, self.request_id, self.grupos = versao, operacao, request_id, grupos

    def _busca(self, nome, grupos):
        for tag, attrs in self.grupos:
            if tag in grupos and nome in attrs:
                return attrs[nome][1]
        return None

    def op(self, nome, padrao=None):
        v = self._busca(nome, (G_OPERACAO,))
        return v[0] if v else padrao

    def job(self, nome, padrao=None):
        """Atributo de modelo de trabalho (grupo job; alguns clientes mandam no de operação)."""
        v = self._busca(nome, (G_TRABALHO, G_OPERACAO))
        return v[0] if v else padrao

    def todos(self, nome):
        return self._busca(nome, (G_TRABALHO, G_OPERACAO)) or []


def ler_requisicao(arquivo):
    """Lê cabeçalho e atributos de um pedido IPP. O arquivo fica posicionado no documento."""
    le = _Leitor(arquivo)
    maior, menor = le.ler(1)[0], le.ler(1)[0]
    operacao, request_id = struct.unpack(">Hi", le.ler(6))
    grupos, grupo, ultimo = [], None, None
    while True:
        tag = le.ler(1)[0]
        if tag == G_FIM:
            break
        if tag < 0x10:  # início de grupo
            grupo = {}
            grupos.append((tag, grupo))
            ultimo = None
            continue
        n = struct.unpack(">H", le.ler(2))[0]
        nome = le.ler(n).decode("utf-8", "replace")
        m = struct.unpack(">H", le.ler(2))[0]
        b = le.ler(m)
        valor = _ler_colecao(le) if tag == T_COLECAO else _valor(tag, b)
        if grupo is None:
            raise ErroIPP("Atributo fora de grupo.")
        if n == 0 and ultimo:
            t, lista = grupo[ultimo]
            lista.append(valor)
        else:
            grupo[nome] = (tag, [valor])
            ultimo = nome
    return Requisicao((maior, menor), operacao, request_id, grupos)


# ================================================================ escrita

def _bytes_valor(tag, v):
    if tag in (T_INTEIRO, T_ENUM):
        return struct.pack(">i", int(v))
    if tag == T_BOOL:
        return b"\x01" if v else b"\x00"
    if tag == T_FAIXA:
        return struct.pack(">ii", int(v[0]), int(v[1]))
    if tag == T_RESOLUCAO:
        return struct.pack(">iib", int(v[0]), int(v[1]), int(v[2]))
    if tag in TEXTOS:
        return str(v).encode("utf-8")
    if tag in (T_TEXTO_LING, T_NOME_LING):
        lang, texto = v
        lb, tb = lang.encode(), texto.encode("utf-8")
        return struct.pack(">H", len(lb)) + lb + struct.pack(">H", len(tb)) + tb
    if tag in (T_OCTETOS, T_DATA):
        return bytes(v)
    if 0x10 <= tag <= 0x1F:
        return b""
    raise ValueError(f"tipo IPP {tag:#x} sem codificação")


def _codificar(nome, tag, valores):
    saida = bytearray()
    for i, v in enumerate(valores):
        nb = nome.encode() if i == 0 else b""
        if tag == T_COLECAO:
            saida += bytes([T_COLECAO]) + struct.pack(">H", len(nb)) + nb + struct.pack(">H", 0)
            for membro, mtag, mvalores in v:
                mb = membro.encode()
                saida += bytes([T_MEMBRO]) + struct.pack(">H", 0) + struct.pack(">H", len(mb)) + mb
                saida += _codificar("", mtag, mvalores)
            saida += bytes([T_FIM_COLECAO]) + struct.pack(">HH", 0, 0)
        else:
            vb = _bytes_valor(tag, v)
            saida += bytes([tag]) + struct.pack(">H", len(nb)) + nb + struct.pack(">H", len(vb)) + vb
    return bytes(saida)


class Resposta:
    def __init__(self, status, request_id, versao=(2, 0), mensagem=None):
        self.cabecalho = bytes(versao) + struct.pack(">Hi", status, request_id)
        self.grupos = []
        self.novo_grupo(G_OPERACAO)
        self.add("attributes-charset", T_CHARSET, ["utf-8"])
        self.add("attributes-natural-language", T_IDIOMA, ["pt-br"])
        if mensagem:
            self.add("status-message", T_TEXTO, [mensagem[:255]])

    def novo_grupo(self, tag):
        self.grupos.append((tag, []))

    def add(self, nome, tag, valores):
        self.grupos[-1][1].append((nome, tag, valores))

    def add_lista(self, atributos):
        for nome, tag, valores in atributos:
            self.add(nome, tag, valores)

    def bytes(self):
        saida = bytearray(self.cabecalho)
        for tag, attrs in self.grupos:
            saida.append(tag)
            for nome, t, valores in attrs:
                saida += _codificar(nome, t, valores)
        saida.append(G_FIM)
        return bytes(saida)


# ================================================================ atributos da impressora

FORMATOS = ["application/pdf", "image/pwg-raster", "image/jpeg", "application/octet-stream"]
A4 = (21000, 29700)  # centésimos de milímetro
CARTA = (21590, 27940)
OFICIO = (21590, 35560)


def _media_col(x, y, margem=423):
    return [("media-size", T_COLECAO, [[("x-dimension", T_INTEIRO, [x]), ("y-dimension", T_INTEIRO, [y])]]),
            ("media-top-margin", T_INTEIRO, [margem]), ("media-bottom-margin", T_INTEIRO, [margem]),
            ("media-left-margin", T_INTEIRO, [margem]), ("media-right-margin", T_INTEIRO, [margem]),
            ("media-source", T_PALAVRA, ["main"]), ("media-type", T_PALAVRA, ["stationery"])]


def atributos_impressora(uri, nome, info, local, uuid, fila, inicio, mais_info, estado_msg=None):
    """Atributos que fazem o Folha a Folha ser aceito como impressora sem driver (IPP Everywhere)."""
    agora = int(time.time())
    return [
        ("printer-uri-supported", T_URI, [uri]),
        ("uri-security-supported", T_PALAVRA, ["none"]),
        ("uri-authentication-supported", T_PALAVRA, ["none"]),
        ("printer-name", T_NOME, [nome]),
        ("printer-info", T_TEXTO, [info]),
        ("printer-location", T_TEXTO, [local]),
        ("printer-make-and-model", T_TEXTO, ["Folha a Folha"]),
        ("printer-more-info", T_URI, [mais_info]),
        ("printer-uuid", T_URI, [f"urn:uuid:{uuid}"]),
        ("printer-device-id", T_TEXTO, ["MFG:Folha a Folha;MDL:Impressora virtual;CMD:PDF,PWGRaster,JPEG;"]),
        ("printer-state", T_ENUM, [3]),
        ("printer-state-reasons", T_PALAVRA, ["none"]),
        ("printer-state-message", T_TEXTO, [estado_msg or "Pronta. As impressões aguardam liberação no Folha a Folha."]),
        ("printer-is-accepting-jobs", T_BOOL, [True]),
        ("queued-job-count", T_INTEIRO, [fila]),
        ("printer-up-time", T_INTEIRO, [max(1, agora - inicio)]),
        ("printer-current-time", T_DATA, [_data_ipp(agora)]),
        ("ipp-versions-supported", T_PALAVRA, ["1.1", "2.0"]),
        ("ipp-features-supported", T_PALAVRA, ["ipp-everywhere"]),
        ("operations-supported", T_ENUM, OPERACOES),
        ("charset-configured", T_CHARSET, ["utf-8"]),
        ("charset-supported", T_CHARSET, ["utf-8"]),
        ("natural-language-configured", T_IDIOMA, ["pt-br"]),
        ("generated-natural-language-supported", T_IDIOMA, ["pt-br"]),
        ("document-format-default", T_MIME, ["application/pdf"]),
        ("document-format-supported", T_MIME, FORMATOS),
        ("document-format-preferred", T_MIME, ["application/pdf"]),
        ("pdl-override-supported", T_PALAVRA, ["attempted"]),
        ("compression-supported", T_PALAVRA, ["none"]),
        ("multiple-document-jobs-supported", T_BOOL, [False]),
        ("multiple-operation-time-out", T_INTEIRO, [120]),
        ("job-creation-attributes-supported", T_PALAVRA,
         ["copies", "sides", "page-ranges", "print-color-mode", "media", "media-col", "orientation-requested",
          "print-quality", "printer-resolution"]),
        ("copies-default", T_INTEIRO, [1]),
        ("copies-supported", T_FAIXA, [(1, 99)]),
        ("page-ranges-supported", T_BOOL, [True]),
        ("sides-default", T_PALAVRA, ["one-sided"]),
        ("sides-supported", T_PALAVRA, ["one-sided", "two-sided-long-edge", "two-sided-short-edge"]),
        ("print-color-mode-default", T_PALAVRA, ["monochrome"]),
        ("print-color-mode-supported", T_PALAVRA, ["auto", "color", "monochrome"]),
        ("color-supported", T_BOOL, [True]),
        ("print-quality-default", T_ENUM, [4]),
        ("print-quality-supported", T_ENUM, [3, 4]),
        ("printer-resolution-default", T_RESOLUCAO, [(300, 300, 3)]),
        ("printer-resolution-supported", T_RESOLUCAO, [(300, 300, 3)]),
        ("pwg-raster-document-resolution-supported", T_RESOLUCAO, [(300, 300, 3)]),
        ("pwg-raster-document-type-supported", T_PALAVRA, ["sgray_8", "srgb_8"]),
        ("pwg-raster-document-sheet-back", T_PALAVRA, ["normal"]),
        ("orientation-requested-default", T_ENUM, [3]),
        ("orientation-requested-supported", T_ENUM, [3, 4, 5, 6]),
        ("finishings-default", T_ENUM, [3]),
        ("finishings-supported", T_ENUM, [3]),
        ("media-default", T_PALAVRA, ["iso_a4_210x297mm"]),
        ("media-supported", T_PALAVRA, ["iso_a4_210x297mm", "na_letter_8.5x11in", "na_legal_8.5x14in"]),
        ("media-ready", T_PALAVRA, ["iso_a4_210x297mm"]),
        ("media-col-default", T_COLECAO, [_media_col(*A4)]),
        ("media-col-ready", T_COLECAO, [_media_col(*A4)]),
        ("media-col-database", T_COLECAO, [_media_col(*A4), _media_col(*CARTA), _media_col(*OFICIO)]),
        ("media-col-supported", T_PALAVRA, ["media-size", "media-top-margin", "media-bottom-margin",
                                             "media-left-margin", "media-right-margin", "media-source",
                                             "media-type"]),
        ("media-size-supported", T_COLECAO, [[("x-dimension", T_INTEIRO, [x]), ("y-dimension", T_INTEIRO, [y])]
                                             for x, y in (A4, CARTA, OFICIO)]),
        ("media-top-margin-supported", T_INTEIRO, [423]),
        ("media-bottom-margin-supported", T_INTEIRO, [423]),
        ("media-left-margin-supported", T_INTEIRO, [423]),
        ("media-right-margin-supported", T_INTEIRO, [423]),
        ("media-source-supported", T_PALAVRA, ["main"]),
        ("media-type-supported", T_PALAVRA, ["stationery"]),
        ("output-bin-default", T_PALAVRA, ["face-down"]),
        ("output-bin-supported", T_PALAVRA, ["face-down"]),
        ("which-jobs-supported", T_PALAVRA, ["completed", "not-completed"]),
        ("printer-kind", T_PALAVRA, ["document"]),
    ]


def _data_ipp(ts):
    t = time.gmtime(ts)
    return struct.pack(">HBBBBBBcBB", t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec, 0,
                       b"+", 0, 0)


def atributos_trabalho(uri_impressora, job_id, estado, nome, motivo, mensagem, criado):
    return [
        ("job-id", T_INTEIRO, [job_id]),
        ("job-uri", T_URI, [f"{uri_impressora}/job/{job_id}"]),
        ("job-printer-uri", T_URI, [uri_impressora]),
        ("job-name", T_NOME, [nome or f"Trabalho {job_id}"]),
        ("job-state", T_ENUM, [estado]),
        ("job-state-reasons", T_PALAVRA, [motivo]),
        ("job-state-message", T_TEXTO, [mensagem]),
        ("time-at-creation", T_INTEIRO, [criado]),
    ]


def faixas_para_texto(faixas):
    """[(1, 3), (5, 5)] -> '1-3,5'"""
    partes = []
    for a, b in faixas or []:
        partes.append(str(a) if a == b else f"{a}-{b}")
    return ",".join(partes)
