"""Chave de ativação do Folha a Folha.

O desenvolvedor emite uma chave por cliente (escola, empresa ou rede). A chave traz o nome do cliente, o plano
e a data de validade, assinada digitalmente por ele (Ed25519, RFC 8032). O programa
confere a assinatura sem internet, com a chave pública abaixo: ninguém consegue criar
ou alterar uma chave sem a chave privada do desenvolvedor, que fica só com a empresa.

Formato:  FAF1.<dados em base64url>.<assinatura em base64url>
Regras:
  - sem chave: avaliação de 90 dias a partir da instalação;
  - aviso 15 dias antes do fim;
  - depois do fim da licença paga: 30 dias de carência, imprimindo normalmente;
  - depois disso (ou do fim da avaliação): a impressão para até o gestor inserir uma chave.
"""
import base64
import datetime as dt
import hashlib
import json

# Chave pública do desenvolvedor. Troque pela definitiva com a ferramenta de licenças (comando novo-par).
CHAVE_PUBLICA = "22abf17f8d59c31099eb29f7281b44c13080d28b2800992fa91f97adccf28ade"

PRODUTO = "folha-a-folha"
PREFIXO = "FAF1"
AVALIACAO_DIAS = 90
AVISO_DIAS = 15
CARENCIA_DIAS = 30
PLANOS = {"pequeno": "Pequeno", "medio": "Médio", "grande": "Grande", "rede": "Rede municipal",
          "piloto": "Piloto", "cortesia": "Cortesia"}


class ErroLicenca(Exception):
    pass


# ---------------------------------------------------------------- Ed25519 (RFC 8032, seção 6)

_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493


def _inv(x):
    return pow(x, _P - 2, _P)


_D = -121665 * _inv(121666) % _P
_RAIZ_M1 = pow(2, (_P - 1) // 4, _P)


def _h(dados):
    return hashlib.sha512(dados).digest()


def _h_mod_q(dados):
    return int.from_bytes(_h(dados), "little") % _Q


def _soma(p1, p2):
    a = (p1[1] - p1[0]) * (p2[1] - p2[0]) % _P
    b = (p1[1] + p1[0]) * (p2[1] + p2[0]) % _P
    c = 2 * p1[3] * p2[3] * _D % _P
    d = 2 * p1[2] * p2[2] % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _P, g * h % _P, f * g % _P, e * h % _P)


def _mult(s, ponto):
    q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            q = _soma(q, ponto)
        ponto = _soma(ponto, ponto)
        s >>= 1
    return q


def _iguais(p1, p2):
    return (p1[0] * p2[2] - p2[0] * p1[2]) % _P == 0 and (p1[1] * p2[2] - p2[1] * p1[2]) % _P == 0


def _recuperar_x(y, sinal):
    if y >= _P:
        return None
    x2 = (y * y - 1) * _inv(_D * y * y + 1)
    if x2 == 0:
        return None if sinal else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _RAIZ_M1 % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != sinal:
        x = _P - x
    return x


_GY = 4 * _inv(5) % _P
_GX = _recuperar_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _comprimir(ponto):
    zi = _inv(ponto[2])
    x, y = ponto[0] * zi % _P, ponto[1] * zi % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _descomprimir(b):
    if len(b) != 32:
        return None
    y = int.from_bytes(b, "little")
    sinal = y >> 255
    y &= (1 << 255) - 1
    x = _recuperar_x(y, sinal)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


def _expandir(segredo):
    if len(segredo) != 32:
        raise ErroLicenca("Chave privada com tamanho errado.")
    h = _h(segredo)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def publica_de(segredo):
    a, _ = _expandir(segredo)
    return _comprimir(_mult(a, _G))


def assinar(segredo, mensagem):
    a, prefixo = _expandir(segredo)
    pub = _comprimir(_mult(a, _G))
    r = _h_mod_q(prefixo + mensagem)
    rs = _comprimir(_mult(r, _G))
    s = (r + _h_mod_q(rs + pub + mensagem) * a) % _Q
    return rs + int.to_bytes(s, 32, "little")


def conferir(publica, mensagem, assinatura):
    if len(publica) != 32 or len(assinatura) != 64:
        return False
    a = _descomprimir(publica)
    r = _descomprimir(assinatura[:32])
    if not a or not r:
        return False
    s = int.from_bytes(assinatura[32:], "little")
    if s >= _Q:
        return False
    h = _h_mod_q(assinatura[:32] + publica + mensagem)
    return _iguais(_mult(s, _G), _soma(r, _mult(h, a)))


# ---------------------------------------------------------------- formato da chave

def _b64(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _de_b64(t):
    return base64.urlsafe_b64decode(t + "=" * (-len(t) % 4))


def emitir(segredo, dados):
    """Usado só pelo desenvolvedor, na ferramenta de licenças. Devolve o texto da chave."""
    corpo = json.dumps(dados, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    parte = _b64(corpo)
    assinatura = assinar(segredo, f"{PREFIXO}.{parte}".encode())
    return f"{PREFIXO}.{parte}.{_b64(assinatura)}"


def _data(texto, campo):
    try:
        return dt.date.fromisoformat(str(texto))
    except ValueError:
        raise ErroLicenca(f"Chave com {campo} inválida.")


_MEMO = {}


def ler_chave(texto, publica_hex=None):
    """Confere a chave e devolve os dados dela. Lança ErroLicenca com uma explicação simples."""
    limpo = "".join(str(texto or "").split())
    chave_memo = (limpo, publica_hex)
    if chave_memo in _MEMO:
        return dict(_MEMO[chave_memo])
    dados = _ler_chave(limpo, publica_hex)
    if len(_MEMO) > 16:
        _MEMO.clear()
    _MEMO[chave_memo] = dados
    return dict(dados)


def _ler_chave(limpo, publica_hex):
    if not limpo:
        raise ErroLicenca("Cole a chave de ativação.")
    partes = limpo.split(".")
    if len(partes) != 3 or partes[0] != PREFIXO:
        raise ErroLicenca("Isto não parece uma chave do Folha a Folha. Ela começa com FAF1.")
    try:
        corpo = _de_b64(partes[1])
        assinatura = _de_b64(partes[2])
    except (ValueError, TypeError):
        raise ErroLicenca("A chave está incompleta. Copie de novo, inteira.")
    publica = bytes.fromhex(publica_hex or CHAVE_PUBLICA)
    if not conferir(publica, f"{PREFIXO}.{partes[1]}".encode(), assinatura):
        raise ErroLicenca("Chave inválida: a assinatura não confere. Copie de novo ou fale com o desenvolvedor.")
    try:
        dados = json.loads(corpo.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise ErroLicenca("A chave está corrompida.")
    if dados.get("produto") != PRODUTO:
        raise ErroLicenca("Esta chave é de outro produto.")
    inicio, fim = _data(dados.get("inicio"), "data de início"), _data(dados.get("fim"), "data de fim")
    if fim < inicio:
        raise ErroLicenca("Chave com datas trocadas.")
    dados["texto"] = limpo
    return dados


def situacao(chave_texto, instalado_em, hoje=None, publica_hex=None):
    """Estado da licença: avaliacao, avaliacao_fim, ativa, vencendo, carencia ou bloqueada."""
    hoje = hoje or dt.date.today()
    dados, erro = None, None
    if chave_texto:
        try:
            dados = ler_chave(chave_texto, publica_hex)
        except ErroLicenca as e:
            erro = str(e)
    if dados:
        fim = dt.date.fromisoformat(dados["fim"])
        dias = (fim - hoje).days
        if dias > AVISO_DIAS:
            estado = "ativa"
        elif dias >= 0:
            estado = "vencendo"
        elif dias >= -CARENCIA_DIAS:
            estado = "carencia"
        else:
            estado = "bloqueada"
        r = {"estado": estado, "dias": dias, "fim": dados["fim"], "inicio": dados["inicio"],
             "cliente": dados.get("cliente", ""), "plano": PLANOS.get(dados.get("plano"), dados.get("plano", "")),
             "unidades": dados.get("unidades", 1), "id": dados.get("id", ""),
             "bloqueio_em": (fim + dt.timedelta(days=CARENCIA_DIAS + 1)).isoformat()}
    else:
        inst = dt.date.fromisoformat(instalado_em) if instalado_em else hoje
        fim = inst + dt.timedelta(days=AVALIACAO_DIAS - 1)
        dias = (fim - hoje).days
        estado = "avaliacao" if dias > AVISO_DIAS else ("avaliacao_fim" if dias >= 0 else "bloqueada")
        r = {"estado": estado, "dias": dias, "fim": fim.isoformat(), "inicio": inst.isoformat(), "cliente": "",
             "plano": "Avaliação", "unidades": 1, "id": "", "bloqueio_em": (fim + dt.timedelta(days=1)).isoformat()}
    r["pode_imprimir"] = r["estado"] != "bloqueada"
    r["com_chave"] = bool(dados)
    r["erro_chave"] = erro
    r["mensagem"] = mensagem(r)
    return r


def _br(iso):
    d = dt.date.fromisoformat(iso)
    return d.strftime("%d/%m/%Y")


def mensagem(r):
    e, d = r["estado"], r["dias"]
    if e == "ativa":
        return f"Licença ativa até {_br(r['fim'])}."
    if e == "vencendo":
        return (f"A licença vence {'hoje' if d == 0 else f'em {d} dia' + ('s' if d > 1 else '')} "
                f"({_br(r['fim'])}). Renove para não parar.")
    if e == "carencia":
        falta = CARENCIA_DIAS + d + 1
        quando = "só até hoje" if falta == 1 else f"por mais {falta} dias, contando hoje"
        return f"A licença venceu em {_br(r['fim'])}. A impressão continua {quando}. Insira a chave de renovação."
    if e == "avaliacao":
        return f"Período de avaliação: {d + 1} dias restantes, até {_br(r['fim'])}."
    if e == "avaliacao_fim":
        return (f"A avaliação termina {'hoje' if d == 0 else f'em {d + 1} dias'} ({_br(r['fim'])}). "
                f"Insira a chave de ativação para continuar imprimindo.")
    if r.get("com_chave"):
        return ("A impressão está parada: a licença do Folha a Folha venceu. "
                "O gestor precisa inserir a chave de renovação.")
    return ("A impressão está parada: a avaliação de 90 dias terminou. "
            "O gestor precisa inserir a chave de ativação.")
