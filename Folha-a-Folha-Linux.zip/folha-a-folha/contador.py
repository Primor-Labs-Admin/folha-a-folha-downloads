"""Leitura do contador de páginas das impressoras de rede.

Usa SNMP, o protocolo que quase toda impressora de rede responde, escrito só com a
biblioteca padrão do Python (nada para instalar). O contador lido é o
prtMarkerLifeCount da Printer MIB (RFC 3805): o total de páginas que a máquina já
imprimiu na vida, incluindo cópias feitas no vidro e relatórios da própria impressora.
"""
import random
import socket

OID_CONTADOR = "1.3.6.1.2.1.43.10.2.1.4.1.1"   # prtMarkerLifeCount, primeiro marcador
OID_CONTADOR_BASE = "1.3.6.1.2.1.43.10.2.1.4"  # para achar o contador com outro índice
OID_MODELO = "1.3.6.1.2.1.25.3.2.1.3.1"        # hrDeviceDescr
OID_SISTEMA = "1.3.6.1.2.1.1.1.0"              # sysDescr


class ErroContador(Exception):
    pass


# ---------------------------------------------------------------- codificação (BER)

def _comprimento(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _tlv(tag, conteudo):
    return bytes([tag]) + _comprimento(len(conteudo)) + conteudo


def _inteiro(n):
    if n == 0:
        b = b"\x00"
    else:
        b = n.to_bytes((n.bit_length() + 8) // 8, "big", signed=True)
        while len(b) > 1 and ((b[0] == 0 and b[1] < 0x80) or (b[0] == 0xFF and b[1] >= 0x80)):
            b = b[1:]
    return _tlv(0x02, b)


def _oid(texto):
    partes = [int(x) for x in texto.split(".")]
    corpo = bytearray([40 * partes[0] + partes[1]])
    for p in partes[2:]:
        pedacos = [p & 0x7F]
        p >>= 7
        while p:
            pedacos.append((p & 0x7F) | 0x80)
            p >>= 7
        corpo.extend(reversed(pedacos))
    return _tlv(0x06, bytes(corpo))


def montar_pedido(oid, comunidade="public", versao=0, request_id=1, proximo=False):
    """versao 0 = SNMPv1, 1 = SNMPv2c. proximo=True faz GetNext em vez de Get."""
    varbinds = _tlv(0x30, _tlv(0x30, _oid(oid) + b"\x05\x00"))
    pdu = _tlv(0xA1 if proximo else 0xA0, _inteiro(request_id) + _inteiro(0) + _inteiro(0) + varbinds)
    return _tlv(0x30, _inteiro(versao) + _tlv(0x04, comunidade.encode("utf-8")) + pdu)


# ---------------------------------------------------------------- decodificação

def _ler_tlv(dados, pos):
    if pos + 2 > len(dados):
        raise ErroContador("Resposta da impressora incompleta.")
    tag = dados[pos]
    n = dados[pos + 1]
    pos += 2
    if n & 0x80:
        k = n & 0x7F
        n = int.from_bytes(dados[pos:pos + k], "big")
        pos += k
    fim = pos + n
    if fim > len(dados):
        raise ErroContador("Resposta da impressora incompleta.")
    return tag, dados[pos:fim], fim


def _filhos(conteudo):
    pos, saida = 0, []
    while pos < len(conteudo):
        tag, valor, pos = _ler_tlv(conteudo, pos)
        saida.append((tag, valor))
    return saida


def _oid_texto(b):
    if not b:
        return ""
    partes = [b[0] // 40, b[0] % 40]
    n = 0
    for c in b[1:]:
        n = (n << 7) | (c & 0x7F)
        if not c & 0x80:
            partes.append(n)
            n = 0
    return ".".join(map(str, partes))


class _OutroPedido(Exception):
    pass


def ler_resposta(dados, request_id, cru=False):
    """Devolve (oid, valor) de uma resposta SNMP. cru=True devolve textos como bytes (para campos de bits)."""
    try:
        tag, msg, _ = _ler_tlv(dados, 0)
        if tag != 0x30:
            raise ErroContador("Resposta da impressora inválida.")
        partes = _filhos(msg)
        tag_pdu, pdu = partes[2]
        if tag_pdu != 0xA2:
            raise ErroContador("Resposta da impressora inesperada.")
        campos = _filhos(pdu)
        rid = int.from_bytes(campos[0][1], "big", signed=True)
        if rid != request_id:
            raise _OutroPedido()
        if int.from_bytes(campos[1][1], "big"):
            raise ErroContador("A impressora não informa esse dado.")
        varbind = _filhos(campos[3][1])[0][1]
        (_, oid_b), (tag_v, v) = _filhos(varbind)[:2]
    except (IndexError, ValueError):
        raise ErroContador("Resposta da impressora inválida.")
    oid = _oid_texto(oid_b)
    if tag_v in (0x80, 0x81, 0x82):  # noSuchObject, noSuchInstance, endOfMibView
        raise ErroContador("A impressora não informa esse dado.")
    if tag_v == 0x02:
        return oid, int.from_bytes(v, "big", signed=True)
    if tag_v in (0x41, 0x42, 0x43, 0x46):  # Counter32, Gauge32, TimeTicks, Counter64
        return oid, int.from_bytes(v, "big")
    if tag_v == 0x04:
        return oid, bytes(v) if cru else v.decode("utf-8", "replace").strip("\x00 \r\n")
    return oid, None


# ---------------------------------------------------------------- rede

def separar_endereco(endereco):
    endereco = (endereco or "").strip()
    if not endereco:
        raise ErroContador("Informe o endereço IP da impressora.")
    if endereco.count(":") == 1:
        host, porta = endereco.split(":")
        try:
            return host.strip(), int(porta)
        except ValueError:
            raise ErroContador("Endereço da impressora inválido.")
    return endereco, 161


def consultar(endereco, oid, comunidade="public", proximo=False, timeout=2.0, tentativas=2, cru=False):
    host, porta = separar_endereco(endereco)
    erro = ErroContador("A impressora não respondeu. Confira o endereço IP e se o SNMP está ligado nela.")
    for versao in (1, 0):  # tenta SNMPv2c e depois SNMPv1
        rid = random.randint(1, 0x7FFFFFFF)
        pedido = montar_pedido(oid, comunidade, versao, rid, proximo)
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.settimeout(timeout)
                for _ in range(tentativas):
                    s.sendto(pedido, (host, porta))
                    try:
                        while True:
                            dados, _ = s.recvfrom(65535)
                            try:
                                return ler_resposta(dados, rid, cru)
                            except _OutroPedido:
                                continue
                    except socket.timeout:
                        continue
        except ErroContador as e:
            erro = e
        except OSError as e:
            raise ErroContador(f"Não consegui falar com a impressora ({e}).")
    raise erro


def ler_valor(endereco, comunidade="public", timeout=2.0, tentativas=2):
    """Só o número do contador. Lança ErroContador se não conseguir."""
    comunidade = comunidade or "public"
    try:
        _, valor = consultar(endereco, OID_CONTADOR, comunidade, timeout=timeout, tentativas=tentativas)
    except ErroContador as e:
        if "não respondeu" in str(e) or "falar com" in str(e):
            raise
        oid, valor = consultar(endereco, OID_CONTADOR_BASE, comunidade, proximo=True, timeout=timeout,
                               tentativas=tentativas)
        if not oid.startswith(OID_CONTADOR_BASE + "."):
            raise ErroContador("A impressora não informa o contador de páginas por SNMP. Anote a leitura à mão.")
    if not isinstance(valor, int) or valor < 0:
        raise ErroContador("A impressora devolveu um contador inválido.")
    return valor


def ler_contador(endereco, comunidade="public"):
    """Devolve (páginas, modelo). Lança ErroContador se não conseguir."""
    comunidade = comunidade or "public"
    valor = ler_valor(endereco, comunidade)
    modelo = ""
    for oid in (OID_MODELO, OID_SISTEMA):
        try:
            _, m = consultar(endereco, oid, comunidade, timeout=1.0, tentativas=1)
            if isinstance(m, str) and m:
                modelo = m[:120]
                break
        except ErroContador:
            pass
    return valor, modelo
