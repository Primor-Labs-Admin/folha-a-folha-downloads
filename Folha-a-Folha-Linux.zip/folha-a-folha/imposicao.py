"""Folha a Folha: onde e de que tamanho cada página sai na folha ("Tamanho na folha").

Nenhuma impressora comum alcança a beirada do papel: sobra uma faixa de 3 a 6 mm (às vezes mais
embaixo) onde nada sai. Este módulo:

- descobre o papel e essa faixa (as margens) de cada impressora: pelo que a gestão anotou depois da
  página de calibração, pelo CUPS (media-col-default), pelo arquivo PPD da fila ou, sem nada disso,
  4,2 mm em cada lado (o comum em impressoras a laser);
- descobre onde há tinta em cada página, desenhando-a bem pequena (Poppler, MuPDF ou Ghostscript),
  para não encolher à toa um documento que já tem margem;
- calcula, para cada página, o giro, a escala e a posição na folha (o "plano"). O mesmo plano serve
  para a prévia e para a impressão, então a prévia mostra exatamente o que vai sair.

Ajustar à folha: o maior tamanho, até 100%, em que tudo o que tem tinta fica dentro da área que a
impressora alcança. Documento com margem comum sai em 100%; o que encosta na beirada diminui só o
necessário. Página menor que o papel (A5 numa folha A4) aumenta até encher a área.
Outro tamanho: a porcentagem pedida. Se o conteúdo couber na área, ele é empurrado o mínimo
para dentro dela (1 ou 2 mm); se não couber, o plano avisa o que fica de fora.

Só biblioteca padrão.
"""
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

MM = 72 / 25.4
MARGEM_PADRAO_MM = 4.2

# papéis que a gestão pode escolher: (largura, altura) em mm e o nome PWG que o CUPS entende
PAPEIS = {
    "A4": ((210.0, 297.0), "iso_a4_210x297mm", "A4"),
    "Carta": ((215.9, 279.4), "na_letter_8.5x11in", "Carta (Letter)"),
    "Oficio": ((215.9, 330.2), "na_foolscap_8.5x13in", "Ofício (216 × 330 mm)"),
    "Legal": ((215.9, 355.6), "na_legal_8.5x14in", "Legal (216 × 356 mm)"),
    "A5": ((148.0, 210.0), "iso_a5_148x210mm", "A5"),
    "A3": ((297.0, 420.0), "iso_a3_297x420mm", "A3"),
}
LADOS = ("topo", "baixo", "esq", "dir")


def nome_do_papel(larg_mm, alt_mm):
    """O nome do papel com essas medidas (com 2 mm de folga), ou "" se não for um dos conhecidos."""
    for chave, ((w, h), _, _) in PAPEIS.items():
        if abs(w - larg_mm) < 2 and abs(h - alt_mm) < 2:
            return chave
    return ""


# ---------------------------------------------------------------- papel e margens da impressora

_AREAS = {}
_AREAS_SEG = 600


def _area_do_cups(sistema):
    """Papel e margens padrão da fila no CUPS (Get-Printer-Attributes, media-col-default)."""
    try:
        import acompanhar
        import ipp
        resp = acompanhar.pedir(ipp.GET_PRINTER_ATTRIBUTES, [
            ("printer-uri", ipp.T_URI, [f"ipp://localhost/printers/{sistema}"]),
            ("requested-attributes", ipp.T_PALAVRA, ["media-col-default", "media-default"]),
        ], timeout=3)
    except Exception:
        return None
    col = None
    for _, attrs in resp.grupos:
        if "media-col-default" in attrs and attrs["media-col-default"][1]:
            col = attrs["media-col-default"][1][0]
    if not isinstance(col, dict):
        return None

    def num(d, chave):
        try:
            v = d.get(chave, (None, []))[1]
            return float(v[0]) if v else None
        except (TypeError, ValueError, IndexError):
            return None

    tam = col.get("media-size", (None, [None]))[1]
    tam = tam[0] if tam else None
    if not isinstance(tam, dict):
        return None
    w, h = num(tam, "x-dimension"), num(tam, "y-dimension")
    if not w or not h:
        return None
    margens = {"topo": num(col, "media-top-margin"), "baixo": num(col, "media-bottom-margin"),
               "esq": num(col, "media-left-margin"), "dir": num(col, "media-right-margin")}
    if any(v is None for v in margens.values()):
        margens = None
    else:
        margens = {k: v / 100 for k, v in margens.items()}  # centésimos de mm
    return {"papel_mm": (w / 100, h / 100), "margens": margens, "origem": "cups"}


def _area_do_ppd(sistema):
    """Papel e margens do arquivo PPD da fila (/etc/cups/ppd/FILA.ppd): PageSize padrão e ImageableArea."""
    for pasta in (os.environ.get("CI_PPD", "/etc/cups/ppd"),):
        arq = Path(pasta) / f"{sistema}.ppd"
        try:
            texto = arq.read_text("latin-1", "replace")
        except OSError:
            continue
        m = re.search(r"^\*DefaultPageSize:\s*(\S+)", texto, re.M)
        if not m:
            continue
        nome = re.escape(m.group(1))
        dim = re.search(r'^\*PaperDimension\s+' + nome + r'(?:/[^:]*)?:\s*"([\d.]+)\s+([\d.]+)"', texto, re.M)
        area = re.search(r'^\*ImageableArea\s+' + nome + r'(?:/[^:]*)?:\s*"([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)"', texto, re.M)
        if not dim:
            continue
        w, h = float(dim.group(1)), float(dim.group(2))
        margens = None
        if area:
            x0, y0, x1, y1 = (float(area.group(k)) for k in range(1, 5))
            margens = {"topo": (h - y1) / MM, "baixo": y0 / MM, "esq": x0 / MM, "dir": (w - x1) / MM}
        return {"papel_mm": (w / MM, h / MM), "margens": margens, "origem": "ppd"}
    return None


def area_detectada(sistema):
    """O que a própria impressora informa (guardado por 10 minutos). None se não informar nada."""
    if not sistema:
        return None
    agora = time.time()
    if sistema in _AREAS and agora - _AREAS[sistema][0] < _AREAS_SEG:
        return _AREAS[sistema][1]
    achada = None
    if os.name != "nt":
        achada = _area_do_cups(sistema) or _area_do_ppd(sistema)
        if achada and not achada.get("margens"):
            ppd = _area_do_ppd(sistema)
            if ppd and ppd.get("margens"):
                achada["margens"] = ppd["margens"]
    _AREAS[sistema] = (agora, achada)
    return achada


def area_da_impressora(sistema="", papel="", margens=None):
    """Papel e área de impressão efetivos de uma impressora.
    papel: "" (o da impressora) ou uma chave de PAPEIS; margens: {"topo", "baixo", "esq", "dir"} em mm
    anotadas pela gestão, ou None (as da impressora). Devolve um dicionário com papel_mm, margens (mm),
    papel (chave ou ""), media (nome PWG para mandar ao CUPS: o papel escolhido pela gestão ou, se nada foi
    informado, A4; vazio só quando o próprio CUPS informou o papel) e de onde veio cada coisa."""
    det = area_detectada(sistema) or {}
    if papel in PAPEIS:
        papel_mm, origem_papel, media = PAPEIS[papel][0], "gestao", PAPEIS[papel][1]
    elif det.get("papel_mm"):
        papel_mm, origem_papel, media = tuple(det["papel_mm"]), det["origem"], ""
    else:
        # nada informado: o cálculo usa A4 e o CUPS é avisado disso (2.5.1). Sem o aviso, a fila podia usar
        # outro papel (Carta, por exemplo) e cortar o fim da folha, porque o plano é feito para A4.
        papel_mm, origem_papel, media = PAPEIS["A4"][0], "padrao", PAPEIS["A4"][1]
    if margens and all(isinstance(margens.get(k), (int, float)) for k in LADOS):
        m, origem_margens = {k: float(margens[k]) for k in LADOS}, "gestao"
    elif det.get("margens"):
        m, origem_margens = dict(det["margens"]), det["origem"]
    else:
        m, origem_margens = {k: MARGEM_PADRAO_MM for k in LADOS}, "padrao"
    w, h = papel_mm
    # margens absurdas (impressora que informa errado) viram o padrão
    if m["esq"] + m["dir"] > w * 0.5 or m["topo"] + m["baixo"] > h * 0.5 or min(m.values()) < 0:
        m, origem_margens = {k: MARGEM_PADRAO_MM for k in LADOS}, "padrao"
    return {"papel_mm": (round(w, 2), round(h, 2)), "papel": nome_do_papel(w, h), "media": media,
            "margens": {k: round(v, 2) for k, v in m.items()},
            "origem_papel": origem_papel, "origem_margens": origem_margens}


# ---------------------------------------------------------------- onde há tinta em cada página

_TINTA = {}
DPI_TINTA = 36
CLARO = 248  # mais claro que isto conta como papel; o cinza clarinho de um traço fino conta como tinta


def _ler_pgm(caminho):
    """Caixa da tinta numa imagem PGM (P5): frações (x0, y0, x1, y1) com y para baixo, ou "branca"."""
    with open(caminho, "rb") as f:
        dados = f.read()
    campos, pos = [], 2
    if dados[:2] != b"P5":
        raise ValueError("não é PGM")
    while len(campos) < 3:
        m = re.compile(rb"\s*(?:#[^\n]*\n\s*)*(\d+)").match(dados, pos)
        if not m:
            raise ValueError("PGM estranho")
        campos.append(int(m.group(1)))
        pos = m.end()
    pos += 1
    w, h, maximo = campos
    if maximo > 255:
        raise ValueError("PGM de 16 bits")
    px = dados[pos:pos + w * h]
    limite = CLARO * maximo // 255
    linhas = [y for y in range(h) if px[y * w:(y + 1) * w].translate(None, bytes(range(limite, 256)))]
    if not linhas:
        return "branca"
    y0, y1 = linhas[0], linhas[-1] + 1
    x0, x1 = w, 0
    for y in range(y0, y1):
        linha = px[y * w:(y + 1) * w]
        esq = next((i for i, v in enumerate(linha) if v < limite), None)
        if esq is None:
            continue
        dir_ = w - next(i for i, v in enumerate(reversed(linha)) if v < limite)
        x0, x1 = min(x0, esq), max(x1, dir_)
    # um ponto de folga em cada lado (0,7 mm): o desenho pequeno arredonda a posição dos traços
    x0, y0, x1, y1 = max(0, x0 - 1), max(0, y0 - 1), min(w, x1 + 1), min(h, y1 + 1)
    return (x0 / w, y0 / h, x1 / w, y1 / h)


def tinta(caminho, total, renderizador):
    """Para cada página (como é vista), a caixa da tinta em frações da página (x0, y0, x1, y1), com y para
    baixo, ou "branca". None se não der para desenhar (sem Poppler/MuPDF/Ghostscript, PDF demais, erro).
    Fica guardado enquanto o arquivo não muda."""
    if not renderizador or not total or total > 400:
        return None
    try:
        st = os.stat(caminho)
    except OSError:
        return None
    chave = (str(caminho), st.st_size, st.st_mtime_ns)
    if chave in _TINTA:
        return _TINTA[chave]
    prog, cam = renderizador
    pasta = Path(tempfile.mkdtemp(prefix="tinta-"))
    try:
        if prog == "pdftoppm":
            cmd = [cam, "-r", str(DPI_TINTA), "-cropbox", "-gray", str(caminho), str(pasta / "p")]
        elif prog == "mutool":
            cmd = [cam, "draw", "-q", "-r", str(DPI_TINTA), "-c", "gray", "-o", str(pasta / "p-%d.pgm"), str(caminho)]
        else:
            cmd = [cam, "-q", "-dSAFER", "-dBATCH", "-dNOPAUSE", "-dUseCropBox", "-sDEVICE=pgmraw", f"-r{DPI_TINTA}",
                   "-dTextAlphaBits=1", "-dGraphicsAlphaBits=1", f"-sOutputFile={pasta / 'p-%d.pgm'}", str(caminho)]
        extra = {"creationflags": 0x08000000} if os.name == "nt" else {}
        try:
            subprocess.run(cmd, capture_output=True, timeout=max(30, total), **extra)
        except (subprocess.TimeoutExpired, OSError):
            return None
        arquivos = sorted(pasta.glob("p-*.pgm"), key=lambda p: int(re.search(r"(\d+)\.pgm$", p.name).group(1)))
        if len(arquivos) != total:
            return None
        try:
            saida = [_ler_pgm(a) for a in arquivos]
        except (OSError, ValueError):
            return None
    finally:
        shutil.rmtree(pasta, ignore_errors=True)
    if len(_TINTA) > 40:
        _TINTA.clear()
    _TINTA[chave] = saida
    return saida


# ---------------------------------------------------------------- o plano

def planejar(paginas, tintas, area, modo="ajustar", pct=100):
    """Giro, escala e posição de cada página na folha.

    paginas: [(largura, altura)] em pontos, como cada página é vista (já com o giro do próprio PDF).
    tintas: lista paralela com a caixa da tinta em frações (x0, y0, x1, y1; y para baixo), "branca"
    ou None (não se sabe); ou None para todas.
    area: o que area_da_impressora devolve. modo: "ajustar" ou "pct" (com pct em %).

    Cada item devolvido: giro (0 ou 90, anti-horário, quando a página deitada vai numa folha em pé),
    escala, x, y (canto inferior esquerdo da página na folha, em pontos), largura e altura na folha,
    corta (algo com tinta fica fora da área que a impressora alcança) e pct (a escala em %)."""
    W, H = (v * MM for v in area["papel_mm"])
    m = {k: v * MM for k, v in area["margens"].items()}
    ax0, ay0, ax1, ay1 = m["esq"], m["baixo"], W - m["dir"], H - m["topo"]
    AW, AH = ax1 - ax0, ay1 - ay0
    folga = 0.05  # pontos: arredondamento
    saida = []
    for i, (w, h) in enumerate(paginas):
        t = tintas[i] if tintas and i < len(tintas) else None
        giro = 90 if (w > h + 1) != (W > H + 1) and abs(w - h) > 1 else 0
        ww, hh = (h, w) if giro else (w, h)
        # caixa da tinta em pontos, a partir do canto inferior esquerdo da página já girada
        if t == "branca":
            tinta_pt = None
        elif t is None:
            tinta_pt = (0.0, 0.0, ww, hh)
        else:
            u0, v0, u1, v1 = t
            if giro:  # 90° anti-horário: (u, v) vira (v, 1 - u)
                u0, v0, u1, v1 = v0, 1 - u1, v1, 1 - u0
            tinta_pt = (u0 * ww, (1 - v1) * hh, u1 * ww, (1 - v0) * hh)
        if modo == "ajustar":
            s_pagina = min(AW / ww, AH / hh)
            if s_pagina >= 1:
                s = s_pagina  # página menor que a área: aumenta até encher
                tinta_pt = (0.0, 0.0, ww, hh)
            elif tinta_pt is None:
                s = 1.0  # página em branco
            else:
                tw, th = tinta_pt[2] - tinta_pt[0], tinta_pt[3] - tinta_pt[1]
                s = min(1.0, AW / tw if tw > 0 else 1.0, AH / th if th > 0 else 1.0)
        else:
            s = max(0.01, pct / 100)
        x, y = (W - ww * s) / 2, (H - hh * s) / 2
        corta = False
        if tinta_pt is not None:
            ix0, iy0, ix1, iy1 = x + tinta_pt[0] * s, y + tinta_pt[1] * s, x + tinta_pt[2] * s, y + tinta_pt[3] * s
            # empurra o mínimo para dentro da área, se couber; se não couber, fica centrado e avisa
            if ix1 - ix0 <= AW + folga:
                x += ax0 - ix0 if ix0 < ax0 else ax1 - ix1 if ix1 > ax1 else 0
            else:
                corta = True
            if iy1 - iy0 <= AH + folga:
                y += ay0 - iy0 if iy0 < ay0 else ay1 - iy1 if iy1 > ay1 else 0
            else:
                corta = True
        saida.append({"giro": giro, "escala": s, "x": x, "y": y, "largura": ww * s, "altura": hh * s,
                      "corta": corta, "pct": round(s * 100, 1)})
    return saida


def em_mm(area, plano):
    """O plano em milímetros, com o canto superior esquerdo da folha como origem (para a tela desenhar)."""
    W, H = area["papel_mm"]
    return [{"giro": p["giro"], "pct": p["pct"], "corta": p["corta"],
             "x": round(p["x"] / MM, 2), "y": round(H - (p["y"] + p["altura"]) / MM, 2),
             "largura": round(p["largura"] / MM, 2), "altura": round(p["altura"] / MM, 2)} for p in plano]


# ---------------------------------------------------------------- página de calibração

def _texto_pdf(t):
    return "(" + t.encode("cp1252", "replace").decode("latin-1").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") + ")"


def _mm(v):
    """4.2 -> "4,2 mm"; 3.0 -> "3 mm" (como a tela mostra)."""
    t = f"{float(v):.1f}".rstrip("0").rstrip(".").replace(".", ",")
    return f"{t} mm"


def pagina_calibracao(area, destino):
    """PDF do tamanho do papel com uma escadinha em cada borda: traços a 0; 0,5; 1... 10 mm da beirada.
    Em cada borda, o menor número que saiu inteiro é a margem daquele lado. O retângulo tracejado
    mostra a área que o Folha a Folha está usando agora."""
    W, H = (v * MM for v in area["papel_mm"])
    m = {k: v * MM for k, v in area["margens"].items()}
    c = ["0 0 0 RG 0 0 0 rg 0.5 w"]

    def txt(x, y, t, tam=6):
        c.append(f"BT /F1 {tam} Tf {x:.2f} {y:.2f} Td {_texto_pdf(t)} Tj ET")

    # escadinha: o degrau d fica a d mm da beirada (de meio em meio milímetro, até 10 mm), cada um numa
    # coluna, para os números não se encostarem
    passo, larg = 4.4 * MM, 3.2 * MM
    degraus = [k / 2 for k in range(0, 21)]
    total = len(degraus) * passo
    x_ini, y_ini = (W - total) / 2, (H - total) / 2
    c.append("0.6 w")
    for k, d in enumerate(degraus):
        p = d * MM + 0.3  # o traço (0,6 pt) fica inteiro a d mm da beirada
        rot = (f"{d:.1f}".rstrip("0").rstrip(".")).replace(".", ",")
        x = x_ini + k * passo
        y = y_ini + k * passo
        c.append(f"{x:.2f} {H - p:.2f} m {x + larg:.2f} {H - p:.2f} l S")          # em cima
        c.append(f"{x:.2f} {p:.2f} m {x + larg:.2f} {p:.2f} l S")                  # embaixo
        c.append(f"{p:.2f} {y:.2f} m {p:.2f} {y + larg:.2f} l S")                  # à esquerda
        c.append(f"{W - p:.2f} {y:.2f} m {W - p:.2f} {y + larg:.2f} l S")          # à direita
        tam = 5
        txt(x + 0.3, H - p - 6.2, rot, tam)
        txt(x + 0.3, p + 2.2, rot, tam)
        txt(p + 1.6, y + 2.5, rot, tam)
        txt(W - p - 1.6 - len(rot) * 2.6, y + 2.5, rot, tam)
    # a área usada agora
    c.append("0.8 w [3 2] 0 d 0.72 0.23 0.15 RG")
    c.append(f"{m['esq']:.2f} {m['baixo']:.2f} {W - m['esq'] - m['dir']:.2f} {H - m['baixo'] - m['topo']:.2f} re S")
    c.append("[] 0 d 0 0 0 RG")
    linhas = [
        ("Folha a Folha - página de calibração", 13),
        ("", 6),
        ("Em cada uma das quatro bordas há uma escadinha de traços: o primeiro fica", 9),
        ("na beirada (0 mm), o seguinte a 0,5 mm, depois 1 mm, e assim até 10 mm.", 9),
        ("", 6),
        ("Em cada borda, veja o MENOR número cujo traço saiu inteiro, de ponta a ponta.", 9),
        ("Esse número é a margem daquele lado, em milímetros.", 9),
        ("", 6),
        ("Anote em Gestão > Impressoras > Editar > Papel e área de impressão,", 9),
        ("com \"Medir à mão\" ligado: em cima, embaixo, à esquerda e à direita.", 9),
        ("", 6),
        (f"Margens em uso agora: em cima {_mm(area['margens']['topo'])}, embaixo {_mm(area['margens']['baixo'])},", 8),
        (f"esquerda {_mm(area['margens']['esq'])}, direita {_mm(area['margens']['dir'])} (o retângulo tracejado).", 8),
        (f"Papel: {_mm(area['papel_mm'][0])} x {_mm(area['papel_mm'][1])}. Saiu em tamanho real, sem ajuste.", 8),
    ]
    y = H / 2 + 60
    for t, tam in linhas:
        if t:
            larg = len(t) * tam * 0.5
            txt(max(40, (W - larg) / 2), y, t, tam)
        y -= tam * 1.6
    corpo = "\n".join(c).encode("latin-1")
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {W:.2f} {H:.2f}] /Resources << /Font << /F1 5 0 R >> >> "
         f"/Contents 4 0 R >>").encode(),
        b"<< /Length %d >>\nstream\n" % len(corpo) + corpo + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
    ]
    saida = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    pos = []
    for k, o in enumerate(objs, 1):
        pos.append(len(saida))
        saida += b"%d 0 obj\n" % k + o + b"\nendobj\n"
    xref = len(saida)
    saida += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    for p in pos:
        saida += b"%010d 00000 n \n" % p
    saida += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, xref)
    Path(destino).write_bytes(bytes(saida))
    return str(destino)
