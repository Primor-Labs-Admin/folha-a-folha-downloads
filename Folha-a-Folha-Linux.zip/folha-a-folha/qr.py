"""Folha a Folha: QR code em Python puro, para o cartaz impresso (2.6.0).

É o mesmo gerador da tela (web/qr.js), passado para Python: modo de bytes (UTF-8), correção de erro M,
versões 1 a 10 (até 213 bytes: sobra para um endereço de rede). O teste cartaz_teste.py confere que as duas
grades saem iguais, módulo por módulo.

matriz(texto) devolve a grade (lista de linhas; True = módulo escuro) ou None se o texto não couber.
Só biblioteca padrão.
"""

ECC_POR_BLOCO = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26]  # por versão, nível M
BLOCOS = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5]
VERSAO_MAX = 10


def _modulos_de_dados(v):
    r = (16 * v + 128) * v + 64
    if v >= 2:
        n = v // 7 + 2
        r -= (25 * n - 10) * n - 55
        if v >= 7:
            r -= 36
    return r


def _palavras_de_dados(v):
    return _modulos_de_dados(v) // 8 - ECC_POR_BLOCO[v] * BLOCOS[v]


# ---- Reed-Solomon no campo de 256 elementos

def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = ((z << 1) ^ ((z >> 7) * 0x11D)) & 0xFFFF
        z ^= ((y >> i) & 1) * x
    return z & 0xFF


def _divisor_rs(grau):
    r = [0] * grau
    r[grau - 1] = 1
    raiz = 1
    for _ in range(grau):
        for j in range(grau):
            r[j] = _gf_mul(r[j], raiz)
            if j + 1 < grau:
                r[j] ^= r[j + 1]
        raiz = _gf_mul(raiz, 0x02)
    return r


def _resto_rs(dados, divisor):
    r = [0] * len(divisor)
    for b in dados:
        f = b ^ r.pop(0)
        r.append(0)
        for i, c in enumerate(divisor):
            r[i] ^= _gf_mul(c, f)
    return r


# ---- dados + correção de erro, já intercalados

def _palavras_finais(dados_bytes, v):
    capacidade = _palavras_de_dados(v) * 8
    bits = []

    def poe(valor, n):
        for i in range(n - 1, -1, -1):
            bits.append((valor >> i) & 1)

    poe(0x4, 4)
    poe(len(dados_bytes), 8 if v <= 9 else 16)
    for b in dados_bytes:
        poe(b, 8)
    poe(0, min(4, capacidade - len(bits)))
    poe(0, (8 - (len(bits) % 8)) % 8)
    pad = 0xEC
    while len(bits) < capacidade:
        poe(pad, 8)
        pad ^= 0xEC ^ 0x11
    dados = []
    for i in range(0, len(bits), 8):
        b = 0
        for j in range(8):
            b = (b << 1) | bits[i + j]
        dados.append(b)
    n, ecc = BLOCOS[v], ECC_POR_BLOCO[v]
    bruto = _modulos_de_dados(v) // 8
    curtos, tam_curto = n - (bruto % n), bruto // n
    div = _divisor_rs(ecc)
    blocos, k = [], 0
    for i in range(n):
        dat = dados[k:k + tam_curto - ecc + (0 if i < curtos else 1)]
        k += len(dat)
        e = _resto_rs(dat, div)
        if i < curtos:
            dat = dat + [0]
        blocos.append(dat + e)
    saida = []
    for i in range(len(blocos[0])):
        for j, bl in enumerate(blocos):
            if i != tam_curto - ecc or j >= curtos:
                saida.append(bl[i])
    return saida


# ---- a grade

_MASCARAS = (
    lambda x, y: (x + y) % 2 == 0,
    lambda x, y: y % 2 == 0,
    lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (x // 3 + y // 2) % 2 == 0,
    lambda x, y: ((x * y) % 2) + ((x * y) % 3) == 0,
    lambda x, y: (((x * y) % 2) + ((x * y) % 3)) % 2 == 0,
    lambda x, y: (((x + y) % 2) + ((x * y) % 3)) % 2 == 0,
)


def _penalidade(m):
    tam = len(m)
    total = 0
    linhas = [list(l) for l in m] + [[m[y][x] for y in range(tam)] for x in range(tam)]
    for l in linhas:
        corrida = 1
        for i in range(1, tam + 1):
            if i < tam and l[i] == l[i - 1]:
                corrida += 1
            else:
                if corrida >= 5:
                    total += 3 + (corrida - 5)
                corrida = 1
        s = "".join("1" if c else "0" for c in l)
        for i in range(0, tam - 6):
            if s[i:i + 7] != "1011101":
                continue
            antes, depois = s[max(0, i - 4):i], s[i + 7:i + 11]
            if i - 4 < 0 or antes == "0000":
                total += 40
            if i + 11 > tam or depois == "0000":
                total += 40
    for y in range(tam - 1):
        for x in range(tam - 1):
            c = m[y][x]
            if c == m[y][x + 1] and c == m[y + 1][x] and c == m[y + 1][x + 1]:
                total += 3
    escuros = sum(1 for l in m for c in l if c)
    # igual ao Math.ceil do JavaScript, com divisão exata
    num, den = abs(escuros * 20 - tam * tam * 10), tam * tam
    total += (-(-num // den) - 1) * 10
    return total


def _montar(v, palavras, mascara_fixa=None):
    tam = v * 4 + 17
    m = [[False] * tam for _ in range(tam)]
    fn = [[False] * tam for _ in range(tam)]

    def poe(x, y, escuro):
        m[y][x] = bool(escuro)
        fn[y][x] = True

    for i in range(tam):
        poe(6, i, i % 2 == 0)
        poe(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (tam - 4, 3), (3, tam - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                d = max(abs(dx), abs(dy))
                if 0 <= cx + dx < tam and 0 <= cy + dy < tam:
                    poe(cx + dx, cy + dy, d != 2 and d != 4)
    if v > 1:
        n = v // 7 + 2
        passo = -(-(v * 4 + 4) // (n * 2 - 2)) * 2
        pos = [6]
        p = tam - 7
        while len(pos) < n:
            pos.insert(1, p)
            p -= passo
        for i, cx in enumerate(pos):
            for j, cy in enumerate(pos):
                if (i == 0 and j == 0) or (i == 0 and j == n - 1) or (i == n - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        poe(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)

    def formato(mascara):
        dados = mascara  # nível M = 00
        r = dados
        for _ in range(10):
            r = (r << 1) ^ ((r >> 9) * 0x537)
        bits = ((dados << 10) | r) ^ 0x5412
        b = lambda i: ((bits >> i) & 1) != 0  # noqa: E731
        for i in range(0, 6):
            poe(8, i, b(i))
        poe(8, 7, b(6))
        poe(8, 8, b(7))
        poe(7, 8, b(8))
        for i in range(9, 15):
            poe(14 - i, 8, b(i))
        for i in range(0, 8):
            poe(tam - 1 - i, 8, b(i))
        for i in range(8, 15):
            poe(8, tam - 15 + i, b(i))
        poe(8, tam - 8, True)

    formato(0)
    if v >= 7:
        r = v
        for _ in range(12):
            r = (r << 1) ^ ((r >> 11) * 0x1F25)
        bits = (v << 12) | r
        for i in range(18):
            bit, a, c = ((bits >> i) & 1) != 0, tam - 11 + (i % 3), i // 3
            poe(a, c, bit)
            poe(c, a, bit)
    # dados em zigue-zague
    i = 0
    dir_ = tam - 1
    while dir_ >= 1:
        if dir_ == 6:
            dir_ = 5
        for vert in range(tam):
            for j in range(2):
                x = dir_ - j
                sobe = ((dir_ + 1) & 2) == 0
                y = tam - 1 - vert if sobe else vert
                if not fn[y][x] and i < len(palavras) * 8:
                    m[y][x] = ((palavras[i >> 3] >> (7 - (i & 7))) & 1) != 0
                    i += 1
        dir_ -= 2

    def aplicar(mascara):
        f = _MASCARAS[mascara]
        for y in range(tam):
            for x in range(tam):
                if not fn[y][x] and f(x, y):
                    m[y][x] = not m[y][x]

    melhor, menor = mascara_fixa, None
    if mascara_fixa is None:
        for k in range(8):
            aplicar(k)
            formato(k)
            p = _penalidade(m)
            if menor is None or p < menor:
                menor, melhor = p, k
            aplicar(k)
    aplicar(melhor)
    formato(melhor)
    return m


def matriz(texto, mascara=None):
    """Grade do QR (True = módulo escuro) ou None se o texto não couber. `mascara` (0 a 7) só serve para testes."""
    dados = list(str(texto).encode("utf-8"))
    for v in range(1, VERSAO_MAX + 1):
        bits_precisos = 4 + (8 if v <= 9 else 16) + len(dados) * 8
        if bits_precisos <= _palavras_de_dados(v) * 8:
            return _montar(v, _palavras_finais(dados, v), mascara)
    return None
