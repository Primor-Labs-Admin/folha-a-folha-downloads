"""Folha a Folha: relatório de impressões em PDF (2.7.0).

Uma ou mais folhas, no tamanho do papel, com o período, os números, para que foi impresso, quem imprimiu e os
pontos de atenção. Não leva nomes de arquivos (só a tela e a planilha mostram) e os pontos de atenção saem sem eles.
O gestor baixa em PDF ou imprime (sem contar na cota de ninguém), em Gestão, Relatórios.

pdf(info, papel_mm) devolve os bytes do PDF. O desenho é feito para A4 e encolhe ou cresce com o papel.
O texto usa as medidas de letra do cartaz.py. Só biblioteca padrão.
"""
import cartaz

MM = 72 / 25.4


def _cortar(texto, tam, larg, negrito=False):
    """Corta o texto com "..." para caber em larg pontos."""
    texto = " ".join(str(texto).split())
    if cartaz.largura(texto, tam, negrito) <= larg:
        return texto
    while texto and cartaz.largura(texto + "...", tam, negrito) > larg:
        texto = texto[:-1]
    return texto.rstrip() + "..."


def _n(v):
    return f"{int(v):,}".replace(",", ".")


def _reais(v):
    return "R$ " + f"{float(v or 0):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _pag(v):
    return f"{_n(v)} {'página' if int(v) == 1 else 'páginas'}"


class _Folhas:
    """Várias páginas com o mesmo tamanho; texto à esquerda, à direita e retângulos cheios."""

    def __init__(self, papel_mm):
        self.W, self.H = (float(v) * MM for v in papel_mm)
        self.k = max(0.5, min(1.5, self.W / (210 * MM), self.H / (297 * MM)))
        self.margem = 16 * MM * self.k
        self.util = self.W - 2 * self.margem
        self.paginas = []
        self.c = []
        self.y = 0.0
        self.nova()

    def nova(self):
        self.c = ["0 g 0 G"]
        self.paginas.append(self.c)
        self.y = self.H - self.margem

    def cabe(self, altura):
        """Garante espaço para a altura pedida; senão, começa outra folha."""
        if self.y - altura < self.margem + 14 * self.k:
            self.nova()

    def txt(self, x, t, tam, negrito=False, cinza=False, y=None):
        y = self.y if y is None else y
        if cinza:
            self.c.append("0.35 g")
        self.c.append(f"BT /{'F2' if negrito else 'F1'} {tam:.1f} Tf {x:.2f} {y:.2f} Td {cartaz._texto_pdf(t)} Tj ET")
        if cinza:
            self.c.append("0 g")

    def direita(self, x_fim, t, tam, negrito=False, cinza=False):
        self.txt(x_fim - cartaz.largura(t, tam, negrito), t, tam, negrito, cinza)

    def retangulo(self, x, y, larg, alt, cinza):
        self.c.append(f"{cinza:.2f} g {x:.2f} {y:.2f} {larg:.2f} {alt:.2f} re f 0 g")

    def linha(self, y=None, cinza=0.75):
        y = self.y if y is None else y
        self.c.append(f"{cinza:.2f} G 0.5 w {self.margem:.2f} {y:.2f} m {self.W - self.margem:.2f} {y:.2f} l S 0 G")

    def bytes(self, rodape):
        total = len(self.paginas)
        for n_pag, c in enumerate(self.paginas, 1):
            tam = 8 * self.k
            c.append("0.35 g")
            c.append(f"BT /F1 {tam:.1f} Tf {self.margem:.2f} {self.margem - 4 * self.k:.2f} Td "
                     f"{cartaz._texto_pdf(_cortar(rodape, tam, self.util * 0.8))} Tj ET")
            t = f"Folha {n_pag} de {total}"
            c.append(f"BT /F1 {tam:.1f} Tf {self.W - self.margem - cartaz.largura(t, tam):.2f} "
                     f"{self.margem - 4 * self.k:.2f} Td {cartaz._texto_pdf(t)} Tj ET")
            c.append("0 g")
        objs = [b"<< /Type /Catalog /Pages 2 0 R >>", None]
        fonte = "<< /Type /Font /Subtype /Type1 /BaseFont /%s /Encoding /WinAnsiEncoding >>"
        ids_pag = []
        extras = []
        base = 5  # 1 catálogo, 2 páginas, 3 e 4 fontes
        for i, c in enumerate(self.paginas):
            corpo = "\n".join(c).encode("latin-1", "replace")
            id_pag, id_corpo = base + 2 * i, base + 2 * i + 1
            ids_pag.append(id_pag)
            extras.append(
                (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {self.W:.2f} {self.H:.2f}] "
                 f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {id_corpo} 0 R >>").encode())
            extras.append(b"<< /Length %d >>\nstream\n" % len(corpo) + corpo + b"\nendstream")
        objs[1] = ("<< /Type /Pages /Kids [" + " ".join(f"{i} 0 R" for i in ids_pag) + f"] /Count {len(ids_pag)} >>").encode()
        objs += [(fonte % "Helvetica").encode(), (fonte % "Helvetica-Bold").encode()] + extras
        saida = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        pos = []
        for n_obj, o in enumerate(objs, 1):
            pos.append(len(saida))
            saida += b"%d 0 obj\n" % n_obj + o + b"\nendobj\n"
        xref = len(saida)
        saida += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
        for p in pos:
            saida += b"%010d 00000 n \n" % p
        saida += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, xref)
        return bytes(saida)


def pdf(info, papel_mm=(210.0, 297.0)):
    """info: lugar, quando, filtros, gerado_em, totais, por_finalidade, por_pessoa, atencao, alerta_grande
    (o que a tela do relatório recebe do servidor)."""
    f = _Folhas(papel_mm)
    k, m, util = f.k, f.margem, f.util
    t = info["totais"]

    # ---- cabeçalho
    f.y -= 11 * k
    f.txt(m, _cortar(info.get("lugar") or "Folha a Folha", 11 * k, util), 11 * k, cinza=True)
    f.y -= 26 * k
    f.txt(m, "Relatório de impressões", 24 * k, True)
    f.y -= 20 * k
    f.txt(m, _cortar(info["quando"], 14 * k, util, True), 14 * k, True)
    for linha in (cartaz.quebrar(info["filtros"], 10 * k, util)[:3] if info.get("filtros") else []):
        f.y -= 14 * k
        f.txt(m, linha, 10 * k, cinza=True)
    f.y -= 12 * k
    f.linha()
    f.y -= 30 * k

    # ---- números
    caixas = [(_n(t["paginas"]), "páginas"), (_n(t["impressoes"]), "impressão" if t["impressoes"] == 1 else "impressões"),
              (_n(t["pessoas"]), "pessoa" if t["pessoas"] == 1 else "pessoas")]
    if t.get("custo", 0) > 0:
        caixas.append((_reais(t["custo"]), "custo"))
    larg_caixa = util / len(caixas)
    tam_num = 22 * k
    tam_num = min(tam_num, *[larg_caixa * 0.92 * 1000 / max(1, cartaz.largura(v, 1000, True)) for v, _ in caixas])
    for i, (valor, rotulo) in enumerate(caixas):
        f.txt(m + i * larg_caixa, valor, tam_num, True)
        f.txt(m + i * larg_caixa, rotulo, 10 * k, cinza=True, y=f.y - 14 * k)
    f.y -= 26 * k
    avisos = []
    if t.get("provas"):
        avisos.append(f"{_n(t['provas'])} {'prova' if t['provas'] == 1 else 'provas'} antes de imprimir.")
    if t.get("erros"):
        avisos.append(f"{_n(t['erros'])} {'impressão não saiu' if t['erros'] == 1 else 'impressões não saíram'} "
                      "por erro da impressora (não contam na cota).")
    for a in avisos:
        f.y -= 13 * k
        f.txt(m, a, 10 * k, cinza=True)
    f.y -= 22 * k

    def titulo(texto, nota=""):
        f.cabe(60 * k)
        f.txt(m, texto, 14 * k, True)
        f.y -= 6 * k
        f.linha()
        f.y -= 16 * k
        if nota:
            for linha in cartaz.quebrar(nota, 9.5 * k, util):
                f.txt(m, linha, 9.5 * k, cinza=True)
                f.y -= 12 * k
            f.y -= 2 * k

    # ---- para que foi impresso
    titulo("Para que foi impresso")
    if not info["por_finalidade"]:
        f.txt(m, "Nada impresso neste período.", 11 * k, cinza=True)
        f.y -= 22 * k
    else:
        maior = max(1, *[d["paginas"] for d in info["por_finalidade"]])
        tam = 10.5 * k
        larg_nome, larg_barra = util * 0.40, util * 0.34
        for d in info["por_finalidade"][:20]:
            f.cabe(20 * k)
            nome = d["nome"] + (f": {d['texto']}" if d.get("texto") else "")
            f.txt(m, _cortar(nome, tam, larg_nome - 6 * k), tam)
            f.retangulo(m + larg_nome, f.y - 1 * k, max(1.5, larg_barra * d["paginas"] / maior), 8 * k, 0.55)
            pct = round(100 * d["paginas"] / t["paginas"]) if t["paginas"] else 0
            f.direita(m + util, f"{_n(d['paginas'])}  ({pct}%)", tam, True)
            f.y -= 17 * k
        if len(info["por_finalidade"]) > 20:
            f.txt(m, f"e mais {len(info['por_finalidade']) - 20} (veja na planilha)", 9.5 * k, cinza=True)
            f.y -= 17 * k
    f.y -= 12 * k

    # ---- quem imprimiu
    titulo("Quem imprimiu")
    if not info["por_pessoa"]:
        f.txt(m, "Ninguém imprimiu neste período.", 11 * k, cinza=True)
        f.y -= 22 * k
    else:
        tam = 10.5 * k
        c_imp, c_pag, c_custo = m + util * 0.62, m + util * 0.80, m + util
        f.txt(m, "Pessoa", 9.5 * k, True, True)
        f.direita(c_imp, "impressões", 9.5 * k, True, True)
        f.direita(c_pag, "páginas", 9.5 * k, True, True)
        if t.get("custo", 0) > 0:
            f.direita(c_custo, "custo", 9.5 * k, True, True)
        f.y -= 16 * k
        for u in info["por_pessoa"][:60]:
            f.cabe(20 * k)
            f.txt(m, _cortar(u["nome"], tam, util * 0.58), tam)
            f.direita(c_imp, _n(u["impressoes"]), tam)
            f.direita(c_pag, _n(u["paginas"]), tam, True)
            if t.get("custo", 0) > 0:
                f.direita(c_custo, _reais(u["custo"]), tam)
            f.y -= 16 * k
        if len(info["por_pessoa"]) > 60:
            f.txt(m, f"e mais {len(info['por_pessoa']) - 60} pessoas (veja na planilha)", 9.5 * k, cinza=True)
            f.y -= 16 * k
    f.y -= 12 * k

    # ---- pontos de atenção
    titulo("Pontos de atenção",
           f"Impressões a partir de {_pag(info.get('alerta_grande', 50))}, o mesmo arquivo 3 vezes ou mais, e quem "
           "imprimiu o dobro da média. Servem para conversar, não provam uso errado.")
    if not info["atencao"]:
        f.txt(m, "Nada fora do comum neste período.", 11 * k, cinza=True)
        f.y -= 20 * k
    else:
        tam = 10.5 * k
        for a in info["atencao"][:30]:
            linhas = cartaz.quebrar(a.get("texto_pdf") or a["texto"], tam, util - 12 * k)
            f.cabe(len(linhas) * 14 * k + 6 * k)
            f.txt(m, "-", tam, True)
            for linha in linhas:
                f.txt(m + 12 * k, linha, tam)
                f.y -= 14 * k
            f.y -= 4 * k
    return f.bytes(f"Gerado em {info.get('gerado_em', '')} pelo Folha a Folha. Não gasta cota.")
