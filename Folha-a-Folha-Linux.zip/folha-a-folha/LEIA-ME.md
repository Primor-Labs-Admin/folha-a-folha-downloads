# Folha a Folha

Controle de cotas de impressão para escolas, empresas e outras organizações.

Cada pessoa da equipe tem uma cota mensal em cada impressora. O sistema avisa quando a cota está acabando e trava a impressão quando ela termina. As pessoas podem conversar entre si e passar páginas umas para as outras, dentro das regras que o gestor escolher.

Cada impressão registra **para que ela é** (as finalidades são escolhidas pelo gestor), a pessoa **confere a prévia** antes de gastar a cota e pode imprimir **uma prova** antes do resto. O gestor vê tudo o que foi impresso, por quem e para quê, em **Gestão, Relatórios**.

## Três jeitos de instalar: local, central da TI ou unidade

Na primeira configuração, o Folha a Folha pergunta **como vai ser esta instalação**:

| Tipo | Para quem | Como funciona |
|---|---|---|
| **Só este lugar** | Uma escola, uma empresa pequena, um setor | Quem instala é o gestor e decide tudo ali: pessoas, cotas e impressoras. É o jeito das versões anteriores. |
| **Central da TI** | A TI de uma prefeitura, secretaria ou empresa com vários setores | A TI cria os **setores** (ex.: Educação › Escola Alfa; Saúde › UBS Centro), dá a **cota de cada um** em páginas por mês e escolhe os **gestores de setor**. Setores na mesma rede imprimem pela própria central. |
| **Unidade de uma central** | Uma escola, UBS ou filial com aparelho próprio (computador ou caixinha) | O aparelho recebe da TI o nome da unidade, a cota e as regras, e imprime sozinho, mesmo sem internet. |

### Cotas em cascata

- Cada setor só entrega o que recebeu: **a soma das cotas das pessoas e dos setores de dentro não passa da cota do setor**. O sistema recusa na hora de salvar.
- Na ficha de cada setor, a TI escolhe se o gestor **pode passar da cota, com justificativa** (fica em Exceções, para a TI ver) e se o setor **pode ter cota negativa**.
- A TI também escolhe **quem cadastra as pessoas** de cada setor: a própria TI ou o gestor do setor.
- O **gestor de setor** entra no app com o usuário e a senha dele e vê, em Gestão, só o setor dele (e os de dentro): Resumo, Relatórios, Equipe e Regras do setor.
- Pessoas de setores diferentes não passam páginas umas para as outras: a cota de cada setor é da TI.
- Na instalação local, vale a mesma ideia com a impressora: a soma das cotas das pessoas não passa da **cota do grupo** da impressora (quando há uma).

### Ligar uma unidade com aparelho próprio

1. Na central, em **Gestão, Setores**, crie a unidade e marque **Unidade com aparelho próprio**.
2. **Pela rede:** toque em **Código**. O código vale 7 dias e uma vez só. No aparelho da unidade, na primeira configuração, escolha **Unidade de uma central**, informe o endereço da central (por exemplo `http://10.0.0.5:8080`) e o código.
3. **Sem internet:** toque em **Pendrive** e leve o arquivo baixado. No aparelho da unidade, escolha **Unidade de uma central** e carregue o arquivo. O arquivo traz a chave da unidade: guarde como uma senha.
4. Pronto: o aparelho vira a unidade (o nome vem da central) e o gestor dele cadastra as pessoas e divide a cota, se a TI deixou o cadastro com ele.

**Depois de ligada:**
- Com rede, a unidade conversa com a central a cada 5 minutos. Ela manda os números do mês e recebe as cotas e as regras. Em Gestão, Ajustes, **Central da TI**, há **Sincronizar agora**.
- Sem rede, a impressão continua com as últimas cotas recebidas. Para levar os números à TI: **Baixar relatório para a central** (pendrive) e, na central, **Carregar relatório de unidade**. Para trazer mudanças da TI: na central, **Pendrive**; na unidade, **Carregar arquivo da central**.
- Só a unidade chama a central: não é preciso abrir porta no roteador da unidade. Se a central ficar na internet, coloque-a atrás de um servidor com HTTPS (por exemplo nginx ou Caddy); na rede interna da prefeitura, não precisa.
- A cota da unidade chega **assinada pela central** (assinatura digital Ed25519). Se alguém mexer no banco do aparelho para aumentá-la, a assinatura deixa de conferir e a unidade fica sem poder aumentar cotas até sincronizar de novo.
- O relatório leva os números do mês (páginas, custo, páginas por finalidade e por impressora, excedentes e aumentos), o contador de cada impressora e as justificativas de quando a unidade passou da cota do setor. Os nomes de arquivos e o detalhe por pessoa ficam na unidade, com o gestor de lá. Com o cadastro pela TI, o pacote da central leva os nomes e os usuários das pessoas da unidade e o resumo protegido da senha (a senha em si não vai no pacote). A senha dessas pessoas é cuidada pela TI, na central.
- Quem tem acesso de administrador ao aparelho da unidade ainda consegue mexer nas cotas das pessoas direto no banco. A central não impede, mas percebe pelo relatório: o cartão da unidade, em Setores, mostra **Acima da cota** (o aparelho entregou mais páginas do que recebeu) ou **Usou mais que a cota** (as páginas do mês passam do que a cota e a cota negativa explicam). Guarde o aparelho como se guarda a impressora.
- A sincronização confere o relógio: se o do aparelho estiver mais de 10 minutos diferente do da central, aparece um aviso (a virada do mês e a licença dependem da data).

## Empresa, escola ou outra organização

Na primeira configuração, o gestor escolhe onde o Folha a Folha vai ser usado: **Empresa**, **Escola** ou **Outra organização**. Isso muda só as palavras das telas ("devolver à empresa", "a escola pede uma prova"), os exemplos dos campos e as finalidades sugeridas. As regras são as mesmas. Dá para trocar depois em **Gestão, Ajustes, Geral**.

Desde a versão 2.6.0, nenhuma tela fala de escola se o lugar não for uma escola: os exemplos acompanham o tipo escolhido. Quem já usava o app antes continua com o tipo que tinha.

| Tipo | Finalidades sugeridas (além de Documento pessoal e Outro) |
|---|---|
| Escola | Atividade pedagógica, Planejamento e formação, Documento da escola |
| Empresa | Trabalho e clientes, Documento interno, Treinamento e estudo |
| Outra organização | Atividades do dia a dia, Documento interno, Formação e estudo |

Quem administra é o **gestor** (antes chamado de "direção"). As outras pessoas são **usuários**. Pode haver mais de um gestor.

## Os dois estilos de instalação

Na primeira configuração, o gestor escolhe como a equipe vai imprimir. Dá para trocar depois, em **Gestão, Impressoras, Estilo de instalação**, sem reiniciar o programa.

| | Só pelo navegador | Como impressora (recomendado) |
|---|---|---|
| O que se instala nos aparelhos | Nada | A impressora "Folha a Folha", uma vez em cada computador e celular |
| Como a pessoa imprime | Abre o app no navegador e envia os arquivos (PDF, foto, Word, Excel ou PowerPoint) | Imprime de qualquer programa escolhendo "Folha a Folha" e libera no app. O envio de arquivos pelo app continua valendo. |
| Escolha da impressora de verdade | Na tela Imprimir, antes de enviar | Na hora de liberar, vendo o saldo de cada uma |
| Rede | Só o endereço do app (porta 8080) | Também a impressora: porta 8080, 631 quando livre e anúncio no Wi-Fi (porta UDP 5353) |
| Bom para | Começar rápido, equipe que imprime mais pelo celular | Quem imprime do Word, do Excel, do navegador e de outros programas no computador |

No estilo navegador, a impressora Folha a Folha fica desligada: não aparece na rede e não recebe documentos.

## Como funciona (estilo impressora)

```
 Computador ou celular    Imprimir ▸ "Folha a Folha", de qualquer programa
           │
           ▼
 Computador do sistema    guarda o documento até a pessoa abrir o app,
           │              escolher a impressora e liberar (senha + saldo)
           ▼
 Impressora de verdade    a laser do escritório, a colorida, a alugada…
```

- O programa roda em **um computador do lugar** (Windows ou Linux) onde as impressoras de verdade estão instaladas.
- Nos outros computadores e nos celulares, a equipe instala **uma impressora só: a Folha a Folha**. Imprime de qualquer programa, como sempre.
- O documento **não sai no papel na hora**. Ele fica aguardando no sistema. A pessoa abre o app, vê "1 impressão aguardando", escolhe **em qual impressora de verdade** vai sair (vendo o saldo de cada uma), ajusta as cópias e toca em **Imprimir**. Com vários documentos esperando, **Liberar todas** manda todos de uma vez.
- O sistema confere a cota e só envia se houver saldo. Se faltar, a pessoa pode liberar em outra impressora ou pedir páginas a colegas. O que ninguém liberar é apagado sozinho depois de algumas horas (4, se não mudar), sem gastar páginas.
- Também dá para mandar arquivos direto pelo app, na tela **Imprimir**. É o caminho do iPhone e é o único caminho no estilo navegador.
- Cada página impressa conta 1 (frente e verso conta 2, porque são dois lados impressos).

### Importante: o bloqueio só vale para o que passa pelo sistema

Se alguém conseguir imprimir **direto** na impressora de verdade, o sistema não fica sabendo e não consegue impedir. Um celular no mesmo Wi-Fi costuma encontrar a impressora sozinho. Por isso, feche as impressoras de verdade para todos, menos para o computador do sistema. Para a equipe, a única impressora que aparece passa a ser a Folha a Folha.

## Como fechar a impressora

Faça na ordem. Em impressora alugada (de prefeitura, de contrato de locação), peça à empresa locadora ou à TI, com o conhecimento de quem fiscaliza o contrato: são ajustes comuns e costumam ser feitos sem custo.

1. **Escolha como ligar a impressora.**
    - **Por cabo USB ao computador do sistema** (o mais simples e o mais seguro): tire o cabo de rede da impressora e desligue no painel dela o Wi-Fi, o Wi-Fi Direct, o AirPrint e o Mopria. Sem rede, ninguém chega nela por outro caminho. O computador precisa ficar perto da impressora e ligado. A digitalização pela rede (para pasta ou e-mail) pode deixar de funcionar.
    - **Em rede:** siga os passos abaixo.
2. **Abra a página de configuração da impressora.** No navegador do computador do sistema, digite o endereço IP dela. O IP aparece no painel da impressora ou na página de configuração que ela imprime.
3. **Coloque senha de administrador** na página e no painel, para ninguém desfazer os ajustes.
4. **Aceite trabalhos só do computador do sistema.** Procure "Controle de acesso", "Filtro de IP" ou "Access Control List" e cadastre só o IP do computador do sistema. Antes, reserve esse IP no roteador, para ele não mudar.
5. **Desligue as portas de entrada automáticas:** Wi-Fi Direct, AirPrint, Mopria, impressão por e-mail e impressão na nuvem do fabricante (por exemplo, HP ePrint). Se houver, desligue também "Bonjour" ou "mDNS", que fazem a impressora aparecer sozinha nos celulares.
6. **Deixe o SNMP ligado** (só em rede), com a comunidade "public" ou outra que você anote. É por ele que o Folha a Folha lê o contador.
7. **Nos outros computadores:** remova as impressoras de verdade e instale neles a **Folha a Folha** (veja abaixo). Não compartilhe as impressoras do computador do sistema na rede do Windows. No computador do sistema, use uma conta de usuário comum.
8. **Se a TI puder,** coloque as impressoras numa rede separada, que só o computador do sistema enxerga.

### No próprio computador do sistema

A impressora de verdade precisa continuar instalada no computador do sistema, porque é por ela que o Folha a Folha imprime. Sem mais nada, os programas desse computador (navegador, LibreOffice, visualizador de fotos) continuam imprimindo direto nela.

**Linux (Ubuntu, Mint):** rode uma vez, no Terminal, de dentro da pasta do programa:

```bash
sudo sh ferramentas/so-pela-folha-a-folha.sh
```

Antes, feche a janela do Folha a Folha (Ctrl + C) e confira em **Gestão, Impressoras** se o estilo é **Como impressora**. O comando:
1. cria o usuário de sistema `folhaafolha` e copia o programa, com a pasta `dados`, para `/opt/folha-a-folha`;
2. liga o Folha a Folha como serviço desse usuário, sozinho quando o computador liga (não precisa mais da janela do Terminal);
3. faz cada impressora de verdade aceitar trabalhos **só desse usuário** e desliga o compartilhamento delas: quem tentar imprimir direto nela, de qualquer programa, recebe "não autorizado";
4. instala a impressora **Folha a Folha** neste computador e a deixa como padrão.

Para desfazer: `sudo sh /opt/folha-a-folha/ferramentas/so-pela-folha-a-folha.sh --desfazer` (as impressoras voltam a aceitar qualquer programa).

**Para atualizar depois:** descompacte a versão nova em qualquer pasta e rode o mesmo comando de dentro dela. O programa em `/opt/folha-a-folha` é trocado e os dados de lá são mantidos.

**Trocou a impressora de rede para USB?** Instale-a de novo pelo USB (Configurações, Impressoras), apague a fila antiga, confira em **Gestão, Impressoras, Editar** se "Impressora deste computador" aponta para a fila nova e rode o comando de novo, para ele travar a fila nova.

**Windows:** ainda não há esse passo automático. Use para o sistema um computador em que ninguém imprima por outros programas.

**A cópia no vidro continua livre.** Numa multifuncional, quem tira cópia direto na máquina não passa por sistema nenhum. Há duas saídas:
- **Códigos de usuário da própria impressora** (muitas têm "contabilidade de trabalhos" com cota), que exigem um código no painel para copiar.
- **Liberação na impressora com senha ou crachá,** se a empresa locadora oferecer.

## Impressora Folha a Folha (computadores e celulares)

Só no estilo impressora. Quando o sistema está ligado, ele aparece na rede como uma impressora chamada **Folha a Folha**. O endereço aparece na janela do programa e em **Gestão, Impressoras**, por exemplo `http://192.168.0.15:8080/ipp/print`. Na tela **Imprimir** do app há o passo a passo para cada aparelho.

**Windows 10 e 11**
1. Configurações, Dispositivos (ou Bluetooth e dispositivos), Impressoras e scanners, **Adicionar**.
2. Se "Folha a Folha" aparecer, clique nela e pronto.
3. Se não aparecer: **"A impressora que eu quero não está na lista"**, **"Selecionar uma impressora compartilhada pelo nome"** e cole o endereço `http://…/ipp/print`.
4. Se pedir driver, escolha o fabricante **Microsoft** e o modelo **Microsoft IPP Class Driver**.

**Linux (Ubuntu, Mint e outros)**
1. Configurações, Impressoras, Adicionar. "Folha a Folha" aparece sozinha.
2. Ou no terminal: `sudo lpadmin -p Folha_a_Folha -E -v ipp://192.168.0.15:8080/ipp/print -m everywhere` (troque pelo endereço do seu sistema).

**Android**
1. Configurações, Dispositivos conectados (ou Conexões), Impressão, **Serviço de impressão padrão** ligado.
2. No mesmo Wi-Fi do computador do sistema, "Folha a Folha" aparece sozinha ao tocar em Imprimir em qualquer app.
3. Se não aparecer: **Adicionar impressora** e informe só o IP do computador do sistema. Isso funciona quando a porta 631 está livre no computador do sistema (normal no Windows; no Linux ela é do CUPS, e o Android acha a Folha a Folha pelo anúncio no Wi-Fi).

**iPhone e iPad:** ainda não aparecem como impressora. A pessoa salva em PDF e envia pela tela **Imprimir** do app.

**De quem é cada impressão?** Desde a versão 2.1, a Folha a Folha **só aceita documentos de quem está com o app aberto** no aparelho de onde imprime:
1. Abra o app no computador ou no celular e entre com seu usuário e senha.
2. Imprima pela Folha a Folha, de qualquer programa. O documento vai **só para você**: ninguém mais vê, nem quem usar o mesmo computador depois.
3. Libere no app (de qualquer aparelho em que você entrar).
- **Sem ninguém com o app aberto e desbloqueado naquele aparelho**, a impressora recusa o documento. O programa mostra o aviso para abrir o app e entrar antes. Isso protege os computadores compartilhados: nada fica guardado para quem chegar depois.
- O app deixado aberto em segundo plano continua valendo (ele avisa o sistema a cada 30 segundos). Fechado há mais de 3 minutos, ou com a tela bloqueada por falta de uso, não vale.
- Com **duas pessoas** com o app aberto no mesmo aparelho, a impressora recusa e pede para sair das outras contas.
- Se a pessoa tem **login próprio** num computador (por exemplo `ana.silva`), o gestor coloca esse nome em **Equipe**, na ficha dela, em **Nome de usuário no computador**. Aí o que sai desse login é dela mesmo sem o app aberto, e ela libera **também pelo celular**.
- O gestor pode voltar ao jeito antigo em **Gestão, Impressoras, Impressora Folha a Folha**, desligando **Só aceitar de quem está com o app aberto**. Aí quem abre o app no aparelho de onde saiu a impressão vê o documento para liberar, como na versão 2.0.

**Ajustes do gestor** (em **Gestão, Impressoras**, seção Impressora Folha a Folha):
- **Uma Folha a Folha para cada impressora:** além da geral, aparece uma fila com o nome de cada impressora, por exemplo "Folha a Folha - Colorida". O documento já chega sugerindo aquela impressora. Continua precisando liberar no app.
- **Anunciar no Wi-Fi:** faz os aparelhos acharem a Folha a Folha sozinhos. Desligue se a rede for compartilhada com outros prédios ou empresas.
- **Horas para liberar antes de apagar:** de 1 a 72. O padrão é 4.
- A lista **Aguardando liberação** mostra o que está na fila. O gestor pode descartar.

## Licença e chave de ativação

- **Avaliação:** sem chave, o Folha a Folha funciona completo por **90 dias** a partir da instalação.
- **Chave de ativação:** depois da compra, o desenvolvedor envia por e-mail uma chave que começa com `FAF1.`. O gestor abre **Gestão, Ajustes, Licença e ativação**, cola a chave inteira e toca em **Ativar**. A tela mostra para quem é a licença, o plano e a validade.
- **Avisos:** 15 dias antes do fim, o gestor vê um aviso no Início.
- **Carência:** depois do vencimento, a impressão continua por mais **30 dias**, com aviso.
- **Depois disso,** a impressão (e a liberação de documentos) para até o gestor colar a chave de renovação. Nada é apagado: cadastros, cotas, mensagens e relatórios continuam lá, e o gestor continua acessando tudo.
- **Renovação:** a chave nova substitui a antiga na mesma tela e vale na hora.
- A chave é conferida neste computador, sem internet. Nenhum dado é enviado para conferir a licença.

## Conferência com o contador

O Folha a Folha compara o contador total da impressora com as páginas que passaram pelo sistema. A diferença é o que saiu por fora: cópias no vidro, impressões diretas e relatórios da própria máquina.

- **Impressora em rede:** em **Gestão, Impressoras, Editar**, informe o IP da impressora. O sistema lê o contador sozinho, de hora em hora. O botão **Ler contador** faz uma leitura na hora.
- **Impressora por USB:** use **Anotar contador** e digite o total que aparece no painel da impressora, no primeiro e no último dia de cada mês.
- O resultado aparece no **Resumo do mês**: páginas no contador, páginas pelo sistema, páginas fora do sistema e quanto elas custaram.
- Se o contador diminuir (impressora trocada, por exemplo), o sistema pede confirmação antes de registrar.

## Só desconta o que saiu (Linux)

No Linux, o Folha a Folha acompanha cada impressão no servidor de impressão do computador (o CUPS) até ela sair da fila:

- **Enquanto está na fila**, as páginas ficam reservadas: já aparecem como usadas, mas ainda não valem de vez. No **Início**, a pessoa vê a impressão e o que está acontecendo ("Imprimindo", "Parada na impressora: sem papel", "a impressora não responde"), com o botão **Cancelar impressão**.
- **Terminou bem:** as páginas ficam descontadas.
- **Cancelada ou com erro:** as páginas voltam sozinhas para a cota, e a pessoa recebe um aviso no Início. Se a impressora chegou a mandar parte, conta só essa parte.
- **Além da cota:** a parte que não saiu também sai do registro e do desconto do mês seguinte.
- **O gestor** vê a situação em **Relatórios** e pode cancelar impressões presas na fila.

**Com o IP da impressora** (em **Gestão, Impressoras, Editar**) e a opção **Descontar só o que a impressora contar** ligada, o sistema vai além e confere pelo contador da própria máquina:

- Cada impressão espera a anterior terminar naquela impressora. O sistema lê o contador antes de soltar e depois que ela acaba, e desconta só o que a máquina contou. Se o papel enroscar e alguém cancelar depois de 3 de 10 páginas, descontam 3.
- O sistema espera a impressora ficar em repouso antes de fechar a conta. Enquanto ela diz que está com papel enroscado, sem papel ou com a tampa aberta, o resto ainda pode sair.
- Nunca desconta mais do que o pedido. Cópias feitas no vidro durante a impressão não pesam para ninguém.
- Só começa a devolver pelo contador depois da primeira impressão completa em que o contador bateu. Isso evita devolver páginas de impressoras que atualizam o contador com atraso. Trocou o IP ou a impressora, confere de novo.
- Se a impressora não responder ao contador por 2 minutos, a impressão segue só pelo acompanhamento do CUPS.

**No Windows**, as páginas continuam sendo descontadas quando a impressão vai para a impressora. Lá, o computador não diferencia uma impressão que terminou de uma que foi cancelada. Se algo não sair, o gestor devolve em **Relatórios, Devolver páginas**.

## Instalação no Windows

1. **Python**: instale o **Python Install Manager** pela Microsoft Store (ou pelo site <https://www.python.org/downloads/>). Depois, no Prompt de Comando, rode `py install 3.13`. Sem a Store, use o instalador tradicional do Python 3.13 e, na primeira tela, **marque "Add python.exe to PATH"**. O Folha a Folha foi testado com o Python 3.11, 3.12 e 3.13.
2. **Impressoras**: instale as impressoras neste computador, se ainda não estiverem, e faça uma página de teste pelo Windows.
3. **SumatraPDF** (necessário no Windows): baixe a versão *portable* em <https://www.sumatrapdfreader.org/download-free-pdf-viewer>, renomeie para `SumatraPDF.exe` e coloque na pasta `ferramentas`.
4. **LibreOffice** (recomendado): com ele instalado, a equipe também pode enviar arquivos do Word, do Excel e do PowerPoint pelo app. Sem ele, envia PDF ou foto.
5. **Miniaturas da prévia** (recomendado): instale o **Ghostscript** (<https://ghostscript.com/releases/gsdnld.html>, versão de 64 bits) ou copie o `pdftoppm.exe` do **Poppler para Windows**, com as DLLs que vêm junto, para a pasta `ferramentas`. Sem nenhum dos dois, a prévia abre o PDF no leitor do navegador, sem as folhas desenhadas lado a lado. Em **Gestão, Impressoras, Este computador** aparece se o programa foi encontrado.
6. Dê dois cliques em **`iniciar.bat`**. Uma janela preta mostra o endereço, por exemplo `http://192.168.0.15:8080`, e o endereço da impressora Folha a Folha.
7. Na primeira vez, o Windows pergunta sobre o Firewall: **permita em "Redes privadas"**. Sem isso, os celulares e os outros computadores não conseguem acessar nem imprimir. A rede local precisa estar marcada como **Rede privada** nas configurações de rede do Windows.
8. **Ligar sozinho com o Windows**: aperte `Windows + R`, digite `shell:startup` e dê Enter. Na pasta que abrir, cole um **atalho** para o `iniciar.bat`.

## Instalação no Linux (Ubuntu, Mint e parecidos)

1. O Python 3 já vem instalado. Confira com `python3 --version`.
2. **Impressoras**: instale-as pelo menu *Impressoras* do sistema ou em <http://localhost:631>. O CUPS precisa estar instalado: `sudo apt install cups`.
3. **LibreOffice** (para arquivos do Word, do Excel e do PowerPoint; o Ubuntu costuma já trazer): `sudo apt install libreoffice-writer libreoffice-calc libreoffice-impress`.
   **Miniaturas da prévia:** `sudo apt install poppler-utils` (quase sempre já vem com o CUPS).
4. Na pasta do programa, rode `./iniciar.sh`. A janela mostra o endereço para os celulares, como `http://192.168.0.15:8080`. Para conferir o IP do computador: `hostname -I`.
5. Se houver firewall: `sudo ufw allow 8080/tcp` e `sudo ufw allow 5353/udp` (anúncio no Wi-Fi).
6. **Anúncio no Wi-Fi:** com o Avahi (já vem no Ubuntu e no Mint), instale também `sudo apt install avahi-utils`. O sistema usa o Avahi para anunciar a Folha a Folha.
7. **Ligar sozinho e só imprimir pela Folha a Folha:** o mais simples é o comando `sudo sh ferramentas/so-pela-folha-a-folha.sh` (veja "No próprio computador do sistema"). **Só ligar sozinho** (estilo navegador, central da TI ou antes da primeira configuração): `sudo sh ferramentas/so-pela-folha-a-folha.sh --so-ligar`. Ele copia o programa para `/opt/folha-a-folha`, liga como serviço e mostra o endereço de rede. Se preferir fazer à mão, crie o arquivo `/etc/systemd/system/folha-a-folha.service`. Troque `/home/usuario/folha-a-folha` e `usuario` pela pasta e pelo usuário corretos:

   ```ini
   [Unit]
   Description=Folha a Folha
   After=network-online.target cups.service

   [Service]
   User=usuario
   WorkingDirectory=/home/usuario/folha-a-folha
   ExecStart=/usr/bin/python3 servidor.py
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```

   Depois rode `sudo systemctl enable --now folha-a-folha`.

## Digitalizar documentos e imagens

A tela **Escanear** aparece junto de **Imprimir**. A digitalização é independente da fila de impressão: a multifuncional pode não aparecer entre as impressoras disponíveis na rede e, ainda assim, aparecer como scanner, desde que o driver de digitalização do fabricante a exponha ao sistema operacional.

O Folha a Folha usa os serviços nativos do computador onde o servidor está rodando:

- **Windows:** WIA (Windows Image Acquisition). Instale o pacote completo do fabricante e confirme que o dispositivo aparece em **Configurações, Bluetooth e dispositivos, Impressoras e scanners** e no aplicativo **Scanner do Windows**. Drivers somente de impressão ou que exponham apenas TWAIN, sem WIA, não são suficientes para esta integração.
- **Linux (Ubuntu/Mint):** SANE. Instale `sudo apt install sane-utils`. Para scanners de rede compatíveis com eSCL/AirScan, instale também `sudo apt install sane-airscan`. Alguns fabricantes exigem instalar o backend/pacote SANE próprio. O usuário que executa o Folha a Folha precisa ter permissão de acesso ao scanner; em instalações comuns, isso pode exigir entrar no grupo `scanner` e reiniciar a sessão.

A descoberta consulta WIA ou SANE diretamente, não a lista de impressoras do CUPS/Windows. Assim, scanners de rede continuam elegíveis mesmo quando a fila de impressão está oculta ou desativada. O acesso depende de o driver de digitalização reconhecer o dispositivo; um driver de impressão não fornece, por si só, o protocolo de scanner.

As opções mostradas são limitadas ao que o driver informa: mesa de vidro, alimentador automático e duplex; modo colorido, cinza ou preto e branco; resoluções disponíveis; tamanho de papel; brilho e contraste quando oferecidos; e saída em PDF, BMP, JPG, PNG ou TIFF conforme os formatos aceitos. No alimentador, é possível informar a quantidade de páginas (limite de 100 por operação). PDF com várias páginas fica em um único documento; ao escolher imagem, várias páginas são entregues em um ZIP com um arquivo por página. O sistema oferece prévia no navegador para PDF, JPG e PNG de uma página.

Digitalizar **não consome cota de impressão**. Os arquivos temporários ficam vinculados ao usuário e são apagados automaticamente depois de 12 horas.

## Usuário e senha (versão 2.1)

- Cada pessoa entra com **usuário e senha**. A tela de entrada não mostra a lista de nomes: quem chega não vê quem trabalha ali.
- A senha tem **pelo menos 8 caracteres** e não pode ser o usuário, o nome ou algo óbvio como `12345678`. Fica guardada só como resumo protegido (PBKDF2-SHA256 com sal), no banco do computador do sistema (`dados/controle.db`). Nem o gestor nem o desenvolvedor conseguem ver a senha de ninguém.
- O gestor dá uma **senha provisória** ao cadastrar. No primeiro acesso, o app mostra o usuário da pessoa e pede que ela crie a dela (dá para desligar esse pedido no cadastro).
- Para trocar a senha, toque na sua inicial, no alto da tela. Quem troca a senha sai dos outros aparelhos onde estava.
- Errar 5 vezes seguidas faz o app esperar 30 segundos; o tempo dobra a cada nova série, até 15 minutos.
- **Cadastro pela própria pessoa:** na tela de entrada, **Criar meu cadastro**. Ela informa nome, usuário (o app sugere), senha e, se quiser, a função ou turma. O pedido fica em **Gestão, Equipe, Esperando aprovação**, sem cota e sem acesso; o Início do gestor avisa quantos esperam. O gestor toca em **Aprovar**, define as páginas por mês em cada impressora (e o setor, se houver) ou em **Recusar**. Quem tenta entrar antes da aprovação vê o aviso de que falta aprovar. No máximo 5 pedidos por hora do mesmo aparelho. O gestor desliga em **Ajustes, Geral, As pessoas podem pedir o cadastro na tela de entrada**. Numa unidade com o cadastro pela TI, não aparece.
- **Quem veio da 2.0:** cada pessoa ganhou um usuário tirado do nome (por exemplo `ana.silva`; se repetir, `ana.silva2`). Na primeira vez, ela digita o **nome** como está cadastrado e o **PIN de antes**. O app mostra o usuário e pede a senha nova. O gestor vê os usuários em **Equipe**; quem ainda não criou a senha aparece com o selo "Ainda não criou a senha".

## Primeiro uso (gestor)

1. Abra o endereço no computador ou no celular. Na primeira vez, o sistema pergunta **como vai ser a instalação** (só este lugar, central da TI ou unidade de uma central; veja a primeira seção), onde vai ser usado (escola, empresa ou outra organização), o nome do lugar, o seu nome, o seu **usuário** e uma **senha** e o **estilo de instalação** (só pelo navegador ou como impressora). Você fica como **gestor** (na central, como **TI**).
2. Em **Gestão, Impressoras**, edite cada impressora (o sistema começa com "Impressora principal" e "Segunda impressora"; troque os nomes):
   - **Impressora deste computador**: escolha a impressora real. Enquanto estiver em *Modo teste*, nada sai no papel, mas a cota é descontada. É bom para treinar a equipe.
   - **Cota mensal do grupo**: numa impressora alugada, coloque a cota contratada. Numa própria, defina a cota interna que quiserem.
3. Em **Equipe**, cadastre cada pessoa com o nome, o **usuário** (o app sugere a partir do nome, por exemplo `ana.silva`) e uma **senha provisória**. O app mostra o que entregar a ela. No primeiro acesso, a pessoa cria a senha dela, e nem o gestor fica sabendo qual é.
4. Volte em **Impressoras** e use **Dividir igualmente**, ou defina a cota de cada pessoa em **Equipe**.
5. Em **Ajustes, Controle de impressão**, confira a lista de **finalidades** e troque o que não servir.
6. **No estilo impressora:** instale a **Folha a Folha** nos computadores e mostre à equipe como adicionar no celular (seção acima). Faça uma impressão de teste de cada aparelho e libere pelo app.
7. Terminados os testes, vá em **Ajustes** e use **Apagar impressões de teste**.
   Em **Ajustes, Geral**, escolha também em quantos minutos sem uso a tela bloqueia (5, se não mudar; 0 para nunca).
8. Depois da compra, cole a chave de ativação em **Ajustes, Licença e ativação**.

**Cartaz para a equipe entrar (versão 2.6.0):** em **Gestão**, no fim da tela de Resumo, **Endereço para os celulares** tem três botões. **Imprimir cartaz** manda para a impressora que você escolher uma folha com o nome do lugar, o QR code, o endereço escrito e os passos para entrar; não conta na cota de ninguém. **Baixar cartaz (PDF)** guarda a mesma folha em A4. **Copiar endereço** copia o endereço para colar numa mensagem. Na aba **Equipe**, o botão **Cartaz com QR code para a equipe entrar** leva direto para lá. Desde a 2.6.1, o cartaz lê o endereço na hora: se o computador do sistema estiver sem rede, o app avisa e não faz o cartaz.

**QR code do endereço:** em **Gestão**, no fim da tela de Resumo, **Endereço para os celulares** mostra o endereço e um QR code dele. No app Folha a Folha do Android, toque em **Ler QR code do servidor** na tela de endereço e aponte a câmera: o app conecta sozinho. O QR só leva a endereços da rede local; se a rede mudar o endereço, o QR muda junto.

Dica: peça ao responsável pelo roteador para **reservar o IP** do computador do sistema. Assim o endereço nunca muda.

## Uso da equipe

- **Início**: mostra quantas páginas restam em cada impressora. A pilha fica amarela quando está acabando e vermelha quando acaba.
- **Escanear:** use a aba **Escanear** para escolher o scanner, ajustar origem, resolução, cor, papel e formato e digitalizar documentos ou imagens. O scanner é descoberto pelo driver WIA (Windows) ou SANE (Linux), independentemente da fila de impressão. A digitalização não desconta páginas da cota. Em PDF, dá para acrescentar páginas em várias passagens (por exemplo, usando a mesa de vidro), reuni-las em um único PDF, girar cada página e recortar suas margens antes de concluir. Girar e recortar precisam do Pillow no computador do sistema (opcional; sem ele, o PDF sai normalmente, só sem giro e recorte): no Ubuntu/Mint, `sudo apt install python3-pil`; no Windows, o `iniciar.bat` instala sozinho (ou `py -m pip install --user -r requirements.txt`).
- **Imprimir de qualquer programa:** primeiro abra o app no aparelho e entre. Depois escolha a impressora **Folha a Folha** e imprima como sempre. Volte ao app: ele vai direto para a tela de liberar (se o app já estava aberto no Início, troca de tela sozinho quando a impressão chega). Na tela **Imprimir**, escolha a impressora de verdade, as cópias, **frente e verso ou só frente** e **para que é**, e toque em **Conferir e imprimir**. Antes, o sistema mostra quantas páginas vão ser usadas e quanto custa. Para escolher só algumas páginas, toque em **Mais opções**. Se não for mais imprimir, toque em **Descartar**.
- **Liberar todas:** com dois ou mais documentos esperando, o cartão **Liberar as N de uma vez** abre uma janela com a lista, a impressora, a prova e a finalidade. Cada documento sai com as cópias e os lados que estão no seu cartão (dá para mudar no cartão antes). O sistema confere se a cota dá para todos antes de mandar o primeiro.
- **Mandar arquivos pelo app:** na mesma tela, em "ou envie um arquivo daqui", escolha um ou vários arquivos (veja "O que dá para imprimir"), a impressora, as cópias, os lados e para que é.
- **Compartilhar do celular (app Android):** em qualquer programa do celular (galeria, arquivos, WhatsApp, e-mail), toque em **Compartilhar** e escolha **Folha a Folha**. O app abre na tela de Imprimir com o arquivo já enviado, como se você o tivesse escolhido ali. Vale para PDF, fotos (JPG ou PNG) e arquivos do Word, Excel, PowerPoint e LibreOffice, até 20 de uma vez e 60 MB cada. Se você estava com um documento na tela, o novo se junta a ele. Só existe no app Android; no navegador e no iPhone continue usando **Escolher arquivos**.
- **Conferir antes:** veja a seção Controle de impressão.
- **Várias fotos, banner e páginas por folha:** veja a seção Montar as folhas.
- **Fotos (JPG ou PNG):** viram uma folha A4 antes de imprimir, em pé ou deitada conforme a foto (inclusive a foto tirada com o celular de lado), ocupando a folha com uma margem pequena. A parte transparente de um PNG sai branca. A prévia mostra a folha como vai sair.
- **Tela bloqueada:** se o app ficar parado (5 minutos, se o gestor não mudar), ele pede a senha de novo. Assim ninguém usa a cota de quem esqueceu o app aberto num computador compartilhado. Quem não for a pessoa da tela toca em **Não sou…: trocar de pessoa**.
- Se faltar saldo, aparece o botão para pedir páginas (a colegas ou à reserva, conforme a regra escolhida pelo gestor).
- **Conversas**:
  - **Devolver sobras**: no topo da tela. As páginas que a pessoa não vai usar voltam para a reserva. O que ninguém usar vira economia.
  - **Mural da equipe**: recados para todos. Um pedido de páginas feito aqui pode ser atendido por qualquer colega, e o primeiro que aceitar passa as páginas.
  - **Conversa com um colega**: mensagens, **Pedir páginas** e **Passar páginas**. A lista mostra quanto cada colega tem sobrando.
- **Histórico**: as impressões do mês e as páginas recebidas ou passadas.
- No celular, use **"Adicionar à tela de início"** no menu do navegador para ter um ícone.

## O que dá para imprimir

| Caminho | Tipos de arquivo | Vários de uma vez |
|---|---|---|
| Tela **Imprimir** do app | PDF; fotos JPG e PNG; Word, Excel e PowerPoint (`.doc`, `.docx`, `.xls`, `.xlsx`, `.ppt`, `.pptx`, `.rtf`) e os do LibreOffice (`.odt`, `.ods`, `.odp`) | Sim: até 20 arquivos (ou 40 fotos para montar) |
| Impressora **Folha a Folha** | Qualquer arquivo que algum programa do aparelho abra e imprima: o próprio programa transforma em PDF ou imagem antes de mandar | Sim: cada um fica esperando, e **Liberar todas** manda todos |

- Word, Excel e PowerPoint são convertidos em PDF pelo **LibreOffice** no computador do sistema. A formatação pode mudar um pouco, principalmente as fontes; a prévia mostra como vai sair. Sem o LibreOffice, o app pede para salvar como PDF.
- Outros tipos (TXT, GIF, WEBP, HEIC, links do Google Docs) não entram pelo app: salve como PDF, ou imprima do próprio programa pela impressora Folha a Folha.

### Vários arquivos de uma vez

- Escolha vários arquivos no seletor (no celular, toque e segure para marcar mais de um) ou, com um arquivo já escolhido, toque em **+ Mais**. Aparece a lista com as páginas de cada um. O **×** tira um arquivo da lista.
- Várias **fotos** escolhidas juntas viram uma **montagem** (veja Montar as folhas). Fotos junto com documentos entram na lista, cada uma numa folha.
- A impressora, as cópias, frente e verso, a prova e a finalidade valem para todos. Cada arquivo sai inteiro e começa numa folha nova. Para escolher páginas, imprima o arquivo sozinho.
- **Conferir antes:** com prova, cada arquivo sai com a 1ª folha (ou 1 cópia) e espera a conferência. Com a prova obrigatória a partir de N páginas, só os arquivos grandes saem com a 1ª folha; os outros saem inteiros.
- **Cota:** o sistema confere se dá para todos antes de mandar o primeiro. Se faltar, nada sai.
- **Se a impressora falhar no meio** (sem papel, desligada), os que já saíram ficam contados, o que falhou não é descontado, e os que faltam continuam na tela para tentar de novo.
- Nos relatórios, cada arquivo aparece com o próprio nome.

## Controle de impressão

Tudo se liga e desliga em **Gestão, Ajustes, Controle de impressão**. Algumas escolhas ficam com cada pessoa, em **Minha conta** (o círculo com as iniciais).

### O que é cada impressão

Há dois jeitos de perguntar, escolhidos pelo gestor em **Ajustes, Controle de impressão, Como perguntar o que é cada impressão**:

- **Campo livre** (padrão das instalações novas, desde a 2.6.0): a pessoa escreve o que é, em poucas palavras ("Ata da reunião", "Proposta para o cliente Souza"). O app põe a primeira letra maiúscula e o resto minúsculo, para os textos iguais ficarem juntos nos relatórios. Embaixo do campo aparecem os últimos textos que a própria pessoa usou: é só tocar. **É documento pessoal** é uma chave ao lado, com o limite de páginas que o gestor definir.
- **Lista de finalidades**: a pessoa escolhe uma finalidade da lista do gestor. Quem já usava o app antes da 2.6.0 continua assim, até o gestor trocar.

Nos relatórios, o campo livre mostra uma linha para cada texto (os 12 mais usados e o resto junto), e tocar numa linha filtra por ela.

Na lista de finalidades, a lista é do gestor, em **Ajustes, Controle de impressão, Finalidades**:
- Começa com as sugestões do tipo de lugar (veja a primeira seção). Dá para trocar nomes e exemplos, acrescentar (**+ Nova finalidade**, até 10) e tirar (**×**). **Voltar às sugestões** desfaz as mudanças.
- **Documento pessoal** e **Outro** estão sempre na lista: o pessoal tem limite próprio e o "Outro" pede a descrição.
- Uma finalidade tirada some da tela de imprimir, mas as impressões antigas continuam com o nome dela nos relatórios.

Também:
- Há um campo **"Do que se trata?"**, opcional. Ele é obrigatório em "Outro" e, se o gestor quiser, em todas.
- **Documentos pessoais:** até 10 páginas por pessoa por mês, somando as impressoras. O gestor muda o número, usa 0 para não permitir ou deixa vazio para não ter limite próprio (aí conta só na cota).
- **Onde perguntar:** em todas as impressoras (padrão), só nas impressoras marcadas, ou em nenhuma. As marcadas também aparecem em **Impressoras, Editar**.

### Confirmar a impressora

Quem tem cota em mais de uma impressora vê, logo acima do botão de imprimir, a caixa **"Conferi: é para sair na _nome da impressora_"**. O botão só acende depois de marcar. Se a pessoa trocar de impressora, a caixa desmarca e mostra a nova, para conferir de novo. Vale para o arquivo mandado pelo app, para a impressão que chegou pela Folha a Folha e para **Liberar todas**. Com uma impressora só, a caixa não aparece. O gestor desliga em **Ajustes, Controle de impressão, Impressora certa**.

### Prévia antes de imprimir

Ao tocar em **Conferir e imprimir**, abre uma janela com:
- as **folhas como vão sair**: com frente e verso, a página da frente e a do verso lado a lado, folha por folha (até 8 folhas; o resto é resumido). Com vários arquivos, as primeiras folhas de cada um;
- as páginas escolhidas, **frente e verso ou só frente** (com um botão para trocar ali mesmo), a **orientação** (em pé, deitada ou misturada, lida das próprias páginas), as cópias, a impressora, a finalidade e o total em páginas da cota e em folhas de papel.

Com a prévia **obrigatória** (padrão), a pessoa marca "As páginas são essas" (ou "Os arquivos são esses"), "Frente e verso (ou só frente) está certo", "A orientação está certa" e, se for mais de uma cópia, "São N cópias mesmo". O botão de imprimir só acende depois disso. O gestor pode deixar a prévia opcional (cada pessoa desliga em Minha conta) ou desligá-la.

As miniaturas são desenhadas no computador do sistema (veja Instalação). Só a própria pessoa vê a prévia do seu arquivo: nem os colegas nem o gestor abrem o documento.

### Impressão de prova

Para conferir na impressora antes de gastar a cota toda:
- **Só a 1ª folha:** sai a primeira folha (com frente e verso, as duas primeiras páginas).
- **Só 1 cópia:** quando são várias cópias, sai uma.

Depois, a pessoa vai até a impressora e confere. No app (no Início e em Imprimir) aparece **"Confira a prova na impressora"** com três botões:
- **Saiu certo: imprimir o resto.** O resto sai sem precisar enviar o arquivo de novo.
- **Ajustar.** O arquivo volta para a tela Imprimir, para mudar lados, páginas ou cópias. O resto não sai.
- **Cancelar o resto.** O arquivo é apagado. A prova já saiu e continua contada.

Antes da prova, o sistema confere se a cota dá para a impressão inteira. O resto espera até o prazo da fila (4 horas, se não mudar; no máximo 12) e depois é apagado sem gastar páginas. O gestor escolhe: a pessoa decide (padrão), **obrigatória a partir de N páginas** (20, se não mudar) ou desligada.

### Relatórios do gestor

Em **Gestão, Relatórios**:
- **Período:** o primeiro controle da tela. Escolha **Um mês** (com o seletor de mês), **Últimos 7 dias**, **Últimos 30 dias**, **Últimos 90 dias**, **Este ano** ou **Datas à escolha** (do dia… até o dia…, no máximo 2 anos). Tudo na tela, a planilha e o PDF seguem o período escolhido. A cota é do mês: num período, o relatório mostra o que foi impresso, não o saldo de cota.
- **Filtros:** ficam recolhidos no botão **Filtros**. Pessoa, impressora, finalidade e busca no nome do arquivo ou na descrição. Cada filtro ligado aparece como uma etiqueta logo abaixo do período: toque nela para tirar. **Limpar filtros** tira todos.
- **Levar o relatório:** logo abaixo dos números. **Imprimir relatório** (só o gestor geral) manda uma folha para a impressora que você escolher, sem contar na cota de ninguém. **Baixar relatório (PDF)** serve para qualquer gestor. O PDF traz o período, os filtros, os números, para que foi impresso, quem imprimiu e os pontos de atenção; **não leva nomes de arquivos**. **Baixar planilha** traz tudo, com a lista de impressões.
- **Números:** páginas, impressões, pessoas, custo e quantas provas foram feitas.
- **Para que foi impresso:** páginas e percentual de cada finalidade. Tocar numa linha filtra por ela.
- **Pontos de atenção:** impressões a partir de 50 páginas (dá para mudar em Ajustes), o mesmo arquivo 3 vezes ou mais e quem imprimiu o dobro da média da equipe no período. Servem para conversar, não provam uso errado.
- **Quem imprimiu:** cada pessoa com páginas, custo e as finalidades principais. Tocar filtra por ela. Em **Equipe**, na ficha da pessoa, **Ver tudo o que imprimiu** abre o relatório dela.
- **Impressões:** aparecem 20 de cada vez, com **Ver mais impressões** (a tela mostra até 500; a planilha traz todas). Cada uma tem nome do arquivo, finalidade, descrição, data, impressora, páginas, cópias, lados, prova e situação, e o botão **Devolver páginas** para folha enroscada ou com defeito.
- **Baixar planilha:** com os filtros e o período aplicados, inclui finalidade, descrição, lados e prova, e o total por finalidade. Num período, a primeira tabela mostra as impressões por pessoa, no lugar da cota do mês.

### Aumento de cota e cota negativa

As duas coisas ficam sempre registradas com a justificativa, em **Relatórios, Exceções do mês** e na planilha.

- **Aumento de cota:** a pessoa toca em **Pedir aumento à gestão** (no Início ou na tela Imprimir, quando falta), diz quantas páginas e para quê. O gestor vê o pedido no **Resumo do mês** e aprova tudo, uma parte ou não aprova, escrevendo o motivo (obrigatório para não aprovar). As páginas aprovadas valem só no mês. A gestão pode desligar os pedidos.
- **Cota negativa:** com um limite (por exemplo, 10 páginas por pessoa por mês), quem não tem mais cota pode imprimir até esse tanto além, escrevendo a justificativa na hora. O gestor escolhe se o que passou **sai da cota do mês seguinte** (padrão) ou só fica registrado. Com 0, ninguém passa da cota.
- Onde se ajusta: na instalação local e na unidade, em **Gestão, Ajustes, Aumento de cota e cota negativa**; na central, na ficha de cada setor (a TI) e em **Regras do setor** (o gestor do setor, dentro do que a TI permitir). Numa unidade, a cota negativa só liga se a TI permitir.

### Quem liga o quê

| Controle | Onde | Padrão |
|---|---|---|
| Como perguntar o que é | Gestor | Campo livre (instalação nova); lista de finalidades (quem já usava) |
| Onde perguntar | Gestor | Em todas as impressoras |
| Lista de finalidades | Gestor | Sugestões do tipo de lugar |
| Descrição obrigatória | Gestor | Só em "Outro" |
| Documentos pessoais por mês | Gestor | 10 páginas |
| Prévia com confirmações | Gestor | Obrigatória |
| Impressão de prova | Gestor | A pessoa escolhe |
| Destacar impressões grandes | Gestor | A partir de 50 páginas |
| Frente e verso já marcado | Cada pessoa | Desligado (começa em só frente) |
| Começar sempre com prova | Cada pessoa | Desligado |
| Ver a prévia | Cada pessoa, se o gestor deixar opcional | Ligado |
| Pedidos de aumento de cota | Gestor (e TI, por setor) | Ligado |
| Cota negativa (páginas além da cota por mês) | Gestor, dentro do que a TI permitir | 0 (desligada) |
| Descontar a cota negativa do mês seguinte | Gestor | Ligado |
| Setor passar da própria cota, com justificativa | TI | Desligado |
| Quem cadastra as pessoas do setor | TI | O gestor do setor |

### Começar o teste numa impressora

1. Em **Ajustes, Controle de impressão**, escolha **"Só nas impressoras que eu marcar"**, marque a impressora do teste e salve.
2. Avise a equipe antes, numa reunião ou por escrito.
3. Para que nada escape do relatório, **feche a impressora** para todos, menos para o computador do sistema (seção Como fechar a impressora):
   - **Se a impressora é alugada** (de prefeitura ou de contrato de locação): os ajustes (filtro de IP, senha, Wi-Fi Direct, AirPrint, troca para USB) são pedidos à empresa locadora, com o conhecimento de quem fiscaliza o contrato. Não mexa sozinho na configuração de um equipamento alugado. Enquanto isso não acontece, use o estilo navegador e a conferência com o contador, que mostra quanto foi impresso por fora.
   - **Se a impressora é própria:** o próprio lugar pode fazer os ajustes. O mais simples é ligar por cabo USB ao computador do sistema.
4. Depois de um mês, veja o relatório e decida se liga nas outras impressoras.

## Montar as folhas

Na tela **Imprimir**, logo abaixo do arquivo, aparecem as opções de montagem. A cada escolha o app monta as folhas de novo e mostra quantas vão sair. A prévia, a prova e a cota passam a valer para essas folhas.

**Fotos (uma ou várias, JPG ou PNG).** Dá para escolher várias de uma vez no seletor de arquivos.
- **Por folha:** folha inteira, 2, 4, 6 ou 9 por folha, como no "Imprimir imagens" do Windows.
- **Vezes cada foto:** a mesma foto repetida, por exemplo 4 vezes numa folha para recortar.
- **Preencher o espaço:** corta as bordas da foto para não sobrar espaço em branco. Desligado, a foto sai inteira.
- A foto gira 90° sozinha quando fica bem maior assim. Entre as fotos sai um tracejado claro para recortar.

**Banner (uma foto).** A foto é ampliada em 2, 4, 6, 9, 12 ou 16 folhas.
- O app escolhe sozinho se as folhas ficam em pé ou deitadas, para a imagem ficar o maior possível, e mostra o tamanho final (por exemplo, cerca de 95 × 59 cm em 12 folhas).
- Cada folha sai com marcas de corte nos cantos e a posição escrita na borda ("linha 2 de 3, coluna 1 de 4"). Corte nas marcas e junte as folhas.
- **Preencher todas as folhas:** corta as sobras da imagem para o banner não ter faixa branca.
- A prévia mostra o banner já montado, e o banner sai sempre só frente.

**PDF com várias páginas: páginas por folha.** Escolha 1, 2 ou 4 por folha. Com **Escolher páginas**, só as páginas escolhidas entram. Com 2 por folha, duas páginas ficam lado a lado numa folha deitada; com 4, ficam em grade. A cota conta as folhas que saem.
- Precisa do Poppler ou do Ghostscript no computador do sistema (o mesmo da prévia, veja Instalação). As páginas são redesenhadas em alta resolução (200 pontos por polegada com 2 por folha, 150 com 4).
- Documento que chegou pela impressora Folha a Folha: toque em **Mais opções** para levá-lo à tela Imprimir e escolher páginas por folha.
- **Fotos impressas pela impressora do celular** chegam como página pronta (o próprio Android monta a página), por isso não aparecem as opções de fotos por folha e banner. Para montar fotos, envie a foto pela tela **Imprimir**, em **Escolher arquivos**.

No relatório do gestor, a montagem aparece com o nome do que foi feito, por exemplo "caderno.pdf (4 páginas por folha)" ou "Banner de passeio.jpg (95 x 59 cm)".

## Tamanho na folha (versão 2.4.8)

Na tela **Imprimir**, em **Como imprimir**, documentos (PDF, Word, Excel, PowerPoint e o que chegou pela impressora Folha a Folha, por **Mais opções**) têm duas opções:

- **Ajustar à folha** (o padrão): cada página sai no maior tamanho, até 100%, em que tudo o que tem tinta cabe na área que a impressora alcança. Documento que já tem margem (o comum em Word, LibreOffice e PDF de sites) sai em **100%, igual ao original**. Só encolhe a página que tem algo encostado na beirada, e só o necessário (por exemplo, 97,6%). Página menor que o papel (A5 numa folha A4) aumenta até encher a área. Página deitada gira para caber na folha em pé.
- **Outro tamanho**: de 25% a 200% do original, de 1 em 1, nos botões − e + ou na barra. Começa em **100%**. A página fica no centro da folha; se algo encosta na beirada e cabe na área, o app empurra só o necessário para dentro, sem encolher. O que passar da área (o tracejado) não sai, e a tela diz quais páginas passam.

O desenho ao lado mostra a folha da impressora, o tracejado da área que ela alcança e a primeira página no tamanho e no lugar em que vai sair. A prévia (**Conferir e imprimir**) mostra todas as folhas do mesmo jeito. O cálculo é o mesmo da impressão: o que a prévia mostra é o que sai. A cota não muda: conta as mesmas páginas.

### Papel e área de impressão (gestão)

Nenhuma impressora alcança a beirada do papel: sobra uma faixa de 3 a 5 mm, diferente em cada modelo e às vezes em cada lado. O app usa, nesta ordem:

1. as medidas que a gestão anotou (**Medir à mão**);
2. o que a impressora informa ao CUPS (Linux);
3. o driver da impressora (arquivo PPD, no Linux);
4. sem nada disso, 4,2 mm de cada lado (estimado; a tela avisa).

Para ficar exato, em **Gestão → Impressoras → Editar → Papel e área de impressão**:

1. Toque em **Imprimir página de calibração**. Sai uma folha em tamanho real com uma escadinha de traços em cada borda: o primeiro na beirada (0 mm), depois 0,5 mm, 1 mm... até 10 mm. Não conta na cota de ninguém.
2. Em cada borda, veja o **menor número cujo traço saiu inteiro**. Esse é a margem daquele lado.
3. Ligue **Medir à mão**, anote os quatro números (em cima, embaixo, esquerda, direita) e toque em **Salvar**.

No mesmo lugar, **Papel** diz qual papel está na bandeja (A4, Carta, Ofício, Legal, A5 ou A3). Deixe em "O que a impressora usa" se a impressora já está certa no computador; escolha um papel quando ela estiver configurada com um e imprimir em outro. Com papel escolhido, o app pede esse papel ao CUPS em cada impressão.

- A preferência **Começar no tamanho original (100%)** (em Minha conta) abre a tela em **Outro tamanho**, 100%.
- Vale também para a prova: a prova e o restante saem no mesmo tamanho. Em vários arquivos de uma vez, cada documento tem o próprio cálculo; as fotos saem como sempre (elas têm o próprio Tamanho na folha, em Montar as folhas). Impressões que chegam pela impressora Folha a Folha e são soltas da fila saem em **Ajustar à folha**.
- **Como funciona:** o app faz uma cópia do PDF em que cada página já tem o tamanho do papel da impressora, com o conteúdo na escala e no lugar calculados. O texto continua vetorial e nítido, e campos de formulário e links acompanham. Para saber onde há tinta, o app desenha cada página em baixa resolução com o Poppler, o MuPDF ou o Ghostscript (sem nenhum deles, a página inteira conta como conteúdo, e Ajustar encolhe um pouco mais). Depois, pede ao CUPS (Linux) para não redimensionar nem reposicionar (`print-scaling=none`, `fit-to-page=false` e, com papel escolhido, `media=`), ou ao SumatraPDF (Windows) para imprimir sem escala (`noscale` e `paper=`). A cópia é apagada logo depois de ir para a impressora.
- **PDF protegido por senha** (comum em documentos baixados de sites oficiais): não dá para redesenhar sem perder nitidez. O app desenha as páginas escolhidas como imagem, em alta resolução (300 pontos por polegada, ou 200 com mais de 30 páginas), no mesmo tamanho e lugar, se houver Poppler, MuPDF ou Ghostscript no computador do sistema. Sem eles, **Ajustar à folha** imprime com o ajuste automático do sistema de impressão, e os outros tamanhos avisam que não dá.

## Trocas de páginas

O gestor escolhe como as páginas circulam, em **Gestão, Trocas**:

| Regra | Como funciona |
|---|---|
| **Com limite** (padrão) | Cada pessoa passa até uma parte da própria cota por mês (50%, se não mudar) e recebe de colegas até outra parte (100%). Quem tem cota 0 numa impressora não recebe páginas dela. |
| **Livre entre colegas** | Qualquer pessoa passa para qualquer colega, sem limite. |
| **Pela reserva** | Ninguém passa para ninguém. Quem tem sobra devolve para a reserva; quem precisa pede à reserva. Até 20 páginas por pessoa por mês saem na hora (dá para mudar ou usar 0); acima disso, o gestor libera ou recusa na mesma tela. |

- A reserva de cada impressora é a cota do grupo menos o que foi distribuído, mais o que foi devolvido, menos o que foi liberado.
- Em qualquer regra, a pessoa pode **devolver sobras**, e as páginas trocadas valem só no mês. Ninguém junta estoque para o mês seguinte.
- Na hora de passar páginas, todos veem o aviso: "As páginas são da escola (ou da empresa, ou da organização). Passar é ajuda entre colegas; não é permitido vender nem trocar por pagamento."
- A tela **Trocas** mostra os números do mês, quem mais passou, quem mais recebeu e as **trocas que se repetem** (a mesma dupla 3 vezes ou mais no mês, ou em 3 meses seguidos). Isso não quer dizer que haja algo errado, mas vale uma conversa.
- A planilha do mês lista todas as trocas, devoluções e liberações da reserva.

## Quanto custa e quanto economiza

Em **Gestão, Impressoras, Editar**, informe para cada impressora:

- **Custo por página (R$):** numa impressora alugada, o valor por página do contrato (por exemplo, 0,37). Numa própria, a soma de papel e toner.
- **Páginas por mês antes do sistema** (opcional): a média dos meses anteriores, pelo contador da impressora ou pela fatura.

Com isso:

- Cada pessoa vê quanto custa cada impressão antes de imprimir, e quanto já gastou no mês.
- O **Resumo do mês** mostra o gasto em reais de cada impressora e uma tabela **mês a mês** com páginas, gasto e **economia** em relação à média de antes. O mês em que o sistema começou fica fora da comparação, porque está incompleto.
- A planilha do mês traz o gasto de cada pessoa e o custo de cada impressão.

Cada impressão guarda o preço do dia em que foi feita. Mudar o preço depois não altera o que já foi impresso. Impressões feitas antes de o preço ser informado passam a usar o preço novo.

Atenção: se o contrato cobra uma franquia mínima de páginas por mês, a economia real só existe nas páginas acima dela.

## Privacidade (LGPD)

- Em **Gestão, Ajustes, Privacidade**, preencha o nome e o CNPJ da empresa que mantém o sistema, o contato de privacidade dela e o contato da gestão. Esses dados aparecem no aviso de privacidade.
- Cada pessoa vê o aviso no primeiro acesso e confirma com **Entendi**. Ele fica sempre disponível em **Minha conta, Privacidade** e na tela de entrada.
- As mensagens são apagadas automaticamente depois do prazo escolhido. O padrão é 12 meses.
- Os arquivos enviados para imprimir são apagados logo depois da impressão (o arquivo do Word, do Excel ou do PowerPoint é apagado assim que vira PDF). O que ninguém liberar é apagado sozinho no prazo da fila (4 horas, se não mudar) e os arquivos mandados pelo app, em até 12 horas. Na impressão de prova, o arquivo espera a conferência e é apagado no fim (ou no prazo).
- Cada impressão guarda o nome do arquivo, as páginas, a data, o custo, a **finalidade e a descrição**. O gestor vê essa lista por pessoa. O **conteúdo** dos arquivos não fica guardado, e só a própria pessoa vê a prévia do que enviou.
- Na versão 1.4 o aviso mudou para incluir a finalidade. Quem tinha confirmado o aviso antigo vê o novo no próximo acesso e confirma de novo.
- Quando alguém sai, desative a pessoa em **Equipe**. Se ela pedir, toque em **Apagar dados pessoais**: o nome vira "Pessoa removida", e as mensagens, os nomes de arquivos e as descrições das impressões são apagados. Os números de páginas continuam nos relatórios. Não dá para desfazer.

## Regras das cotas

- A cota recomeça **todo dia 1º**. O que sobrou **não acumula**.
- Páginas trocadas entre colegas valem **só para o mês em que foram passadas**. Pedidos não atendidos expiram na virada do mês.
- Se a impressora der erro, a impressão **não é descontada**.
- Se a folha enroscar ou sair com defeito, o gestor usa **Relatórios, Devolver páginas**.
- O gestor pode **liberar ou tirar páginas** de alguém só no mês atual. Fica em **Equipe**, ao tocar na pessoa.
- A soma das cotas mensais das pessoas não passa da cota do grupo da impressora nem da cota do setor (veja Cotas em cascata). Diminuir sempre pode.
- Quem imprimiu além da cota (cota negativa) começa o mês seguinte com menos, se a gestão escolheu descontar. O Início avisa.
- Em **Resumo do mês** o gestor vê o total do grupo, quanto foi distribuído, quanto foi impresso e quanto cada pessoa ainda tem. Ali também dá para **baixar a planilha** do mês.

## Cópia de segurança

Tudo fica na pasta `dados` (arquivo `controle.db`). Copie essa pasta de vez em quando para um pendrive. Para mudar o sistema de computador, copie a pasta inteira do programa.

## Problemas comuns

| O que acontece | O que fazer |
|---|---|
| Quero imprimir o QR code para a equipe | **Gestão**, Resumo do mês, no fim da tela: **Imprimir cartaz** (não conta na cota) ou **Baixar cartaz (PDF)**. Na aba Equipe, o botão **Cartaz com QR code para a equipe entrar** leva até lá. |
| O cartaz ou a tela mostra `http://127.0.0.1` em vez do endereço da rede | Até a 2.6.0, o programa lia o endereço uma vez só, ao ligar. Se ligasse antes de a rede ficar pronta, ficava com esse endereço, que só funciona no próprio computador. Atualize para a 2.6.1. Enquanto não atualizar, religue o programa com a rede já ligada (no Linux, como serviço: `sudo systemctl restart folha-a-folha`). |
| Em **Endereço para os celulares** aparece "Este computador não está numa rede agora" | O computador do sistema está sem Wi-Fi e sem cabo de rede. Ligue a rede e abra a aba de novo: o endereço aparece sozinho em alguns segundos, sem religar o programa. |
| Depois de atualizar, a tela continua com cara da versão antiga (por exemplo, a aba Ajustes da Gestão cortada no computador) | A aba do navegador que já estava aberta continua com a tela antiga. Recarregue a página (F5). |
| As telas falam de escola e o lugar é uma empresa | Em **Gestão, Ajustes, Geral**, troque **Onde é usado** para Empresa (ou Outra organização) e salve. As palavras e os exemplos mudam na hora. |
| Quero que a pessoa escreva o que é, em vez de escolher numa lista | Em **Gestão, Ajustes, Controle de impressão**, marque **Campo livre** em "Como perguntar o que é cada impressão" e salve. |
| Compartilhei um arquivo e o app não aparece na lista | Só aparece para PDF, fotos JPG ou PNG e arquivos do Office ou LibreOffice. Para outros tipos, salve como PDF antes. |
| Compartilhei e o app abriu sem o arquivo | Entre com seu usuário e senha, ou desbloqueie a tela: o arquivo entra logo depois. Se o app tiver sido fechado pelo Android antes disso, compartilhe de novo. |
| O celular não abre o endereço | Confira se o celular está no **mesmo Wi-Fi** do computador, se a janela do programa está aberta e se o Firewall permitiu o acesso. |
| O endereço começa com `127.` (por exemplo `127.0.1.1`) | É um endereço interno do computador e não serve para os celulares. Desde a versão 1.4.1 o programa mostra o endereço da rede. No Linux, confira com `hostname -I` (o primeiro número); no Windows, com `ipconfig` (Endereço IPv4). |
| A Folha a Folha não aparece sozinha | Adicione pelo endereço (seção Impressora Folha a Folha). Algumas redes bloqueiam o anúncio entre aparelhos ("isolamento de clientes" no roteador). |
| Imprimi e não apareceu no app | A impressão vai para quem estava com o app aberto naquele aparelho na hora de imprimir. Se o programa avisou que a impressora recusou, abra o app, entre e imprima de novo. Se imprimiu de um computador com login próprio, peça ao gestor para colocar esse nome na sua ficha. |
| A impressão apareceu e sumiu | Passou do prazo da fila e foi apagada sem gastar páginas. Imprima de novo. |
| "A impressão está parada" | A avaliação terminou ou a licença venceu há mais de 30 dias. O gestor cola a chave em **Ajustes, Licença e ativação**. |
| Chave que começa com `GIZ1.` (de antes da 2.4.9) | As chaves agora começam com `FAF1.`. A `GIZ1.` deixa de valer e o programa volta a contar a avaliação de 90 dias da instalação. Peça uma chave nova ao desenvolvedor. |
| "Chave inválida: a assinatura não confere" | A chave foi copiada pela metade ou com um caractere a mais. Copie de novo, inteira, do e-mail do desenvolvedor. |
| A Folha a Folha não aparece em nenhum aparelho | Confira se o estilo é "como impressora" em **Gestão, Impressoras**. |
| "SumatraPDF não encontrado" | Coloque o `SumatraPDF.exe` na pasta `ferramentas` (veja acima). |
| A impressora não aparece na lista | Instale-a no computador e confira se ela imprime uma página de teste pelo sistema. |
| "Não imprimiu: a impressora recusou" | Veja se a impressora está ligada e com papel. A cota não foi descontada. |
| A impressão ficou "Na fila" no Início | O motivo aparece embaixo do nome (sem papel, impressora desligada...). Resolva na impressora e ela sai sozinha, ou toque em **Cancelar impressão**: o que não saiu volta para a cota. |
| "Aguardando a vez: outra impressão está saindo" | Com o contador ligado, cada impressão espera a anterior terminar. Se a anterior travou, cancele-a (Relatórios). |
| "Esperando a impressora responder" | O sistema tenta ler o contador antes de imprimir. Confira se a impressora está ligada. Em 2 minutos a impressão segue mesmo assim. |
| Vários arquivos: "… foi para a impressora. … não saiu" | A impressora falhou no meio. Os que saíram foram contados; os outros continuam na tela. Resolva o problema (papel, cabo) e toque em imprimir de novo. |
| Esqueceram a senha | O gestor abre **Equipe**, toca na pessoa e dá uma **nova senha provisória**. A antiga deixa de valer e, no próximo acesso, a pessoa cria outra. |
| Não aparece "Criar meu cadastro" na tela de entrada | Desde a 2.2, a versão aparece embaixo da tela de entrada. Se não aparecer, o computador do sistema ainda roda uma versão antiga: descompacte a nova e rode de novo o comando de instalação de dentro da pasta nova (veja Instalação no Linux). Confira também **Gestão, Ajustes, Geral, As pessoas podem pedir o cadastro na tela de entrada**. Aparelho onde alguém já entrou abre direto no Início: toque na bolinha com as iniciais e em **Sair deste aparelho**. |
| "Seu cadastro ainda está esperando a aprovação" | O gestor ainda não aprovou. Ele vê o pedido em **Gestão, Equipe, Esperando aprovação**. |
| Esqueceram o usuário | O gestor vê o usuário de cada pessoa em **Equipe**, embaixo do nome. |
| "Usuário ou senha incorretos" | Confira o usuário (sem espaços, com ponto) e a senha (diferencia maiúsculas). Depois de 5 erros seguidos, o app espera 30 segundos antes de deixar tentar de novo; o tempo dobra a cada nova série de erros, até 15 minutos. |
| Depois da atualização para a 2.1, não sei meu usuário | Em Usuário, digite seu nome como está cadastrado; em Senha, o PIN de antes. O app mostra o usuário e pede uma senha nova. |
| A impressora Folha a Folha recusou o documento | Ninguém estava com o app aberto e desbloqueado naquele aparelho (ou havia duas pessoas). Abra o app, entre e imprima de novo. |
| Arquivo do Word, Excel ou PowerPoint não é aceito | Instale o LibreOffice no computador do sistema ou salve o arquivo como PDF. |
| "… não dá para enviar por aqui" | O tipo de arquivo não é aceito pelo app (veja "O que dá para imprimir"). Salve como PDF ou imprima do próprio programa pela impressora Folha a Folha. |
| No celular, a planilha não aparece para escolher | Corrigido na versão 1.8: o seletor de arquivos passou a mostrar planilhas e apresentações. |
| A foto saiu em branco | Acontecia até a versão 1.4.1, quando a foto ia direto para a impressora. Desde a 1.5 ela vira PDF antes. O gestor devolve a folha em **Relatórios**, na impressão, **Devolver páginas**. |
| A tela pede a senha de novo | O app ficou parado mais que o tempo escolhido em **Ajustes, Geral** e bloqueou. Digite a senha. |
| "Esta imagem PNG é do tipo entrelaçado" | Abra a imagem e salve de novo como JPG (ou tire um print da tela) e envie de novo. |
| "Diga para que é esta impressão" | Escolha uma das finalidades antes de imprimir. Em "Outro", escreva do que se trata. |
| "Documentos pessoais: até 10 páginas por mês" | O limite de páginas pessoais do mês acabou. Fale com o gestor. |
| A prévia não mostra as folhas desenhadas | Falta o programa das miniaturas no computador do sistema (Ghostscript ou Poppler, veja Instalação). Enquanto isso, a prévia abre o PDF no navegador ou em outra aba. |
| A prova que estava esperando sumiu | Passou do prazo e o resto foi apagado sem gastar páginas. Imprima de novo. |
| O botão de imprimir não acende na prévia | Marque todas as confirmações (páginas, lados, orientação e cópias). |
| O PDF saiu menor do que pelo leitor de PDF | Desde a 2.4.8, **Ajustar à folha** só encolhe a página que encosta na beirada. Se ainda sair menor, a área estimada da impressora pode ser maior que a real: imprima a página de calibração e anote as margens (Gestão → Impressoras → Editar → Papel e área de impressão). |
| Em 100% ou em Ajustar à folha cortou um pedaço da beirada | A impressora alcança menos do que o app está usando. Imprima a página de calibração e anote as margens em **Medir à mão**. Se a calibração sair sem os traços de cima e de baixo e o fim da folha cortado (uns 17 mm), a fila da impressora usa outro papel (Carta, por exemplo): na versão 2.5.0 ou anterior, escolha o **Papel** (A4) no mesmo lugar; a partir da 2.5.1 o app já pede A4 sozinho. Se o corte é só embaixo (ou só de um lado) e o desenho saiu deslocado, a bandeja pode ter outro papel: escolha o **Papel** certo no mesmo lugar. |
| A página de calibração saiu menor, ou com as escadinhas cortadas de jeitos muito diferentes | O sistema de impressão ainda está ajustando por conta própria. No Linux, veja em `lpoptions -p NOME-DA-FILA -l` se há uma opção de ajustar à página ligada e desligue; no Windows, desligue "Ajustar à página" nas preferências da impressora. |
| "Não deu para preparar o tamanho na folha" | O PDF é protegido ou está danificado, e falta o Poppler ou o Ghostscript no computador do sistema para desenhá-lo como imagem. Use **Ajustar à folha** (imprime com o ajuste automático do sistema) ou instale o Poppler (veja Instalação). |
| "Não deu para preparar este PDF em …%" | O app não conseguiu montar este PDF na folha. Escolha **Ajustar à folha** e imprima de novo. |
| O botão de imprimir está apagado | Marque a caixa "Conferi: é para sair na …", logo acima dele, depois de conferir a impressora. |
| "Passa da cota de …" ao salvar uma pessoa ou um setor | A soma das cotas passaria da cota de cima. Diminua de alguém ou peça mais a quem dá a cota (a TI). Se a TI deixou passar, o app pede a justificativa. |
| "A soma das cotas na … ficaria …" | A soma das cotas das pessoas passaria da cota do grupo da impressora. Aumente a cota do grupo em Impressoras ou diminua de alguém. |
| "Código de adesão errado ou vencido" | O código vale 7 dias e uma vez só. Peça um novo à TI (Gestão, Setores, Código). |
| "Não consegui falar com a central" | Confira o endereço da central em Ajustes, Central da TI, e a rede. A impressão continua; use o pendrive enquanto isso. |
| "O relógio deste aparelho está … diferente do da central" | Acerte a data e a hora do aparelho da unidade. |
| "O pacote da central não confere" | Alguém mexeu nos dados da central guardados no aparelho. Sincronize ou carregue o arquivo da central de novo. |
| "Você imprime pela unidade …" ao entrar na central | A pessoa é de uma unidade com aparelho próprio: entra pelo aparelho de lá. |

## Detalhes técnicos

- Feito em Python, usando só a biblioteca padrão (Python 3.9 ou mais novo). Não precisa instalar pacotes.
- Banco de dados SQLite em `dados/controle.db`. Os arquivos mandados pelo app ficam em `dados/arquivos` (apagados depois da impressão ou após 12 horas). Os que chegam pela impressora Folha a Folha ficam em `dados/fila` (apagados ao liberar, descartar ou vencer o prazo). As miniaturas da prévia ficam em `dados/arquivos/previas` e são apagadas com o arquivo (ou após 12 horas).
- Tipo de lugar e finalidades: guardados em `config` (`tipo_local`, `finalidades`). Cada impressão grava o código da finalidade; as tiradas da lista ficam guardadas como inativas para os relatórios. Na versão 1.8, o nome do lugar continua na chave `escola`, por compatibilidade com as versões anteriores.
- Setores e central (2.0): tabelas `setores` (árvore, cota mensal, regras em JSON, chave da unidade guardada como resumo SHA-256), `excecoes` (o registro de exceções com justificativa), `aumentos`, `unidade_impressoras` e `cotas_remotas`. Na central, a chave Ed25519 que assina os pacotes é gerada na instalação. Rotas da central: `/api/central/adesao` e `/api/central/sincronizar` (a unidade chama, com a chave dela). O relatório da unidade vai com HMAC-SHA256 feito com a chave da unidade.
- Cota negativa: cada impressão guarda `excedente` e `justificativa`; o desconto do mês seguinte é um movimento `desconto`, e o aumento aprovado é um movimento `aumento`.
- Vários arquivos: cada arquivo vira uma impressão própria (rotas `/api/imprimir-lote` e `/api/retidas/liberar-todas`). A licença, a finalidade e a cota são conferidas para o total antes do primeiro envio.
- Prévia: a página é desenhada como imagem pelo `pdftoppm` (Poppler), pelo `mutool` (MuPDF) ou pelo Ghostscript, procurados na pasta `ferramentas` e no sistema, nessa ordem. Sem nenhum, o app mostra o próprio PDF.
- Montagens: o programa gera um PDF novo (fotos por folha, banner, páginas por folha), que é impresso como qualquer PDF. A foto original fica guardada junto até a impressão; o original e a montagem são apagados depois de imprimir (ou em até 12 horas).
- Fotos: JPG e PNG são transformados em PDF de uma página pelo próprio programa (a foto JPG entra no PDF sem ser recomprimida; a orientação gravada pela câmera é respeitada).
- Bloqueio: a sessão guarda a hora do último uso de verdade (toque, tecla ou rolagem, avisado pelo app); a atualização automática da tela não conta. Passado o tempo, todo pedido é recusado até a senha ser digitada de novo.
- Prova: a impressão é dividida em partes (a prova e, depois, o resto em uma ou duas partes), cada uma registrada como impressão com a etapa "prova" ou "resto".
- Porta padrão 8080, para o app e para a impressora Folha a Folha (`/ipp/print`). Para trocar: `iniciar.bat --porta 9000` ou `./iniciar.sh --porta 9000`.
- A impressora também responde na porta padrão das impressoras, 631, quando ela está livre (`--porta-ipp 0` desliga).
- Impressora Folha a Folha: protocolo IPP (o mesmo das impressoras de rede modernas, "IPP Everywhere"). Aceita PDF, PWG Raster e JPEG. O PWG Raster vira PDF antes de seguir para a impressora de verdade. O anúncio na rede usa mDNS/DNS-SD (porta UDP 5353), pelo Avahi no Linux ou por conta própria.
- Impressão: `lp` (CUPS) no Linux e SumatraPDF no Windows.
- Acompanhamento da fila (Linux): `acompanhar.py` consulta o CUPS por IPP (`localhost:631` ou o soquete `/run/cups/cups.sock`) com Get-Job-Attributes, a cada 2 segundos, enquanto houver impressão `na_fila`. O número do trabalho vem da resposta do `lp`. Com o contador, o trabalho vai com `lp -H hold` e é solto com `lp -i N -H resume`. A situação da impressora vem do SNMP (hrPrinterStatus e hrPrinterDetectedErrorState). Cada impressão guarda `pedido` (o que foi pedido) e `total` (o que valeu). Sem o CUPS respondendo, volta ao jeito antigo.
- Licença: assinatura digital Ed25519 conferida localmente (`licenca.py`). A chave privada que emite as licenças fica só com o desenvolvedor, fora deste pacote.
- Arquivos: `servidor.py` (sistema e regras das cotas), `licenca.py` (chave de ativação), `impressao.py` (contagem de páginas e envio às impressoras), `imposicao.py` (papel e margens de cada impressora, tinta de cada página, cálculo do Tamanho na folha e página de calibração), `escala.py` (montagem de cada página na folha, sem perder a nitidez), `ipp.py` (a impressora Folha a Folha), `raster.py` (conversão de PWG Raster em PDF), `mdns.py` (anúncio no Wi-Fi), `contador.py` (leitura do contador por SNMP, porta UDP 161), `acompanhar.py` (acompanhamento da fila no CUPS), `web/` (telas).
- **Central e unidades:** testadas aqui com três servidores na mesma máquina (central, unidade pela rede e unidade por arquivo). Ainda falta testar numa rede de verdade, com a central em outro prédio.
- **Ainda sem teste em aparelhos reais:** a instalação no Windows, no Android e no Linux foi feita seguindo as normas (IPP, PWG Raster, mDNS) e testada aqui com um cliente IPP. Confira em cada tipo de aparelho no piloto.


### Edição de digitalizações (versão 2.4)

Na aba **Escanear**, use **Digitalizar** para acrescentar páginas ao documento em montagem. É possível repetir a operação para digitalizar páginas soltas na mesa de vidro ou usar o alimentador; cada passagem é adicionada ao mesmo lote. Na lista de páginas, os controles giram cada página em 90 graus e o recorte aceita margens superior, direita, inferior e esquerda em porcentagem (0 a 40%). Ao selecionar **Concluir e gerar PDF multipágina**, o Folha a Folha aplica os ajustes e cria um único PDF. Girar e recortar precisam do Pillow no computador do sistema (opcional; sem ele, o PDF sai normalmente, só sem giro e recorte): no Ubuntu/Mint, `sudo apt install python3-pil`; no Windows, o `iniciar.bat` instala sozinho (ou `py -m pip install --user -r requirements.txt`).

### Sobre

A aba **Sobre** identifica o Folha a Folha como software de bilhetagem e gerenciamento de impressão, desenvolvido por Alysson Christiano Primor com auxílio de inteligência artificial. Contato: diceflowsoftware@gmail.com.

## Versão 2.4.1 — resposta a pedidos de transferência

- Quem recebe um pedido direto de páginas pode responder **Não posso atender**, tanto na tela inicial quanto na conversa.
- A mensagem é opcional: em branco, vai uma resposta padrão. Ela fica registrada na conversa para o solicitante.
- O pedido passa a `recusado` sem movimentar cotas e deixa imediatamente a lista de pendências da tela inicial.
- Se a transferência falhar por exceder o limite mensal (por exemplo, pedido de 70 páginas quando o limite disponível é 50), nada é transferido e o pedido continua aberto até que o destinatário escolha responder que não pode atender.
- Pedidos publicados no mural continuam sem recusa individual: o mural não tem destinatário específico.


## Versão 2.4.2 — orientação de papel para fotos

Na tela de impressão, depois de selecionar a impressora, escolha em **Como imprimir**: Automática (o padrão desde a 2.4.8: segue a forma da foto), Retrato (vertical) ou Paisagem (horizontal). A opção define a orientação da folha A4 usada para converter JPG/PNG em PDF. Ao alterar a escolha depois do envio, o sistema remonta o PDF a partir da imagem original; em listas com vários arquivos, aplica a orientação a cada foto sem alterar a orientação própria dos PDFs.


## Versão 2.4.4 — orientação junto às opções de impressão

- O campo **Orientação do papel** saiu da etapa de seleção de arquivos e agora aparece como o primeiro controle do bloco **Como imprimir**, logo depois da escolha da impressora.
- A mudança de orientação depois do envio refaz o PDF a partir da imagem original, sem exigir que a pessoa selecione o arquivo novamente.
- Em lotes mistos, a orientação escolhida é aplicada às fotos JPG/PNG; documentos PDF mantêm sua orientação original.
- A prévia e a impressão utilizam o PDF remontado com a orientação escolhida.


## Versão 2.4.5 — intervalo de páginas no iPhone

O campo “Quais páginas?” agora solicita o teclado de texto completo em dispositivos móveis, em vez do teclado numérico que não oferece hífen e vírgula. Assim, é possível digitar intervalos e listas como `1-3, 5, 8-10` diretamente no iPhone. A validação e a interpretação do intervalo permanecem iguais no navegador e no servidor.


## Versão 2.4.6 — dispensar pedidos antigos do mural

Pedidos publicados no mural podem ser dispensados individualmente da tela inicial de cada pessoa. A ação não recusa nem encerra o pedido globalmente: os demais colegas continuam podendo atendê-lo. O registro é persistido por usuário e pedido, e pode ser acionado tanto na faixa da tela inicial quanto no cartão do pedido dentro da conversa do mural.


## Versão 2.4.7 — revisão do Escanear e do Ajustar à folha

**Escanear**
- O **Formato** escolhido agora vale: JPG, PNG, TIFF ou BMP saem direto, uma imagem por página (várias páginas num ZIP). Antes, a tela sempre gerava PDF. Em **PDF**, as páginas entram no documento em montagem (várias passagens, girar, recortar).
- **Girar** saía ao contrário: a tela mostrava a página girada para a direita e o PDF saía girado para a esquerda. Agora o PDF sai como a tela mostra (↶ esquerda, ↷ direita).
- Um erro ao concluir (por exemplo, um recorte inválido) **apagava todas as páginas escaneadas**. Agora o documento só é apagado depois que o PDF fica pronto.
- O PDF escaneado sai no **tamanho real** da folha (A4 escaneada vira PDF A4, sem margem extra). Antes, a página era encolhida para caber com margem, e a cópia impressa saía cerca de 6% menor.
- Páginas em **600 dpi** ou mais viravam erro ("Imagem grande demais"). Agora viram PDF normalmente.
- Páginas sem giro nem recorte entram no PDF como saíram do scanner (preto e branco continua preto e branco, sem virar JPEG colorido). Com giro ou recorte, preto e branco e cinza continuam assim.
- **Tamanho do papel** no Linux: o SANE mostra a área do scanner com nomes curtos (-x, -y), e a lista só oferecia "Automático". Agora mostra A4, A5, Carta, Ofício e A3 conforme o scanner, e o tamanho escolhido é aplicado.
- **Papel atolado** no meio do alimentador: as folhas que saíram inteiras ficam, a folha pela metade não entra, e o app avisa onde parou.
- O documento em montagem **continua depois de recarregar a página** (o celular recarrega a aba ao trocar de aplicativo). Trocar de scanner não perde mais o documento. **Descartar documento** pede confirmação e apaga as páginas na hora.
- Enquanto o scanner trabalha, a tela não bloqueia por falta de uso. Antes, ao terminar, o servidor **desbloqueava** a sessão sem pedir a senha, mesmo que ela tivesse sido bloqueada; agora uma tela bloqueada continua bloqueada.
- A lista de scanners fica guardada por 5 minutos: escolher opções e digitalizar não repetem a procura inteira (que no Linux, com scanner de rede, leva de 5 a 30 segundos). **Atualizar lista** sempre procura de novo.
- No Linux, a instalação como serviço (`ferramentas/so-pela-folha-a-folha.sh`) põe o usuário do serviço nos grupos `scanner` e `lp`, que dão acesso ao scanner USB. Rode de novo o comando de instalação para valer.
- O Pillow virou opcional e não é mais instalado pelo `iniciar.sh` (no Ubuntu/Mint, o pip do sistema recusa; use `sudo apt install python3-pil`).

**Ajustar à folha**
- Em página girada (PDF de página deitada, comum em planilhas e apresentações), o deslocamento de 4 mm ia para o lado, não para baixo. Agora desce na folha como a prévia mostra.
- PDF protegido por senha num computador sem Poppler/Ghostscript (o comum no Windows) **não imprimia** em Ajustar à folha, o padrão. Agora imprime com o ajuste automático de antes. Os outros tamanhos continuam avisando que não dá.

**Outros**
- Pedido do mural dispensado: no cartão do mural aparece "Fora da sua tela inicial", em vez do botão de dispensar de novo. As marcas de pedidos já encerrados são limpas sozinhas.
- Textos "2 páginas página(s)" corrigidos.


## Versão 2.4.8 — tamanho na folha exato

- **Ajustar à folha** encolhia todo documento para 96% e descia 4 mm, mesmo quando ele já tinha margem: a impressão saía pequena, com margens grandes. Agora mede onde há tinta em cada página e usa o maior tamanho, até 100%, em que tudo cabe na área que a impressora alcança. Documento com margem sai em 100%, igual ao original.
- **100%** deixava a impressora decidir onde pôr a página: página deitada, papel diferente do PDF ou conteúdo encostado na beirada saíam cortados. Agora o app monta cada página na folha da impressora (gira a deitada, centraliza, empurra para dentro o que encosta na beirada) e avisa quando algo passa da área.
- **Gestão → Impressoras → Editar → Papel e área de impressão**: papel da bandeja, margens lidas do CUPS ou do driver, **página de calibração** e **Medir à mão**.
- O desenho do Tamanho na folha e a prévia mostram a folha com a área da impressora (tracejado), com a página no tamanho e no lugar exatos. Clicar em Conferir logo depois de mudar o tamanho espera o cálculo, em vez de mostrar o tamanho anterior.
- **Outro tamanho** começa em 100% (antes, 96%). A preferência virou **Começar no tamanho original (100%)**.
- Impressões soltas da fila da impressora Folha a Folha saem em **Ajustar à folha** (antes, com o ajuste automático do sistema).
- Fotos: a orientação do papel começa em **Automática** (segue a forma da foto).
- PDF com página **cortada** (recorte feito no Acrobat, no Preview do Mac ou por alguns scanners): a prévia, as miniaturas e as **páginas por folha** mostravam a página inteira, de antes do recorte. Agora mostram só a parte que se vê, como a impressão, e o Tamanho na folha também mede só essa parte.
- Se o app não consegue montar um PDF de estrutura incomum, **Ajustar à folha** imprime com o ajuste automático do sistema, em vez de dar erro.
- **Ainda sem teste em impressora de verdade:** o cálculo e a montagem foram conferidos desenhando o PDF que vai para a impressora e medindo onde a tinta cai. Falta conferir no piloto se cada impressora respeita o "sem ajuste" (`print-scaling=none`) e, no Windows, onde o SumatraPDF põe a página. A página de calibração serve exatamente para isso: se as escadinhas saírem inteiras a partir das medidas anotadas, está certo.

## Versão 2.4.9 — revisão de usabilidade e fim do nome Giz

- **Marca:** o nome Giz saiu das telas, das mensagens e do manual. A chave de ativação agora começa com `FAF1.` (antes `GIZ1.`). O nome da empresa que aparecia em Sobre e no aviso de privacidade só aparece se o gestor digitar em **Ajustes**; o nome antigo foi apagado na atualização.
- **Textos:** o cadastro pela tela de entrada fala em "o gestor" (não mais "a direção") e não usa mais "Obrigada".
- **Sem conexão:** se o aparelho sai do Wi-Fi, aparece uma faixa no topo com a hora dos últimos dados. Antes a tela ficava parada, sem aviso.
- **Leitores de tela:** o app não anuncia mais a tela inteira a cada atualização (a cada 6 segundos).
- **Primeira configuração:** "Onde vai ser usado?" mostra que é obrigatório e, se ficar sem escolha, a tela rola até ele.
- **Toque:** botões pequenos, segmentos e botões do mural passaram de 38-40 px para 44 px. O texto das abas continua com 11 px em telas estreitas, porque com 12 px as seis abas não cabem em 360 px. Em telas de 340 px ou menos (celulares bem pequenos), o texto das abas passa a 10 px: antes as abas saíam da tela.
- **Erros:** um erro inesperado do sistema mostra "Algo deu errado no sistema..." no lugar do texto técnico (o detalhe continua no registro do serviço). Pedido com tamanho inválido dá "Pedido inválido".
- **Desempenho:** os arquivos da tela (cerca de 350 KB) agora vão comprimidos e só são baixados de novo quando mudam.
- **Segurança:** conexão parada por mais de 2 minutos é fechada, para não prender o computador do sistema.
- **Atenção ao atualizar:** quem tem uma chave `GIZ1.` instalada precisa de uma chave nova (`FAF1.`). Até lá vale a avaliação de 90 dias.
- **Ainda sem teste em aparelho de verdade:** a faixa de falta de conexão, o toque nos botões e o leitor de tela foram conferidos só no Chrome simulado de celular, não em celular, tablet ou leitor de tela de verdade.

## Versão 2.4.10 — compartilhar do celular e QR do endereço

- **Compartilhar para o Folha a Folha:** a tela agora recebe arquivos mandados pelo "Compartilhar" do app Android (veja "Uso da equipe"). Nada muda para quem usa o navegador ou o computador.
- **QR code do endereço:** em Gestão, **Endereço para os celulares** ganhou um QR code (gerado no próprio computador, sem internet) para o app Android achar o servidor. Quem usa o navegador pode ignorá-lo.
- **O que o app guarda:** o arquivo compartilhado fica numa pasta privada do app, no celular, só até a tela recebê-lo (e no máximo 1 hora). Ele é apagado quando a tela confirma, e a pasta inteira é esvaziada toda vez que o app abre. O servidor continua apagando o arquivo depois de imprimir ou no prazo, como sempre.
- **Ainda sem teste em aparelho de verdade:** o recebimento pela tela foi conferido só no Chrome simulado, com uma ponte de mentira no lugar do app. O "Compartilhar" do Android e a cópia do arquivo no celular só um aparelho real confirma. O QR foi lido por um leitor de computador (OpenCV), não pela câmera de um celular.

## Versão 2.5.0 — convivência e exclusão de conta (exigências da Google Play)

- **Termos de uso:** no primeiro acesso (e sempre que mudarem) o app mostra os termos de uso com as regras de convivência junto com o aviso de privacidade, e a pessoa precisa aceitar ("Entendi e aceito os termos"). **Sem o aceite, o servidor recusa mensagens, pedidos e páginas passadas.** Quem já usava o app vê a folha de novo, uma vez. Em Gestão → Ajustes, **Endereço dos termos de uso** guarda o link (https://) do texto completo, que aparece na folha.
- **Bloquear um colega:** em cada mensagem de outra pessoa há um botão de opções (três pontinhos): **Bloquear** ou **Denunciar**. Na conversa direta também há o botão **Bloquear**. Quem bloqueia deixa de ver as mensagens e os pedidos do outro (no mural e nas conversas), e o outro não consegue escrever, pedir nem passar páginas para quem o bloqueou. Para desbloquear: menu do seu nome → **Pessoas bloqueadas**.
- **Denunciar:** a pessoa escolhe o motivo e, se quiser, explica. A denúncia guarda o trecho da mensagem, quem denunciou e quem escreveu. Só o gestor vê.
- **Gestão → Denúncias (nova aba):** o gestor lê cada denúncia e escolhe **Apagar a mensagem**, **Desativar a pessoa** ou **Ignorar**. O início do gestor avisa quando há denúncias ou pedidos de exclusão esperando.
- **Filtro de palavras:** mensagens e pedidos com palavras ofensivas saem com asteriscos. Em Gestão → Ajustes dá para **desligar o filtro**, **acrescentar palavras** e **liberar palavras** da lista inicial.
- **Excluir a conta:** menu do seu nome → **Excluir minha conta** (pede a senha). O pedido vai para o gestor, em Gestão → Denúncias → **Pedidos para excluir a conta**. Ao atender, o nome vira "Pessoa removida" e as mensagens, a senha, o login, os bloqueios e os arquivos são apagados; os números de impressão ficam. A pessoa pode cancelar o pedido enquanto o gestor não atendeu. O único gestor principal não pode pedir (cadastre outro antes).
- **Aviso de privacidade:** ganhou "Bloqueios e denúncias" e "Excluir a conta" (versão 3 do aviso).
- **Banco de dados:** tabelas novas `bloqueios` e `denuncias` e a coluna `exclusao_pedida` em `usuarios`, criadas na atualização, sem perder nada.
- **Ainda sem teste em aparelho de verdade:** as telas foram conferidas só no Chrome simulado de celular. O filtro só pega palavras da lista (e as que o gestor acrescentar): ele não entende o sentido da frase, por isso as denúncias existem.

## Versão 2.5.1 — papel certo na impressão (correção)

- **O que estava errado:** quando o app não descobria o papel da impressora, ele calculava o "Ajustar à folha" para A4, mas não avisava o sistema de impressão. Se a fila usasse outro papel (Carta, por exemplo), o fim da folha saía cortado (uns 17 mm) e a página de calibração saía sem os traços de cima e de baixo. Foi visto no CEI em 23/11/2026.
- **O que muda:** sem papel informado pela impressora nem escolhido na gestão, o app passa a pedir **A4** ao sistema de impressão (`-o media=iso_a4_210x297mm` no Linux, `paper=A4` no SumatraPDF), o mesmo papel usado no cálculo. Quem já escolheu o papel em Gestão → Impressoras → Editar → Papel e área de impressão não vê diferença. Se a bandeja tem outro papel (Carta, Ofício...), escolha-o ali.
- **Margens:** a impressora do CEI saiu com 4,5 mm nos quatro lados. O app estima 4,2 mm: ligue **Medir à mão** e anote as medidas da calibração para o corte não passar.
- **Ainda sem teste em outras impressoras:** só a do CEI mostrou o problema. O teste desta versão simula o `lp`; a impressão de verdade foi vista só no CEI, com o papel escolhido à mão.

## Versão 2.6.0 — cartaz com QR code, campo livre, texto para qualquer lugar e correções

- **Cartaz com QR code:** em Gestão, Resumo do mês, **Endereço para os celulares** ganhou **Imprimir cartaz** (uma folha com o nome do lugar, o QR code, o endereço e os passos para entrar, que não conta na cota de ninguém), **Baixar cartaz (PDF)** e **Copiar endereço**. Na aba Equipe há um botão que leva até lá. O cartaz sai no papel da impressora escolhida.
- **"O que é?" em campo livre:** em vez de escolher numa lista, a pessoa escreve o que é. O app arruma o texto (primeira letra maiúscula, resto minúsculo), mostra os últimos textos da própria pessoa como atalhos e tem a chave **É documento pessoal**. É o padrão das instalações novas. **Quem já usava continua com a lista de finalidades**: para trocar, Gestão, Ajustes, Controle de impressão, **Campo livre**. Os relatórios e a planilha agrupam pelos textos iguais.
- **Texto para qualquer lugar:** os exemplos que falavam de escola em qualquer instalação ("Professora do Maternal II", "turma", "prefeitura", "as colegas") agora acompanham o tipo de lugar. Na instalação, **Empresa** vem primeiro, e sem tipo escolhido as palavras são neutras ("a organização"). A aba Sobre não diz mais "bilhetagem". Quem já usava como escola continua como escola.
- **Gestão:** a aba aberta fica sempre à vista na faixa de cima, e a faixa esmaece na ponta quando há mais abas para aquele lado. No computador aparecem todas.
- **Leitura:** o texto cinza (dicas, detalhes, nomes das abas de baixo) ficou mais escuro, para dar contraste de pelo menos 4,5.
- **Correção (central da TI):** um gestor de setor conseguia rebaixar o gestor geral e trocar a senha dele. Agora só a TI muda a conta de um gestor geral.
- **Correção (planilha do mês):** nome de arquivo, descrição ou nome de pessoa começando com = + - ou @ viravam fórmula no Excel e no Calc. Agora saem com um apóstrofo na frente.
- **Correção (segurança):** um pedido recusado antes de ser lido (sem a marca do app, arquivo acima de 60 MB ou endereço que não existe) deixava uma sobra que o servidor tratava como outro pedido. Agora a conexão é fechada.
- **Correção:** número quebrado, "verdadeiro", lista ou número gigante onde se espera um número inteiro, e mês mal escrito, agora são recusados com mensagem, em vez de dar "Algo deu errado".
- **Ainda sem teste em aparelho de verdade:** tudo foi conferido num Chrome simulado de celular e com uma impressora de mentira. O cartaz foi lido por um leitor de QR de computador (OpenCV), não pela câmera de um celular, e não foi impresso numa impressora de verdade. O botão de baixar o PDF não foi testado dentro do app Android.

## Versão 2.6.1 — endereço certo no cartaz e na tela (correção)

- **Correção (endereço):** o programa lia o endereço deste computador na rede uma vez só, ao ligar. Se ligasse antes de a rede ficar pronta (computador que liga e só depois conecta no Wi-Fi), a tela e o cartaz ficavam com `http://127.0.0.1`, que só funciona no próprio computador, até o programa ser religado. Agora ele confere a rede a cada 10 segundos: o endereço aparece e muda sozinho.
- **Cartaz:** lê o endereço na hora de baixar ou imprimir. Sem rede, o app avisa ("O computador do sistema não está numa rede agora") e não faz o cartaz.
- **Tela:** sem rede, **Endereço para os celulares** avisa, em vez de mostrar um endereço que não serve.
- **Impressora Folha a Folha (estilo impressora):** o anúncio no Wi-Fi também acompanha a rede. Antes, se o programa ligasse sem rede, a impressora não era anunciada até ele ser religado; e, se o endereço mudasse, o anúncio continuava com o antigo.
- **Gestão:** a aba aberta volta para a vista quando a janela muda de largura com a Gestão aberta (encolher a janela, aumentar o zoom, girar o celular).
- **Depois de atualizar:** recarregue (F5) as abas do navegador que já estavam abertas, para pegarem a tela nova.
- **Visto em aparelho de verdade:** no piloto, em 23/11/2026, o cartaz da 2.6.0 saiu inteiro numa impressora de verdade, mas com `http://127.0.0.1`, que esta versão corrige. **Só simulado:** a correção foi conferida com uma rede de mentira e num Chrome simulado. Falta conferir no computador do piloto e ler o QR code com a câmera de um celular.

## Versão 2.7.0 — relatórios por período, mais fáceis de ler, e relatório em PDF

- **Período:** o relatório deixa de ser só por mês. Dá para ver os últimos 7, 30 ou 90 dias, o ano ou datas à escolha. A planilha e o PDF seguem o período. Datas erradas (fim antes do início, mais de 2 anos) são recusadas com mensagem.
- **Mais fácil de usar no celular:** o período vem em primeiro lugar; os filtros ficam recolhidos e os ligados aparecem como etiquetas que se tiram com um toque; as impressões aparecem 20 de cada vez, com **Ver mais impressões**; os botões de levar o relatório ficam logo abaixo dos números; botões e campos novos têm 44 px ou mais de altura; as etiquetas dizem "Tirar o filtro…" para o leitor de tela.
- **Relatório em PDF:** **Baixar relatório (PDF)** e **Imprimir relatório** (só o gestor geral; não conta na cota). Uma ou mais folhas, no papel da impressora, sem nomes de arquivos.
- **Planilha:** a de um período traz "Impressões por pessoa no período" no lugar da cota do mês, e o nome do arquivo leva as datas.
- **Nada muda** para quem só imprime. O banco de dados não muda: atualizar não perde nada.
- **Depois de atualizar:** recarregue (F5) as abas do navegador que já estavam abertas.
- **Só simulado:** conferido num Chrome simulado de celular (360 px) e com uma impressora de mentira. **Não** foi impresso numa impressora de verdade, **não** foi testado com leitor de tela, nem dentro do app Android. As datas dos atalhos (últimos 30 dias etc.) saem do relógio do aparelho que está vendo o relatório.
