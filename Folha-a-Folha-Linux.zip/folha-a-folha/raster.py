"""PWG Raster: o formato de imagem que alguns sistemas (Windows, Android) mandam às impressoras.

Aqui ele é lido, as páginas são contadas e o resultado vira um PDF comum, que segue
para a impressora real pelo mesmo caminho dos outros arquivos. Só biblioteca padrão.
Formato definido na norma PWG 5102.4 (cabeçalho de 1796 bytes por página, compressão
por repetição de linhas e de pixels).
"""
import struct
import zlib

SINC = b"RaS2"
TAM_CABECALHO = 1796


class ErroRaster(Exception):
    pass


def eh_pwg(inicio):
    return inicio[:4] == SINC


def _cabecalho(b):
    u = lambda off: struct.unpack(">I", b[off:off + 4])[0]  # noqa: E731
    return {
        "dpi_x": u(276) or 300, "dpi_y": u(280) or 300,
        "largura": u(372), "altura": u(376),
        "bits_cor": u(384), "bits_pixel": u(388), "bytes_linha": u(392),
        "ordem": u(396), "espaco": u(400), "cores": u(420),
    }


# espaços de cor (CUPS/PWG): 0 W, 1 RGB, 3 K, 6 CMYK, 18 sGray, 19 sRGB, 20 AdobeRGB
def _pdf_cor(h):
    esp, n = h["espaco"], h["cores"] or {0: 1, 3: 1, 18: 1, 1: 3, 19: 3, 20: 3, 6: 4}.get(h["espaco"], 1)
    if n == 1:
        return "/DeviceGray", (b"/Decode [1 0]" if esp == 3 else b""), (0x00 if esp == 3 else 0xFF)
    if n == 3:
        return "/DeviceRGB", b"", 0xFF
    if n == 4:
        return "/DeviceCMYK", b"", 0x00
    raise ErroRaster(f"Espaço de cor não suportado ({esp}).")


def _linhas(dados, pos, h, branco):
    """Gera as linhas descompactadas de uma página. Devolve (lista de linhas, nova posição)."""
    largura_b = h["bytes_linha"]
    unidade = max(1, h["bits_pixel"] // 8)
    altura = h["altura"]
    linhas, y, n = [], 0, len(dados)
    cor_branca = bytes([branco])
    while y < altura:
        if pos >= n:
            raise ErroRaster("Imagem incompleta.")
        repete = dados[pos] + 1
        pos += 1
        linha = bytearray()
        while len(linha) < largura_b:
            if pos >= n:
                raise ErroRaster("Imagem incompleta.")
            c = dados[pos]
            pos += 1
            if c == 128:  # resto da linha em branco
                linha += cor_branca * (largura_b - len(linha))
            elif c > 128:  # pixels literais
                k = (257 - c) * unidade
                linha += dados[pos:pos + k]
                pos += k
            else:  # um pixel repetido c+1 vezes
                linha += dados[pos:pos + unidade] * (c + 1)
                pos += unidade
        linha = bytes(linha[:largura_b])
        for _ in range(min(repete, altura - y)):
            linhas.append(linha)
            y += 1
    return linhas, pos


def pwg_para_pdf(dados, caminho_pdf):
    """Converte PWG Raster em PDF. Devolve o número de páginas."""
    if not eh_pwg(dados):
        raise ErroRaster("O arquivo não é PWG Raster.")
    pos, paginas = 4, []
    while pos + TAM_CABECALHO <= len(dados):
        h = _cabecalho(dados[pos:pos + TAM_CABECALHO])
        pos += TAM_CABECALHO
        if not h["largura"] or not h["altura"] or not h["bytes_linha"]:
            raise ErroRaster("Cabeçalho de página inválido.")
        if h["ordem"] != 0:
            raise ErroRaster("Ordem de cores não suportada.")
        espaco, decode, branco = _pdf_cor(h)
        linhas, pos = _linhas(dados, pos, h, branco)
        comp = zlib.compressobj(6)
        imagem = b"".join(comp.compress(l) for l in linhas) + comp.flush()
        paginas.append((h, espaco, decode, imagem))
    if not paginas:
        raise ErroRaster("Nenhuma página na imagem.")
    _escrever_pdf(paginas, caminho_pdf)
    return len(paginas)


def _escrever_pdf(paginas, caminho):
    objs = {}
    n_paginas = len(paginas)
    # 1 catálogo, 2 páginas; depois, para cada página: página, conteúdo, imagem
    kids = []
    for i, (h, espaco, decode, imagem) in enumerate(paginas):
        pid, cid, iid = 3 + 3 * i, 4 + 3 * i, 5 + 3 * i
        kids.append(f"{pid} 0 R")
        larg_pt = h["largura"] * 72.0 / h["dpi_x"]
        alt_pt = h["altura"] * 72.0 / h["dpi_y"]
        conteudo = f"q {larg_pt:.2f} 0 0 {alt_pt:.2f} 0 0 cm /Im0 Do Q".encode()
        objs[pid] = (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {larg_pt:.2f} {alt_pt:.2f}] "
                     f"/Resources << /XObject << /Im0 {iid} 0 R >> >> /Contents {cid} 0 R >>").encode()
        objs[cid] = b"<< /Length %d >>\nstream\n" % len(conteudo) + conteudo + b"\nendstream"
        objs[iid] = (b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s "
                     b"/BitsPerComponent %d %s /Filter /FlateDecode /Length %d >>\nstream\n"
                     % (h["largura"], h["altura"], espaco.encode(), h["bits_cor"], decode, len(imagem))
                     + imagem + b"\nendstream")
    objs[1] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objs[2] = f"<< /Type /Pages /Count {n_paginas} /Kids [{' '.join(kids)}] >>".encode()
    total = 2 + 3 * n_paginas
    with open(caminho, "wb") as f:
        f.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets = [0] * (total + 1)
        for k in range(1, total + 1):
            offsets[k] = f.tell()
            f.write(b"%d 0 obj\n" % k + objs[k] + b"\nendobj\n")
        xref = f.tell()
        f.write(b"xref\n0 %d\n0000000000 65535 f \n" % (total + 1))
        for k in range(1, total + 1):
            f.write(b"%010d 00000 n \n" % offsets[k])
        f.write(b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (total + 1, xref))


# ---------------------------------------------------------------- para testes

def comprimir_pagina(linhas, unidade):
    """Codifica linhas no formato PWG (usado pelos testes para gerar arquivos de exemplo)."""
    saida = bytearray()
    i = 0
    while i < len(linhas):
        rep = 1
        while i + rep < len(linhas) and linhas[i + rep] == linhas[i] and rep < 256:
            rep += 1
        saida.append(rep - 1)
        linha = linhas[i]
        px = [linha[k:k + unidade] for k in range(0, len(linha), unidade)]
        j = 0
        while j < len(px):
            k = 1
            while j + k < len(px) and px[j + k] == px[j] and k < 128:
                k += 1
            if k > 1:
                saida.append(k - 1)
                saida += px[j]
                j += k
            else:
                lit = [px[j]]
                j += 1
                while j < len(px) and len(lit) < 127 and (j + 1 >= len(px) or px[j] != px[j + 1]):
                    lit.append(px[j])
                    j += 1
                if len(lit) == 1:  # um pixel sozinho: "repetir 1 vez"
                    saida.append(0)
                else:
                    saida.append(257 - len(lit))
                saida += b"".join(lit)
        i += rep
    return bytes(saida)


def montar_cabecalho(largura, altura, dpi=300, espaco=18, cores=1, bits_cor=8):
    b = bytearray(TAM_CABECALHO)
    b[0:9] = b"PwgRaster"
    bits_pixel = bits_cor * cores
    bytes_linha = (largura * bits_pixel + 7) // 8
    for off, v in ((276, dpi), (280, dpi), (372, largura), (376, altura), (384, bits_cor),
                   (388, bits_pixel), (392, bytes_linha), (396, 0), (400, espaco), (420, cores)):
        b[off:off + 4] = struct.pack(">I", v)
    return bytes(b)
