"""Anúncio da impressora na rede local (mDNS / DNS-SD), como as impressoras de verdade fazem.

Com isso, celulares e computadores no mesmo Wi-Fi encontram "Folha a Folha" sozinhos.
No Linux com Avahi, usa o próprio Avahi. Nos outros casos, usa este respondedor
escrito só com a biblioteca padrão (RFC 6762 e RFC 6763).
"""
import shutil
import socket
import struct
import subprocess
import threading
import time

GRUPO, PORTA = "224.0.0.251", 5353
T_A, T_PTR, T_TXT, T_SRV, T_ANY = 1, 12, 16, 33, 255
CLASSE_IN, FLUSH = 1, 0x8000


def _nome(texto):
    saida = bytearray()
    for parte in texto.rstrip(".").split("."):
        b = parte.encode("utf-8")
        saida += bytes([len(b)]) + b
    return bytes(saida + b"\x00")


def _ler_nome(dados, pos):
    partes, saltou, fim = [], False, pos
    for _ in range(128):
        n = dados[pos]
        if n == 0:
            pos += 1
            break
        if n & 0xC0 == 0xC0:
            alvo = struct.unpack(">H", dados[pos:pos + 2])[0] & 0x3FFF
            if not saltou:
                fim = pos + 2
            saltou, pos = True, alvo
            continue
        partes.append(dados[pos + 1:pos + 1 + n].decode("utf-8", "replace"))
        pos += 1 + n
    return ".".join(partes), (fim if saltou else pos)


class Registros:
    """Os registros DNS que descrevem uma ou mais impressoras Folha a Folha."""

    def __init__(self, ip, porta, servicos, host=None):
        self.ip, self.porta = ip, porta
        self.host = (host or f"folha-a-folha-{ip.split('.')[-1]}") + ".local"
        self.servicos = servicos  # lista de (nome da instância, caminho, dict TXT)

    def _txt(self, d):
        saida = bytearray()
        for k, v in d.items():
            b = f"{k}={v}".encode("utf-8")[:255]
            saida += bytes([len(b)]) + b
        return bytes(saida)

    def todos(self):
        """Lista de (nome, tipo, classe, ttl, rdata)."""
        r = [("_services._dns-sd._udp.local", T_PTR, CLASSE_IN, 4500, _nome("_ipp._tcp.local"))]
        for inst, caminho, txt in self.servicos:
            nome_inst = f"{inst}._ipp._tcp.local"
            r.append(("_ipp._tcp.local", T_PTR, CLASSE_IN, 4500, _nome(nome_inst)))
            r.append(("_print._sub._ipp._tcp.local", T_PTR, CLASSE_IN, 4500, _nome(nome_inst)))
            r.append((nome_inst, T_SRV, CLASSE_IN | FLUSH, 120,
                      struct.pack(">HHH", 0, 0, self.porta) + _nome(self.host)))
            r.append((nome_inst, T_TXT, CLASSE_IN | FLUSH, 4500, self._txt({**txt, "rp": caminho})))
        r.append((self.host, T_A, CLASSE_IN | FLUSH, 120, socket.inet_aton(self.ip)))
        return r


def _pacote(id_, perguntas, respostas, adicionais):
    saida = bytearray(struct.pack(">HHHHHH", id_, 0x8400, len(perguntas), len(respostas), 0, len(adicionais)))
    for nome, tipo in perguntas:
        saida += _nome(nome) + struct.pack(">HH", tipo, CLASSE_IN)
    for nome, tipo, classe, ttl, rdata in respostas + adicionais:
        saida += _nome(nome) + struct.pack(">HHIH", tipo, classe, ttl, len(rdata)) + rdata
    return bytes(saida)


def responder(dados, registros, porta_origem=PORTA):
    """Monta a resposta a uma consulta mDNS, ou None se não for conosco."""
    if len(dados) < 12:
        return None
    id_, flags, qd = struct.unpack(">HHH", dados[:6])
    if flags & 0x8000:  # é uma resposta, não uma pergunta
        return None
    pos, perguntas = 12, []
    for _ in range(qd):
        nome, pos = _ler_nome(dados, pos)
        tipo, _cls = struct.unpack(">HH", dados[pos:pos + 4])
        pos += 4
        perguntas.append((nome.lower(), tipo))
    todos = registros.todos()
    respostas = []
    for nome, tipo in perguntas:
        for reg in todos:
            if reg[0].lower() == nome and (tipo in (reg[1], T_ANY)) and reg not in respostas:
                respostas.append(reg)
    if not respostas:
        return None
    adicionais = []
    for reg in respostas:
        if reg[1] == T_PTR:
            alvo, _ = _ler_nome(reg[4], 0)
            for extra in todos:
                if extra[0].lower() == alvo.lower() and extra not in respostas + adicionais:
                    adicionais.append(extra)
    if any(r[1] == T_SRV for r in respostas + adicionais):
        for extra in todos:
            if extra[1] == T_A and extra not in respostas + adicionais:
                adicionais.append(extra)
    legado = porta_origem != PORTA
    return _pacote(id_ if legado else 0, perguntas if legado else [], respostas, adicionais)


def anuncio(registros, adeus=False):
    """Anúncio espontâneo. Com adeus=True, TTL zero: os aparelhos esquecem a impressora."""
    regs = registros.todos()
    if adeus:
        regs = [(nome, tipo, classe, 0, rdata) for nome, tipo, classe, _ttl, rdata in regs]
    return _pacote(0, [], regs, [])


class Anunciante:
    def __init__(self, registros):
        self.registros = registros
        self.processos = []
        self.modo = None
        self.sock = None
        self.ativo = False

    def iniciar(self):
        if self._avahi():
            self.modo = "avahi"
            return self.modo
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            s.bind(("", PORTA))
            mreq = socket.inet_aton(GRUPO) + socket.inet_aton(self.registros.ip)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(self.registros.ip))
        except OSError:
            self.modo = None
            return None
        self.sock = s
        self.ativo = True
        threading.Thread(target=self._ouvir, daemon=True).start()
        threading.Thread(target=self._anunciar, daemon=True).start()
        self.modo = "próprio"
        return self.modo

    def _avahi(self):
        cmd = shutil.which("avahi-publish-service")
        if not cmd:
            return False
        for inst, caminho, txt in self.registros.servicos:
            args = [cmd, "-s", "--subtype=_print._sub._ipp._tcp", inst, "_ipp._tcp", str(self.registros.porta)]
            args += [f"{k}={v}" for k, v in {**txt, "rp": caminho}.items()]
            try:
                p = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except OSError:
                return False
            time.sleep(0.5)
            if p.poll() is not None:  # Avahi não está rodando
                self.parar()
                return False
            self.processos.append(p)
        return True

    def _anunciar(self):
        for espera in (0, 1, 2):
            time.sleep(espera)
            if not self.ativo:
                return
            try:
                self.sock.sendto(anuncio(self.registros), (GRUPO, PORTA))
            except OSError:
                pass

    def _ouvir(self):
        while self.ativo:
            try:
                dados, (ip, porta) = self.sock.recvfrom(9000)
                if not self.ativo:
                    break
                r = responder(dados, self.registros, porta)
                if r:
                    self.sock.sendto(r, (ip, porta) if porta != PORTA else (GRUPO, PORTA))
            except Exception:
                if not self.ativo:
                    break
                time.sleep(0.2)

    def parar(self):
        if self.sock:
            self.ativo = False
            try:
                self.sock.sendto(anuncio(self.registros, adeus=True), (GRUPO, PORTA))
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None
        for p in self.processos:
            try:
                p.terminate()
            except OSError:
                pass
        self.processos = []
